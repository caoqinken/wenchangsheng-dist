/* 核心：存档 · 修行数值 · 时间推进 */
(function () {
  const KEY = "wcs.v3";
  const REALMS = ["炼气", "筑基", "金丹", "元婴", "化神", "炼虚", "合体", "大乘"];
  const LAYERS = ["一层", "二层", "三层", "四层", "五层", "六层", "七层", "八层", "九层"];

  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(KEY) || "{}"); } catch (e) { saved = {}; }

  const S = Object.assign({
    name: "江晚照", realm: 0, layer: 1,
    qi: 0, qiMax: 100,
    stone: 30, herb: 0, mat: 0, pill: 0,
    stamina: 30, staminaMax: 30,
    last: Date.now()
  }, saved);

  const G = {
    S, REALMS, LAYERS,
    realmName() { return REALMS[S.realm] + " " + LAYERS[S.layer - 1]; },
    qiRate() { return 1 + S.layer * 0.12; },
    fmt(n) { n = Math.floor(n); return n >= 10000 ? (n / 10000).toFixed(1) + "万" : String(n); },
    save() { S.last = Date.now(); try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} },
    addQi(n) { S.qi += n; },
    canBreak() { return S.qi >= S.qiMax; },
    doBreak() {
      if (!G.canBreak()) return false;
      S.qi -= S.qiMax;
      S.qiMax = Math.round(S.qiMax * 1.32);
      if (S.layer >= 9) { S.layer = 1; S.realm = Math.min(REALMS.length - 1, S.realm + 1); }
      else S.layer++;
      G.save();
      return true;
    },
    tick(dt) { S.qi = Math.min(S.qiMax * 1.5, S.qi + G.qiRate() * dt); }
  };
  window.G = G;
})();
