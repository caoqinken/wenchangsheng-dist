/* 启动装配：事件 · 主循环 */
(function () {
  const G = window.G, UI = window.UI, S = G.S;

  function act(name) {
    if (name === "tuna") {
      S.qi += 20; G.save(); UI.renderHud(); UI.toast("吐纳一次\n灵气 +20");
    } else if (name === "break") {
      if (G.doBreak()) { UI.renderAll(); UI.toast("破境成功\n" + G.realmName()); }
      else UI.toast("灵气未满\n修为 " + G.fmt(S.qi) + " / " + G.fmt(S.qiMax));
    } else if (name === "info") {
      UI.toast("加成明细\n修炼速率 " + G.qiRate().toFixed(1) + "/秒｜道途与功法加成另行结算");
    } else {
      UI.toast("此地尚在开辟\n后续版本开放");
    }
  }

  document.addEventListener("click", (e) => {
    const el = e.target.closest("[data-tab],[data-panel],[data-act],[data-close]");
    if (!el) return;
    if (el.dataset.tab) UI.switchTab(el.dataset.tab);
    else if (el.dataset.panel) UI.openPanel(el.dataset.panel);
    else if (el.dataset.act) act(el.dataset.act);
    else if (el.dataset.close) { UI.closePanel(); UI.closeDialog(); }
  });

  UI.renderAll();

  let last = Date.now();
  setInterval(() => {
    const now = Date.now(), dt = Math.min(60, (now - last) / 1000);
    last = now;
    G.tick(dt);
    UI.renderHud();
  }, 1000);

  setInterval(() => UI.renderFeed(), 3000);
  setInterval(() => G.save(), 5000);
  document.addEventListener("visibilitychange", () => { if (document.hidden) G.save(); });
})();
