/* 图层渲染：场景 · 热点 · 立绘 · HUD · 印章 · 纸卷 · 弹窗 */
(function () {
  const G = window.G, S = G.S;
  const $ = (id) => document.getElementById(id);

  const TABS = [
    { k: "home",   t: "修炼", scene: "art/世界_山河长卷.webp", hero: "art/修士立绘.webp",
      hots: [{ x: 50, y: 42, ico: "☯", tag: "打坐" }, { x: 78, y: 30, ico: "📖", tag: "功法" }] },
    { k: "battle", t: "历练", scene: "art/天下山川.webp",
      hots: [{ x: 30, y: 34, ico: "🏔", tag: "青云" }, { x: 66, y: 52, ico: "🌋", tag: "魔渊" }, { x: 46, y: 72, ico: "🏯", tag: "试炼塔" }] },
    { k: "cave",   t: "洞府", scene: "art/势力_青云门.webp",
      hots: [{ x: 24, y: 46, ico: "🌿", tag: "灵田" }, { x: 50, y: 58, ico: "⚗", tag: "丹房" }, { x: 76, y: 40, ico: "🔥", tag: "炼器坊" }] },
    { k: "world",  t: "世界", scene: "art/世界_山河长卷.webp",
      hots: [{ x: 28, y: 62, ico: "🏮", tag: "坊市" }, { x: 58, y: 40, ico: "⚑", tag: "势力" }, { x: 76, y: 66, ico: "📜", tag: "日常" }] },
    { k: "char",   t: "人物", scene: "art/修士立绘.webp", hero: "art/修士立绘.webp", hots: [] },
    { k: "codex",  t: "道途", scene: "art/事迹_妖兽潮.webp",
      hots: [{ x: 30, y: 40, ico: "🏺", tag: "古宝" }, { x: 62, y: 58, ico: "🐾", tag: "妖兽" }] }
  ];

  const PANELS = {
    home: [
      ["☯", "吐纳", "今日 100 次", "tuna"],
      ["⛰", "突破", "灵气足可破境", "break"],
      ["📊", "加成明细", "修炼 +0%", "info"]
    ],
    battle: [
      ["🏔", "青云秘境", "第 0/6 关"], ["🌋", "幽谷魔渊", "未解锁"], ["🗻", "昆仑之巅", "未解锁"],
      ["🌊", "九幽冥海", "未解锁"], ["🗺", "世界地图", "五域"], ["🏯", "试炼塔", "第 1 层"]
    ],
    cave: [
      ["🌿", "灵田", "Lv.3"], ["⚗", "炼丹房", "Lv.2"], ["🔥", "炼器坊", "未解锁"],
      ["🧘", "练功房", "Lv.1"], ["🏠", "弟子居所", "12/20"], ["📯", "招募堂", "今日 1 次"]
    ],
    world: [
      ["🏮", "坊市", "今日特价"], ["📜", "日常委托", "2 可领"], ["⚑", "势力", "3 方"],
      ["📯", "悬赏", "刷新中"], ["📖", "大事记", "第 55 年"], ["🔮", "天机阁", "机缘 1"]
    ],
    char: [
      ["☯", "功法", "长生诀 1 层"], ["🏺", "法宝", "无"], ["🐾", "灵兽", "0/6"],
      ["⚗", "丹药", "药力 0/0"], ["🧭", "道心", "未择"], ["💾", "存档", "自动"]
    ],
    codex: [
      ["🏺", "古宝", "0/15"], ["⚔", "法宝", "0/24"], ["🐾", "妖兽", "0/31"],
      ["🏔", "秘境", "1/6"], ["📜", "事迹", "3 条"], ["🎖", "成就", "2 项"]
    ]
  };

  let curTab = "home";

  const ui = {
    tab() { return curTab; },
    tabs() { return TABS; },

    renderAll() { ui.renderScene(); ui.renderHud(); ui.renderTabs(); ui.renderFeed(); },

    renderScene() {
      const t = TABS.find((x) => x.k === curTab);
      document.querySelector("#scene .scene-img").style.backgroundImage = `url("${t.scene}")`;
      $("hero").innerHTML = t.hero ? `<img src="${t.hero}" alt="">` : "";
      $("actors").innerHTML = (t.hots || []).map((h) => `
        <div class="hot" data-panel="${t.k}" style="left:${h.x}%;top:${h.y}%;transform:translate(-50%,-50%)">
          <div class="ring">${h.ico}</div><div class="tag">${h.tag}</div>
        </div>`).join("");
    },

    renderHud() {
      const pct = Math.min(100, S.qi / S.qiMax * 100);
      $("hud").innerHTML = `
        <div class="ava"><img src="art/修士立绘.webp" alt=""></div>
        <div class="who"><div class="n">${S.name}</div>
          <div class="b"><i style="width:${pct.toFixed(1)}%"></i></div></div>
        <div class="res">
          <div class="r"><i style="background:#7fb6d9"></i>${G.fmt(S.qi)}</div>
          <div class="r"><i style="background:#d9c37f"></i>${G.fmt(S.stone)}</div>
          <div class="r"><i style="background:#9fd97f"></i>${S.stamina}/${S.staminaMax}</div>
        </div>`;
    },

    renderTabs() {
      $("tabs").innerHTML = TABS.map((t) => `
        <div class="seal ${t.k === curTab ? "on" : ""}" data-tab="${t.k}">${t.t}</div>`).join("");
    },

    renderFeed() {
      $("feed").innerHTML = `
        <div><span class="k">[修炼]</span> 灵气 +${G.qiRate().toFixed(1)}/秒</div>
        <div><span class="k">[境界]</span> ${G.realmName()} · 修为 ${G.fmt(S.qi)}/${G.fmt(S.qiMax)}</div>`;
    },

    switchTab(k) { curTab = k; ui.renderAll(); ui.closePanel(); },

    openPanel(k) {
      const t = TABS.find((x) => x.k === k) || TABS[0];
      const rows = PANELS[k] || [];
      $("panel").className = "on";
      $("panel").innerHTML = `
        <div class="veil" data-close="1"></div>
        <div class="scroll">
          <div class="sc-head"><b>${t.t}</b><span class="mark">长</span></div>
          <div class="sc-body"><div class="g3">
            ${rows.map((r) => `<div class="item" data-act="${r[3] || "wip"}">
              <span class="ci">${r[0]}</span><span class="cn">${r[1]}</span><span class="cv">${r[2]}</span></div>`).join("")}
          </div></div>
          <div class="sc-foot"><div class="seal-btn" data-close="1">返回</div></div>
        </div>`;
    },

    closePanel() { $("panel").className = ""; $("panel").innerHTML = ""; },

    toast(msg) {
      const d = $("dialog");
      d.className = "on";
      d.innerHTML = `<div class="dlg"><h3>${msg.split("\n")[0]}</h3>
        <p>${msg.split("\n").slice(1).join("<br>")}</p>
        <div class="row"><button class="pri" data-close="1">知道了</button></div></div>`;
    },

    closeDialog() { $("dialog").className = ""; $("dialog").innerHTML = ""; }
  };

  window.UI = ui;
})();
