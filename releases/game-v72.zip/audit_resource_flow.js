// 《问长生》P1 资源净流量诊断（基于当前 dispatchRate/buildingOutput 实际函数）
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = __dirname;
const store = {};
global.localStorage = { getItem:k=>store[k]||null, setItem:(k,v)=>store[k]=String(v), removeItem:k=>delete store[k] };
global.window = { addEventListener:()=>{} };
global.document = { hidden:false };
global.confirm = ()=>true;
function load(f){ vm.runInThisContext(fs.readFileSync(path.join(root,f),'utf8'),{filename:f}); }
load('js/config.js');
load('js/state.js');
load('js/inventory.js');
load('js/dispatch.js');
load('js/build.js');
// 使用中性基线，隔离秘境章节/弟子境界影响；不叠加官职、宗门、庇护与建筑等级。
global.stableMult = () => 1;
global.officeBonus = () => 0;
global.dynastyFolkMult = () => 1;
global.fieldTempleLv = () => 0;
global.fieldMineLv = () => 0;
global.fieldGardenLv = () => 0;
S = defaultState();
const HOUR = 3600;
const rows = [];
for (let realm=0; realm<=10; realm++) {
  const ch = Math.min(realm, CONFIG.CHAPTERS.length - 1);
  for (const teamSize of [1,3]) {
    S.realm = realm;
    S.disciples = Array.from({length:teamSize}, (_,i)=>({id:i+1, realm, layer:0, loyalty:80, specialty:'farm', bond:90}));
    S.mapTeam = {[ch]: S.disciples.map(d=>d.id)};
    S.clearedMaps = {[ch]:true};
    S.fieldVein = {}; S.fieldMine = {}; S.fieldGarden = {}; S.lostFields = {};
    const r = dispatchRate(ch);
    rows.push({realm, chapter:ch+1, teamSize, stone:r.stone*HOUR, qi:r.qi*HOUR, herb:r.herb*HOUR, material:r.material*HOUR, folk:r.folk*HOUR});
  }
}
// 直接使用 build.js 的 buildingOutput 计算建筑产能，不计特殊加成。
S.disciples=[]; S.buildings={farm:1,alchemy:1,forge:0,practice:0,recruit:0};
const farm1 = buildingOutput('farm');
const alch1 = buildingOutput('alchemy');
const farm4 = (S.buildings.farm=4, buildingOutput('farm'));
const alchConsume1 = 2 * S.buildings.alchemy;
const report = [];
report.push('# v0.54.3 全境界资源净流量诊断');
report.push('');
report.push('> 口径：调用当前源码 `dispatchRate()`、`buildingOutput()`；每小时按 3600 秒换算。中性基线不叠加宗门、王朝、官职、庇护、灵脉/矿场/药圃等级、安定度惩罚。每名弟子设为对应境界、忠诚80、灵植专精、情谊90；每处秘境最多3名，分别测1人/3人。章节映射为 min(境界索引, 第7章)。这是净流量诊断样本，不是全服玩家行为预测。');
report.push('');
report.push('| 玩家境界 | 驻守章节 | 弟子数 | 灵石/小时 | 灵气/小时 | 灵草/小时 | 灵材/小时 | 凡人/小时 |');
report.push('|---|---:|---:|---:|---:|---:|---:|---:|');
for (const r of rows) report.push(`| ${CONFIG.REALMS[r.realm]} | ${r.chapter} | ${r.teamSize} | ${r.stone.toFixed(1)} | ${r.qi.toFixed(1)} | ${r.herb.toFixed(1)} | ${r.material.toFixed(1)} | ${r.folk.toFixed(2)} |`);
report.push('');
report.push('## 洞府灵田—炼丹房原料平衡');
report.push('');
report.push(`- 灵田 Lv.1：${farm1.toFixed(2)} 灵草/秒（${(farm1*HOUR).toFixed(0)}/小时）。`);
report.push(`- 炼丹房 Lv.1：消耗 ${alchConsume1.toFixed(2)} 灵草/秒，产出 ${alch1.toFixed(2)} 培元丹/秒（满料时）。`);
report.push(`- 灵田 Lv.4：${farm4.toFixed(2)} 灵草/秒；理论上恰好覆盖炼丹房 Lv.1 的基础消耗，尚未计入弟子/势力增益。`);
report.push('- 结论：炼丹房每级消耗2灵草/秒，灵田每级只产0.5灵草/秒；若两者同级，灵草净缺口为1.5×建筑等级/秒。要做到完全自给，灵田等级约需达到炼丹房等级的4倍。');
report.push('');
report.push('## 关键发现与风险');
report.push('');
report.push('1. **秘境驻守的基础灵草产出远低于洞府灵田**：每名弟子基础派遣系数很低，驻守更偏灵石/灵气/灵材/人口来源，不应被误认为主要炼丹原料来源。');
report.push('2. **炼丹房是高强度灵草消耗口**：当前 1:4 的建筑产能比意味着玩家若同时升级灵田与炼丹房，必须有意识地保持灵田等级领先；UI 目前没有显示这个自给率提示。');
report.push('3. **凡人增长较慢且受灵脉/安定度/官职等因素影响**：不要用旧注释中的“每分钟约1.2人”作为实际净增长结论，应以实际 `dispatchRate()` 与 `addFolk()` 容量钳制后的入账量为准。');
report.push('4. **本报告不修改资源倍率或成本**：下一步应把丹方手动炼制、秘境建设、弟子招募、法宝炼制/升阶等消耗纳入分阶段生命周期模拟，再决定是否调整经济。');
report.push('');
report.push('## 复现');
report.push('');
report.push('```bash');
report.push('node audit_resource_flow.js');
report.push('```');
const out = path.join(root,'..','docs','v0.54.3_P1_全境界资源净流量诊断.md');
fs.writeFileSync(out, report.join('\n')+'\n');
console.log(report.join('\n'));
