// v0.56.9 私有秘境经营经济 Monte Carlo：模拟设施岗位、修士个人钱包、租金与居民消费。
// 固定种子、10,000 个秘境年度样本；岗位工资仅向已建成设施提供的在岗居民发放，从既有共享发行额度划拨，不新增货币发行。
const WORLDS = 10000, DAYS = 365;
let seed = 0x56c80001;
function rand(){ seed = (Math.imul(seed,1664525)+1013904223)>>>0; return seed/4294967296; }
const totals = {issued:0,spent:0,residentAllocation:0,walletIncome:0,rentDue:0,rentPaid:0,residentPurchaseSpend:0,merchantPaid:0,shortRentDays:0,emptyBudgetDays:0,departedWalletBalance:0,closingWalletBalance:0,maxIssued:0};
let violations=0, samples=[];
for(let w=0;w<WORLDS;w++){
  const caveLv = 1 + Math.floor(rand()*5), cap = 3+(caveLv-1)*2;
  const shops = 1 + Math.floor(rand()*4);
  const jobSlots = caveLv + (shops-1)*2; // 洞府维护岗位1/级；每座经营设施提供2个岗位。
  let residents = Math.floor(rand()*(cap+1));
  let wallets = Array.from({length:residents},()=>0);
  let world={issued:0,spent:0,residentAllocation:0,walletIncome:0,rentDue:0,rentPaid:0,residentPurchaseSpend:0,merchantPaid:0,shortRentDays:0,departedWalletBalance:0,closingWalletBalance:0};
  for(let d=0;d<DAYS;d++){
    const issued=Math.min(700,100+residents*35+shops*25);
    const employed=Math.min(residents,jobSlots);
    const allocation=Math.min(issued,employed*35);
    let remaining=issued-allocation, spent=allocation;
    // 仅在岗居民获得工资；待业居民依靠既有余额生活，不会被系统补发消费金。
    for(let i=0;i<employed;i++) wallets[i]+=35;
    const due=residents*2;
    let rent=0;
    for(let i=0;i<residents;i++){const paid=Math.min(2,wallets[i]);wallets[i]-=paid;rent+=paid;}
    // 居民每日最多购买一枚丹药，单价按市场价示例值12灵石；这是钱包内部转账。
    let residentPurchaseSpend=0;
    for(let i=0;i<residents;i++) if(rand()<0.12 && wallets[i]>=12){wallets[i]-=12;residentPurchaseSpend+=12;}
    // 商铺采购只能花划拨修士钱包后的公共剩余额度。
    const earlyDemand=Math.floor(rand()*Math.max(1,remaining)*1.35);
    const earlyMerchant=Math.min(earlyDemand,remaining);
    remaining-=earlyMerchant; spent+=earlyMerchant;
    const demand=Math.floor(rand()*260);
    const merchant=Math.min(demand,remaining);
    remaining-=merchant; spent+=merchant;
    world.issued+=issued; world.spent+=spent; world.residentAllocation+=allocation; world.walletIncome+=allocation;
    world.rentDue+=due; world.rentPaid+=rent; world.residentPurchaseSpend+=residentPurchaseSpend; world.merchantPaid+=merchant+earlyMerchant;
    if(rent<due) world.shortRentDays++;
    if(remaining===0) totals.emptyBudgetDays++;
    if(remaining<0||spent>issued||Math.abs((issued-remaining)-spent)>1e-9||allocation+remaining+earlyMerchant+merchant!==issued) violations++;
    // 人口迁徙：离境者携走个人余额，不回流玩家或共享资金池。
    if(rand()<0.035 && residents<cap){residents++;wallets.push(0);}
    if(rand()<0.02 && residents>0){const idx=Math.floor(rand()*residents);world.departedWalletBalance+=wallets[idx];wallets.splice(idx,1);residents--;}
  }
  world.closingWalletBalance=wallets.reduce((a,b)=>a+b,0);
  if(world.walletIncome !== world.rentPaid + world.residentPurchaseSpend + world.departedWalletBalance + world.closingWalletBalance) violations++;
  for(const k of Object.keys(world)) totals[k]+=world[k];
  totals.maxIssued=Math.max(totals.maxIssued,Math.min(700,100+cap*35+4*25));
  if(w<8) samples.push({world:w+1,cap,shops,days:DAYS,...world});
}
const rentCoverage=totals.rentDue?totals.rentPaid/totals.rentDue:1;
const spendRatio=totals.issued?totals.spent/totals.issued:0;
console.log(JSON.stringify({version:'0.56.9',seed:'0x56c80001',worlds:WORLDS,daysPerWorld:DAYS,totalWorldDays:WORLDS*DAYS,violations,totals,rentCoverage,spendRatio,meanAnnualIssued:totals.issued/WORLDS,meanAnnualRentDue:totals.rentDue/WORLDS,meanAnnualRentPaid:totals.rentPaid/WORLDS,meanAnnualResidentPurchaseSpend:totals.residentPurchaseSpend/WORLDS,meanAnnualMerchantPaid:totals.merchantPaid/WORLDS,samples},null,2));
if(violations) process.exit(1);
