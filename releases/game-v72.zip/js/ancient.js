// ============================================================
// 《问长生》古宝体系（v0.30.0）
// 收集 → 升星（碎片）→ 注灵（灵材+灵石）→ 套装加成
// 属性汇总为唯一来源 ancientBonus()，供 playerCombat / cultivationBreakdown 读取
// ============================================================

function ancientDef(key) {
  return (CONFIG.ANCIENT_TREASURES || []).find(a => a.key === key) || null;
}
function ancientSetDef(key) {
  return (CONFIG.ANCIENT_SETS || []).find(s => s.key === key) || null;
}
function ancientOwned(key) {
  return !!(S.ancient && S.ancient[key]);
}
function ancientStar(key) {
  const a = S.ancient && S.ancient[key];
  return a ? (a.star || 1) : 0;
}
function ancientInfuse(key) {
  const a = S.ancient && S.ancient[key];
  return a ? (a.infuse || 0) : 0;
}
// v0.37.0：古宝碎片改为储物袋内真实物品（frag:<套装>），不再单独记数
function ancientFragCount(setKey) {
  return (typeof invCount === "function") ? Math.floor(invCount("frag:" + setKey)) : ((S.ancientFrag && S.ancientFrag[setKey]) || 0);
}
function addAncientFrag(setKey, n) {
  if (typeof invAdd === "function") { invAdd("frag:" + setKey, n); return; }
  if (!S.ancientFrag) S.ancientFrag = {};
  S.ancientFrag[setKey] = (S.ancientFrag[setKey] || 0) + n;
}

// 获得古宝（重复获得转为该套碎片）
function grantAncient(key) {
  const def = ancientDef(key);
  if (!def) return { ok: false, msg: "无此古宝" };
  if (!S.ancient) S.ancient = {};
  if (S.ancient[key]) {
    addAncientFrag(def.set, 3);
    return { ok: true, dup: true, frag: 3, item: def };
  }
  S.ancient[key] = { star: 1, infuse: 0 };
  save();
  return { ok: true, dup: false, item: def };
}

// 每套 5 件，按章节顺序解锁：首次探明第 ch 章 → 对应套第 (ch % 5) 件
function ancientByChapter(ch) {
  const list = CONFIG.ANCIENT_TREASURES.filter(a => {
    // 第 0~2 章 → 青云；3~4 → 魔渊；5~6 → 混元
    if (ch <= 2) return a.set === "qingyun";
    if (ch <= 4) return a.set === "moyuan";
    return a.set === "hunyuan";
  });
  const offset = ch <= 2 ? ch : ch <= 4 ? (ch - 3) : (ch - 5);
  return list[offset] || list[list.length - 1];
}

// 单件属性（星级每级 +20%，注灵每级 +1%）
function ancientItemBonus(key) {
  const def = ancientDef(key);
  if (!def || !ancientOwned(key)) return { atk: 0, def: 0, hp: 0, cult: 0 };
  const starMul = 1 + 0.2 * (ancientStar(key) - 1);
  const inf = ancientInfuse(key) * 0.01;
  return {
    atk: (def.atk || 0) * starMul + inf,
    def: (def.def || 0) * starMul + inf,
    hp: (def.hp || 0) * starMul + inf,
    cult: (def.cult || 0) * starMul + inf,
  };
}

// 汇总：所有古宝 + 套装（3 件 / 5 件）
function ancientBonus() {
  const sum = { atk: 0, def: 0, hp: 0, cult: 0 };
  if (!S.ancient) return sum;
  const setCount = {};
  for (const key in S.ancient) {
    const b = ancientItemBonus(key);
    sum.atk += b.atk; sum.def += b.def; sum.hp += b.hp; sum.cult += b.cult;
    const d = ancientDef(key);
    if (d) setCount[d.set] = (setCount[d.set] || 0) + 1;
  }
  for (const sk in setCount) {
    const set = ancientSetDef(sk);
    if (!set) continue;
    const add = b => { if (!b) return; sum.atk += b.atk || 0; sum.def += b.def || 0; sum.hp += b.hp || 0; sum.cult += b.cult || 0; };
    if (setCount[sk] >= 5) add(set.bonus5);
    if (setCount[sk] >= 3) add(set.bonus3);
  }
  return sum;
}

// ---------- 养成操作 ----------
function starUpAncient(key) {
  if (!ancientOwned(key)) return { ok: false, msg: "尚未获得此古宝" };
  const A = CONFIG.ANCIENT;
  const star = ancientStar(key);
  if (star >= A.MAX_STAR) return { ok: false, msg: "已至满星" };
  const def = ancientDef(key);
  const need = star * A.STAR_FRAG;
  if (ancientFragCount(def.set) < need) {
    return { ok: false, msg: `碎片不足（需 ${need}，持有 ${ancientFragCount(def.set)}）· 击败该套对应章节 BOSS 可得` };
  }
  invRemove("frag:" + def.set, need);
  S.ancient[key].star = star + 1;
  save();
  return { ok: true, star: star + 1 };
}

function infuseAncient(key) {
  if (!ancientOwned(key)) return { ok: false, msg: "尚未获得此古宝" };
  const A = CONFIG.ANCIENT;
  const lv = ancientInfuse(key);
  if (lv >= A.INFUSE_MAX) return { ok: false, msg: "注灵已满" };
  if ((S.materials || 0) < A.INFUSE_MAT) return { ok: false, msg: `灵材不足（需 ${A.INFUSE_MAT}）` };
  if (S.stone < A.INFUSE_STONE) return { ok: false, msg: `灵石不足（需 ${A.INFUSE_STONE}）` };
  invRemove("material", A.INFUSE_MAT);
  S.stone -= A.INFUSE_STONE;
  S.ancient[key].infuse = lv + 1;
  save();
  return { ok: true, infuse: lv + 1 };
}

// 碎片合成：消耗 10 碎片换该套下一件未拥有的古宝
function forgeAncient(setKey) {
  const A = CONFIG.ANCIENT;
  if (ancientFragCount(setKey) < A.FRAG_FOR_ITEM) {
    return { ok: false, msg: `碎片不足（需 ${A.FRAG_FOR_ITEM}）` };
  }
  const next = CONFIG.ANCIENT_TREASURES.find(a => a.set === setKey && !ancientOwned(a.key));
  if (!next) return { ok: false, msg: "此套已集齐" };
  invRemove("frag:" + setKey, A.FRAG_FOR_ITEM);
  if (!S.ancient) S.ancient = {};
  S.ancient[next.key] = { star: 1, infuse: 0 };
  save();
  return { ok: true, item: next };
}

// ---------- 界面（v0.49.0）----------
// 古宝不再单独占一个入口面板，归入「道途录 · 古宝图鉴」：
//   图鉴页只列套装简卡（结论层）→ 点某套进详情（升星 / 注灵）
//   碎片合成统一在「储物袋」对该套碎片操作，不在此处重复开合成按钮
function ancientBonusTxt(b) {
  return [
    b.atk ? "攻 +" + (b.atk * 100).toFixed(1) + "%" : "",
    b.def ? "防 +" + (b.def * 100).toFixed(1) + "%" : "",
    b.hp ? "血 +" + (b.hp * 100).toFixed(1) + "%" : "",
    b.cult ? "修炼 +" + (b.cult * 100).toFixed(1) + "%" : "",
  ].filter(Boolean).join(" ｜ ");
}

// 套装效果一句话（3 件 / 5 件）
function ancientSetBonusText(set) {
  const part = o => "件：" + Object.keys(o).map(k => k + " +" + Math.round(o[k] * 100) + "%").join(" ");
  const out = [];
  if (set.bonus3) out.push("3 " + part(set.bonus3));
  if (set.bonus5) out.push("5 " + part(set.bonus5));
  return out.join(" ｜ ");
}

// 套装简卡（图鉴页 / 古宝总览共用）
function ancientSetCodexHtml() {
  const A = CONFIG.ANCIENT;
  return `<div class="anc-codex">${CONFIG.ANCIENT_SETS.map(set => {
    const items = CONFIG.ANCIENT_TREASURES.filter(a => a.set === set.key);
    const owned = items.filter(a => ancientOwned(a.key)).length;
    const frag = ancientFragCount(set.key);
    const canForge = owned < items.length && frag >= A.FRAG_FOR_ITEM;
    return `<button class="anc-set-row" data-action="ancset" data-set="${set.key}">
      <span class="anc-set-row-main">
        <span class="anc-set-row-name">${esc(set.name)}${owned >= items.length ? " · 已集齐" : ""}</span>
        <span class="anc-set-row-sub">${owned}/${items.length} 件 ｜ 碎片 ${frag}${canForge ? " · 可合成" : ""} ｜ ${esc(ancientSetBonusText(set))}</span>
      </span>
      <span class="anc-set-row-go">详情 ›</span>
    </button>`;
  }).join("")}</div>`;
}

// 单套详情：升星 / 注灵（合成不在此处）
function showAncientSetDetail(setKey) {
  const A = CONFIG.ANCIENT;
  const set = ancientSetDef(setKey);
  if (!set) return;
  const items = CONFIG.ANCIENT_TREASURES.filter(a => a.set === setKey);
  const owned = items.filter(a => ancientOwned(a.key)).length;
  const rows = items.map(it => {
    const has = ancientOwned(it.key);
    if (!has) {
      return `<div class="anc-row locked"><span class="anc-name">${esc(it.name)}</span><span class="anc-tag">未获得</span></div>`;
    }
    const star = ancientStar(it.key), inf = ancientInfuse(it.key);
    return `<div class="anc-row">
      <div class="anc-main">
        <div class="anc-name">${esc(it.name)} <span class="anc-star">${"★".repeat(star)}${"☆".repeat(A.MAX_STAR - star)}</span></div>
        <div class="anc-desc">${esc(it.desc)} ｜ 注灵 Lv.${inf}/${A.INFUSE_MAX}</div>
        <div class="anc-bonus">${ancientBonusTxt(ancientItemBonus(it.key))}</div>
      </div>
    </div>`;
  }).join("");
  showModal(`
    <div class="result anc-modal">
      <div class="result-title">${esc(set.name)}</div>
      <div class="result-line">收集 <b>${owned}/${items.length}</b> ｜ 碎片 <b>${ancientFragCount(setKey)}</b></div>
      <div class="anc-note">${esc(ancientSetBonusText(set))}</div>
      <div class="anc-note">收集与套装效果在此查阅；<b>升星与注灵在炼器坊操作</b>（器物养成唯一入口），碎片合成在储物袋。首探秘境得古宝，击杀章 BOSS 得碎片。</div>
      ${rows || '<div class="build-out muted">此套暂无古宝</div>'}
      <div class="build-row"><button class="btn-sm" data-action="craft">去炼器坊升星 / 注灵</button></div>
      <button class="btn-primary" data-action="closemodal">收起</button>
    </div>`);
}

// 古宝总览弹窗（兼容旧入口 data-action="ancient"）
function showAncientPanel() {
  const b = ancientBonus();
  showModal(`
    <div class="result anc-modal">
      <div class="result-title">古宝图鉴</div>
      <div class="result-line">当前总加成：<b>${ancientBonusTxt(b) || "尚无古宝"}</b></div>
      <div class="anc-note">古宝特效：${esc(ancientEffectSummary())}</div>
      <div class="anc-note">按套查看 → 升星／注灵；碎片合成在储物袋里做。首探秘境得古宝，击杀章 BOSS 得碎片。</div>
      ${ancientSetCodexHtml()}
      <button class="btn-primary" data-action="closemodal">收起</button>
    </div>`);
}

// ---------- 古宝特效（v0.35.0）----------
// 每件古宝在 effect 中带一个特效；按星级（每星 +20%）与注灵（每级 +0.5%）放大
function ancientEffectSum(kind) {
  let v = 0;
  if (!S.ancient) return 0;
  for (const key in S.ancient) {
    const def = ancientDef(key);
    if (!def || !def.effect || def.effect.kind !== kind) continue;
    const starMul = 1 + 0.2 * (ancientStar(key) - 1);
    v += def.effect.v * starMul + ancientInfuse(key) * 0.005;
  }
  return v;
}

// 特效摘要（UI）
function ancientEffectSummary() {
  const kinds = [
    ["atk", "伤害"], ["reduce", "减伤"], ["cd", "冷却缩减"], ["crit", "暴击"],
    ["thorns", "反伤"], ["lifesteal", "吸血"], ["trib", "渡劫"], ["skill", "技能倍率"],
  ];
  return kinds.map(([k, n]) => {
    const v = ancientEffectSum(k);
    return v > 0 ? n + " +" + (v * 100).toFixed(1) + "%" : "";
  }).filter(Boolean).join(" ｜ ") || "暂无特效";
}
