// ============================================================
// 《问长生》放置挂机系统：修炼 + 突破/渡劫 + 离线收益
// v0.5.0：境内升层 100% 成功；跨大境界触发渡劫判定（风险+加成+保底）
// ============================================================

// 每秒修炼积累
function idleTick(dt) {
  const rate = cultivationRate();
  S.qi += rate * dt;
  // 悟道与吐纳同源但独立记账，避免功法成长挤占境界突破所需灵气。
  S.wudao = Math.max(0, Number(S.wudao) || 0) + rate * CONFIG.GONGFA_WUDAO_RATE * dt;
}

// 突破所需灵气
function breakCostNow() { return CONFIG.breakCost(kNow()); }

// 是否已达最高（v0.13.0：境界扩至 11 境，金仙 9 层满 = 飞升）
function isMaxRealm() {
  return kNow() >= CONFIG.REALMS.length * CONFIG.LAYERS_PER_REALM - 1;
}

// 渡劫成功率（含全部加成：基础-境衰减+渡劫丹+庇护+声望+功法）
function tribulationRate() {
  let rate = CONFIG.TRIB_BASE_RATE - S.realm * CONFIG.TRIB_REALM_DECAY;
  rate += S.tribPillBuff * CONFIG.TRIB_PILL_BONUS;                // 渡劫丹
  rate += (S.breakPillBuff || 0) * CONFIG.PILLS.BREAK_PILL;       // 破境丹（v0.38.0）
  if (blessed("qingyun")) rate += CONFIG.TRIB_BLESS_BONUS;        // 势力庇护
  rate += Math.min(Math.floor(S.reputation / 100) * CONFIG.TRIB_REP_BONUS, CONFIG.TRIB_REP_CAP);  // 声望
  rate += gongfaBonus().trib;                                      // 功法（v0.19.0 分层体系）
  if (typeof ancientEffectSum === "function") rate += ancientEffectSum("trib");   // 古宝（v0.35.0）
  if (typeof meridianSum === "function") rate += meridianSum().trib;              // 大周天 + 丹田（v0.50.0）
  return Math.max(CONFIG.TRIB_MIN_RATE, Math.min(CONFIG.TRIB_MAX_RATE, rate));
}

// 服用渡劫丹：下次渡劫成功率 +15%/枚（可叠加，渡劫后消耗）
function useTribPill() {
  if (S.tribPills < 1) return { ok: false, msg: "没有渡劫丹，可去坊市购买" };
  invRemove("tribPill", 1);
  S.tribPillBuff++;
  save();
  return { ok: true, buff: S.tribPillBuff };
}

// 突破：境内升层 100% 成功；跨大境界（第9层→下一境）触发渡劫判定
function doBreak() {
  if (isMaxRealm()) return { ok: false, msg: "已至渡劫巅峰，可飞升" };
  // 元神受损（v0.29.0）：渡劫失败后 30 分钟内不可再渡劫
  if (Date.now() < (S.soulHurtUntil || 0)) {
    const left = Math.ceil(((S.soulHurtUntil || 0) - Date.now()) / 60000);
    return { ok: false, msg: `元神受损，${left} 分钟后可再渡劫` };
  }
  const cost = CONFIG.breakCost(kNow());
  if (S.qi < cost) return { ok: false, msg: "灵气不足" };
  const isRealmBreak = S.layer === CONFIG.LAYERS_PER_REALM - 1;
  S.qi -= cost;
  if (!isRealmBreak) {
    // 境内升层：无风险
    S.layer++;
    if (typeof dailyProgress === "function") dailyProgress("break1", 1);
    save();
    return { ok: true, realm: S.realm, layer: S.layer };
  }
  // ---- 渡劫判定 ----
  const rate = tribulationRate();
  const pity = S.tribFails >= CONFIG.TRIB_PITY - 1;   // 心境圆融：连败保底必成
  if (pity || Math.random() < rate) {
    S.layer = 0;
    S.realm++;
    S.tribFails = 0;
    S.tribPillBuff = 0;                               // 渡劫丹buff消耗
    S.breakPillBuff = 0;                              // 破境丹同消耗
    S.reputation += CONFIG.TRIB_SUCCESS_REP;
    if (typeof dailyProgress === "function") dailyProgress("break1", 1);
    save();
    return { ok: true, trib: true, success: true, rate, pity, realm: S.realm };
  }
  // 失败：损失剩余灵气，保底计数+1，并元神受损 30 分钟（v0.29.0）
  S.qi *= (1 - CONFIG.TRIB_FAIL_QI_LOSS);
  S.tribFails++;
  S.soulHurtUntil = Date.now() + CONFIG.SOUL_HURT_MS;
  if (typeof dailyProgress === "function") dailyProgress("break1", 1);
  save();
  return { ok: true, trib: true, success: false, rate, fails: S.tribFails };
}

// 飞升（终局）
function doAscend() {
  if (!isMaxRealm()) return { ok: false, msg: "尚未到飞升境界" };
  S.ascended = true;
  save();
  return { ok: true };
}

// 离线收益结算（登录/回到前台时调用）
function computeOffline() {
  const now = Date.now();
  // 钳制下界：系统时间回拨会让 elapsed 变负，曾经把体力写成大负数并锁死玩法
  const rawElapsed = Math.max(0, (now - S.lastOnline) / 1000);
  // 引魔香只作用于下一次真实离线结算；短暂切后台不消耗，也不吃掉加成。
  if (rawElapsed <= 10) {
    S.lastOnline = now;
    return { elapsed: 0, gain: 0, incense: false };
  }
  const incense = !!S.huntingIncense;
  const cap = incense ? CONFIG.OFFLINE_INCENSE_CAP_SEC : CONFIG.OFFLINE_CAP_SEC;
  const elapsed = Math.min(rawElapsed, cap);
  // 恢复体力（放在早退之后，避免短间隔也走一遍）
  S.stamina = Math.max(0, Math.min(S.stamina + Math.floor(elapsed / CONFIG.STAMINA_RECOVER_SEC), CONFIG.MAX_STAMINA));
  const _gfOff = (typeof gongfaBonus === "function") ? (gongfaBonus().offline || 0) : 0;
  const rate = CONFIG.OFFLINE_RATE * (1 + _gfOff);
  const gain = cultivationRate() * elapsed * rate;
  S.qi += gain;
  const wudaoGain = cultivationRate() * elapsed * rate * CONFIG.GONGFA_WUDAO_RATE;
  S.wudao = Math.max(0, Number(S.wudao) || 0) + wudaoGain;
  // v0.52.0：悟道与灵气同源，离线按相同效率结算，避免功法成长只在线才产出。
  // v0.47.0：离线一并结算洞府经营与秘境驻守（按离线效率折算），闭关归来有真实产能
  const herbsBeforeOffline = Math.max(0, Number(S.herbs) || 0);
  const detail = {
    qi: gain, wudao: wudaoGain, herb: 0, herbConsumed: 0, herbNet: 0, pill: 0,
    material: 0, stone: 0, dispatchQi: 0, dispatchHerb: 0,
    nodeHerb: 0, nodeMaterial: 0, dispatchFolk: 0, incense, capSec: cap,
  };
  if (typeof buildingOutput === "function") {
    const bless = (typeof blessed === "function" && blessed("sanxiu")) ? 1.1 : 1;
    // 离线灵田先产草，再由炼丹房按在线同一配方消耗；不能凭空离线炼丹。
    const farmHerb = buildingOutput("farm") * elapsed * rate * bless;
    if (farmHerb > 0) { gainItem("herb", farmHerb); detail.herb = farmHerb; }
    const alch = S.buildings.alchemy || 0;
    if (alch > 0) {
      const consumePerSec = 2 * alch;
      const herbLimit = consumePerSec * elapsed * rate;
      const herbsUsed = Math.min(Math.max(0, Number(S.herbs) || 0), herbLimit);
      if (herbsUsed > 0) {
        invRemove("herb", herbsUsed);
        detail.herbConsumed = herbsUsed;
        const pill = (herbsUsed / consumePerSec) * buildingOutput("alchemy") * bless;
        if (pill > 0) { gainItem("pill", pill); detail.pill = pill; }
      }
    }
    if (typeof dispatchRate === "function" && S.clearedMaps) {
      let stone = 0, mat = 0, dispatchQi = 0, dispatchHerb = 0, dispatchFolk = 0;
      const huntMult = incense ? CONFIG.OFFLINE_INCENSE_DISPATCH_MULT : 1;
      for (const ch in S.clearedMaps) {
        if (!S.clearedMaps[ch]) continue;
        const chNum = parseInt(ch, 10);
        if (typeof fieldEducationTickOne === "function") fieldEducationTickOne(chNum, elapsed, rate * 0.5 * huntMult);
        const r = dispatchRate(chNum);
        if (!r || !(r.total > 0)) continue;
        const dispatchFactor = elapsed * rate * 0.5 * huntMult;
        const grossStone = (r.stone || 0) * dispatchFactor;
        const societyLevy = typeof fieldSocietyCollectLevy === "function" ? fieldSocietyCollectLevy(chNum, grossStone) : 0;
        const oneStone = grossStone - societyLevy;
        const oneMat = (r.material || 0) * dispatchFactor;
        const oneQi = (r.qi || 0) * dispatchFactor;
        const oneHerb = (r.herb || 0) * dispatchFactor;
        stone += oneStone; mat += oneMat; dispatchQi += oneQi; dispatchHerb += oneHerb;
        const added = typeof addFolk === "function" ? addFolk((r.folk || 0) * dispatchFactor, chNum) : 0;
        dispatchFolk += added;
        // 离线资源结算由本函数统一入账，同时写入驻守结算单；避免主循环再次调用 dispatchOffline 重复发奖。
        if (typeof dispatchSettleAcc === "function") {
          const scale = rate * 0.5 * huntMult;
          dispatchSettleAcc(chNum, elapsed, {
            stone: elapsed > 0 ? oneStone / elapsed : 0,
            qi: (r.qi || 0) * scale,
            herb: (r.herb || 0) * scale,
            material: (r.material || 0) * scale,
            folk: elapsed > 0 ? added / elapsed : 0,
          });
        }
      }
      // 资源点离线刷新此前由 dispatchOffline 处理；迁入唯一离线入口，避免与常规驻守收益重复。
      const nodeCycles = Math.min(CONFIG.DISPATCH.NODE_OFFLINE_CAP, Math.floor(elapsed / CONFIG.DISPATCH.NODE_INTERVAL));
      if (nodeCycles > 0 && S.mapTeam) {
        for (const ch in S.mapTeam) {
          if (!S.clearedMaps[ch] || !dispatchRate(parseInt(ch, 10)).total) continue;
          const vein = typeof fieldVeinLv === "function" ? fieldVeinLv(parseInt(ch, 10)) : 0;
          const nodeHerb = (3 + vein * 2) * nodeCycles;
          const nodeMat = (1 + vein) * nodeCycles;
          gainItem("herb", nodeHerb); gainItem("material", nodeMat);
          detail.nodeHerb += nodeHerb;
          detail.nodeMaterial += nodeMat;
          if (typeof dispatchSettleAcc === "function") dispatchSettleAcc(parseInt(ch, 10), 0, { stone: 0, qi: 0, herb: nodeHerb, material: nodeMat, folk: 0 });
        }
      }
      if (stone > 0) { S.stone += stone; detail.stone = stone; }
      if (mat > 0) { gainItem("material", mat); detail.material += mat; }
      if (dispatchQi > 0) { S.qi += dispatchQi; detail.dispatchQi = dispatchQi; }
      if (dispatchHerb > 0) { gainItem("herb", dispatchHerb); detail.dispatchHerb += dispatchHerb; }
      if (dispatchFolk > 0) detail.dispatchFolk = dispatchFolk;
    }
  }
  // 以背包最终镜像计算灵草净变化，避免「产草后全被炼丹消耗」仍显示灵草增加。
  detail.herbNet = (Number(S.herbs) || 0) - herbsBeforeOffline;
  S.lastOnline = now;
  if (incense) S.huntingIncense = 0; // 一次有效离线结算后燃尽
  if (typeof dailyProgress === "function") dailyProgress("offline", 1);
  // 结算资源、更新时间戳与燃尽状态一起落盘，避免刷新后重复领取引魔香效果。
  if (typeof save === "function") save();
  return { elapsed, gain, detail };
}


// 引魔香：为下一次有效离线结算预先点燃，不叠加、不重复消耗。
function useHuntingIncense() {
  if (S.huntingIncense) return { ok: false, msg: "引魔香已燃起，待下一次离线结算后再用" };
  if (typeof invCount === "function" && invCount("incense") < 1) return { ok: false, msg: "袋中没有引魔香" };
  invRemove("incense", 1);
  S.huntingIncense = 1;
  save();
  return { ok: true };
}

// ---------- 丹药效果（v0.38.0 丹方物品化）----------
// 聚气丹：立即补 5% 突破所需灵气
function useQiPill() {
  if (invCount("qiPill") < 1) return { ok: false, msg: "没有聚气丹" };
  invRemove("qiPill", 1);
  const gain = Math.max(1, Math.floor(CONFIG.breakCost(kNow()) * CONFIG.PILLS.QI_PILL));
  S.qi += gain;
  save();
  return { ok: true, qi: gain };
}

// 破境丹：下次渡劫 +10%（可叠）
function useBreakPill() {
  if (invCount("breakPill") < 1) return { ok: false, msg: "没有破境丹" };
  invRemove("breakPill", 1);
  S.breakPillBuff = (S.breakPillBuff || 0) + 1;
  save();
  return { ok: true, buff: S.breakPillBuff, plus: CONFIG.PILLS.BREAK_PILL };
}

// 回春丹：下次入秘境自带气血护盾
function useHealPill() {
  if (invCount("healPill") < 1) return { ok: false, msg: "没有回春丹" };
  if ((S.healShield || 0) > 0) return { ok: false, msg: "药力未散，护盾已在身（进秘境后再生效）" };
  invRemove("healPill", 1);
  S.healShield = CONFIG.PILLS.HEAL_SHIELD;
  save();
  return { ok: true, shield: CONFIG.PILLS.HEAL_SHIELD };
}

// 洗髓丹：法宝洗练免灵石 1 次
function useMarrowPill() {
  if (invCount("marrowPill") < 1) return { ok: false, msg: "没有洗髓丹" };
  invRemove("marrowPill", 1);
  S.rerollFree = (S.rerollFree || 0) + 1;
  save();
  return { ok: true, free: S.rerollFree };
}

// 悟道丹：功法升层悟道消耗 -30%（1 次）
function useDaoPill() {
  if (invCount("daoPill") < 1) return { ok: false, msg: "没有悟道丹" };
  invRemove("daoPill", 1);
  S.gongfaCut = (S.gongfaCut || 0) + 1;
  save();
  return { ok: true, cut: S.gongfaCut };
}
