// ============================================================
// 《问长生》新手引路（v0.47.0）
// 七步引路把已有系统串成一条「先做什么」的线，每步有实物奖励
// 判定全部基于真实系统状态（不新造进度字段），完成后自动发奖并推进
// ============================================================

function guideState() {
  if (!S.guide || typeof S.guide !== "object") S.guide = { step: 0, done: [] };
  if (!Array.isArray(S.guide.done)) S.guide.done = [];
  if (!S.guideFlags || typeof S.guideFlags !== "object") S.guideFlags = {};
  return S.guide;
}

function guideList() { return CONFIG.GUIDE || []; }

// 单步是否已完成（纯状态判定）
function guideStepDone(key) {
  const g = guideState();
  const f = S.guideFlags;
  switch (key) {
    case "g1": return (S.tunaCount || 0) > 0;
    case "g2": return (S.buildings && (S.buildings.farm || 0) > 0);
    case "g3": return (S.bestStage || 0) > 0;
    case "g4": {
      let n = 0;
      const b = S.gongfaBooks || {};
      for (const k in b) if (b[k] && b[k].learned) n++;
      return n >= 2;
    }
    case "g5": return !!f.danClaimed;
    case "g6": return (S.artifacts || []).length > 0;
    case "g7": return (S.friends || []).some(x => (x.events || []).length > 0);
    default: return false;
  }
}

function guideCurrent() {
  const g = guideState();
  const list = guideList();
  for (let i = 0; i < list.length; i++) {
    if (g.done.indexOf(list[i].key) < 0) return { step: i + 1, total: list.length, def: list[i] };
  }
  return null;
}

// 结算：从当前步起，连续完成的都发奖（一次可跳多步）
function guideTick() {
  const g = guideState();
  const list = guideList();
  const got = [];
  let guard = 0;
  while (guard++ < 10) {
    const cur = guideCurrent();
    if (!cur) break;
    if (!guideStepDone(cur.def.key)) break;
    g.done.push(cur.def.key);
    g.step = g.done.length;
    const r = cur.def.reward || {};
    const gained = [];
    if (r.stone) { S.stone += r.stone; gained.push("灵石 +" + r.stone); }
    if (r.qiPct) {
      const q = Math.max(1, Math.floor(CONFIG.breakCost(kNow()) * r.qiPct));
      S.qi += q; gained.push("灵气 +" + fmt(q));
    }
    if (r.pill) { gainItem("pill", r.pill); gained.push("培元丹 +" + r.pill); }
    if (r.talisman) { gainItem("talisman", r.talisman); gained.push("功法残卷 +" + r.talisman); }
    if (r.material) { gainItem("material", r.material); gained.push("灵材 +" + r.material); }
    if (r.fate) { S.fate = (S.fate || 0) + r.fate; gained.push("机缘 +" + r.fate); }
    got.push({ name: cur.def.name, gained });
  }
  if (got.length) {
    save();
    for (const one of got) {
      if (typeof toast === "function") toast(`引路达成：${one.name}（${one.gained.join("、")}）`);
    }
  }
  return got;
}

// 引路进度卡（修炼页顶部）
function guideCardHtml() {
  const cur = guideCurrent();
  const g = guideState();
  const total = guideList().length;
  if (!cur) {
    return `<div class="card guide-card done">
      <div class="build-head"><span>引路</span><span>${g.done.length}/${total} 已尽</span></div>
      <div class="build-desc">七步引路已走完，往后看你自己怎么修。</div>
    </div>`;
  }
  const d = cur.def;
  return `<div class="card guide-card">
    <div class="build-head"><span>引路 · 第 ${cur.step}/${total} 步</span><span>${g.done.length} 已成</span></div>
    <div class="build-out"><b>${esc(d.name)}</b>　${esc(d.desc)}</div>
    <div class="build-desc">${esc(d.hint || "")}</div>
    <div class="build-row">
      <button class="btn-sm" data-action="tab" data-tab="${esc(d.tab || "home")}">去做</button>
      <span class="muted" style="font-size:11px">奖励：${guideRewardText(d.reward)}</span>
    </div>
  </div>`;
}

function guideRewardText(r) {
  if (!r) return "无";
  const t = [];
  if (r.stone) t.push("灵石 " + r.stone);
  if (r.qiPct) t.push("灵气 " + Math.round(r.qiPct * 100) + "%");
  if (r.pill) t.push("培元丹 " + r.pill);
  if (r.talisman) t.push("残卷 " + r.talisman);
  if (r.material) t.push("灵材 " + r.material);
  if (r.fate) t.push("机缘 " + r.fate);
  return t.join("、") || "无";
}
