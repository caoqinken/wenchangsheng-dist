// ============================================================
// 《问长生》入口 + 主循环
// ============================================================

let _gameStarted = false;

function init() {
  bindEvents();
  if (typeof bindOnboardEvents === "function") bindOnboardEvents();
  // v0.25.0：无道号 → 先建角，建角完成后由 onboard 调用 startGame()
  if (typeof needsOnboarding === "function" && needsOnboarding()) {
    if (typeof showOnboarding === "function") showOnboarding();
    return;
  }
  startGame();
}

// 正式进入游戏世界（首启建角完成后也会走到这里）
function startGame() {
  if (_gameStarted) return;
  _gameStarted = true;
  // 读档后同步弟子 id 序列（否则刷新页面后新弟子必然与旧弟子撞号）
  if (typeof refreshDiscipleSeq === "function") refreshDiscipleSeq();
  if (typeof applySettings === "function") applySettings();

  // 离线结算
  const off = computeOffline();
  if (off.elapsed > 0 && off.gain > 0) {
    const d = off.detail || { qi: off.gain };
    const rows = [];
    rows.push(`灵气 +${fmt((d.qi || 0) + (d.dispatchQi || 0))}`);
    if (d.wudao > 0) rows.push(`悟道 +${fmt(d.wudao)}`);
    const herbNet = Number(d.herbNet) || 0;
    if (Math.abs(herbNet) > 1e-9) rows.push(`灵草 ${herbNet > 0 ? "+" : ""}${fmt(herbNet)}`);
    if (d.pill > 0) rows.push(`培元丹 +${fmt(d.pill)}`);
    if ((d.material || 0) + (d.nodeMaterial || 0) > 0) rows.push(`灵材 +${fmt((d.material || 0) + (d.nodeMaterial || 0))}`);
    if (d.stone > 0) rows.push(`灵石 +${fmt(d.stone)}`);
    if (d.dispatchFolk > 0) rows.push(`凡人 +${fmt(d.dispatchFolk)}`);
    if (d.incense) rows.push(`引魔香生效：驻守离线产出 +${Math.round((CONFIG.OFFLINE_INCENSE_DISPATCH_MULT - 1) * 100)}%`);
    showModal(`
      <div class="result win">
        <div class="result-title">闭关归来</div>
        <div class="result-line">离线 ${fmtTime(off.elapsed)}，洞府与秘境照常运转：</div>
        <div class="offline-list">${rows.map(r => `<span class="bag-tag">${esc(r)}</span>`).join("")}</div>
        <div class="result-line muted-line">洞府修炼/建筑按在线的 ${Math.round(CONFIG.OFFLINE_RATE * 100)}% 结算；秘境驻守另乘 50%，普通离线约为在线的 25%${d.incense ? "（引魔香提升至约 37.5%）" : ""}。本次离线上限 ${Math.round((d.capSec || CONFIG.OFFLINE_CAP_SEC) / 3600)} 小时；闭关功法加成另计。</div>
        <button class="btn-primary" data-action="closemodal">开始修炼</button>
      </div>`);
  }

  showView("home");

  // 主循环：每秒 tick
  let last = Date.now();
  setInterval(() => {
    const now = Date.now();
    const dt = (now - last) / 1000;
    last = now;
    if (dt <= 0) return;
    // 切后台/休眠超过 60 秒：不再丢弃这段收益，改走离线结算补发
    if (dt > 60) {
      const o = computeOffline();
      // computeOffline 已统一结算洞府、驻守与资源点；此处不可再次调用 dispatchOffline，否则重复发放。
      refreshView();
      return;
    }
    idleTick(dt);
    buildTick(dt);
    if (typeof dispatchTick === "function") dispatchTick(dt);
    if (typeof dispatchNodeTick === "function") dispatchNodeTick(dt);   // 驻守资源点刷新（v0.28.0）
    if (typeof missionsTick === "function") missionsTick();             // 弟子任务结算（v0.33.0）
    timeTick(dt);  // 世界时间推进（内部驱动势力演化 + 事件判定）
    // 道途录：成就判定 + 图鉴汇总（v0.6.5）
    if (typeof guideTick === "function") guideTick();   // 新手引路判定（v0.47.0）
    if (typeof codexTick === "function") {
      const got = codexTick();
      if (got.length) {
        toast(got.length === 1
          ? `🎖 达成成就「${got[0].name}」`
          : `🎖 达成 ${got.length} 项成就：${got[0].name} 等`);
      }
    }
    // 体力恢复
    if (S.stamina < CONFIG.MAX_STAMINA) {
      S.stamina = Math.min(S.stamina + dt / CONFIG.STAMINA_RECOVER_SEC, CONFIG.MAX_STAMINA);
    }
    // 轻量刷新当前视图
    refreshView();
    // 每 10 秒存档
    if (Math.random() < 0.1) save();
  }, 1000);

  // 离开页面时存档
  window.addEventListener("beforeunload", save);
  window.addEventListener("visibilitychange", () => {
    if (document.hidden) { save(); return; }
    // 回到前台：补结算离线收益（放置类游戏的核心体验，旧版只在整页刷新时结算）
    const o = computeOffline();
    if (o.elapsed > 10) {
      if (o.gain > 0) toast(`闭关 ${fmtTime(o.elapsed)}，灵气 +${fmt(o.gain)}`);
      refreshView();
    }
    last = Date.now();   // 重置主循环基准，避免回前台后 dt 尖峰
  });
}

// 刷新当前视图（v0.9.0 增量渲染）
// 洞府页：只更新动态节点；其余页面：HTML 差异比对，内容变了才写 DOM。
// 目的：避免每秒整页重建导致点击丢失、滚动复位、输入框失焦。
function refreshView() {
  if (document.hidden) return;
  renderTopbar();
  const v = el("view");
  if (currentTab === "home") {
    const sig = homeStructSig();
    if (sig !== _homeSig) {
      // 境界/层数变化（突破成功）→ 结构可能变（按钮文案/渡劫提示），整页重建一次
      _homeSig = sig;
      const html = viewHome();
      v.innerHTML = html;
      _lastHtml = html;
    } else {
      updateHomeDynamic();
    }
    return;
  }
  const html = renderViewHtml(currentTab);
  if (html !== _lastHtml) {
    _lastHtml = html;
    v.innerHTML = html;
  }
}

function fmtTime(sec) {
  if (sec < 60) return Math.floor(sec) + "秒";
  if (sec < 3600) return Math.floor(sec / 60) + "分钟";
  return (sec / 3600).toFixed(1) + "小时";
}

init();
