// ============================================================
// 《问长生》时间系统：游戏内时间推进，驱动世界演化节拍
// ============================================================

// 每秒推进游戏内时间
function timeTick(dt) {
  S.gameTime.dayTick += dt;
  while (S.gameTime.dayTick >= CONFIG.DAY_SEC) {
    S.gameTime.dayTick -= CONFIG.DAY_SEC;
    advanceDay();
  }
}

// 新的一天：日期推进 + 世界演化
function advanceDay() {
  S.gameTime.day++;
  if (S.gameTime.day > CONFIG.DAYS_PER_MONTH) {
    S.gameTime.day = 1;
    S.gameTime.month++;
    if (S.gameTime.month > CONFIG.MONTHS_PER_YEAR) {
      S.gameTime.month = 1;
      S.gameTime.year++;
    }
  }
  // 每日驱动：势力演化 + 世界事件判定 + 弟子自主行为 + 经济演化
  factionTick();
  // v0.32.0：驻守秘境安定度每日下降（妖兽余孽与势力骚扰）
  if (typeof stableDailyTick === "function") stableDailyTick();
  // v0.33.0：庙祝安抚（每处任职 +1 安定）
  if (typeof staffOf === "function" && S.staff) {
    for (const ch in S.staff) {
      if (S.staff[ch] && S.staff[ch].office === "miao" && S.clearedMaps && S.clearedMaps[ch]) {
        addFieldStable(ch, 1);
      }
    }
  }
  // v0.33.0：魔道争夺判定
  if (typeof conflictDaily === "function") conflictDaily();
  // v0.33.0：王朝赋税
  if (typeof taxDaily === "function") taxDaily();
  eventTick();
  npcTick();
  economyTick();
  // v0.57.0：凡人家庭婚育与聚落生活消费。
  if (typeof fieldSocietyDailyTick === "function") fieldSocietyDailyTick();
  // v0.56.3：私有秘境修行洞府吸引修士，按日推进本地修士人口。
  if (typeof fieldResidentsDailyTick === "function") fieldResidentsDailyTick();
}

function dateStr() {
  return `第${S.gameTime.year}年 ${S.gameTime.month}月 ${S.gameTime.day}日`;
}
