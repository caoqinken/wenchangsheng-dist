// ============================================================
// 《问长生》开局建角（v0.25.0）
// 道号 + 形象 → 建立角色档案（存档按道号分档）
// ============================================================

const ONB = { name: "", avatar: "qingshan", dao: "fa" };

function needsOnboarding() { return !S.playerName; }

function onboardRandomName() {
  const taken = listProfiles().map(p => p.name);
  const pool = CONFIG.RANDOM_NAMES.filter(n => taken.indexOf(n) < 0);
  const arr = pool.length ? pool : CONFIG.RANDOM_NAMES;
  return arr[Math.floor(Math.random() * arr.length)];
}

function onboardCardsHtml() {
  return CONFIG.AVATARS.map(a => `
    <div class="onb-card ${ONB.avatar === a.key ? "picked" : ""}" data-onb-avatar="${a.key}">
      <img src="${a.img}" alt="${esc(a.name)}">
      <div class="onb-card-name">${esc(a.name)}</div>
      <div class="onb-card-desc">${esc(a.desc)}</div>
      <div class="onb-card-mark">✓</div>
    </div>`).join("");
}

function onboardDaoHtml() {
  return CONFIG.DAO_PATHS.map(d => `
    <div class="onb-dao ${ONB.dao === d.key ? "picked" : ""}" data-onb-dao="${d.key}">
      <div class="onb-dao-name">${esc(d.name)}</div>
      <div class="onb-dao-desc">${esc(d.desc)}</div>
      <div class="onb-dao-stat">${esc(daoSummary(d.key))}</div>
    </div>`).join("");
}

function onboardProfilesHtml() {
  const list = listProfiles();
  if (!list.length) return "";
  const rows = list.map(p => `
    <button class="btn-sm onb-profile" data-onb-continue="${esc(p.name)}">
      ${esc(p.name)}
    </button>`).join("");
  return `
    <div class="onb-sec">
      <div class="onb-sec-title">此界已有道号</div>
      <div class="onb-profiles">${rows}</div>
    </div>`;
}

function onboardHtml() {
  return `
    <div class="onb-wrap">
      <div class="onb-bg"></div>
      <div class="onb-panel">
        <div class="onb-title">问 长 生</div>
        <div class="onb-sub">红尘万丈，仙途初启。请先定下道号与形貌。</div>
        <div class="onb-sec">
          <div class="onb-sec-title">道号</div>
          <div class="onb-name-row">
            <input id="onb-name" class="onb-input" maxlength="${CONFIG.NAME_MAX}"
                   placeholder="${CONFIG.NAME_MIN}~${CONFIG.NAME_MAX} 字" value="${esc(ONB.name)}">
            <button class="btn-sm" data-onb-random>随机</button>
          </div>
          <div class="onb-hint" id="onb-hint">道号将作为存档归属，之后可在人物页切换。</div>
        </div>
        <div class="onb-sec">
          <div class="onb-sec-title">形貌</div>
          <div class="onb-grid">${onboardCardsHtml()}</div>
        </div>
        <div class="onb-sec">
          <div class="onb-sec-title">道途</div>
          <div class="onb-dao-grid">${onboardDaoHtml()}</div>
          <div class="onb-hint">体修厚血近战、法修群攻高真元、剑修高攻、体法双修全面但修炼更慢；日后可在人物页改修。</div>
        </div>
        ${onboardProfilesHtml()}
        <button class="btn-primary onb-start" data-onb-start>入 世</button>
        ${listProfiles().length ? `<button class="btn-sm onb-back" data-onb-back>返回仙途</button>` : ""}
        <div class="onb-foot">旧版本单档已清空，本版起每名修士各自一档。</div>
      </div>
    </div>`;
}

function showOnboarding() {
  ONB.name = onboardRandomName();
  ONB.avatar = S.avatar || "qingshan";
  ONB.dao = S.dao || "fa";
  const host = el("onboard");
  if (!host) return;
  host.innerHTML = onboardHtml();
  host.classList.add("show");
  document.body.classList.add("onboarding");
}

function hideOnboarding() {
  const host = el("onboard");
  if (host) { host.classList.remove("show"); host.innerHTML = ""; }
  document.body.classList.remove("onboarding");
}

function onboardPickAvatar(key) {
  ONB.avatar = key;
  const host = el("onboard");
  if (!host) return;
  host.querySelectorAll("[data-onb-avatar]").forEach(c => {
    c.classList.toggle("picked", c.dataset.onbAvatar === key);
  });
}

function onboardRandomize() {
  ONB.name = onboardRandomName();
  const input = el("onb-name");
  if (input) input.value = ONB.name;
}

function onboardStart() {
  const input = el("onb-name");
  const name = (input ? input.value : ONB.name || "").trim();
  const r = createCharacter(name, ONB.avatar, ONB.dao);
  if (!r.ok) {
    const hint = el("onb-hint");
    if (hint) { hint.textContent = r.msg; hint.classList.add("warn"); }
    if (typeof toast === "function") toast(r.msg);
    return;
  }
  hideOnboarding();
  if (typeof startGame === "function") startGame();
  if (typeof toast === "function") toast(`道号「${S.playerName}」已立 · 仙途开启`);
}

function onboardContinue(name) {
  const r = switchCharacter(name);
  if (!r.ok) { if (typeof toast === "function") toast(r.msg); return; }
  hideOnboarding();
  if (typeof startGame === "function") startGame();
  if (typeof toast === "function") toast(`重返仙途 · ${S.playerName}`);
}

// 从建角界面返回（仅当已有道号可回）
function onboardBack() {
  const b = profileBook();
  const target = (b.last && b.names[b.last]) ? b.last : (Object.keys(b.names)[0] || "");
  if (!target) return;
  onboardContinue(target);
}

// 事件委托：建角界面由块级点击驱动，避免每次重绘重复绑定
function bindOnboardEvents() {
  const host = el("onboard");
  if (!host) return;
  host.addEventListener("click", ev => {
    const t = ev.target;
    if (!t || !t.closest) return;
    const av = t.closest("[data-onb-avatar]");
    if (av) { onboardPickAvatar(av.dataset.onbAvatar); return; }
    const dp = t.closest("[data-onb-dao]");
    if (dp) {
      ONB.dao = dp.dataset.onbDao;
      host.querySelectorAll("[data-onb-dao]").forEach(c => c.classList.toggle("picked", c.dataset.onbDao === ONB.dao));
      return;
    }
    if (t.closest("[data-onb-random]")) { onboardRandomize(); return; }
    if (t.closest("[data-onb-start]")) { onboardStart(); return; }
    if (t.closest("[data-onb-back]")) { onboardBack(); return; }
    const cont = t.closest("[data-onb-continue]");
    if (cont) { onboardContinue(cont.dataset.onbContinue); return; }
  });
  host.addEventListener("input", ev => {
    if (ev.target && ev.target.id === "onb-name") {
      ONB.name = ev.target.value;
      const hint = el("onb-hint");
      if (hint) { hint.textContent = "道号将作为存档归属，之后可在人物页切换。"; hint.classList.remove("warn"); }
    }
  });
}

// ---------- 换角色（人物页入口）----------
function showSwitchCharModal() {
  const list = listProfiles();
  const rows = list.map(p => `
    <div class="shop-item">
      <span>${esc(p.name)}${S.playerName === p.name ? "（当前）" : ""}</span>
      ${S.playerName === p.name ? `<span class="muted">当前道号</span>`
        : `<button class="btn-sm" data-action="switchto" data-name="${esc(p.name)}">进入</button>`}
    </div>`).join("");
  showModal(`
    <div class="result">
      <div class="result-title">道号</div>
      <div class="result-line">当前：<b>${esc(S.playerName || "无名")}</b></div>
      <div class="shop-list">${rows || `<div class="result-line muted">暂无其他道号</div>`}</div>
      <button class="btn-sm" data-action="newchar">新建道号</button>
      <button class="btn-primary" data-action="closemodal">返回</button>
    </div>`);
}

function doSwitchChar(name) {
  if (!name || name === S.playerName) return;
  save();
  const r = switchCharacter(name);
  if (!r.ok) { toast(r.msg); return; }
  closeModal();
  if (typeof refreshDiscipleSeq === "function") refreshDiscipleSeq();
  showView("home");
  toast(`已切换道号 · ${S.playerName}`);
}

function doNewChar() {
  save();
  closeModal();
  S = defaultState();          // 临时空档，仅用于建角界面
  showOnboarding();
}
