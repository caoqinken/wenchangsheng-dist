// ============================================================
// 《问长生》弟子经营完整版（v0.33.0）
// 职务：庙祝/矿正/城主/护法（真实效果，非纸面）
// 任务：清剿/护送/传道（耗时、成功率、失败惩罚）
// 争夺：魔道窥伺 → 护法抵御 / 失守 → 赎回
// 王朝：州牧/司农/国师 + 每日赋税
// ============================================================

// ---------- 职务 ----------
function officeDef(key) { return CONFIG.STAFF.OFFICES.find(o => o.key === key) || null; }
function staffOf(ch) { return (S.staff && S.staff[ch]) || null; }

function officeScale(d) {
  const a = Math.max(1, Math.min(5, d.aptitude || 1));
  return CONFIG.STAFF.APT_SCALE[a - 1];
}

// 任命职务：必须是在该秘境驻守的弟子；一人只能任一处
function appointStaff(ch, officeKey, discipleId) {
  if (!S.clearedMaps || !S.clearedMaps[ch]) return { ok: false, msg: "该秘境尚未探明" };
  if (!officeDef(officeKey)) return { ok: false, msg: "无此职务" };
  const pid = String(discipleId);
  const d = S.disciples.find(x => String(x.id) === pid);
  if (!d) return { ok: false, msg: "弟子不存在" };
  if (dispatchTeam(ch).map(String).indexOf(pid) < 0) return { ok: false, msg: "该弟子尚未驻守此秘境" };
  for (const k in (S.staff || {})) {
    if (String(S.staff[k].discipleId) === pid) delete S.staff[k];
  }
  if (!S.staff) S.staff = {};
  S.staff[ch] = { discipleId: d.id, office: officeKey };
  save();
  return { ok: true, office: officeDef(officeKey), disciple: d };
}

// 某秘境职务对产出的加成（0 表示无）
function officeBonus(ch, kind) {
  const st = staffOf(ch);
  if (!st) return 0;
  const d = S.disciples.find(x => String(x.id) === String(st.discipleId));
  if (!d) return 0;
  const sc = officeScale(d);
  if (kind === "stone" && st.office === "kuang") return 0.15 * sc;
  if (kind === "folk") {
    if (st.office === "miao") return 0.10 * sc;
    if (st.office === "cheng") return 0.05 * sc;
  }
  return 0;
}

function officeCapBonus(ch) {
  const st = staffOf(ch);
  return (st && st.office === "cheng") ? 20 : 0;
}
function hasGuard(ch) {
  const st = staffOf(ch);
  return !!(st && st.office === "hu");
}

// ---------- 弟子任务 ----------
function missionDef(key) { return CONFIG.MISSION.TYPES.find(t => t.key === key) || null; }
// 任务风险是各任务自身的基础失败率；弟子资质/境界只提供成功率加成。
// 将任务类型纳入计算，避免 UI 展示风险与实际判定脱节。
function missionRate(d, type) {
  const M = CONFIG.MISSION;
  const def = missionDef(type);
  const baseSuccess = def && Number.isFinite(Number(def.risk))
    ? 1 - Math.max(0, Math.min(1, Number(def.risk)))
    : M.BASE_RATE;
  const aptitudeBonus = Math.max(0, Number(d && d.aptitude) || 1) * (M.APT_RATE || 0);
  const realmBonus = Math.max(0, Number(d && d.realm) || 0) * (M.REALM_RATE || 0);
  return Math.max(0, Math.min(0.95, baseSuccess + aptitudeBonus + realmBonus));
}
function discipleBusy(id) {
  return (S.missions || []).some(m => m.status === "run" && String(m.discipleId) === String(id));
}

function missionStart(type, ch, discipleId) {
  const def = missionDef(type);
  if (!def) return { ok: false, msg: "无此任务" };
  // 清剿与传道归属到实际驻守聚落；传道不能凭空生成凡人。
  if ((type === "clear" || type === "preach") && (ch === undefined || ch === null)) {
    const active = Object.keys(S.mapTeam || {}).filter(k => S.mapTeam[k] && S.mapTeam[k].length && S.clearedMaps && S.clearedMaps[k]).sort((a,b) => Number(a)-Number(b));
    if (active.length) ch = parseInt(active[0], 10);
    else if (type === "preach") return { ok: false, msg: "传道需有弟子驻守的凡人聚落作为根基" };
  }
  if (type === "preach" && (!S.clearedMaps || !S.clearedMaps[ch] || !dispatchTeam(ch).length)) return { ok: false, msg: "传道需派弟子驻守目标秘境" };
  const d = S.disciples.find(x => String(x.id) === String(discipleId));
  if (!d) return { ok: false, msg: "弟子不存在" };
  if (discipleBusy(d.id)) return { ok: false, msg: "该弟子正在执行任务" };
  if (S.stamina < (def.stamina || 0)) return { ok: false, msg: "体力不足" };
  S.stamina -= def.stamina || 0;
  S.missionSeq = (S.missionSeq || 0) + 1;
  if (!S.missions) S.missions = [];
  S.missions.push({
    id: S.missionSeq, type, ch: (ch === undefined ? null : ch),
    discipleId: d.id, successRate: missionRate(d, type),
    endAt: Date.now() + def.sec * 1000, status: "run",
  });
  save();
  return { ok: true, mission: S.missions[S.missions.length - 1], def };
}

function missionsTick() {
  if (!S.missions || !S.missions.length) return;
  const now = Date.now();
  for (const m of S.missions) {
    if (m.status !== "run" || now < m.endAt) continue;
    const def = missionDef(m.type);
    const d = S.disciples.find(x => String(x.id) === String(m.discipleId));
    m.status = "done";
    if (!def || !d) { m.success = false; continue; }
    // 按派遣时锁定的成功率结算；旧存档中没有该字段时再按当前状态兼容计算。
    const successRate = Number.isFinite(Number(m.successRate))
      ? Math.max(0, Math.min(0.95, Number(m.successRate)))
      : missionRate(d, m.type);
    if (Math.random() < successRate) {
      m.success = true;
      if (def.stable && m.ch !== null && m.ch !== undefined) addFieldStable(m.ch, def.stable);
      if (def.rep) S.reputation = (S.reputation || 0) + def.rep;
      if (def.stone) S.stone += def.stone;
      if (def.folk) {
        if (typeof addFolk === "function") addFolk(def.folk, m.ch);
        else S.folk = Math.min(folkCap(), (S.folk || 0) + def.folk);
      }
      // 传道任务为驻守教化提供额外贡献；不替代持续驻守积累。
      if (m.type === "preach" && m.ch !== null && m.ch !== undefined && typeof fieldEducationAdd === "function") {
        fieldEducationAdd(m.ch, CONFIG.FIELD_EDUCATION.PREACH_BONUS, `弟子${d.name}传道四方`);
      }
      const growthResult = typeof discipleAddGrowth === "function" ? discipleAddGrowth(d, def.growth || 0) : { gained: 0, levels: 0 };
      m.growthGained = growthResult.gained || 0;
      m.levelsGained = growthResult.levels || 0;
      if (typeof addEventLog === "function") addEventLog(`弟子${d.name}完成「${def.name}」`);
      if (typeof sectTaskProgress === "function") sectTaskProgress("mission", 1);
    } else {
      m.success = false;
      d.loyalty = Math.max(0, (d.loyalty || 0) - CONFIG.MISSION.FAIL_LOYALTY);
      const growthResult = typeof discipleAddGrowth === "function" ? discipleAddGrowth(d, CONFIG.MISSION.FAIL_GROWTH || 0) : { gained: 0, levels: 0 };
      m.growthGained = growthResult.gained || 0;
      m.levelsGained = growthResult.levels || 0;
      if (typeof addEventLog === "function") addEventLog(`弟子${d.name}执行「${def.name}」失利，忠诚下降`);
    }
  }
  // 完成记录保留 60 秒供 UI 展示
  S.missions = S.missions.filter(m => m.status === "run" || (now - (m.endAt || 0) < 60000));
  save();
}

// ---------- 势力争夺 ----------
function mapNameOf(ch) {
  const m = CONFIG.fieldMap(parseInt(ch, 10));
  return m ? m.name : "秘境";
}

function conflictChance() {
  const rel = (S.factions && S.factions.moyuan) ? S.factions.moyuan.relation : 0;
  if (rel >= CONFIG.CONFLICT.REL_THRESHOLD) return 0;
  return rel < 0 ? CONFIG.CONFLICT.LOW_REL_CHANCE : CONFIG.CONFLICT.BASE_CHANCE;
}

// 每日判定：返回今日被窥伺的秘境列表（供 UI/日志）
function conflictDaily() {
  // v0.56.0：势力争夺不再直接夺走整处秘境或清空弟子队伍。
  // 未完成教化的秘境遭窥伺时，只造成少量教化侵蚀；私有化后不再受此影响。
  const hits = [];
  if (!S.mapTeam || !S.clearedMaps) return hits;
  const chance = conflictChance();
  if (chance <= 0) return hits;
  for (const ch in S.clearedMaps) {
    if (!S.clearedMaps[ch] || (S.fieldEducation && S.fieldEducation[ch] && S.fieldEducation[ch].private)) continue;
    if (Math.random() >= chance) continue;
    const stationed = !!(S.mapTeam[ch] && S.mapTeam[ch].length);
    const guarded = hasGuard(ch);
    if (stationed && guarded) {
      addFieldStable(ch, -5);
      if (typeof addEventLog === "function") addEventLog(`护法击退势力窥伺（${mapNameOf(ch)}），教化根基未受损，安定 -5`);
      hits.push({ ch: parseInt(ch, 10), guarded: true, eroded: 0 });
    } else {
      const e = typeof fieldEducationOf === "function" ? fieldEducationOf(ch, true) : null;
      const loss = 0.005; // 每次窥伺侵蚀0.5%，不是整处失守
      if (e) e.progress = Math.max(0, e.progress - loss);
      addFieldStable(ch, -5);
      if (typeof addEventLog === "function") addEventLog(`${mapNameOf(ch)}遭势力渗透，教化度 -${(loss * 100).toFixed(1)}%，安定 -5`);
      hits.push({ ch: parseInt(ch, 10), guarded: false, stationed, eroded: loss });
    }
  }
  if (hits.length) save();
  return hits;
}

function ransomCost(ch) { return 1500 * (parseInt(ch, 10) + 1); }

function ransomField(ch) {
  if (!S.lostFields || !S.lostFields[ch]) return { ok: false, msg: "该秘境并未失守" };
  const cost = ransomCost(ch);
  if (S.stone < cost) return { ok: false, msg: `灵石不足（需 ${fmt(cost)}）` };
  S.stone -= cost;
  delete S.lostFields[ch];
  if (!S.fieldStable) S.fieldStable = {};
  S.fieldStable[ch] = CONFIG.STABLE.INIT;
  save();
  return { ok: true, cost };
}

// ---------- 王朝官职 ----------
function dynastyOfficeDef(key) { return CONFIG.DYNASTY_OFFICES.find(o => o.key === key) || null; }
function dynastyAppoint(officeKey, discipleId) {
  if (!S.dynasty || !S.dynasty.name) return { ok: false, msg: "尚未立朝" };
  const def = dynastyOfficeDef(officeKey);
  if (!def) return { ok: false, msg: "无此官职" };
  const d = S.disciples.find(x => String(x.id) === String(discipleId));
  if (!d) return { ok: false, msg: "弟子不存在" };
  if (!S.dynastyOffice) S.dynastyOffice = {};
  // 一人只能任一职
  for (const k in S.dynastyOffice) {
    if (String(S.dynastyOffice[k]) === String(d.id)) delete S.dynastyOffice[k];
  }
  S.dynastyOffice[officeKey] = d.id;
  save();
  return { ok: true, office: def, disciple: d };
}
function dynastyOfficeMult(kind) {
  if (!S.dynasty || !S.dynasty.name || !S.dynastyOffice) return 0;
  if (kind === "cult" && S.dynastyOffice.guoshi) return 0.03;
  return 0;
}
function dynastyFolkMult() {
  if (!S.dynasty || !S.dynasty.name) return 1;
  return 1 + (S.dynastyOffice && S.dynastyOffice.zhoumu ? 0.20 : 0);
}

// 每日赋税：凡人 0.5% × 100 → 灵石
function taxDaily() {
  if (!S.dynasty || !S.dynasty.name) return 0;
  const gain = Math.floor((S.folk || 0) * CONFIG.TAX_RATE * 100);
  if (gain > 0) S.stone += gain;
  return gain;
}

// ---------- 汇总（UI 用）----------
function staffSummary(ch) {
  const st = staffOf(ch);
  if (!st) return "未任命";
  const d = S.disciples.find(x => String(x.id) === String(st.discipleId));
  const def = officeDef(st.office);
  return `${def ? def.name : st.office} · ${d ? d.name : "?"}（效果 ×${d ? officeScale(d).toFixed(1) : "?"}）`;
}
