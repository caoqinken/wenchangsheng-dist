// ============================================================
// 《问长生》储物法器（v0.37.0 重构：网游式容器背包）
// 设定：储物袋/储物戒按材质分品级，内部空间（格数）与单格堆叠上限各不相同
// 唯一真源：S.bag.slots（每格 {key, n} 或 null）
// S.herbs / S.materials / S.pills / S.talisman / S.tribPills 为派生镜像，仅供读取
// ============================================================

// ---------- 容器定义 ----------
function invDefs() { return CONFIG.INV.CONTAINERS; }

function invTier() {
  const list = invDefs();
  if (!S.bag || typeof S.bag !== "object") return 0;
  const t = parseInt(S.bag.tier, 10);
  return (isFinite(t) && t >= 0 && t < list.length) ? t : 0;
}

function invDef() { return invDefs()[invTier()]; }

function invSlots() { return invDef().slots; }

function invNextDef() { return invDefs()[invTier() + 1] || null; }

// ---------- 物品定义（含动态物品：种子 / 古宝碎片） ----------
function invItemDef(key) {
  if (!key || typeof key !== "string") return null;
  if (key.indexOf("seed:") === 0) {
    const raw = key.slice(5);
    const rare = raw.indexOf("rare:") === 0;
    const ck = rare ? raw.slice(5) : raw;
    const c = CONFIG.GARDEN.CROPS.find(x => x.key === ck);
    if (!c) return null;
    return {
      key, name: (rare ? "异种" : "") + c.name + "种子", cat: "seed", stack: 99,
      price: rare ? Math.max(1, Math.round(c.seed * 0.75)) : Math.max(1, Math.round(c.seed / 2)),
      char: rare ? "异" : "籽",
      desc: rare ? `异种灵种：种植后该作物产量 +50%，生长时间缩短 10%。` : `药园种植物：${c.name}，成熟产 ${[c.herb ? "灵草+" + c.herb : "", c.pill ? "丹药+" + c.pill : "", c.material ? "灵材+" + c.material : ""].filter(Boolean).join(" ")}`,
      crop: ck, rare,
    };
  }
  if (key.indexOf("book:") === 0) {
    const bk = key.slice(5);
    const b = (typeof gongfaBook === "function") ? gongfaBook(bk) : (CONFIG.GONGFA_BOOKS.find(x => x.key === bk) || null);
    if (!b) return null;
    return {
      key, name: "《" + b.name + "》", cat: "book", stack: 1,
      price: Math.round(CONFIG.TALISMAN_PRICE * 0.6 * (typeof gongfaGrade === "function" ? gongfaGrade(b) : b.tier)),
      icon: "assets/图标_功法要诀.webp",
      desc: `${typeof gongfaGradeName === "function" ? gongfaGradeName(gongfaGrade(b)) : b.tier + "阶"}功法秘籍：可领悟并修炼至 ${b.layers} 层。${b.desc || ""}`,
      gongfa: bk,
    };
  }
  if (key.indexOf("art:") === 0) {
    const aid = parseInt(key.slice(4), 10);
    const a = (S.artifacts || []).find(x => String(x.id) === String(aid));
    if (!a) return null;
    const ti = (typeof tierInfo === "function") ? tierInfo(a.tier) : { name: "法宝", color: "#8B7355" };
    const tp = (typeof typeInfo === "function") ? typeInfo(a.type) : { slot: "法宝", attr: "" };
    const stDef = (a.setKey && typeof artifactSetDef === "function") ? artifactSetDef(a.setKey) : null;
    const stCnt = (stDef && typeof artifactSetCounts === "function") ? (artifactSetCounts()[a.setKey] || 0) : 0;
    return {
      key, name: a.name, cat: "gear", stack: 1, price: 0,
      icon: "assets/装备_法宝.webp", tier: a.tier, tierName: ti.name, color: ti.color,
      desc: `${ti.name} · ${tp.slot}类（${tp.attr || "—"}）｜可装备、洗练词条或分解回收灵材` + (stDef ? `｜套装「${stDef.name}」已装备 ${stCnt}/3` : ""),
      aid,
    };
  }
  if (key.indexOf("sp:") === 0) {
    const ch = parseInt(key.slice(3), 10);
    const nm = CONFIG.FIELD_SPECIALTIES[ch];
    if (!nm) return null;
    const SP = CONFIG.SPECIALTY_ITEM;
    return {
      key, name: nm, cat: "material", stack: SP.stack,
      price: SP.priceBase + ch * SP.priceStep,
      char: "特", desc: SP.desc + `（${CONFIG.fieldMap(ch) ? CONFIG.fieldMap(ch).name : "秘境 " + (ch + 1)}特产）`,
      chapter: ch,
    };
  }
  if (key.indexOf("frag:") === 0) {
    const sk = key.slice(5);
    const st = CONFIG.ANCIENT_SETS.find(x => x.key === sk);
    if (!st) return null;
    return {
      key, name: st.name + "碎片", cat: "frag", stack: 999, price: 0, char: "片",
      desc: `集齐可合成 ${st.name} 古宝、或为已有古宝升星`, set: sk,
    };
  }
  return CONFIG.ITEMS[key] || null;
}

function invCatName(cat) {
  const c = CONFIG.ITEM_CATS.find(x => x.key === cat);
  return c ? c.name : "杂物";
}

// 单格上限：物品自身堆叠与当前法器空间承载力取小
function invStackCap(def) {
  const d = def || {};
  if (d.cat === "gear") return 1;          // 法宝一件一格，不可堆叠
  const base = d.stack || 99;
  return Math.min(base, invDef().stack);
}

// ---------- 结构自检 + 旧档装袋 + 镜像同步 ----------
function invEnsure() {
  if (!S) return;
  if (!S.bag || typeof S.bag !== "object") S.bag = { tier: 0, slots: [], pending: true };
  const cap = invSlots();
  if (!S.bag.stash || typeof S.bag.stash !== "object") S.bag.stash = {};
  if (!Array.isArray(S.bag.slots)) S.bag.slots = [];
  while (S.bag.slots.length < cap) S.bag.slots.push(null);
  if (S.bag.slots.length > cap) S.bag.slots.length = cap;
  for (let i = 0; i < S.bag.slots.length; i++) {
    const st = S.bag.slots[i];
    if (!st || typeof st !== "object" || typeof st.key !== "string" || !(st.n > 0)) S.bag.slots[i] = null;
  }
  if (S.bag.pending) {
    invMigrateLegacy();
    S.bag.pending = false;
  }
  if (!S.bag.gearMigrated) {
    invMigrateGear();
    S.bag.gearMigrated = true;
  }
  invSync();
}

// 旧存档：把扁平资源字段装进袋子（只在首次执行）
function invMigrateLegacy() {
  const pairs = [
    ["herb", S.herbs], ["material", S.materials], ["pill", S.pills],
    ["talisman", S.talisman], ["tribPill", S.tribPills],
  ];
  for (const [k, v] of pairs) {
    const n = Number(v);
    if (isFinite(n) && n > 0) invAddRaw(k, n);
  }
  const frag = S.ancientFrag || {};
  for (const setKey in frag) {
    const n = Number(frag[setKey]);
    if (isFinite(n) && n > 0) invAddRaw("frag:" + setKey, n);
  }
  const spc = S.specialty || {};
  for (const ch in spc) {
    const n = Number(spc[ch]);
    if (isFinite(n) && n > 0 && CONFIG.FIELD_SPECIALTIES[ch]) invAddRaw("sp:" + ch, n);
  }
}

// 旧档法宝入袋（v0.38.0）：未装备且不在袋中的实体补进空格
function invMigrateGear() {
  const lo = S.loadout || {};
  const equipped = {};
  for (const k in lo) if (lo[k] != null) equipped[String(lo[k])] = true;
  const inBag = {};
  for (const st of S.bag.slots) if (st && st.key.indexOf("art:") === 0) inBag[st.key.slice(4)] = true;
  for (const a of (S.artifacts || [])) {
    if (equipped[String(a.id)]) continue;
    if (inBag[String(a.id)]) continue;
    invAddRaw("art:" + a.id, 1);
  }
  // 清理指向已不存在实体的法宝格
  for (let i = 0; i < S.bag.slots.length; i++) {
    const st = S.bag.slots[i];
    if (st && st.key.indexOf("art:") === 0 && !invItemDef(st.key)) S.bag.slots[i] = null;
    if (st && st.key.indexOf("book:") === 0 && !invItemDef(st.key)) S.bag.slots[i] = null;
  }
  invSync();
}

// 镜像字段重算（读代码用 S.herbs 等，不写）
function invSync() {
  if (!S || !S.bag) return;
  const acc = { herb: 0, material: 0, pill: 0, talisman: 0, tribPill: 0 };
  const frag = {};
  const spc = {};
  for (const st of S.bag.slots) {
    if (!st) continue;
    if (acc[st.key] !== undefined) acc[st.key] += st.n;
    else if (st.key.indexOf("frag:") === 0) {
      const k = st.key.slice(5);
      frag[k] = (frag[k] || 0) + st.n;
    } else if (st.key.indexOf("sp:") === 0) {
      const k = st.key.slice(3);
      spc[k] = (spc[k] || 0) + st.n;
    }
  }
  S.herbs = acc.herb;
  S.materials = acc.material;
  S.pills = acc.pill;
  S.talisman = acc.talisman;
  S.tribPills = acc.tribPill;
  S.ancientFrag = frag;
  S.specialty = spc;
}

// ---------- 计数与查询 ----------
function invCount(key) {
  invEnsure();
  let n = 0;
  for (const st of S.bag.slots) if (st && st.key === key) n += st.n;
  return n;
}

function invUsedSlots() {
  invEnsure();
  let n = 0;
  for (const st of S.bag.slots) if (st) n++;
  return n;
}

function invFreeSlots() { return invSlots() - invUsedSlots(); }

function invStacksOf(key) {
  invEnsure();
  return S.bag.slots.filter(st => st && st.key === key).length;
}

// 还能再装多少个该物品（已有未满堆叠的余量 + 空格容量）
function invRoomFor(key) {
  invEnsure();
  const def = invItemDef(key);
  if (!def) return 0;
  const cap = invStackCap(def);
  let room = 0;
  for (const st of S.bag.slots) {
    if (!st) room += cap;
    else if (st.key === key) room += Math.max(0, cap - st.n);
  }
  return room;
}

// 购买/领取前的空间校验：装不下就不许交易，避免「买了立刻散卖」亏损
function invRoomCheck(key, n) {
  const room = invRoomFor(key);
  const need = Number(n) || 1;
  if (room + 1e-9 >= need) return { ok: true };
  const def = invItemDef(key);
  return { ok: false, msg: `${invDef().name}空间不足：还需 ${Math.ceil(need - room)} 件位（${def ? def.name : "物品"}），先去更换更高品级法器` };
}

// 拥有的物品种类（只列出真实存在的，未拥有的不出现）
function invOwnedKeys() {
  invEnsure();
  const seen = {};
  const out = [];
  for (const st of S.bag.slots) {
    if (!st || seen[st.key]) continue;
    if (!invItemDef(st.key)) continue;
    seen[st.key] = true;
    out.push(st.key);
  }
  return out;
}

// ---------- 增减 ----------
// 纯堆叠分配（不触发同步/save）：先补已有未满堆叠，再占空格
function invAddRaw(key, n) {
  const def = invItemDef(key);
  if (!def) return { added: 0, overflow: n };
  const cap = invStackCap(def);
  let left = Number(n) || 0;
  if (!(left > 0)) return { added: 0, overflow: 0 };
  const slots = S.bag.slots;
  for (let i = 0; i < slots.length && left > 1e-9; i++) {
    const st = slots[i];
    if (!st || st.key !== key) continue;
    if (st.n >= cap) continue;
    const put = Math.min(cap - st.n, left);
    st.n += put; left -= put;
  }
  for (let i = 0; i < slots.length && left > 1e-9; i++) {
    if (slots[i]) continue;
    const put = Math.min(cap, left);
    slots[i] = { key, n: put };
    left -= put;
  }
  return { added: (Number(n) || 0) - left, overflow: left };
}

// 自动入袋（无提示）：返回 added / overflow
function invAdd(key, n) {
  invEnsure();
  const r = invAddRaw(key, n);
  invSync();
  return r;
}

// 产出入袋：装不下的部分散卖折算灵石，并节流提示
let _invNoticeAt = 0;
function invOverflowNotice(def, overflow, cash, stashed) {
  const now = Date.now();
  if (now - _invNoticeAt < (CONFIG.INV.NOTICE_CD || 20000)) return;
  _invNoticeAt = now;
  const name = def ? def.name : "物品";
  const tail = stashed
    ? `，已暂存袋口 ${fmt(Math.floor(overflow))} 件（升级法器后可取回）`
    : (cash > 0 ? `，其中 ${fmt(Math.floor(overflow))} 件散卖得 ${fmt(cash)} 灵石` : "");
  if (typeof toast === "function") toast(`${invDef().name}已满：${name} 装不下${tail}`);
}

// 取回袋口暂存物（升级法器腾出空间后可用）
function invRecallStash() {
  invEnsure();
  const stash = S.bag.stash || {};
  const got = [];
  let left = 0;
  for (const key in stash) {
    const n = stash[key];
    const r = invAddRaw(key, n);
    if (r.added > 1e-9) got.push((invItemDef(key) || {}).name + " ×" + Math.floor(r.added));
    if (r.overflow > 1e-9) { stash[key] = r.overflow; left++; }
    else delete stash[key];
  }
  invSync();
  if (typeof save === "function") save();
  return { got, left };
}

function invStashTotal() {
  invEnsure();
  let n = 0;
  for (const k in (S.bag.stash || {})) n += S.bag.stash[k];
  return n;
}

// 生产/掉落统一入口：装不下的散卖
function gainItem(key, n) {
  invEnsure();
  const v = Number(n) || 0;
  if (!(v > 0)) return { added: 0, overflow: 0 };
  const r = invAddRaw(key, v);
  invSync();
  if (r.overflow > 1e-9) {
    const def = invItemDef(key);
    const price = (def && def.price) || 0;
    if (price > 0) {
      const cash = Math.floor(r.overflow * price * (CONFIG.INV.OVERFLOW_SELL || 0.6));
      if (cash > 0) S.stone = (S.stone || 0) + cash;
      invOverflowNotice(def, r.overflow, cash);
    } else {
      // 不可出售之物（碎片等）绝不蒸发：寄存于袋口，升级法器后可取回
      S.bag.stash[key] = (S.bag.stash[key] || 0) + r.overflow;
      invOverflowNotice(def, r.overflow, 0, true);
    }
  }
  return r;
}

// 扣除（不足则尽力扣）：返回实际扣除量
function invRemove(key, n) {
  invEnsure();
  let left = Number(n) || 0;
  if (!(left > 0)) return 0;
  const want = left;
  const slots = S.bag.slots;
  for (let i = slots.length - 1; i >= 0 && left > 1e-9; i--) {
    const st = slots[i];
    if (!st || st.key !== key) continue;
    const take = Math.min(st.n, left);
    st.n -= take; left -= take;
    if (st.n <= 1e-9) slots[i] = null;
  }
  invSync();
  return want - left;
}

// 严格扣库：不足时完全不扣，供秘境交易/委托等跨系统调用，避免部分成交。
function invRemoveExact(key, n) {
  invEnsure();
  const need = Number(n);
  if (!key || !isFinite(need) || need <= 0) return { ok: false, removed: 0, msg: "库存扣除参数无效" };
  const have = invCount(key);
  if (have + 1e-9 < need) return { ok: false, removed: 0, have, msg: `库存不足：${(invItemDef(key) || {}).name || key} 持有 ${Math.floor(have)}，需要 ${Math.ceil(need)}` };
  const removed = invRemove(key, need);
  if (removed + 1e-9 < need) return { ok: false, removed: 0, have, msg: "库存状态发生变化，交易未完成" };
  return { ok: true, removed };
}

// 统一库房只读快照：背包格与袋口暂存仍属于同一库存真源，不创建第二份仓储数据。
function fieldWarehouseSnapshot() {
  invEnsure();
  const rows = [];
  const keys = new Set();
  for (const st of S.bag.slots) if (st) keys.add(st.key);
  for (const key of Object.keys(S.bag.stash || {})) keys.add(key);
  for (const key of keys) {
    const def = invItemDef(key);
    if (!def) continue;
    const bagCount = invCount(key);
    const stashCount = Math.max(0, Number((S.bag.stash || {})[key]) || 0);
    rows.push({ key, name: def.name, cat: def.cat || "other", count: bagCount + stashCount, bagCount, stashCount, hasReferencePrice: Number(def.price) > 0 });
  }
  rows.sort((a,b) => a.cat.localeCompare(b.cat, "zh-CN") || a.name.localeCompare(b.name, "zh-CN"));
  return { rows, usedSlots: invUsedSlots(), totalSlots: invSlots(), stashTotal: invStashTotal(), source: "S.bag.slots + S.bag.stash" };
}

// 秘境交易统一扣除玩家库房；当前只允许扣除实际在储物袋格内的数量，袋口暂存不可直接交易。
function fieldWarehouseTake(key, n) {
  const need = Number(n);
  if (!isFinite(need) || need <= 0 || Math.floor(need) !== need) return { ok: false, removed: 0, msg: "交易数量必须为正整数" };
  return invRemoveExact(key, need);
}

// 直接设定持有量（清空后重设，用于迁移/调试/剧情重置）
function invSet(key, n) {
  invEnsure();
  const have = invCount(key);
  if (have > 0) invRemove(key, have);
  const v = Number(n) || 0;
  if (v > 0) { invAddRaw(key, v); invSync(); }
  return invCount(key);
}

// 法宝专用：按 aid 找到所在格索引
function invArtSlotIndex(aid) {
  invEnsure();
  return S.bag.slots.findIndex(st => st && st.key === "art:" + aid);
}

// 从袋中移除法宝（装备/分解时用），返回是否移除成功
function invTakeArtifact(aid) {
  invEnsure();
  const idx = invArtSlotIndex(aid);
  if (idx < 0) return false;
  S.bag.slots[idx] = null;
  invSync();
  return true;
}

// 把法宝放入袋中（炼制/卸下时用），返回是否成功
function invPutArtifact(aid) {
  invEnsure();
  if (invArtSlotIndex(aid) >= 0) return true;
  const r = invAddRaw("art:" + aid, 1);
  invSync();
  return r.added > 0;
}

function invHas(key, n) { return invCount(key) >= (n || 1) - 1e-9; }

// 合并同类堆叠（升级法器后堆叠上限变大，可压缩格数）
function invCompact() {
  invEnsure();
  const slots = S.bag.slots;
  const keys = {};
  for (const st of slots) if (st) keys[st.key] = true;
  const kept = slots.filter(Boolean).slice(0);
  for (let i = 0; i < slots.length; i++) slots[i] = null;
  let idx = 0;
  for (const k in keys) {
    let total = 0;
    for (const st of kept) if (st.key === k) total += st.n;
    const def = invItemDef(k);
    const cap = invStackCap(def);
    while (total > 1e-9 && idx < slots.length) {
      const put = Math.min(cap, total);
      slots[idx++] = { key: k, n: put };
      total -= put;
    }
  }
  invSync();
}

// ---------- 法器升级 ----------
function invUpgrade() {
  invEnsure();
  const nx = invNextDef();
  if (!nx) return { ok: false, msg: "已是最高品级储物法器，可纳须弥" };
  if ((S.realm || 0) < nx.realm) return { ok: false, msg: `需 ${CONFIG.REALMS[nx.realm]}期方可驾驭此物` };
  if ((S.stone || 0) < nx.price) return { ok: false, msg: `灵石不足（需 ${fmt(nx.price)}）` };
  S.stone -= nx.price;
  S.bag.tier = invTier() + 1;
  const cap = invSlots();
  while (S.bag.slots.length < cap) S.bag.slots.push(null);
  invCompact();
  invEnsure();
  if (typeof save === "function") save();
  return { ok: true, def: nx };
}

// ---------- 出售 / 丢弃 ----------
function invSell(key, n) {
  invEnsure();
  const def = invItemDef(key);
  if (!def) return { ok: false, msg: "此物不可出售" };
  if (!(def.price > 0)) return { ok: false, msg: `${def.name}无法出售（可用于合成/升星）` };
  const have = Math.floor(invCount(key));
  if (have < 1) return { ok: false, msg: "袋中无此物" };
  const cnt = Math.max(1, Math.min(have, Math.floor(Number(n) || have)));
  invRemove(key, cnt);
  const gain = Math.round(cnt * def.price);
  S.stone += gain;
  if (typeof save === "function") save();
  return { ok: true, count: cnt, gain, name: def.name };
}

function invDrop(key, n) {
  invEnsure();
  const def = invItemDef(key);
  if (!def) return { ok: false, msg: "此物不可丢弃" };
  const have = Math.floor(invCount(key));
  if (have < 1) return { ok: false, msg: "袋中无此物" };
  const cnt = Math.max(1, Math.min(have, Math.floor(Number(n) || have)));
  invRemove(key, cnt);
  if (typeof save === "function") save();
  return { ok: true, count: cnt, name: def.name };
}

// 统一使用入口（v0.38.0）：按物品类型走各自效果函数
function useItem(key) {
  invEnsure();
  if (invCount(key) < 1) return { ok: false, msg: "袋中已无此物" };
  switch (key) {
    case "pill": return usePill();
    case "tribPill": return useTribPill();
    case "qiPill": return useQiPill();
    case "breakPill": return useBreakPill();
    case "healPill": return useHealPill();
    case "marrowPill": return useMarrowPill();
    case "daoPill": return useDaoPill();
    case "incense": return useHuntingIncense();
    default: return { ok: false, msg: "此物需在对应系统使用（功法页 / 炼器坊 / 古宝）" };
  }
}

// 使用结果文案
function useItemText(key, r) {
  if (!r.ok) return r.msg || "使用失败";
  switch (key) {
    case "pill": return `炼化药力 ${r.buff}/${r.cap}（修炼 +${(Math.min(r.buff * CONFIG.PILL_RATE_BONUS, CONFIG.PILL_BONUS_CAP) * 100).toFixed(0)}%）`;
    case "tribPill": return `服下渡劫丹，下次渡劫 +${CONFIG.TRIB_PILL_BONUS * 100}%（已叠 ${r.buff} 枚）`;
    case "qiPill": return `聚气丹化开，灵气 +${fmt(r.qi)}`;
    case "breakPill": return `破境丹入腹，下次渡劫 +${Math.round(r.plus * 100)}%（已叠 ${r.buff} 枚）`;
    case "healPill": return `回春丹药力护体，下次入秘境带 ${Math.round(r.shield * 100)}% 气血护盾`;
    case "marrowPill": return `洗髓丹药力在身，下次法宝洗练免灵石（剩 ${r.free} 次）`;
    case "daoPill": return `悟道丹开慧，下次功法升层灵石 -${Math.round(CONFIG.PILLS.DAO_STONE_CUT * 100)}%（剩 ${r.cut} 次）`;
    case "incense": return `引魔香已点燃：下一次离线结算上限 ${CONFIG.OFFLINE_INCENSE_CAP_SEC / 3600} 小时，秘境驻守产出 +${Math.round((CONFIG.OFFLINE_INCENSE_DISPATCH_MULT - 1) * 100)}%`;
    default: return "已使用";
  }
}

// ---------- 界面 ----------
function invCellHtml(idx, filter) {
  invEnsure();
  const st = S.bag.slots[idx];
  if (!st) return `<div class="bag-cell empty"><span class="bag-idx">${idx + 1}</span></div>`;
  const def = invItemDef(st.key);
  if (!def) return `<div class="bag-cell empty"><span class="bag-idx">${idx + 1}</span></div>`;
  const dim = (filter && filter !== "all" && def.cat !== filter) ? " dim" : "";
  const icon = def.icon
    ? `<img class="bag-ico" src="${def.icon}" alt="">`
    : `<span class="bag-char">${esc(def.char || "物")}</span>`;
  const gradeStyle = (def.cat === "gear" && def.color) ? ` style="border-color:${def.color};box-shadow:inset 0 0 0 1px ${def.color}33"` : "";
  return `<button class="bag-cell full${dim}${def.cat === "gear" ? " gear" : ""}"${gradeStyle} data-action="invitem" data-key="${esc(st.key)}">
    ${icon}
    <span class="bag-cnt">${st.n >= 10000 ? "9999+" : fmt(Math.floor(st.n))}</span>
    <span class="bag-nm">${esc(def.name)}</span>
  </button>`;
}

function inventoryHtml(filter) {
  invEnsure();
  const d = invDef();
  const f = filter || "all";
  const cells = [];
  for (let i = 0; i < invSlots(); i++) cells.push(invCellHtml(i, f));
  const nx = invNextDef();
  const upText = nx
    ? `下一级：<b>${esc(nx.name)}</b>（${nx.slots} 格 · 单格 ${nx.stack}）｜ ${fmt(nx.price)} 灵石 ｜ 需 ${CONFIG.REALMS[nx.realm]}期`
    : "已是最高品级：袖里乾坤，纳须弥于芥子";
  const canUp = nx && (S.realm || 0) >= nx.realm && (S.stone || 0) >= nx.price;
  const cats = CONFIG.ITEM_CATS.map(c => `<button class="bag-cat${f === c.key ? " on" : ""}" data-action="invfilter" data-cat="${c.key}">${esc(c.name)}</button>`).join("");
  const owned = invOwnedKeys();
  const empty = owned.length === 0
    ? `<div class="bag-empty-tip">袋中空空。灵田产灵草、炼丹房产丹药、秘境采集与 BOSS 掉落都会自动入袋。</div>`
    : "";
  return `<div class="result inv-modal">
    <div class="result-title">${esc(d.name)}</div>
    <div class="bag-head">
      <span class="bag-grade">${esc(d.grade)}</span>
      <span class="bag-meta">已用 <b>${invUsedSlots()}/${invSlots()}</b> 格 ｜ 单格上限 <b>${d.stack}</b></span>
    </div>
    <div class="bag-own">持有物 ${owned.length} 种：${owned.length ? owned.map(k => { const dd = invItemDef(k); return `<span class="bag-tag">${esc(dd.name)} ×${fmt(Math.floor(invCount(k)))}</span>`; }).join("") : "无"}</div>
    <div class="bag-cats">${cats}</div>
    <div class="bag-grid">${cells.join("")}</div>
    ${empty}
    ${invStashTotal() > 0 ? `<div class="bag-stash">
      <div class="bag-stash-head">袋口暂存 <span class="muted">（袋满时收不进的东西，绝不丢失）</span></div>
      <div class="bag-stash-body">${Object.keys(S.bag.stash || {}).map(k => {
        const dd = invItemDef(k); return `<span class="bag-tag">${esc(dd ? dd.name : k)} ×${fmt(Math.floor(S.bag.stash[k]))}</span>`;
      }).join("")}</div>
      <button class="btn-sm" data-action="invrecall">整理入库</button>
    </div>` : ""}
    <div class="bag-up">${upText}</div>
    <div class="build-row">
      <button class="btn-sm" data-action="invupgrade" ${canUp ? "" : "disabled"}>更换法器</button>
      <button class="btn-sm" data-action="invcompact">整理</button>
    </div>
    <div class="tip">点击格子查看详情：可使用、出售或丢弃。同类物品自动堆叠，单格上限由法器品级决定；袋满时新得物品按 ${Math.round((CONFIG.INV.OVERFLOW_SELL || 0.6) * 100)}% 售价散卖。</div>
    <button class="btn-primary" data-action="closemodal">收起</button>
  </div>`;
}

function showInventory(filter) {
  if (filter) _invFilter = filter;
  showModal(inventoryHtml(_invFilter || "all"));
}

let _invFilter = "all";

function showItemDetail(key) {
  invEnsure();
  const def = invItemDef(key);
  if (!def) return;
  const n = invCount(key);
  if (n < 1) { toast("袋中已无此物"); showInventory(_invFilter); return; }
  const stacks = invStacksOf(key);
  const cap = invStackCap(def);
  const catName = invCatName(def.cat);
  const priceTxt = def.price > 0 ? `${def.price} 灵石/件` : "不可出售";
  let ops = "";
  const usable = ["pill", "tribPill", "qiPill", "breakPill", "healPill", "marrowPill", "daoPill", "incense"];
  if (usable.indexOf(key) >= 0) ops += `<button class="btn-sm" data-action="invuse">使用 1 枚</button>`;
  if (def.cat === "book") ops += `<button class="btn-sm" data-action="tab" data-tab="char">去领悟功法</button>`;
  if (def.cat === "seed") ops += `<button class="btn-sm" data-action="garden">去药园种植</button>`;
  if (def.cat === "frag") {
    // v0.49.0：古宝碎片合成唯一入口就在这里（不再在图鉴里重复开一个合成按钮）
    const need = CONFIG.ANCIENT.FRAG_FOR_ITEM;
    const setKey = def.set;
    const left = CONFIG.ANCIENT_TREASURES.filter(a => a.set === setKey && !ancientOwned(a.key)).length;
    if (left > 0) {
      ops += `<button class="btn-sm" data-action="ancforge" data-set="${setKey}" ${Math.floor(n) >= need ? "" : "disabled"}>合成下一件古宝（${need} 碎片）</button>`;
    } else {
      ops += `<span class="muted">此套已集齐，碎片仅用于升星</span>`;
    }
    ops += `<button class="btn-sm" data-action="ancset" data-set="${setKey}">该套古宝详情</button>`;
  }
  if (def.cat === "gear") {
    ops += `<button class="btn-sm" data-action="invequip" data-aid="${def.aid}">装备</button>`;
    ops += `<button class="btn-sm danger" data-action="invsalvage" data-aid="${def.aid}">分解</button>`;
  }
  if (def.price > 0) {
    ops += `<button class="btn-sm" data-action="invsell" data-n="1">出售 1</button>`;
    ops += `<button class="btn-sm" data-action="invsell" data-n="all">全部出售</button>`;
  }
  ops += `<button class="btn-sm danger" data-action="invdrop" data-n="1">丢弃 1</button>`;
  showModal(`<div class="result">
    <div class="result-title">${esc(def.name)}</div>
    <div class="bag-detail">
      <div class="bag-detail-ico">${def.icon ? `<img src="${def.icon}" alt="">` : esc(def.char || "物")}</div>
      <div class="bag-detail-body">
        <div class="bag-detail-line">类别：${esc(catName)} ｜ 持有：<b>${fmt(Math.floor(n))}</b>（占 ${stacks} 格）</div>
        <div class="bag-detail-line">单格堆叠上限：${cap} ｜ 售价：${esc(priceTxt)}</div>
        <div class="bag-detail-line muted-line">${esc(def.desc || "")}</div>
      </div>
    </div>
    <div class="build-row">${ops}</div>
    <button class="btn-primary" data-action="invback">返回储物袋</button>
  </div>`);
  _invDetailKey = key;
}

let _invDetailKey = null;

// ---------- 兼容旧接口 ----------
// 已领悟功法数（储物袋用）
function gongfaLearnedCount() {
  let n = 0;
  const b = S.gongfaBooks || {};
  for (const k in b) if (b[k] && b[k].learned) n++;
  return n;
}

function invRow(icon, name, count, desc, src, btn, action, extra) {
  return `<div class="inv-row">
    <div class="inv-ico">${icon || "◈"}</div>
    <div class="inv-body">
      <div class="inv-name">${esc(name)} <b>×${fmt(count)}</b></div>
      <div class="inv-desc">${esc(desc)}</div>
      <div class="inv-src">来源：${esc(src)}</div>
    </div>
    ${btn ? `<button class="btn-sm" data-action="${action}" ${extra || ""}>${esc(btn)}</button>` : ""}
  </div>`;
}

// 新手衔接提示：告诉玩家「下一步该做什么」，避免内容多却无处下手
function nextStepHint() {
  const hasArt = (S.artifacts || []).length > 0;
  const forge = (S.buildings && S.buildings.forge) || 0;
  const tal = S.talisman || 0;
  const learned = gongfaLearnedCount();
  if (!hasArt && forge > 0 && (S.materials || 0) >= 10) return { text: "炼器坊已开且灵材充足 · 去炼制第一件法宝", tab: "build" };
  if (!hasArt && forge === 0) return { text: "去洞府解锁炼器坊，才能炼制法宝", tab: "build" };
  if (tal > 0 && learned < CONFIG.GONGFA_BOOKS.length) return { text: `有 ${tal} 本功法要诀 · 去人物页领悟新功法`, tab: "char" };
  if ((S.clearedMaps && Object.keys(S.clearedMaps).length === 0) && (S.bestStage || 0) === 0) return { text: "入秘境探索第一章，通关可得功法要诀", tab: "battle" };
  return null;
}


// 洞府主页库房摘要：仅展示共享储物法器库存，不维护秘境副本库存。
function fieldWarehouseCardHtml() {
  const snap = fieldWarehouseSnapshot();
  const visible = snap.rows.filter(x => x.count > 0);
  const preview = visible.slice(0, 8).map(x => `<span class="bag-tag">${esc(x.name)} ×${fmt(Math.floor(x.count))}${x.stashCount > 0 ? `（袋口 ${fmt(Math.floor(x.stashCount))}）` : ""}</span>`).join("");
  return `<div class="card">
    <div class="build-head"><span class="build-name">洞府统一库房</span><span class="build-lv">${visible.length} 种物品</span></div>
    <div class="build-desc">库存直接读取储物法器；丹药阁、炼器阁和拍卖行后续均从这里扣货，不另建背包、不复制商品。</div>
    <div class="build-out">可用空间 ${snap.usedSlots}/${snap.totalSlots} 格 ｜ 袋口暂存 ${fmt(Math.floor(snap.stashTotal))} 件</div>
    <div class="bag-own">${preview || "库房暂无物品"}${visible.length > 8 ? `<span class="bag-tag">另有 ${visible.length - 8} 种</span>` : ""}</div>
  </div>`;
}
