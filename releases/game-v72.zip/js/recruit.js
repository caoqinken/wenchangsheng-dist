// ============================================================
// 《问长生》弟子与凡人体系 v2（v0.32.0）
// 凡人：驻守秘境繁衍 → 派驻建筑（灵脉师/矿工/药农）→ 招徒选拔
// 秘境：安定度（妖兽余孽与势力骚扰）→ 建庙安抚
// 王朝：宗门 Lv3 + 凡人 100 → 立朝，凡人大兴
// ============================================================

// ---------- 秘境凡人聚落账本（v0.54.2）----------
// S.folk 保留为全局总人口镜像；真实人口按章节存放，招徒与当地建设优先消耗当地人口。
function syncFolkTotal() {
  if (!S.fieldSettlements || typeof S.fieldSettlements !== "object") S.fieldSettlements = { _reserve: 0 };
  let sum = Math.max(0, Number(S.fieldSettlements._reserve) || 0);
  for (const ch in S.fieldSettlements) if (ch !== "_reserve") sum += Math.max(0, Number(S.fieldSettlements[ch].population) || 0);
  S.folk = sum;
  return sum;
}

function ensureFolkLedger() {
  if (!S.fieldSettlements || typeof S.fieldSettlements !== "object" || Array.isArray(S.fieldSettlements)) S.fieldSettlements = {};
  for (const ch in S.fieldSettlements) {
    if (ch === "_reserve") continue;
    const v = S.fieldSettlements[ch] || {};
    S.fieldSettlements[ch] = {
      population: Math.max(0, Number(v.population) || 0),
      foundedAt: typeof v.foundedAt === "string" ? v.foundedAt : "",
      name: typeof v.name === "string" ? v.name : "",
    };
  }
  S.fieldSettlements._reserve = Math.max(0, Number(S.fieldSettlements._reserve) || 0);
  let ledger = S.fieldSettlements._reserve;
  for (const ch in S.fieldSettlements) if (ch !== "_reserve") ledger += S.fieldSettlements[ch].population;
  const total = Math.max(0, Number(S.folk) || 0);
  if (total > ledger) S.fieldSettlements._reserve += total - ledger;
  else if (total < ledger) {
    let remove = ledger - total;
    const fromReserve = Math.min(remove, S.fieldSettlements._reserve);
    S.fieldSettlements._reserve -= fromReserve; remove -= fromReserve;
    const keys = Object.keys(S.fieldSettlements).filter(k => k !== "_reserve").sort().reverse();
    for (const ch of keys) {
      if (remove <= 0) break;
      const take = Math.min(remove, S.fieldSettlements[ch].population);
      S.fieldSettlements[ch].population -= take; remove -= take;
    }
  }
  return syncFolkTotal();
}

function fieldSettlementCap(ch) {
  const base = CONFIG.LABOR.FOLK_CAP_BASE;
  const active = Object.keys(S.mapTeam || {}).filter(k => S.mapTeam[k] && S.mapTeam[k].length && S.clearedMaps && S.clearedMaps[k]).sort((a,b) => Number(a)-Number(b));
  if (!active.includes(String(ch))) return base;
  const extra = Math.max(0, folkCap() - base * active.length);
  const each = Math.floor(extra / active.length);
  const rem = extra % active.length;
  return base + each + (active.indexOf(String(ch)) < rem ? 1 : 0);
}

function fieldSettlementOf(ch, create) {
  ensureFolkLedger();
  const key = String(ch);
  if (!S.fieldSettlements[key] && create !== false) {
    const map = CONFIG.fieldMap(parseInt(key, 10));
    S.fieldSettlements[key] = {
      population: 0,
      foundedAt: typeof gameDayKey === "function" ? gameDayKey() : "",
      name: map ? `${map.name}聚落` : `第${Number(key) + 1}处聚落`,
    };
  }
  const settlement = S.fieldSettlements[key] || null;
  if (settlement && S.fieldSettlements._reserve > 0) {
    const room = Math.max(0, fieldSettlementCap(key) - settlement.population);
    const move = Math.min(room, S.fieldSettlements._reserve);
    settlement.population += move;
    S.fieldSettlements._reserve -= move;
    syncFolkTotal();
  }
  return settlement;
}

function settlementPopulation(ch) {
  const v = fieldSettlementOf(ch, true);
  return v ? v.population : 0;
}

function addFolk(amount, ch) {
  const n = Math.max(0, Number(amount) || 0);
  if (!n) return 0;
  ensureFolkLedger();
  let accepted = 0;
  if (ch !== undefined && ch !== null) {
    const v = fieldSettlementOf(ch, true);
    const room = Math.max(0, fieldSettlementCap(ch) - v.population);
    accepted = Math.min(n, room);
    v.population += accepted;
  } else {
    const active = Object.keys(S.mapTeam || {}).filter(k => S.mapTeam[k] && S.mapTeam[k].length && S.clearedMaps && S.clearedMaps[k]).sort((a,b) => Number(a)-Number(b));
    if (active.length) {
      let left = n;
      for (const key of active) {
        if (left <= 0) break;
        const got = addFolk(left, key);
        accepted += got; left -= got;
      }
      return accepted;
    }
    // 仅用于兼容旧任务/旧档的无归属人口；新驻守产生的人口始终记入具体秘境。
    const room = Math.max(0, folkCap() - S.folk);
    accepted = Math.min(n, room);
    S.fieldSettlements._reserve += accepted;
  }
  syncFolkTotal();
  return accepted;
}

function consumeFolk(amount, ch) {
  const n = Math.max(0, Math.floor(Number(amount) || 0));
  if (!n) return true;
  ensureFolkLedger();
  if (S.folk < n) return false;
  if (ch !== undefined && ch !== null) {
    const v = fieldSettlementOf(ch, true);
    if (!v || v.population < n) return false;
    v.population -= n;
  } else {
    let left = n;
    const reserveTake = Math.min(left, S.fieldSettlements._reserve);
    S.fieldSettlements._reserve -= reserveTake; left -= reserveTake;
    const keys = Object.keys(S.fieldSettlements).filter(k => k !== "_reserve").sort((a,b) => Number(a)-Number(b));
    for (const key of keys) {
      if (left <= 0) break;
      const take = Math.min(left, S.fieldSettlements[key].population);
      S.fieldSettlements[key].population -= take; left -= take;
    }
    if (left > 0) return false;
  }
  syncFolkTotal();
  return true;
}

// ---------- 凡人容量 ----------
function folkCap() {
  const L = CONFIG.LABOR;
  let n = L.FOLK_CAP_BASE * (typeof playerTerritory === "function" ? playerTerritory() : 0);
  if (S.sect && S.sect.lv) n += L.FOLK_CAP_SECT * S.sect.lv;
  if (S.dynasty && S.dynasty.name) n += L.FOLK_CAP_DYNASTY;
  // 城主职务（v0.33.0）：每处 +20
  if (typeof officeCapBonus === "function" && S.mapTeam) {
    for (const ch in S.mapTeam) {
      if (S.mapTeam[ch] && S.mapTeam[ch].length) n += officeCapBonus(ch);
    }
  }
  return n;
}

// ---------- 秘境安定度 ----------
function fieldStableOf(ch) {
  if (!S.fieldStable) S.fieldStable = {};
  if (typeof S.fieldStable[ch] !== "number") S.fieldStable[ch] = CONFIG.STABLE.INIT;
  return S.fieldStable[ch];
}
function addFieldStable(ch, n) {
  if (!S.fieldStable) S.fieldStable = {};
  S.fieldStable[ch] = Math.max(0, Math.min(100, fieldStableOf(ch) + n));
}
// 安定度对产出的乘区（低于 30 减半）
function stableMult(ch) {
  return fieldStableOf(ch) < CONFIG.STABLE.LOW ? CONFIG.STABLE.LOW_MULT : 1;
}

// ---------- 神庙（建庙安抚）----------
function fieldTempleLv(ch) { return (S.fieldTemple && S.fieldTemple[ch]) || 0; }
function templeCost(ch) {
  const T = CONFIG.STABLE;
  return { stone: Math.floor(T.TEMPLE_STONE * Math.pow(T.TEMPLE_GROWTH, fieldTempleLv(ch))), labor: T.TEMPLE_LABOR * (fieldTempleLv(ch) + 1) };
}
function upgradeTemple(ch) {
  if (!S.clearedMaps || !S.clearedMaps[ch]) return { ok: false, msg: "该秘境尚未探明" };
  const lv = fieldTempleLv(ch);
  if (lv >= CONFIG.STABLE.TEMPLE_MAX) return { ok: false, msg: "神庙已至顶级" };
  const c = templeCost(ch);
  if (S.stone < c.stone) return { ok: false, msg: `灵石不足（需 ${fmt(c.stone)}）` };
  if (settlementPopulation(ch) < c.labor && (S.fieldSettlements._reserve || 0) <= 0) return { ok: false, msg: `本地聚落凡人不足（需 ${c.labor} 名工匠）` };
  if (!consumeFolk(c.labor, ch)) return { ok: false, msg: `本地聚落凡人不足（需 ${c.labor} 名工匠）` };
  S.stone -= c.stone;
  if (!S.fieldTemple) S.fieldTemple = {};
  S.fieldTemple[ch] = lv + 1;
  addFieldStable(ch, 15);
  save();
  return { ok: true, lv: lv + 1, cost: c };
}

// 安抚（派人祭祀，提升安定）
function sootheField(ch) {
  const T = CONFIG.STABLE;
  if (!S.clearedMaps || !S.clearedMaps[ch]) return { ok: false, msg: "该秘境尚未探明" };
  if (S.stone < T.SOOTHE_STONE) return { ok: false, msg: `灵石不足（需 ${T.SOOTHE_STONE}）` };
  S.stone -= T.SOOTHE_STONE;
  addFieldStable(ch, T.SOOTHE_ADD);
  save();
  return { ok: true, stable: fieldStableOf(ch) };
}

// 每名驻守秘境每日安定度自然下降（妖兽余孽与势力骚扰）
function stableDailyTick() {
  if (!S.mapTeam) return;
  for (const ch in S.mapTeam) {
    if (!S.mapTeam[ch] || !S.mapTeam[ch].length) continue;
    if (!S.clearedMaps || !S.clearedMaps[ch]) continue;
    addFieldStable(ch, -CONFIG.STABLE.DAILY_DECAY);
  }
}

// ---------- 建筑派驻凡人（工种）----------
const LABOR_ROLE = { vein: "灵脉师", mine: "矿工", garden: "药农" };
function laborNeed(nextLv) { return nextLv * CONFIG.LABOR.PER_BUILD_LEVEL; }
function fieldLaborOf(ch, type) {
  return (S.fieldLabor && S.fieldLabor[ch] && S.fieldLabor[ch][type]) || 0;
}
function addFieldLabor(ch, type, n) {
  if (!S.fieldLabor) S.fieldLabor = {};
  if (!S.fieldLabor[ch]) S.fieldLabor[ch] = { vein: 0, mine: 0, garden: 0 };
  S.fieldLabor[ch][type] = (S.fieldLabor[ch][type] || 0) + n;
}

// ---------- 招徒：秘境凡人聚集地选拔 ----------
function rollSpiritRoot() {
  const dMax = (S.dynasty && S.dynasty.name) ? 5 : 4;   // 天品灵根需立朝
  const pool = CONFIG.SPIRIT_ROOTS.filter(r => r.grade <= dMax);
  const totalW = pool.reduce((s, r) => s + r.w, 0);
  let r = Math.random() * totalW;
  for (const it of pool) {
    r -= it.w;
    if (r <= 0) return it;
  }
  return pool[0];
}

function recruitCandidates(ch) {
  if (!S.clearedMaps || !S.clearedMaps[ch]) return { ok: false, msg: "该秘境尚未探明" };
  if (!dispatchTeam(ch).length) return { ok: false, msg: "需先派弟子驻守，才有凡人聚集地可选拔" };
  if (settlementPopulation(ch) < 1 && (S.fieldSettlements._reserve || 0) < 1) return { ok: false, msg: "该聚落人口不足，继续驻守可繁衍凡人" };
  const list = [];
  for (let i = 0; i < CONFIG.RECRUIT.CANDIDATES; i++) {
    const root = rollSpiritRoot();
    list.push({
      name: CONFIG.DISCIPLE_NAMES[Math.floor(Math.random() * CONFIG.DISCIPLE_NAMES.length)],
      grade: root.grade, root: root.name, cost: root.cost, aptitude: root.aptitude,
      specialty: null,
    });
  }
  S.recruitPool = { ch, day: gameDayKey(), list };
  save();
  return { ok: true, pool: S.recruitPool };
}

function refreshCandidates() {
  const pool = S.recruitPool;
  if (!pool || !Array.isArray(pool.list)) return { ok: false, msg: "请先开山收徒" };
  if (S.stone < CONFIG.RECRUIT.REFRESH_STONE) return { ok: false, msg: "灵石不足" };
  // 先校验全部前置条件，再扣费；失败不允许吞灵石。
  if (!S.clearedMaps || !S.clearedMaps[pool.ch]) return { ok: false, msg: "该秘境尚未探明" };
  if (!dispatchTeam(pool.ch).length) return { ok: false, msg: "需先派弟子驻守，才有凡人聚集地可选拔" };
  if (settlementPopulation(pool.ch) < 1 && (S.fieldSettlements._reserve || 0) < 1) return { ok: false, msg: "该聚落人口不足，继续驻守可繁衍凡人" };
  S.stone -= CONFIG.RECRUIT.REFRESH_STONE;
  const r = recruitCandidates(pool.ch);
  if (r.ok) r.cost = CONFIG.RECRUIT.REFRESH_STONE;
  else S.stone += CONFIG.RECRUIT.REFRESH_STONE;
  save();
  return r;
}

function hireCandidate(idx) {
  const pool = S.recruitPool;
  if (!pool || !pool.list || !pool.list[idx]) return { ok: false, msg: "候选不存在" };
  if (!S.clearedMaps || !S.clearedMaps[pool.ch]) return { ok: false, msg: "该秘境尚未探明" };
  if (!dispatchTeam(pool.ch).length) return { ok: false, msg: "需先派弟子驻守，才有凡人聚集地可选拔" };
  if (S.disciples.length >= discipleSlots()) {
    return { ok: false, msg: `弟子名额已满（${discipleSlots()}）· 辟建洞府/提升境界/升宗可扩招` };
  }
  const cand = pool.list[idx];
  if (S.stone < cand.cost) return { ok: false, msg: `灵石不足（需 ${fmt(cand.cost)}）` };
  if (settlementPopulation(pool.ch) < 1 && (S.fieldSettlements._reserve || 0) < 1) return { ok: false, msg: "该聚落人口不足（需 1 名）" };
  if (!consumeFolk(1, pool.ch)) return { ok: false, msg: "该聚落人口不足（需 1 名）" };
  S.stone -= cand.cost;
  // 用现有个体生成器，资质取灵根品级
  const d = createDisciple();
  d.name = cand.name;
  d.aptitude = cand.aptitude;
  d.specialty = rollSpecialty();
  d.root = cand.root;
  S.disciples.push(d);
  pool.list.splice(idx, 1);
  save();
  return { ok: true, disciple: d };
}

// ---------- 立朝（凡间王朝）----------
function dynastyReady() {
  return !!(S.sect && S.sect.lv >= CONFIG.DYNASTY.NEED_SECT)
    && (S.folk || 0) >= CONFIG.DYNASTY.NEED_FOLK;
}
function foundDynasty(name) {
  if (S.dynasty && S.dynasty.name) return { ok: false, msg: "已立王朝" };
  if (!dynastyReady()) {
    return { ok: false, msg: `需宗门 Lv.${CONFIG.DYNASTY.NEED_SECT} 且凡人 ≥ ${CONFIG.DYNASTY.NEED_FOLK}（当前凡人 ${Math.floor(S.folk || 0)}）` };
  }
  if (S.stone < CONFIG.DYNASTY.STONE) return { ok: false, msg: `灵石不足（需 ${fmt(CONFIG.DYNASTY.STONE)}）` };
  S.stone -= CONFIG.DYNASTY.STONE;
  S.dynasty = { name: (name || "大衍王朝").slice(0, 8) };
  save();
  return { ok: true, dynasty: S.dynasty };
}
function dynastySummary() {
  if (!S.dynasty || !S.dynasty.name) return "未立王朝";
  return `${S.dynasty.name} ｜ 凡人繁衍 ×${CONFIG.DYNASTY.FOLK_MULT} ｜ 弟子名额 +${CONFIG.SLOTS.DYNASTY} ｜ 全属性 +${Math.round(CONFIG.DYNASTY.ATTR * 100)}%`;
}
