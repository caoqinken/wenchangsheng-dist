// ============================================================
// 《问长生》战斗系统：关卡推图 + 结算 + 掉落
// v0.15.0 起本文件负责「速战（按公式一键结算）」；实时战斗见 js/battle2.js
// ============================================================

// 模拟一场自动战斗（每秒一轮互击，含法宝词条：暴击/吸血/反伤）
// v0.8.0：抽出 simulateBattleWith(eAtk, eDef, eHp)，供关卡与试炼塔共用，避免两套战斗逻辑漂移
// v0.15.0：本函数仍是「速战」与「试炼塔」的唯一数值来源，战斗 v2 的期望 DPS 必须与之等价
function simulateBattleWith(eAtk, eDef, eHp) {
  const p = playerCombat();
  const _af = (typeof artifactAffix === "function")
    ? artifactAffix()
    : { crit: 0, lifesteal: 0, thorns: 0 };
  // 功法「会心」「噬血」与法宝词条合并（v0.20.0），并沿用同一上限
  const _gf = (typeof gongfaBonus === "function") ? gongfaBonus() : { crit: 0, lifesteal: 0 };
  const af = {
    crit: Math.min(_af.crit + (_gf.crit || 0), CONFIG.AFFIX_CAP.crit),
    lifesteal: Math.min(_af.lifesteal + (_gf.lifesteal || 0), CONFIG.AFFIX_CAP.lifesteal),
    thorns: _af.thorns,
  };
  const pBase = Math.max(p.attack - eDef, p.attack * 0.05);
  const eBase = Math.max(eAtk - p.defense, eAtk * 0.05);
  let pHp = p.hp, eHpCur = eHp, rounds = 0, crits = 0;
  const maxRounds = 2000;
  while (pHp > 0 && eHpCur > 0 && rounds < maxRounds) {
    // --- 我方出手 ---
    let dmg = pBase;
    if (af.crit > 0 && Math.random() < af.crit) { dmg *= CONFIG.AFFIX_CRIT_MULT; crits++; }
    const before = eHpCur;
    eHpCur -= dmg;
    // 吸血：按实际造成的伤害回复气血
    if (af.lifesteal > 0) {
      const real = Math.min(before, dmg);
      pHp = Math.min(p.hp, pHp + real * af.lifesteal);
    }
    if (eHpCur <= 0) break;
    // --- 敌方出手 ---
    pHp -= eBase;
    // 反伤：受击反弹
    if (af.thorns > 0) eHpCur -= eBase * af.thorns;
    rounds++;
  }
  return { win: eHpCur <= 0, rounds: Math.min(rounds + 1, maxRounds), pDmg: pBase, eDmg: eBase, enemyHp: eHp, crits };
}

// 关卡战斗（沿用原参数）
function simulateBattle(n) {
  return simulateBattleWith(CONFIG.enemyAttack(n), CONFIG.enemyDefense(n), CONFIG.enemyHp(n));
}

// 通关结算（v0.15.0 抽出：速战与亲征共用同一套掉落/进度/剧情逻辑，避免两套漂移）
function settleStageWin(n) {
  const isBoss = CONFIG.isBoss(n);
  let stones = Math.floor(CONFIG.stoneDrop(n, isBoss));
  // 势力庇护：与魔渊宗关系达标，灵石掉落 +20%
  if (blessed("moyuan")) stones = Math.floor(stones * 1.2);
  S.stone += stones;
  if (n + 1 > S.bestStage) S.bestStage = n + 1;
  // 累计战绩（供道途录成就判定，v0.6.5）
  if (!S.stats) S.stats = { battleWins: 0, bossWins: 0 };
  S.stats.battleWins = (S.stats.battleWins || 0) + 1;
  if (isBoss) S.stats.bossWins = (S.stats.bossWins || 0) + 1;
  // 掉落：小怪 30% 掉灵草，BOSS 必掉丹药；另独立掉落灵材（法宝原料，v0.6.0）
  let dropText = "";
  let story = null;
  if (isBoss) {
    // v0.38.0：BOSS 掉秘籍（未学功法）或残卷
    const _ch = CONFIG.chapterOf(n);
    const _maxTier = CONFIG.BOOK_DROP_TIER[_ch] || 1;
    const _pool = CONFIG.GONGFA_BOOKS.filter(b => b.tier <= _maxTier && !gongfaLearned(b.key));
    if (_pool.length && Math.random() < 0.6) {
      const _b = _pool[Math.floor(Math.random() * _pool.length)];
      gainItem("book:" + _b.key, 1);
      dropText = "《" + _b.name + "》秘籍";
    } else {
      gainItem("talisman", 1);
      dropText = "功法残卷 ×1";
    }
    if (Math.random() < 0.5) {
      gainItem("pill", 1);
      dropText += "、培元丹 ×1";
    }
    // 章节叙事（v0.11.0）：首次通关该章 BOSS 时解锁一次性剧情
    const chIdx = CONFIG.chapterOf(n);
    const chDef = CONFIG.CHAPTERS[chIdx];
    // 注意：storySeen 不在此处写入。若玩家弹窗未选就离开，
    // 下次通关同一章 BOSS 应再次弹出（选择未完成＝剧情未过）。
    if (chDef && chDef.story) {
      if (!S.storySeen) S.storySeen = {};
      if (!S.storySeen[chIdx]) story = Object.assign({ ch: chIdx }, chDef.story);
    }
    // 妖兽 / 秘境图鉴（v0.8.0）：击杀该章末关 BOSS 收录
    const ch = CONFIG.chapterOf(n);
    const beast = CONFIG.CODEX_BEASTS.find(b => b.chapter === ch);
    if (beast && typeof recordBeastCodex === "function") recordBeastCodex(beast.key);
    const region = CONFIG.CODEX_REGIONS.find(r => r.chapter === ch);
    if (region && typeof recordRegionCodex === "function") recordRegionCodex(region.key);
  }
  else if (Math.random() < 0.3) { gainItem("herb", 1); dropText = "灵草 ×1"; }
  const matDrop = isBoss
    ? CONFIG.MATERIAL_BOSS_DROP
    : (Math.random() < CONFIG.MATERIAL_DROP_CHANCE ? 1 : 0);
  if (matDrop > 0) {
    gainItem("material", matDrop);
    dropText += (dropText ? "、" : "") + "灵材 ×" + matDrop;
  }
  save();
  return { stones, isBoss, dropText, story };
}

// 挑战关卡 n（速战：按公式一键结算，与旧版本行为完全一致）
function startBattle(n) {
  if (S.stamina < 1) return { ok: false, msg: "体力不足，请稍候恢复" };
  S.stamina--;
  const r = simulateBattle(n);
  if (r.win) {
    const st = settleStageWin(n);
    return Object.assign(
      { ok: true, win: true, rounds: r.rounds, pDmg: r.pDmg, eDmg: r.eDmg },
      st
    );
  } else {
    save();
    return { ok: true, win: false, rounds: r.rounds, pDmg: r.pDmg, eDmg: r.eDmg, enemyHp: r.enemyHp };
  }
}

// 亲征（v0.15.0）：只扣体力，实际战斗在 UI 层实时进行；结束后由 UI 调 settleStageWin
function startBattleManual(n) {
  if (S.stamina < 1) return { ok: false, msg: "体力不足，请稍候恢复" };
  S.stamina--;
  save();
  return { ok: true };
}

// 关卡显示名
function stageName(n) {
  const ch = CONFIG.chapterOf(n);
  const chName = CONFIG.CHAPTERS[ch] ? CONFIG.CHAPTERS[ch].name : "未知秘境";
  if (CONFIG.isBoss(n)) return chName + " · BOSS";
  return chName + " · 第" + (n % (CONFIG.STAGES_PER_CHAPTER + 1) + 1) + "关";
}

// 推荐战力提示（怪物战力）
function enemyPower(n) {
  return CONFIG.enemyAttack(n) * 10 + CONFIG.enemyDefense(n) * 8 + CONFIG.enemyHp(n) * 0.5;
}
