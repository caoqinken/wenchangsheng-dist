// ============================================================
// 《问长生》秘境统一身份层（v0.58.0 P0）
// 只提供统一身份与旧账本读取入口；本阶段不迁移业务数据。
// ============================================================

function realmIdForChapter(ch) {
  const n = Number(ch);
  return Number.isInteger(n) && n >= 0 ? "field_" + n : null;
}

function realmChapterOf(ref) {
  if (typeof ref === "number" && Number.isInteger(ref) && ref >= 0) return String(ref);
  const value = String(ref == null ? "" : ref);
  if (/^field_\d+$/.test(value)) return value.slice(6);
  if (/^\d+$/.test(value)) return String(Number(value));
  return null;
}

function realmOf(ref, create) {
  const ch = realmChapterOf(ref);
  if (ch == null) return null;
  if (!S.realms || typeof S.realms !== "object") S.realms = {};
  const id = "field_" + ch;
  if (!S.realms[id]) S = migrateState(S);
  return S.realms[id] || null;
}

function realmLegacyData(ref, moduleKey) {
  const realm = realmOf(ref, false);
  if (!realm || !realm.legacyBindings) return null;
  const source = realm.legacyBindings[moduleKey];
  if (!source || !S[source] || typeof S[source] !== "object") return null;
  return S[source][realm.sourceChapter] == null ? null : S[source][realm.sourceChapter];
}

function realmIsPrivate(ref) {
  const realm = realmOf(ref, false);
  return !!realm && realm.status === "private" && realm.ownership === "player";
}

function realmList(options) {
  const opts = options || {};
  S = migrateState(S); // 同步本次运行中新探明/新经营的秘境身份，不复制业务数据。
  const list = Object.values(S.realms || {});
  return list.filter(r => r && (!opts.privateOnly || r.status === "private"))
    .sort((a, b) => Number(a.sourceChapter) - Number(b.sourceChapter));
}

function realmRename(ref, name) {
  const realm = realmOf(ref, false);
  const clean = String(name == null ? "" : name).trim().slice(0, 24);
  if (!realm || !clean) return { ok: false, msg: "秘境或名称无效" };
  realm.name = clean;
  save();
  return { ok: true, name: clean };
}
