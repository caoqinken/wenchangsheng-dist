// ============================================================
// 《问长生》修炼方向（v0.29.0）
// 体修 / 法修 / 剑修 / 体法双修：影响攻击、防御、气血、修炼速率、真元
// ============================================================

function daoDef(key) {
  return (CONFIG.DAO_PATHS || []).find(d => d.key === key) || CONFIG.DAO_PATHS[0];
}

// 更换道途：原型期免费（一测期给玩家试错空间），后续可加洗髓成本
function setDao(key) {
  const def = (CONFIG.DAO_PATHS || []).find(d => d.key === key);
  if (!def) return { ok: false, msg: "无效道途" };
  S.dao = key;
  save();
  return { ok: true, path: def };
}

// 道途差异摘要（UI 用）
function daoSummary(key) {
  const d = daoDef(key);
  const parts = [];
  const pct = v => (v >= 1 ? "+" : "") + Math.round((v - 1) * 100) + "%";
  if (d.atk !== 1) parts.push("攻 " + pct(d.atk));
  if (d.def !== 1) parts.push("防 " + pct(d.def));
  if (d.hp !== 1) parts.push("血 " + pct(d.hp));
  if (d.cult !== 1) parts.push("修炼 " + pct(d.cult));
  if (d.mana !== 1) parts.push("真元 " + pct(d.mana));
  return parts.join(" ｜ ");
}
