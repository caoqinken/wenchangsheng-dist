// ============================================================
// 《问长生》秘境战场渲染（v0.16.0）
// Canvas 2D 等轴测投影 + 圆形图标 + 技能特效
// 只画，不算逻辑
// ============================================================

const FLDV = {
  canvas: null, ctx: null,
  w: 0, h: 0, dpr: 1,
  field: null,
  camX: 0, camY: 0,
  floaters: [],
  bursts: [],
  cones: [],
  warns: [],
  trails: [],
  bgImg: null,
  bgReady: false,
  shake: 0,
  t: 0,
  aim: { x: 0, y: -1 },   // 当前瞄准方向（由操作层每帧写入）
  avatarImg: null,        // 角色形象（v0.22.0）
  avatarReady: false,
};

const FLDV_COLORS = {
  ground: "#1E1B17",
  grid: "rgba(150,135,110,0.10)",
  border: "rgba(176,138,62,0.35)",
  player: "#5C7A6E",
  playerRing: "#8FB3A2",
  normal: "#7A4A3A",
  elite: "#A93F2E",
  boss: "#5A2E4A",
  hp: "#8B2E4A",
  warn: "#A93F2E",
};

// ---------- 投影 ----------
function flvSX(wx, wy) {
  const F = CONFIG.FIELD;
  return (wx - FLDV.camX - (wy - FLDV.camY)) * F.ISO_X + FLDV.w / 2;
}
function flvSY(wx, wy) {
  const F = CONFIG.FIELD;
  return (wx - FLDV.camX + (wy - FLDV.camY)) * F.ISO_Y + FLDV.h / 2;
}
function flvToWorld(sx, sy) {
  const F = CONFIG.FIELD;
  const ix = (sx - FLDV.w / 2) / F.ISO_X;
  const iy = (sy - FLDV.h / 2) / F.ISO_Y;
  return {
    x: (ix + iy) / 2 + FLDV.camX,
    y: (iy - ix) / 2 + FLDV.camY,
  };
}

// ---------- 初始化 ----------
function flvInit(canvas, field) {
  FLDV.canvas = canvas;
  FLDV.ctx = canvas.getContext("2d");
  FLDV.field = field;
  // 每次进秘境都会新建 canvas 元素（默认 300×150）。
  // 若不清理上一次的尺寸缓存，flvResize 会判定「尺寸没变」直接 return，
  // 新画布就停在 300×150 被 CSS 拉伸成竖长畸形 —— 二次进图的必现 bug。
  FLDV.w = 0;
  FLDV.h = 0;
  FLDV.dpr = 0;
  FLDV.camX = field.player.x;
  FLDV.camY = field.player.y;
  FLDV.floaters = [];
  FLDV.bursts = [];
  FLDV.cones = [];
  FLDV.warns = [];
  FLDV.trails = [];
  FLDV.shake = 0;
  FLDV.bgReady = false;
  FLDV.drawErrors = 0;
  flvResize();

  // 角色头像（v0.22.0）：加载后用于圆形图标内填充
  if (typeof currentAvatar === "function") {
    const av = new Image();
    av.onload = () => { if (FLDV.avatarImg === av) FLDV.avatarReady = true; };
    av.src = currentAvatar().img;
    FLDV.avatarImg = av;
    FLDV.avatarReady = false;
  }

  const img = new Image();
  // 只认当前这张图，避免二次进图时旧图的 onload 抢先置位
  img.onload = () => { if (FLDV.bgImg === img) FLDV.bgReady = true; };
  img.src = field.map.bg || "assets/秘境_青云山门.webp";
  FLDV.bgImg = img;
}

function flvResize(force) {
  const c = FLDV.canvas;
  if (!c) return;
  const rect = c.getBoundingClientRect();
  let w = Math.round(rect.width || c.clientWidth || 0);
  let h = Math.round(rect.height || c.clientHeight || 0);
  // 元素刚插入 DOM 时布局可能还没算，rect 为 0。
  // 此时绝不能直接 return —— 画布会停在浏览器默认的 300×150，
  // 被 CSS 拉伸到全屏后就是竖长畸形的根因。退回视口尺寸保证可用。
  if (!w || !h) {
    w = Math.round(window.innerWidth || 390);
    h = Math.round(window.innerHeight || 700);
  }
  if (!w || !h) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const pw = Math.round(w * dpr);
  const ph = Math.round(h * dpr);
  // 以画布真实像素为准判断是否需要重置：
  // 移动端地址栏伸缩会高频触发 resize，重置 canvas 会造成整屏闪动；
  // 而元素被重建时真实像素对不上，必须重建（不能只看缓存值）
  if (!force && c.width === pw && c.height === ph && dpr === FLDV.dpr) {
    FLDV.w = w;
    FLDV.h = h;
    return;
  }
  FLDV.dpr = dpr;
  FLDV.w = w;
  FLDV.h = h;
  c.width = pw;
  c.height = ph;
  FLDV.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

// ---------- 事件 → 特效 ----------
function flvOnEvent(ev) {
  const F = FLDV;
  if (ev.type === "cast") {
    if (ev.shape === "cone") {
      F.cones.push({ x: ev.x, y: ev.y, dx: ev.dx, dy: ev.dy, range: ev.range, angle: ev.angle || 1, color: ev.color, t: 0, life: 0.45 });
    } else if (ev.shape === "nova") {
      F.bursts.push({ x: ev.x, y: ev.y, r0: 10, r1: ev.range || 160, color: ev.color, t: 0, life: 0.5, ring: true });
    } else if (ev.shape === "line") {
      F.bursts.push({ x: ev.x, y: ev.y, r0: 6, r1: 26, color: ev.color, t: 0, life: 0.2, ring: true });
    }
  } else if (ev.type === "elem_gen") {
    const fn = (typeof elementDef === "function" && elementDef(ev.from)) ? elementDef(ev.from).name : "";
    const tn = (typeof elementDef === "function" && elementDef(ev.to)) ? elementDef(ev.to).name : "";
    F.floaters.push({
      x: F.field && F.field.player ? F.field.player.x : 0,
      y: (F.field && F.field.player ? F.field.player.y : 0) - 40,
      text: `${fn}生${tn} +${Math.round((ev.mult || 0) * 100)}%`,
      color: "#B08A3E", big: true, t: 0, life: 1.0,
    });
  } else if (ev.type === "hit") {
    F.floaters.push({
      x: ev.x, y: ev.y, text: "-" + fmt(ev.dmg),
      color: ev.toPlayer ? "#C1543A" : (ev.crit ? "#A93F2E" : "#E4D9C4"),
      big: ev.crit || ev.toPlayer, t: 0, life: 0.85,
    });
    if (ev.absorbed > 0) {
      F.floaters.push({ x: ev.x, y: ev.y - 18, text: "盾 " + fmt(ev.absorbed), color: "#3E7EB8", t: 0, life: 0.8 });
    }
    if (ev.crit) F.shake = 1;
  } else if (ev.type === "aoeWarn") {
    F.warns.push({ x: ev.x, y: ev.y, r: ev.r, dur: ev.dur || 1, t: 0, boss: ev.boss, kind: ev.kind || (ev.boss ? "boss" : "elite"), srcX: ev.srcX, srcY: ev.srcY });
  } else if (ev.type === "aoeBurst") {
    F.bursts.push({ x: ev.x, y: ev.y, r0: ev.r * 0.6, r1: ev.r, color: "#A93F2E", t: 0, life: 0.4, ring: true, fill: true });
    F.shake = 1.4;
  } else if (ev.type === "heal") {
    F.floaters.push({ x: ev.x, y: ev.y - 14, text: "+" + fmt(ev.amount), color: "#5EA07E", t: 0, life: 0.9 });
    for (let i = 0; i < 8; i++) {
      F.trails.push({ x: ev.x + (Math.random() - 0.5) * 40, y: ev.y + (Math.random() - 0.5) * 40, vx: 0, vy: -30 - Math.random() * 30, life: 0.7, color: "#5EA07E" });
    }
  } else if (ev.type === "shield") {
    F.floaters.push({ x: ev.x, y: ev.y - 14, text: "护盾 " + fmt(ev.amount), color: "#3E7EB8", t: 0, life: 0.9 });
    F.bursts.push({ x: ev.x, y: ev.y, r0: 14, r1: 52, color: "#3E7EB8", t: 0, life: 0.45, ring: true });
  } else if (ev.type === "death") {
    F.bursts.push({ x: ev.x, y: ev.y, r0: 4, r1: ev.r * 2.4, color: "#7A4A3A", t: 0, life: 0.5, ring: true, fill: true });
    for (let i = 0; i < 10; i++) {
      F.trails.push({ x: ev.x, y: ev.y, vx: (Math.random() - 0.5) * 90, vy: (Math.random() - 0.5) * 90, life: 0.5, color: "#8B5A4A" });
    }
  } else if (ev.type === "petcast") {
    F.trails.push({
      x: ev.x, y: ev.y,
      vx: (ev.tx - ev.x) * 2.2, vy: (ev.ty - ev.y) * 2.2,
      color: ev.color, t: 0, life: 0.32,
    });
  } else if (ev.type === "capture") {
    // 收服成功/失败：金色光环或灰白消散
    F.floaters.push({
      x: ev.x, y: ev.y - 26,
      text: ev.ok ? ("收服 " + (ev.name || "灵兽") + "！") : "逃走了…",
      color: ev.ok ? "#D8B65A" : "#7C7365",
      big: !!ev.ok, t: 0, life: 1.3,
    });
    F.bursts.push({
      x: ev.x, y: ev.y, r0: 10, r1: ev.ok ? 90 : 46,
      color: ev.ok ? "#D8B65A" : "#7C7365", t: 0, life: 0.6, ring: true,
    });
    if (ev.ok) F.shake = 2;
  } else if (ev.type === "gathered") {
    F.floaters.push({ x: ev.x, y: ev.y - 10, text: ev.text, color: ev.color, big: false, t: 0, life: 1.0 });
    F.bursts.push({ x: ev.x, y: ev.y, r0: 8, r1: 46, color: ev.color, t: 0, life: 0.45, ring: true });
    for (let i = 0; i < 6; i++) {
      F.trails.push({
        x: ev.x + (Math.random() - 0.5) * 30, y: ev.y,
        vx: (Math.random() - 0.5) * 40, vy: -40 - Math.random() * 40,
        life: 0.6, color: ev.color,
      });
    }
  } else if (ev.type === "portal") {
    F.bursts.push({ x: ev.x, y: ev.y, r0: 10, r1: 90, color: "#D8B65A", t: 0, life: 0.7, ring: true });
    F.floaters.push({ x: ev.x, y: ev.y - 20, text: "传送阵开启", color: "#D8B65A", big: true, t: 0, life: 1.2 });
  } else if (ev.type === "trail") {
    F.trails.push({ x: ev.x, y: ev.y, vx: 0, vy: 0, life: 0.3, color: "rgba(143,179,162,0.55)" });
  } else if (ev.type === "dash") {
    F.bursts.push({ x: ev.x, y: ev.y, r0: 8, r1: 40, color: "#8FB3A2", t: 0, life: 0.32, ring: true });
  } else if (ev.type === "end" && !ev.win) {
    F.shake = 2;
  }
}

// ---------- 主绘制 ----------
function flvDraw(dt) {
  const ctx = FLDV.ctx;
  const f = FLDV.field;
  if (!ctx || !f) return;
  // 画布自愈：物理像素与显示尺寸不符就重建（每 15 帧查一次，开销可忽略）。
  // 覆盖「首帧布局未完成 / 设备旋转 / 键盘弹出 / 二次进入」等一切时序问题。
  if (FLDV.canvas) {
    FLDV.chk = (FLDV.chk | 0) + 1;
    if (FLDV.chk >= 15) {
      FLDV.chk = 0;
      const cw = Math.round(FLDV.canvas.clientWidth || 0);
      const chh = Math.round(FLDV.canvas.clientHeight || 0);
      if (cw && chh && (Math.abs(cw - FLDV.w) > 1 || Math.abs(chh - FLDV.h) > 1)) flvResize(true);
    }
  }

  const W = FLDV.w, H = FLDV.h;
  if (!W || !H) return;
  FLDV.t += dt;

  // 摄像机平滑跟随：加死区（<0.6 单位不动）消除亚像素抖动，并做 NaN 兜底
  const camDx = f.player.x - FLDV.camX;
  const camDy = f.player.y - FLDV.camY;
  if (!isFinite(FLDV.camX) || !isFinite(FLDV.camY)) {
    FLDV.camX = f.player.x;
    FLDV.camY = f.player.y;
  } else if (Math.abs(camDx) > 0.6 || Math.abs(camDy) > 0.6) {
    const k = Math.min(1, dt * 8);
    FLDV.camX += camDx * k;
    FLDV.camY += camDy * k;
  }

  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = FLDV_COLORS.ground;
  ctx.fillRect(0, 0, W, H);

  ctx.save();
  if (FLDV.shake > 0) {
    const amp = Math.min(2, FLDV.shake) * 4;
    ctx.translate((Math.random() - 0.5) * amp, (Math.random() - 0.5) * amp);
    FLDV.shake = Math.max(0, FLDV.shake - dt * 9);   // 更快衰减，避免残留
  }

  if (FLDV.bgReady && FLDV.bgImg) {
    ctx.globalAlpha = 0.10;
    ctx.drawImage(FLDV.bgImg, 0, 0, W, H);
    ctx.globalAlpha = 1;
  }

  flvDrawGround(ctx, f);
  flvDrawNodes(ctx, f);
  flvDrawPortal(ctx, f);
  flvDrawAimCone(ctx, f, FLDV.aim);
  flvDrawNodeGuide(ctx, f);
  flvDrawWarns(ctx, dt);

  const drawables = [];
  for (const m of f.monsters) if (m.alive) drawables.push({ y: m.y, kind: "mon", obj: m });
  if (f.pet) drawables.push({ y: f.pet.y, kind: "pet", obj: f.pet });
  drawables.push({ y: f.player.y, kind: "player", obj: f.player });
  drawables.sort((a, b) => a.y - b.y);

  for (const d of drawables) {
    if (d.kind === "mon") flvDrawMonster(ctx, d.obj);
    else if (d.kind === "pet") flvDrawPet(ctx, d.obj);
    else flvDrawPlayer(ctx, d.obj);
  }

  flvDrawProjectiles(ctx, f);
  flvDrawCones(ctx, dt);
  flvDrawBursts(ctx, dt);
  flvDrawTrails(ctx, dt);
  flvDrawFloaters(ctx, dt);

  ctx.restore();
}

function flvDrawGround(ctx, f) {
  const step = 100;
  const size = f.size;
  ctx.strokeStyle = FLDV_COLORS.grid;
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let x = 0; x <= size; x += step) {
    ctx.moveTo(flvSX(x, 0), flvSY(x, 0));
    ctx.lineTo(flvSX(x, size), flvSY(x, size));
  }
  for (let y = 0; y <= size; y += step) {
    ctx.moveTo(flvSX(0, y), flvSY(0, y));
    ctx.lineTo(flvSX(size, y), flvSY(size, y));
  }
  ctx.stroke();

  ctx.strokeStyle = FLDV_COLORS.border;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(flvSX(0, 0), flvSY(0, 0));
  ctx.lineTo(flvSX(size, 0), flvSY(size, 0));
  ctx.lineTo(flvSX(size, size), flvSY(size, size));
  ctx.lineTo(flvSX(0, size), flvSY(0, size));
  ctx.closePath();
  ctx.stroke();
}

// 采集节点：矿脉 / 灵脉 / 灵植 / 遗迹
function flvDrawNodes(ctx, f) {
  for (const n of f.nodes) {
    const sx = flvSX(n.x, n.y), sy = flvSY(n.x, n.y);
    const t = FLDV.t;
    ctx.save();

    if (n.done) {
      ctx.globalAlpha = 0.22;
      ctx.fillStyle = n.color;
      ctx.beginPath(); ctx.arc(sx, sy, n.r * 0.6, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      continue;
    }

    // 光晕呼吸
    const pulse = 0.5 + Math.sin(t * 2.4 + n.id) * 0.28;
    ctx.globalAlpha = 0.22 * pulse;
    ctx.fillStyle = n.glow;
    ctx.beginPath(); ctx.arc(sx, sy, n.r * 2.0, 0, Math.PI * 2); ctx.fill();

    // 地面投影
    ctx.globalAlpha = 0.25;
    ctx.fillStyle = "#000";
    ctx.beginPath(); ctx.ellipse(sx, sy + n.r * 0.7, n.r * 0.9, n.r * 0.4, 0, 0, Math.PI * 2); ctx.fill();

    // 主体
    ctx.globalAlpha = 1;
    ctx.fillStyle = n.color;
    ctx.strokeStyle = n.glow;
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(sx, sy, n.r * 0.85, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // 内部符号
    ctx.fillStyle = n.glow;
    if (n.kind === "ore") {
      ctx.beginPath();
      ctx.moveTo(sx, sy - 6); ctx.lineTo(sx + 6, sy);
      ctx.lineTo(sx, sy + 6); ctx.lineTo(sx - 6, sy);
      ctx.closePath(); ctx.fill();
    } else if (n.kind === "vein") {
      for (let k = 0; k < 3; k++) {
        ctx.globalAlpha = 0.85 - k * 0.22;
        ctx.beginPath(); ctx.arc(sx, sy, 3 + k * 4, 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 1;
    } else if (n.kind === "herb") {
      for (let k = 0; k < 3; k++) {
        const a = -Math.PI / 2 + (k - 1) * 0.9;
        ctx.beginPath();
        ctx.arc(sx + Math.cos(a) * 5, sy + Math.sin(a) * 5, 2.4, 0, Math.PI * 2);
        ctx.fill();
      }
    } else {
      ctx.fillRect(sx - 4, sy - 7, 8, 14);
      ctx.globalAlpha = 0.5;
      ctx.fillRect(sx - 7, sy + 5, 14, 3);
      ctx.globalAlpha = 1;
    }

    // 采集进度环
    if (n.progress > 0) {
      const p = Math.min(1, n.progress / n.gatherTime);
      ctx.strokeStyle = "rgba(0,0,0,0.35)";
      ctx.lineWidth = 4;
      ctx.beginPath(); ctx.arc(sx, sy, n.r + 9, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = "#E8DCC4";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(sx, sy, n.r + 9, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p);
      ctx.stroke();
    }

    ctx.restore();
  }
}

// 传送阵（探索度 ≥80 出现）
function flvDrawPortal(ctx, f) {
  if (!f.portal) return;
  const sx = flvSX(f.portal.x, f.portal.y);
  const sy = flvSY(f.portal.x, f.portal.y);
  const t = FLDV.t;
  const R = CONFIG.FIELD_PORTAL_R;

  ctx.save();
  ctx.globalAlpha = 0.55 + Math.sin(t * 3) * 0.2;
  ctx.strokeStyle = "#D8B65A";
  ctx.lineWidth = 3;
  ctx.beginPath(); ctx.ellipse(sx, sy, R * 1.35, R * 0.68, 0, 0, Math.PI * 2); ctx.stroke();

  ctx.globalAlpha = 0.28;
  ctx.beginPath(); ctx.ellipse(sx, sy, R * 0.9, R * 0.45, 0, 0, Math.PI * 2); ctx.stroke();

  for (let i = 0; i < 6; i++) {
    const a = t * 0.9 + i * Math.PI / 3;
    ctx.globalAlpha = 0.85;
    ctx.fillStyle = "#E8DCC4";
    ctx.beginPath();
    ctx.arc(sx + Math.cos(a) * R * 1.15, sy + Math.sin(a) * R * 0.58, 3, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

// 瞄准指示（v0.25.0：扇形底 + 弹道虚线 + 落点圈 + 目标锁定圈）
// 指向怪物=红、指向资源=金、其余=淡绿；内深外淡
function flvDrawAimCone(ctx, f, aim) {
  if (!aim || !f || !f.player) return;
  const p = f.player;
  const sx = flvSX(p.x, p.y), sy = flvSY(p.x, p.y);
  let range = 200;
  let half = 0.52;                   // 半角 ≈ 30°
  let shape = "cone";
  let width = 46;
  let lockType = "area";
  // 正在拖拽技能 → 用该技能的真实射程/形状绘制弹道
  try {
    if (typeof FS !== "undefined" && FS && FS.dragging) {
      const def = (CONFIG.FIELD_SKILLS || []).find(s => s.key === FS.dragging);
      if (def) {
        shape = def.shape || "cone";
        lockType = def.lock || "area";
        range = def.range || range;
        if (shape === "cone") half = Math.max(0.3, (def.angle || 1.0) / 2);
        if (shape === "line") width = def.width || width;
      }
    }
  } catch (e) { /* 渲染层容错：技能配置缺失时退回默认 */ }
  const ang = Math.atan2(aim.y, aim.x);
  const isoYK = CONFIG.FIELD.ISO_Y / CONFIG.FIELD.ISO_X;

  // 强锁（v0.26.0）：不做方向扇形，直接锁定最近敌人并画追踪线
  if (lockType === "target") {
    const locked = (typeof fldNearest === "function")
      ? fldNearest(f, p.x, p.y, CONFIG.FIELD.SKILL_LOCK_MAX_RANGE) : null;
    ctx.save();
    if (!locked) {
      ctx.globalAlpha = 0.45;
      ctx.strokeStyle = "rgba(120,120,120,.85)";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 5]);
      ctx.beginPath(); ctx.arc(sx, sy, 26, 0, Math.PI * 2); ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 0.9;
      ctx.fillStyle = "rgba(90,90,90,.9)";
      ctx.font = "11px STKaiti, KaiTi, serif";
      ctx.textAlign = "center";
      ctx.fillText("无目标", sx, sy - 34);
      ctx.restore();
      return;
    }
    const tx = flvSX(locked.x, locked.y), ty = flvSY(locked.x, locked.y);
    const tr = locked.r + 9;
    const lc = locked.kind === "boss" ? "168,88,200" : locked.kind === "elite" ? "220,150,60" : "193,60,60";
    // 追踪虚线
    ctx.globalAlpha = 0.55;
    ctx.strokeStyle = "rgba(" + lc + ",0.85)";
    ctx.lineWidth = 1.6;
    ctx.setLineDash([8, 6]);
    ctx.lineDashOffset = -(FLDV.t * 52) % 14;
    ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(tx, ty); ctx.stroke();
    ctx.setLineDash([]);
    // 锁定环
    ctx.globalAlpha = 0.95;
    ctx.strokeStyle = "rgba(" + lc + ",0.95)";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(tx, ty, tr, tr * isoYK, 0, 0, Math.PI * 2); ctx.stroke();
    // 四角准星
    ctx.beginPath();
    ctx.moveTo(tx, ty - tr - 8); ctx.lineTo(tx, ty - tr - 3);
    ctx.moveTo(tx, ty + tr + 3); ctx.lineTo(tx, ty + tr + 8);
    ctx.moveTo(tx - tr - 8, ty); ctx.lineTo(tx - tr - 3, ty);
    ctx.moveTo(tx + tr + 3, ty); ctx.lineTo(tx + tr + 8, ty);
    ctx.stroke();
    ctx.fillStyle = "rgba(193,84,58,.95)";
    ctx.font = "11px STKaiti, KaiTi, serif";
    ctx.textAlign = "center";
    let lockTxt = "锁定";
    if (typeof elementDef === "function" && locked.element) {
      const ed = elementDef(locked.element);
      if (ed) {
        const me = (typeof mainElement === "function") ? mainElement() : null;
        lockTxt = "锁定·" + ed.name + (me && elementBeats(me, locked.element) ? " 克" : me && elementBeats(locked.element, me) ? " 被克" : "");
      }
    }
    ctx.fillText(lockTxt, tx, ty - tr - 12);
    ctx.restore();
    return;
  }

  // 判定扇形内最近目标
  let kind = "none", best = 1e9, target = null;
  for (const m of f.monsters) {
    if (!m.alive) continue;
    if (!fldInCone(m.x, m.y, p.x, p.y, aim.x, aim.y, range, half, m.r)) continue;
    const d = Math.hypot(m.x - p.x, m.y - p.y);
    if (d < best) { best = d; kind = "monster"; target = m; }
  }
  for (const n of f.nodes) {
    if (n.done) continue;
    if (!fldInCone(n.x, n.y, p.x, p.y, aim.x, aim.y, range, half, n.r)) continue;
    const d = Math.hypot(n.x - p.x, n.y - p.y);
    if (d < best) { best = d; kind = "node"; target = n; }
  }

  const rgb = kind === "monster" ? [193, 39, 45]
    : kind === "node" ? [212, 160, 23]
    : [127, 201, 127];
  const aIn = kind === "none" ? 0.16 : 0.42;
  const isoY = CONFIG.FIELD.ISO_Y / CONFIG.FIELD.ISO_X;

  ctx.save();
  ctx.translate(sx, sy);
  ctx.scale(1, isoY);

  // 环身技能（nova）：以自身为圆心的范围环
  if (shape === "nova") {
    ctx.strokeStyle = "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + ",0.55)";
    ctx.fillStyle = "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + ",0.12)";
    ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.arc(0, 0, range, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.restore();
    return;
  }

  ctx.rotate(ang);

  // 1) 扇形底（盲区提示）
  const g = ctx.createRadialGradient(0, 0, 10, 0, 0, range);
  g.addColorStop(0, "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + "," + aIn + ")");
  g.addColorStop(0.55, "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + "," + (aIn * 0.45) + ")");
  g.addColorStop(1, "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + ",0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.arc(0, 0, range, -half, half);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + "," + (kind === "none" ? 0.20 : 0.55) + ")";
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // 2) 弹道虚线：直线技能画到射程终点的双轨线，其它技能画中轴线
  ctx.save();
  ctx.setLineDash([9, 7]);
  ctx.lineDashOffset = -(FLDV.t * 46) % 16;
  ctx.strokeStyle = "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + ",0.75)";
  ctx.lineWidth = 2;
  if (shape === "line") {
    const hw = width / 2;
    ctx.beginPath(); ctx.moveTo(8, -hw); ctx.lineTo(range, -hw); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(8, hw); ctx.lineTo(range, hw); ctx.stroke();
  }
  ctx.beginPath(); ctx.moveTo(8, 0); ctx.lineTo(range, 0); ctx.stroke();
  ctx.restore();

  // 3) 落点圈：弹道末端椭圆
  if (shape === "line" || shape === "cone") {
    const endR = shape === "line" ? Math.max(12, width * 0.55) : range * 0.22;
    ctx.strokeStyle = "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + ",0.65)";
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.arc(range, 0, endR, -Math.PI / 2, Math.PI / 2);
    ctx.stroke();
    ctx.globalAlpha = 0.30;
    ctx.beginPath(); ctx.arc(range, 0, endR, 0, Math.PI * 2); ctx.fillStyle = "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + ",0.5)"; ctx.fill();
    ctx.globalAlpha = 1;
  }

  ctx.restore();

  // 4) 目标锁定圈（世界坐标绘制，再加四角准星）
  if (target) {
    const tx = flvSX(target.x, target.y), ty = flvSY(target.x, target.y);
    const tr = target.r + 7;
    ctx.save();
    ctx.strokeStyle = "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + ",0.9)";
    ctx.lineWidth = 1.8;
    ctx.setLineDash([5, 5]);
    ctx.lineDashOffset = -(FLDV.t * 30) % 10;
    ctx.beginPath(); ctx.ellipse(tx, ty, tr, tr * isoY, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(tx, ty - tr - 6); ctx.lineTo(tx, ty - tr - 2);
    ctx.moveTo(tx, ty + tr + 2); ctx.lineTo(tx, ty + tr + 6);
    ctx.moveTo(tx - tr - 6, ty); ctx.lineTo(tx - tr - 2, ty);
    ctx.moveTo(tx + tr + 2, ty); ctx.lineTo(tx + tr + 6, ty);
    ctx.stroke();
    ctx.restore();
  }
}

// 资源引导（v0.25.0）：最近未采集节点方向箭头 + 距离，靠近后自动采集
function flvDrawNodeGuide(ctx, f) {
  if (!f || !f.player || !f.nodes || !f.nodes.length) return;
  const p = f.player;
  let best = null, bd = 1e9;
  for (const n of f.nodes) {
    if (n.done) continue;
    const d = Math.hypot(n.x - p.x, n.y - p.y);
    if (d < bd) { bd = d; best = n; }
  }
  if (!best) return;
  if (bd <= best.r + 46) return;   // 已在采集范围（节点上有进度环）
  const px = flvSX(p.x, p.y), py = flvSY(p.x, p.y);
  const nx = flvSX(best.x, best.y), ny = flvSY(best.x, best.y);
  const ang = Math.atan2(ny - py, nx - px);
  const R = 30 + (p.r || 14) * 0.6;
  const ax = px + Math.cos(ang) * R, ay = py + Math.sin(ang) * R * 0.72;

  ctx.save();
  ctx.globalAlpha = 0.62 + Math.sin(FLDV.t * 4) * 0.18;
  ctx.fillStyle = best.glow || "#D4A017";
  ctx.beginPath();
  ctx.moveTo(ax + Math.cos(ang) * 8, ay + Math.sin(ang) * 8);
  ctx.lineTo(ax + Math.cos(ang + 2.5) * 7, ay + Math.sin(ang + 2.5) * 7);
  ctx.lineTo(ax + Math.cos(ang - 2.5) * 7, ay + Math.sin(ang - 2.5) * 7);
  ctx.closePath(); ctx.fill();
  ctx.globalAlpha = 0.85;
  ctx.fillStyle = "rgba(232,220,196,0.92)";
  ctx.font = "11px STKaiti, KaiTi, serif";
  ctx.textAlign = "center";
  ctx.fillText(String(Math.round(bd)), ax + Math.cos(ang) * 15, ay + Math.sin(ang) * 11 + 4);
  ctx.restore();
}

function flvDrawWarns(ctx, dt) {
  for (let i = FLDV.warns.length - 1; i >= 0; i--) {
    const w = FLDV.warns[i];
    w.t += dt;
    const p = Math.min(1, w.t / w.dur);
    if (p >= 1) { FLDV.warns.splice(i, 1); continue; }
    const sx = flvSX(w.x, w.y), sy = flvSY(w.x, w.y);
    const rx = w.r * CONFIG.FIELD.ISO_X * 1.6;
    const ry = w.r * CONFIG.FIELD.ISO_Y * 1.6;
    // 预警按怪种分色（v0.25.0）：普通红 / 精英橙 / BOSS 紫
    const col = w.kind === "boss" ? "#A858C8" : w.kind === "normal" ? "#C13E3E" : "#D8963C";

    ctx.save();
    // 来源 → 落点 的方向指示（谁在施法，一目了然）
    if (typeof w.srcX === "number" && typeof w.srcY === "number") {
      const ax = flvSX(w.srcX, w.srcY), ay = flvSY(w.srcX, w.srcY);
      const ang = Math.atan2(sy - ay, sx - ax);
      ctx.globalAlpha = 0.30 + p * 0.22;
      ctx.strokeStyle = col;
      ctx.lineWidth = 2;
      ctx.setLineDash([7, 6]);
      ctx.lineDashOffset = -(w.t * 40) % 13;
      ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(sx, sy); ctx.stroke();
      ctx.setLineDash([]);
      // 施法者一端的扇形（攻击朝向）
      ctx.globalAlpha = 0.22 + p * 0.18;
      ctx.fillStyle = col;
      ctx.beginPath(); ctx.moveTo(ax, ay); ctx.arc(ax, ay, 54, ang - 0.34, ang + 0.34); ctx.closePath(); ctx.fill();
    }

    ctx.globalAlpha = 0.22 + p * 0.18;
    ctx.fillStyle = col;
    ctx.beginPath(); ctx.ellipse(sx, sy, rx * p, ry * p, 0, 0, Math.PI * 2); ctx.fill();

    ctx.globalAlpha = 0.85;
    ctx.strokeStyle = col;
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(sx, sy, rx, ry, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.restore();
  }
}

// 跟宠（v0.21.0）：小一圈的圆标，出手时外扩光环
function flvDrawPet(ctx, pt) {
  const sx = flvSX(pt.x, pt.y), sy = flvSY(pt.x, pt.y);
  const r = pt.r;
  ctx.save();

  if (pt.pulse > 0) {
    ctx.globalAlpha = pt.pulse * 0.5;
    ctx.strokeStyle = pt.color;
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(sx, sy, r + 6 + (1 - pt.pulse) * 14, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 1;
  }

  ctx.globalAlpha = 0.24;
  ctx.fillStyle = "#000";
  ctx.beginPath(); ctx.ellipse(sx, sy + r * 0.8, r * 0.85, r * 0.38, 0, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;

  const g = ctx.createRadialGradient(sx - r * 0.3, sy - r * 0.4, r * 0.2, sx, sy, r);
  g.addColorStop(0, "rgba(255,255,255,.55)");
  g.addColorStop(1, pt.color);
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.fill();

  ctx.strokeStyle = "rgba(255,255,255,.55)";
  ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.stroke();

  // 朝向小喙
  ctx.fillStyle = "rgba(255,255,255,.8)";
  ctx.beginPath();
  ctx.arc(sx + Math.cos(pt.facing) * r * 0.72, sy + Math.sin(pt.facing) * r * 0.72 * 0.6, 2.4, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

function flvDrawPlayer(ctx, p) {
  const sx = flvSX(p.x, p.y), sy = flvSY(p.x, p.y);
  const r = p.r * 0.95;

  ctx.save();

  if (p.shield > 0) {
    ctx.globalAlpha = 0.5;
    ctx.strokeStyle = "#3E7EB8";
    ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(sx, sy, r + 8, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 1;
  }

  ctx.globalAlpha = 0.28;
  ctx.fillStyle = "#000";
  ctx.beginPath(); ctx.ellipse(sx, sy + r * 0.8, r * 0.95, r * 0.45, 0, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;

  if (FLDV.avatarReady && FLDV.avatarImg) {
    // 有形象：圆内填充头像
    ctx.save();
    ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.clip();
    ctx.drawImage(FLDV.avatarImg, sx - r, sy - r, r * 2, r * 2);
    ctx.restore();
    // 一层暖色罩，让头像与暗色场景融合
    ctx.globalAlpha = 0.16;
    ctx.fillStyle = "#1E1B17";
    ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha = 1;
  } else {
    const g = ctx.createRadialGradient(sx - r * 0.3, sy - r * 0.4, r * 0.2, sx, sy, r);
    g.addColorStop(0, "#7FA593");
    g.addColorStop(1, FLDV_COLORS.player);
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.fill();
  }

  ctx.strokeStyle = FLDV_COLORS.playerRing;
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.stroke();

  ctx.restore();
}

function flvDrawMonster(ctx, m) {
  const sx = flvSX(m.x, m.y), sy = flvSY(m.x, m.y);
  const r = m.r * 0.92;
  const col = m.kind === "boss" ? FLDV_COLORS.boss : m.kind === "elite" ? FLDV_COLORS.elite : FLDV_COLORS.normal;

  ctx.save();
  ctx.globalAlpha = 0.28;
  ctx.fillStyle = "#000";
  ctx.beginPath(); ctx.ellipse(sx, sy + r * 0.8, r * 0.95, r * 0.45, 0, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;

  // 野怪扇形光标（v0.25.0）：朝向即攻击朝向，颜色区分危险度（普通红/精英橙/BOSS 紫）
  const mc = m.kind === "boss" ? "168,88,200" : m.kind === "elite" ? "220,150,60" : "193,60,60";
  const coneR = m.kind === "boss" ? 124 : m.kind === "elite" ? 98 : 76;
  const facing = (typeof m.facing === "number") ? m.facing : 0;
  ctx.save();
  ctx.translate(sx, sy);
  ctx.scale(1, CONFIG.FIELD.ISO_Y / CONFIG.FIELD.ISO_X);
  ctx.rotate(facing);
  const cg = ctx.createRadialGradient(0, 0, 6, 0, 0, coneR);
  cg.addColorStop(0, "rgba(" + mc + "," + (m.channel > 0 ? 0.42 : 0.26) + ")");
  cg.addColorStop(0.7, "rgba(" + mc + ",0.10)");
  cg.addColorStop(1, "rgba(" + mc + ",0)");
  ctx.fillStyle = cg;
  ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, coneR, -0.42, 0.42); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = "rgba(" + mc + ",0.42)";
  ctx.lineWidth = 1.2;
  ctx.beginPath(); ctx.arc(0, 0, coneR, -0.42, 0.42); ctx.stroke();
  ctx.restore();

  ctx.fillStyle = m.hurtT > 0 ? "#E8DCC4" : col;
  ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.fill();

  ctx.strokeStyle = m.kind === "boss" ? "#C1546E" : "rgba(255,255,255,0.18)";
  ctx.lineWidth = m.kind === "boss" ? 2.5 : 1.4;
  ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.stroke();

  if (m.channel > 0) {
    ctx.globalAlpha = 0.35 + Math.sin(FLDV.t * 20) * 0.2;
    ctx.strokeStyle = "#E0A050";
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(sx, sy, r + 6, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 1;
  }

  if (m.slowT > 0) {
    ctx.globalAlpha = 0.5;
    ctx.strokeStyle = "#6FC3E8";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(sx, sy, r + 4, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 1;
  }

  const bw = Math.max(26, r * 2.2), bh = 4;
  const by = sy - r - 11;
  ctx.fillStyle = "rgba(0,0,0,0.55)";
  ctx.fillRect(sx - bw / 2, by, bw, bh);
  ctx.fillStyle = m.kind === "boss" ? "#C1546E" : FLDV_COLORS.hp;
  ctx.fillRect(sx - bw / 2, by, bw * Math.max(0, m.hp / m.hpMax), bh);

  ctx.restore();
}

function flvDrawProjectiles(ctx, f) {
  for (const pr of f.projectiles) {
    const sx = flvSX(pr.x, pr.y), sy = flvSY(pr.x, pr.y);
    const tailX = flvSX(pr.x - pr.dx * 26, pr.y - pr.dy * 26);
    const tailY = flvSY(pr.x - pr.dx * 26, pr.y - pr.dy * 26);

    ctx.save();
    ctx.strokeStyle = pr.color;
    ctx.lineWidth = pr.basic ? 3 : 5;
    ctx.globalAlpha = 0.85;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(tailX, tailY);
    ctx.lineTo(sx, sy);
    ctx.stroke();

    ctx.globalAlpha = 1;
    ctx.fillStyle = pr.color;
    ctx.beginPath(); ctx.arc(sx, sy, pr.basic ? 4 : 6, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
}

function flvDrawCones(ctx, dt) {
  for (let i = FLDV.cones.length - 1; i >= 0; i--) {
    const c = FLDV.cones[i];
    c.t += dt;
    const p = c.t / c.life;
    if (p >= 1) { FLDV.cones.splice(i, 1); continue; }
    const sx = flvSX(c.x, c.y), sy = flvSY(c.x, c.y);
    const ang = Math.atan2(c.dy, c.dx);

    ctx.save();
    ctx.globalAlpha = 0.55 * (1 - p);
    ctx.translate(sx, sy);
    ctx.scale(1, CONFIG.FIELD.ISO_Y / CONFIG.FIELD.ISO_X);
    ctx.rotate(ang);
    const g = ctx.createRadialGradient(0, 0, 6, 0, 0, c.range);
    g.addColorStop(0, c.color);
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, c.range * Math.min(1, 0.5 + p * 1.6), -c.angle / 2, c.angle / 2);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
}

function flvDrawBursts(ctx, dt) {
  for (let i = FLDV.bursts.length - 1; i >= 0; i--) {
    const b = FLDV.bursts[i];
    b.t += dt;
    const p = b.t / b.life;
    if (p >= 1) { FLDV.bursts.splice(i, 1); continue; }
    const sx = flvSX(b.x, b.y), sy = flvSY(b.x, b.y);
    const r = b.r0 + (b.r1 - b.r0) * p;
    const rx = r * CONFIG.FIELD.ISO_X * 1.5;
    const ry = r * CONFIG.FIELD.ISO_Y * 1.5;

    ctx.save();
    ctx.globalAlpha = (1 - p) * 0.8;
    if (b.fill) {
      ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.ellipse(sx, sy, rx, ry, 0, 0, Math.PI * 2); ctx.fill();
    }
    ctx.strokeStyle = b.color;
    ctx.lineWidth = 2.5 * (1 - p) + 1;
    ctx.beginPath(); ctx.ellipse(sx, sy, rx, ry, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.restore();
  }
}

function flvDrawTrails(ctx, dt) {
  for (let i = FLDV.trails.length - 1; i >= 0; i--) {
    const t = FLDV.trails[i];
    t.t = (t.t || 0) + dt;
    t.life -= dt;
    if (t.life <= 0) { FLDV.trails.splice(i, 1); continue; }
    t.x += (t.vx || 0) * dt;
    t.y += (t.vy || 0) * dt;
    const sx = flvSX(t.x, t.y), sy = flvSY(t.x, t.y);
    ctx.save();
    ctx.globalAlpha = Math.max(0, Math.min(0.7, t.life * 1.6));
    ctx.fillStyle = t.color;
    ctx.beginPath(); ctx.arc(sx, sy, 3, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
}

function flvDrawFloaters(ctx, dt) {
  for (let i = FLDV.floaters.length - 1; i >= 0; i--) {
    const fl = FLDV.floaters[i];
    fl.t += dt;
    const p = fl.t / fl.life;
    if (p >= 1) { FLDV.floaters.splice(i, 1); continue; }
    const sx = flvSX(fl.x, fl.y);
    const sy = flvSY(fl.x, fl.y) - 22 - p * 34;
    ctx.save();
    ctx.globalAlpha = 1 - p * p;
    ctx.fillStyle = fl.color;
    ctx.font = (fl.big ? "bold 17px" : "14px") + " system-ui, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(fl.text, sx, sy);
    ctx.restore();
  }
}
