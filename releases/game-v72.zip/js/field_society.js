// ============================================================
// 《问长生》凡人社会：家庭、婚育与生活消费（v0.57.0）
// 聚落公库只接收本地驻守灵石产出的1.5%留成；生活消费从公库扣除。
// 婚育为聚落级人口模型，不伪造个人姓名/年龄/家庭成员明细。
// ============================================================
const FIELD_SOCIETY = {
  LEVY_RATE: 0.015,
  DAILY_LIVING_COST: 0.05, // 每名凡人每日生活消费，灵石计价的抽象生活篮子
  MARRIAGE_DAYS: 365,
  BIRTH_DAYS_PER_COUPLE: 730,
  CHILDHOOD_DAYS: 6570, // 约18年成长为成年人口
};

function fieldSocietyOf(ch, create) {
  if (!S.fieldSociety || typeof S.fieldSociety !== "object") S.fieldSociety = {};
  const key = String(ch);
  if (!S.fieldSociety[key] && create !== false) S.fieldSociety[key] = { marriedCouples: 0, marriageProgress: 0, birthProgress: 0, births: 0, children: 0, maturationProgress: 0, treasury: 0, levyIncome: 0, consumptionPaid: 0, consumptionShortfall: 0, lastConsumption: 0, lastLevyDay: "", lastLifeDay: "" };
  const v = S.fieldSociety[key];
  if (!v) return null;
  v.marriedCouples = Math.max(0, Math.floor(Number(v.marriedCouples) || 0));
  v.marriageProgress = Math.max(0, Math.min(0.999999, Number(v.marriageProgress) || 0));
  v.birthProgress = Math.max(0, Math.min(0.999999, Number(v.birthProgress) || 0));
  v.births = Math.max(0, Math.floor(Number(v.births) || 0));
  v.children = Math.max(0, Math.floor(Number(v.children) || 0));
  v.maturationProgress = Math.max(0, Math.min(0.999999, Number(v.maturationProgress) || 0));
  for (const k of ["treasury", "levyIncome", "consumptionPaid", "consumptionShortfall", "lastConsumption"]) v[k] = Math.max(0, Number(v[k]) || 0);
  if (typeof v.lastLevyDay !== "string") v.lastLevyDay = "";
  if (typeof v.lastLifeDay !== "string") v.lastLifeDay = "";
  return v;
}

// 从本地驻守产出的灵石中留成，直接减少玩家本次入账额；不是额外铸币。
function fieldSocietyCollectLevy(ch, grossStone) {
  const gross = Math.max(0, Number(grossStone) || 0);
  if (!gross || !S.mapTeam || !S.mapTeam[ch] || !S.mapTeam[ch].length) return 0;
  const v = fieldSocietyOf(ch, true);
  const levy = gross * FIELD_SOCIETY.LEVY_RATE;
  v.treasury += levy;
  v.levyIncome += levy;
  return levy;
}

function fieldSocietyDailyTick() {
  if (typeof ensureFolkLedger === "function") ensureFolkLedger();
  const day = typeof gameDayKey === "function" ? gameDayKey() : `${S.gameTime.year}-${S.gameTime.month}-${S.gameTime.day}`;
  for (const key of Object.keys(S.fieldSettlements || {})) {
    if (key === "_reserve") continue;
    const pop = Math.max(0, Number(settlementPopulation(key)) || 0);
    if (pop <= 0) continue;
    const v = fieldSocietyOf(key, true);
    if (v.lastLifeDay === day) continue;
    v.lastLifeDay = day;

    // 先结算基本生活消费；温饱程度决定婚育推进速度，避免无粮仍高速繁衍。
    const demand = pop * FIELD_SOCIETY.DAILY_LIVING_COST;
    const paid = Math.min(demand, v.treasury);
    v.treasury -= paid;
    v.lastConsumption = paid;
    v.consumptionPaid += paid;
    v.consumptionShortfall += demand - paid;
    const livelihood = demand > 0 ? paid / demand : 1;

    // 儿童按约18年逐步成熟；旧档人口默认视为既有成年人口，不凭空补造儿童年龄。
    if (v.children > 0) {
      v.maturationProgress += v.children / FIELD_SOCIETY.CHILDHOOD_DAYS;
      const matured = Math.min(v.children, Math.floor(v.maturationProgress));
      if (matured > 0) { v.children -= matured; v.maturationProgress -= matured; }
    } else v.maturationProgress = 0;
    // 成年人口中约60%可婚，按两人一户折算为成年人口的30%。
    const adultPopulation = Math.max(0, pop - v.children);
    const maxCouples = Math.floor(adultPopulation * 0.30);
    const eligibleNew = Math.max(0, maxCouples - v.marriedCouples);
    if (eligibleNew > 0 && livelihood > 0) {
      v.marriageProgress += eligibleNew * livelihood / FIELD_SOCIETY.MARRIAGE_DAYS;
      const weddings = Math.min(eligibleNew, Math.floor(v.marriageProgress));
      if (weddings > 0) { v.marriedCouples += weddings; v.marriageProgress -= weddings; }
    } else if (eligibleNew <= 0) v.marriageProgress = 0;

    // 每对家庭平均约两年迎来一名新生儿；温饱不足会降低生育推进，人口上限仍由聚落账本约束。
    if (v.marriedCouples > 0 && livelihood > 0) {
      v.birthProgress += v.marriedCouples * livelihood / FIELD_SOCIETY.BIRTH_DAYS_PER_COUPLE;
      const due = Math.floor(v.birthProgress);
      if (due > 0) {
        const accepted = typeof addFolk === "function" ? addFolk(due, key) : 0;
        v.births += Math.floor(accepted);
        v.children += Math.floor(accepted);
        v.birthProgress = accepted >= due ? v.birthProgress - due : Math.min(0.999999, v.birthProgress - Math.floor(v.birthProgress));
      }
    }
  }
}

function fieldSocietySummary(ch) {
  const v = fieldSocietyOf(ch, false) || { marriedCouples: 0, births: 0, treasury: 0, levyIncome: 0, consumptionPaid: 0, consumptionShortfall: 0, lastConsumption: 0 };
  const pop = Math.max(0, Number(settlementPopulation(ch)) || 0);
  const demand = pop * FIELD_SOCIETY.DAILY_LIVING_COST;
  return { population: pop, adultPopulation: Math.max(0, pop - (v.children || 0)), children: v.children || 0, marriedCouples: v.marriedCouples || 0, births: v.births || 0, treasury: v.treasury || 0, levyIncome: v.levyIncome || 0, consumptionPaid: v.consumptionPaid || 0, consumptionShortfall: v.consumptionShortfall || 0, lastConsumption: v.lastConsumption || 0, dailyDemand: demand };
}
