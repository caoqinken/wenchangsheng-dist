// ============================================================
// 《问长生》动态经济系统（v0.4.2）：坊市价格波动 + 交易
// 价格演化 = 事件冲击 → 每日均值回归 + 随机漫步，玩家买卖反向影响价格
// ============================================================

// 每日价格演化
function economyTick() {
  for (const key of ["herb", "pill", "tribPill", "material"]) {
    const base = CONFIG.MARKET_BASE[key];
    const lo = base * CONFIG.MARKET_RANGE[0];
    const hi = base * CONFIG.MARKET_RANGE[1];
    let p = S.market[key];
    p += (base - p) * CONFIG.MARKET_MEAN_REVERT;                      // 均值回归（冲击后自然回落）
    p *= 1 + (Math.random() - 0.5) * 2 * CONFIG.MARKET_VOLATILITY;    // 随机漫步
    S.market[key] = Math.max(lo, Math.min(hi, p));                    // 边界钳制
  }
}

// 事件价格冲击：mult>1 涨价（短缺），mult<1 跌价（过剩）
function marketShock(key, mult) {
  const base = CONFIG.MARKET_BASE[key];
  const lo = base * CONFIG.MARKET_RANGE[0];
  const hi = base * CONFIG.MARKET_RANGE[1];
  S.market[key] = Math.max(lo, Math.min(hi, S.market[key] * mult));
}

// 买入灵草（批量）
function buyHerb() {
  const n = CONFIG.TRADE_HERB_BATCH;
  const cost = Math.ceil(S.market.herb * n);
  const _room = invRoomCheck("herb", n);
  if (!_room.ok) return _room;
  if (S.stone < cost) return { ok: false, msg: "灵石不足" };
  S.stone -= cost;
  gainItem("herb", n);
  const hi = CONFIG.MARKET_BASE.herb * CONFIG.MARKET_RANGE[1];
  S.market.herb = Math.min(hi, S.market.herb * (1 + CONFIG.BUY_IMPACT * n));  // 买入推高价
  save();
  return { ok: true, cost, n };
}

// 卖出灵草（批量，不足批量则卖全部）
function sellHerb() {
  const n = Math.min(CONFIG.TRADE_HERB_BATCH, Math.floor(S.herbs));
  if (n <= 0) return { ok: false, msg: "灵草不足" };
  const gain = Math.floor(S.market.herb * n);
  invRemove("herb", n);
  S.stone += gain;
  const lo = CONFIG.MARKET_BASE.herb * CONFIG.MARKET_RANGE[0];
  S.market.herb = Math.max(lo, S.market.herb * (1 - CONFIG.SELL_IMPACT * n)); // 卖出压低价
  save();
  return { ok: true, gain, n };
}

// 买入丹药（单个）
function buyPill() {
  const cost = Math.ceil(S.market.pill);
  const _room = invRoomCheck("pill", 1);
  if (!_room.ok) return _room;
  if (S.stone < cost) return { ok: false, msg: "灵石不足" };
  S.stone -= cost;
  gainItem("pill", 1);
  const hi = CONFIG.MARKET_BASE.pill * CONFIG.MARKET_RANGE[1];
  S.market.pill = Math.min(hi, S.market.pill * (1 + CONFIG.BUY_IMPACT));
  save();
  return { ok: true, cost };
}

// 卖出丹药（单个）
function sellPill() {
  if (S.pills < 1) return { ok: false, msg: "丹药不足" };
  const gain = Math.floor(S.market.pill);
  invRemove("pill", 1);
  S.stone += gain;
  const lo = CONFIG.MARKET_BASE.pill * CONFIG.MARKET_RANGE[0];
  S.market.pill = Math.max(lo, S.market.pill * (1 - CONFIG.SELL_IMPACT));
  save();
  return { ok: true, gain };
}

// 买入渡劫丹（单个，v0.5.0）
function buyTribPill() {
  const cost = Math.ceil(S.market.tribPill);
  const _room = invRoomCheck("tribPill", 1);
  if (!_room.ok) return _room;
  if (S.stone < cost) return { ok: false, msg: "灵石不足" };
  S.stone -= cost;
  gainItem("tribPill", 1);
  const hi = CONFIG.MARKET_BASE.tribPill * CONFIG.MARKET_RANGE[1];
  S.market.tribPill = Math.min(hi, S.market.tribPill * (1 + CONFIG.BUY_IMPACT));
  save();
  return { ok: true, cost };
}

// 买入灵材（批量，v0.6.0 法宝原料）
function buyMaterial() {
  const n = CONFIG.MATERIAL_TRADE_BATCH;
  const cost = Math.ceil(S.market.material * n);
  const _room = invRoomCheck("material", n);
  if (!_room.ok) return _room;
  if (S.stone < cost) return { ok: false, msg: "灵石不足" };
  S.stone -= cost;
  gainItem("material", n);
  const hi = CONFIG.MARKET_BASE.material * CONFIG.MARKET_RANGE[1];
  S.market.material = Math.min(hi, S.market.material * (1 + CONFIG.BUY_IMPACT * n));
  save();
  return { ok: true, cost, n };
}

// 声望兑换渡劫丹（v0.8.0）：给溢出声望一个出口
function exchangeRepForTribPill() {
  const cost = CONFIG.REP_TO_TRIBPILL;
  const _room = invRoomCheck("tribPill", 1);
  if (!_room.ok) return _room;
  if ((S.reputation || 0) < cost) return { ok: false, msg: `声望不足（需 ${cost}）` };
  S.reputation -= cost;
  gainItem("tribPill", 1);
  save();
  return { ok: true, cost, tribPills: S.tribPills };
}

// 卖出灵材（批量，不足批量则卖全部）
function sellMaterial() {
  const n = Math.min(CONFIG.MATERIAL_TRADE_BATCH, Math.floor(S.materials || 0));
  if (n <= 0) return { ok: false, msg: "灵材不足" };
  const gain = Math.floor(S.market.material * n);
  invRemove("material", n);
  S.stone += gain;
  const lo = CONFIG.MARKET_BASE.material * CONFIG.MARKET_RANGE[0];
  S.market.material = Math.max(lo, S.market.material * (1 - CONFIG.SELL_IMPACT * n));
  save();
  return { ok: true, gain, n };
}

// 买入功法要诀（v0.27.0）
function buyTalisman() {
  const price = CONFIG.TALISMAN_PRICE;
  const _room = invRoomCheck("talisman", 1);
  if (!_room.ok) return _room;
  if (S.stone < price) return { ok: false, msg: "灵石不足" };
  S.stone -= price;
  gainItem("talisman", 1);
  save();
  return { ok: true, cost: price };
}
