// ============================================================
// 《问长生》私有秘境修士人口（v0.56.3）
// 修行洞府提供容量；修士按日流入，独立于凡人聚落与宗门弟子名册。
// ============================================================
function fieldResidentsOf(ch, create) {
  if (!S.fieldResidents || typeof S.fieldResidents !== "object") S.fieldResidents = {};
  const key = String(ch);
  if (!S.fieldResidents[key] && create !== false) {
    S.fieldResidents[key] = { cultivators: 0, progress: 0, totalArrived: 0, lastDay: "", wallets: [], nextWalletId: 1, totalWalletIncome: 0, totalWalletSpent: 0, totalResidentPurchases: 0 };
  }
  const r = S.fieldResidents[key] || null;
  if (r) {
    r.cultivators = Math.max(0, Math.floor(Number(r.cultivators) || 0));
    r.progress = Math.max(0, Math.min(0.999999, Number(r.progress) || 0));
    r.totalArrived = Math.max(0, Math.floor(Number(r.totalArrived) || 0));
    r.totalDeparted = Math.max(0, Math.floor(Number(r.totalDeparted) || 0));
    r.converted = Math.max(0, Math.floor(Number(r.converted) || 0));
    r.totalRentPaid = Math.max(0, Math.floor(Number(r.totalRentPaid) || 0));
    if (typeof r.lastRentDay !== "string") r.lastRentDay = "";
    r.departureProgress = Math.max(0, Math.min(0.999999, Number(r.departureProgress) || 0));
    if (typeof r.lastDay !== "string") r.lastDay = "";
    if (!Array.isArray(r.wallets)) r.wallets = [];
    r.wallets = r.wallets.filter(w => w && typeof w === "object").map(w => ({ id: Math.max(1, Math.floor(Number(w.id) || 1)), balance: Math.max(0, Math.floor(Number(w.balance) || 0)), lastIncomeDay: typeof w.lastIncomeDay === "string" ? w.lastIncomeDay : "", purchasesDay: typeof w.purchasesDay === "string" ? w.purchasesDay : "", purchasesCount: Math.max(0, Math.floor(Number(w.purchasesCount) || 0)), occupation: typeof w.occupation === "string" ? w.occupation : "" }));
    r.nextWalletId = Math.max(Math.floor(Number(r.nextWalletId) || 1), ...r.wallets.map(w => w.id + 1), 1);
    r.totalWalletIncome = Math.max(0, Math.floor(Number(r.totalWalletIncome) || 0));
    r.totalWalletSpent = Math.max(0, Math.floor(Number(r.totalWalletSpent) || 0));
    r.totalResidentPurchases = Math.max(0, Math.floor(Number(r.totalResidentPurchases) || 0));
    fieldResidentsSyncWallets(r);
  }
  return r;
}

// 修士钱包按居民个体保存。旧档居民只建立零余额账户，不凭空补发历史灵石。
function fieldResidentsSyncWallets(r) {
  if (!r || !Array.isArray(r.wallets)) return;
  const count = Math.max(0, Math.floor(Number(r.cultivators) || 0));
  while (r.wallets.length < count) r.wallets.push({ id: r.nextWalletId++, balance: 0, lastIncomeDay: "", purchasesDay: "", purchasesCount: 0, occupation: "" });
  while (r.wallets.length > count) {
    const departed = r.wallets.pop();
    // 离境修士带走个人余钱，不回流玩家，也不凭空销毁到玩家账上。
    r.departedWalletBalance = Math.max(0, Number(r.departedWalletBalance) || 0) + Math.max(0, Number(departed.balance) || 0);
  }
}

// 居民岗位由已建成设施提供；岗位工资沿用原有居民消费额度，不另造货币。
function fieldResidentJobPlan(ch, r) {
  const commerce = typeof fieldCommerceOf === "function" ? fieldCommerceOf(ch, false) : null;
  const buildings = commerce && commerce.buildings ? commerce.buildings : {};
  const jobs = [];
  const add = (key, title, slots) => { for (let i = 0; i < slots; i++) jobs.push({ key, title }); };
  add("cave", "洞府维护", (Number(buildings.cave) || 0) * 1);
  add("auction", "坊市执事", (Number(buildings.auction) || 0) * 2);
  add("alchemy", "丹药阁学徒", (Number(buildings.alchemy) || 0) * 2);
  add("forge", "炼器阁杂役", (Number(buildings.forge) || 0) * 2);
  const wallets = r && Array.isArray(r.wallets) ? r.wallets : [];
  wallets.forEach((wallet, index) => { wallet.occupation = jobs[index] ? jobs[index].title : "待业"; });
  return { jobs, employed: Math.min(wallets.length, jobs.length), unemployed: Math.max(0, wallets.length - jobs.length) };
}

function fieldResidentsFundWallets(ch, r, budget, day) {
  if (!r || !budget) return 0;
  fieldResidentsSyncWallets(r);
  let funded = 0;
  const stipend = 35;
  fieldResidentJobPlan(ch, r);
  for (const wallet of r.wallets) {
    if (!wallet.occupation || wallet.occupation === "待业") continue;
    if (wallet.lastIncomeDay === day) continue;
    if (funded + stipend > Math.max(0, Number(budget.residentAllocation) || 0)) break;
    wallet.balance += stipend; wallet.lastIncomeDay = day; funded += stipend;
    r.totalWalletIncome += stipend;
  }
  budget.residentFunded = Math.floor(funded / stipend);
  return funded;
}

function fieldResidentsCollectRent(ch, r) {
  let paid = 0;
  for (const wallet of (r && r.wallets) || []) {
    const due = 2;
    const part = Math.min(due, Math.max(0, Number(wallet.balance) || 0));
    wallet.balance -= part; paid += part;
  }
  if (paid > 0) {
    S.stone = (Number(S.stone) || 0) + paid;
    r.totalRentPaid += paid; r.totalWalletSpent += paid;
  }
  return paid;
}

function fieldResidentsBuyFromPlayer(ch, key, quantity) {
  if (!fieldCommerceCanOperate(ch)) return { ok: false, msg: "秘境尚未私有化" };
  if (!['pill', 'tribPill'].includes(String(key))) return { ok: false, msg: "当前居民仅开放丹药消费" };
  const r = fieldResidentsOf(ch, false);
  if (!r || !r.wallets.length) return { ok: false, msg: "当前没有可消费的本地修士" };
  const n = Number(quantity);
  if (!Number.isInteger(n) || n <= 0) return { ok: false, msg: "购买数量必须为正整数" };
  const have = Math.floor(invCount(key));
  if (have < n) return { ok: false, msg: `库存不足：仅有${have}件` };
  const marketPrice = key === "pill" ? Number(S.market.pill) || 0 : Number(S.market.tribPill) || 0;
  const unit = Math.max(1, Math.floor(marketPrice * 1.25));
  const total = unit * n;
  const day = fieldCommerceDayKey();
  const wallets = r.wallets.filter(w => w.purchasesDay !== day && w.balance >= unit).sort((a,b) => b.balance - a.balance);
  if (wallets.length < n) return { ok: false, msg: `今日可消费修士不足：最多还能购买${wallets.length}件` };
  const removed = fieldWarehouseTake(key, n);
  if (!removed.ok) return removed;
  for (const wallet of wallets.slice(0, n)) { wallet.balance -= unit; wallet.purchasesDay = day; wallet.purchasesCount = 1; }
  S.stone = (Number(S.stone) || 0) + total;
  r.totalWalletSpent += total; r.totalResidentPurchases += n;
  if (typeof save === "function") save();
  return { ok: true, key, n, unit, total, remaining: invCount(key) };
}

function fieldResidentCapacity(ch) {
  const commerce = typeof fieldCommerceOf === "function" ? fieldCommerceOf(ch, false) : null;
  const lv = commerce && commerce.buildings ? Math.max(0, Number(commerce.buildings.cave) || 0) : 0;
  return lv > 0 ? 3 + (lv - 1) * 2 : 0;
}

function fieldResidentDailyRate(ch) {
  if (typeof fieldCommerceCanOperate !== "function" || !fieldCommerceCanOperate(ch)) return 0;
  const capacity = fieldResidentCapacity(ch);
  if (capacity <= 0) return 0;
  const education = typeof fieldEducationOf === "function" ? fieldEducationOf(ch, false) : null;
  const educationMult = 1 + Math.max(0, Math.min(1, Number(education && education.progress) || 0)) * 0.5;
  const stable = typeof fieldStableOf === "function" ? fieldStableOf(ch) : 60;
  const stableMult = stable < 30 ? 0.5 : stable < 60 ? 0.75 : 1;
  const commerce = fieldCommerceOf(ch, false);
  const buildings = commerce && commerce.buildings ? Object.keys(commerce.buildings).filter(k => k !== "cave" && commerce.buildings[k] > 0).length : 0;
  const prosperityMult = 1 + buildings * 0.15;
  return 0.08 * educationMult * stableMult * prosperityMult;
}

function fieldResidentsDailyTick() {
  if (!S.clearedMaps || !S.fieldCommerce) return;
  const day = typeof fieldCommerceDayKey === "function" ? fieldCommerceDayKey() : "";
  for (const ch of Object.keys(S.fieldCommerce)) {
    if (!fieldCommerceCanOperate(ch)) continue;
    const cap = fieldResidentCapacity(ch);
    if (cap <= 0) continue;
    const r = fieldResidentsOf(ch, true);
    if (r.lastDay === day) continue;
    r.lastDay = day;
    // 安定度过低时，居民会逐渐迁出；使用累积概率进度，避免每日随机抖动与重复结算。
    const stable = typeof fieldStableOf === "function" ? fieldStableOf(ch) : 60;
    const leaveRate = stable < 20 ? 0.08 : stable < 35 ? 0.025 : stable < 50 ? 0.005 : 0;
    if (r.cultivators > 0) {
      r.departureProgress += leaveRate;
      if (r.departureProgress >= 1) {
        const leave = Math.min(r.cultivators, Math.floor(r.departureProgress));
        r.cultivators -= leave; r.totalDeparted += leave; r.departureProgress -= leave; fieldResidentsSyncWallets(r);
        if (typeof addEventLog === "function") addEventLog(`【秘境修士】${mapNameOf(ch)}安定不足，${leave} 名修士迁离。`);
      }
    } else {
      r.departureProgress = 0;
    }
    // v0.56.8：先把本地修士对应的35灵石/人消费额度从共享发行池划入个人钱包，再由钱包支付租金。
    if (r.lastRentDay !== day) {
      r.lastRentDay = day; r.lastRentPaid = 0;
      const budget = typeof fieldCommerceEnsureBudget === "function" ? fieldCommerceEnsureBudget(ch) : null;
      if (budget) fieldResidentsFundWallets(ch, r, budget, day);
      if (r.cultivators > 0) {
        const paid = fieldResidentsCollectRent(ch, r);
        r.lastRentPaid = paid;
        if (paid > 0 && typeof addEventLog === "function") addEventLog(`【秘境洞府】${mapNameOf(ch)}本日收取修士个人租金 ${paid} 灵石。`);
      }
    }
    if (r.cultivators >= cap) { r.cultivators = cap; r.progress = 0; continue; }
    r.progress += fieldResidentDailyRate(ch);
    const arrivals = Math.min(cap - r.cultivators, Math.floor(r.progress));
    if (arrivals > 0) {
      r.cultivators += arrivals;
      fieldResidentsSyncWallets(r);
      r.totalArrived += arrivals;
      r.progress -= arrivals;
      if (typeof addEventLog === "function") addEventLog(`【秘境修士】${mapNameOf(ch)}修行洞府迎来 ${arrivals} 名修士，现有 ${r.cultivators}/${cap} 人。`);
    }
    r.progress = Math.max(0, Math.min(0.999999, r.progress));
  }
}

function fieldResidentsConvert(ch) {
  if (!fieldCommerceCanOperate(ch)) return { ok: false, msg: "秘境尚未私有化" };
  const commerce = fieldCommerceOf(ch, false);
  if (!commerce || !(commerce.buildings.cave > 0)) return { ok: false, msg: "请先建设修行洞府" };
  const r = fieldResidentsOf(ch, true), cap = fieldResidentCapacity(ch);
  if (r.cultivators >= cap) return { ok: false, msg: "洞府已满，无法安置新修士" };
  const stable = typeof fieldStableOf === "function" ? fieldStableOf(ch) : 0;
  if (stable < 50) return { ok: false, msg: "秘境安定度至少达到50才可转化" };
  const folkCost = 10, stoneCost = 800;
  if (typeof settlementPopulation !== "function" || settlementPopulation(ch) < folkCost) return { ok: false, msg: `本地凡人不足：需要${folkCost}人` };
  if ((Number(S.stone) || 0) < stoneCost) return { ok: false, msg: `灵石不足：需要${stoneCost}灵石` };
  if (!consumeFolk(folkCost, ch)) return { ok: false, msg: "本地凡人不足，转化未执行" };
  S.stone -= stoneCost;
  r.cultivators++; fieldResidentsSyncWallets(r); r.converted++;
  if (typeof addEventLog === "function") addEventLog(`【秘境教化】${mapNameOf(ch)}消耗${folkCost}名凡人与${stoneCost}灵石，培养出1名修士。`);
  if (typeof save === "function") save();
  return { ok: true, cultivators: r.cultivators, folkCost, stoneCost };
}

function fieldResidentsSummary(ch) {
  const r = fieldResidentsOf(ch, false) || { cultivators: 0, progress: 0, totalArrived: 0, totalDeparted: 0, converted: 0 };
  const cap = fieldResidentCapacity(ch);
  const employment = fieldResidentJobPlan(ch, r);
  return { cultivators: r.cultivators, capacity: cap, employed: employment.employed, unemployed: employment.unemployed, occupations: employment.jobs.map(j => j.title), progress: r.progress, totalArrived: r.totalArrived, totalDeparted: r.totalDeparted || 0, converted: r.converted || 0, totalRentPaid: r.totalRentPaid || 0, lastRentPaid: r.lastRentPaid || 0, walletBalance: (r.wallets || []).reduce((n,w) => n + (Number(w.balance) || 0), 0), walletIncome: r.totalWalletIncome || 0, walletSpent: r.totalWalletSpent || 0, residentPurchases: r.totalResidentPurchases || 0, dailyRate: fieldResidentDailyRate(ch) };
}
