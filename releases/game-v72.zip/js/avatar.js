// ============================================================
// 《问长生》角色形象（v0.22.0）
// 纯外观选择 + 极小初始倾向（±3%），不构成强度差
// ============================================================

function avatarDef(key) {
  return CONFIG.AVATARS.find(a => a.key === key) || CONFIG.AVATARS[0];
}

function currentAvatar() {
  return avatarDef(S.avatar);
}

// 角色形象为纯外观，不提供任何数值加成（避免破坏战斗基数与平衡）
function avatarTint() {
  return { atk: 0, def: 0, hp: 0, cult: 0 };
}

function setAvatar(key) {
  const def = CONFIG.AVATARS.find(a => a.key === key);
  if (!def) return { ok: false, msg: "无此形象" };
  S.avatar = def.key;
  save();
  return { ok: true, avatar: def };
}
