// ============================================================
// 《问长生》秘境教化与私有化（v0.56.0）
// 教化按秘境独立累计；驻守叠加但边际递减；传道任务提供额外教化。
// 私有化完成后永久归属玩家，不再受到外部势力侵蚀。
// ============================================================

function fieldEducationOf(ch, create) {
  if (!S.fieldEducation || typeof S.fieldEducation !== "object") S.fieldEducation = {};
  const key = String(ch);
  if (!S.fieldEducation[key] && create !== false) {
    S.fieldEducation[key] = { progress: 0, private: false, totalGuardSec: 0 };
  }
  const e = S.fieldEducation[key] || null;
  if (e) {
    e.progress = Math.max(0, Math.min(1, Number(e.progress) || 0));
    e.private = !!e.private || e.progress >= 1;
    if (e.private) e.progress = 1;
    e.totalGuardSec = Math.max(0, Number(e.totalGuardSec) || 0);
  }
  return e;
}

function fieldEducationActiveMembers(ch) {
  const ids = dispatchTeam(ch).map(String);
  return ids.filter(id => !(S.missions || []).some(m => m.status === "run" && String(m.discipleId) === id)).length;
}

function fieldEducationMemberFactor(count) {
  const cfg = CONFIG.FIELD_EDUCATION;
  let total = 0;
  for (let i = 0; i < count; i++) {
    total += i < cfg.MEMBER_MULTS.length ? cfg.MEMBER_MULTS[i] : cfg.EXTRA_MEMBER_MULT;
  }
  return total;
}

function fieldEducationTickOne(ch, seconds, activityFactor) {
  const e = fieldEducationOf(ch, true);
  if (!e || e.private || !S.clearedMaps || !S.clearedMaps[ch]) return 0;
  const dt = Math.max(0, Number(seconds) || 0);
  if (!dt) return 0;
  const members = fieldEducationActiveMembers(ch);
  let delta = 0;
  // 只要尚未私有化，外部势力就持续施压；驻守教化必须跑赢这部分侵蚀。
  delta -= CONFIG.FIELD_EDUCATION.PRESSURE_RATE * dt;
  if (members > 0) {
    const factor = Math.max(0, Number(activityFactor) || 0);
    delta += CONFIG.FIELD_EDUCATION.BASE_RATE * fieldEducationMemberFactor(members) * dt * factor;
    e.totalGuardSec += dt;
  } else {
    // 无弟子驻守时再叠加额外侵蚀，不再直接夺取秘境。
    delta -= CONFIG.FIELD_EDUCATION.EROSION_RATE * dt;
  }
  if ((typeof fieldStableOf === "function" ? fieldStableOf(ch) : 100) < CONFIG.STABLE.LOW) {
    delta -= CONFIG.FIELD_EDUCATION.LOW_STABLE_EROSION * dt;
  }
  const before = e.progress;
  e.progress = Math.max(0, Math.min(1, e.progress + delta));
  if (!e.private && e.progress >= CONFIG.FIELD_EDUCATION.PRIVATE_AT) {
    e.progress = 1;
    e.private = true;
    if (typeof addEventLog === "function") addEventLog(`【秘境私有化】${mapNameOf(ch)}完成教化，已归入你的道统，外部势力无法再侵蚀。`);
    if (typeof save === "function") save();
  }
  return e.progress - before;
}

function fieldEducationTick(seconds, activityFactor) {
  if (!S.clearedMaps) return;
  for (const ch in S.clearedMaps) {
    if (S.clearedMaps[ch]) fieldEducationTickOne(parseInt(ch, 10), seconds, activityFactor);
  }
}

function fieldEducationAdd(ch, amount, source) {
  const e = fieldEducationOf(ch, true);
  if (!e || e.private) return { gained: 0, progress: e ? e.progress : 0, private: !!(e && e.private) };
  const add = Math.max(0, Number(amount) || 0);
  const before = e.progress;
  e.progress = Math.min(1, e.progress + add);
  if (e.progress >= 1) {
    e.progress = 1;
    e.private = true;
    if (typeof addEventLog === "function") addEventLog(`【秘境私有化】${mapNameOf(ch)}完成教化，已归入你的道统，外部势力无法再侵蚀。`);
  } else if (add > 0 && typeof addEventLog === "function") {
    addEventLog(`${source || "教化推进"}：${mapNameOf(ch)}教化度 +${(add * 100).toFixed(1)}%`);
  }
  if (typeof save === "function") save();
  return { gained: e.progress - before, progress: e.progress, private: e.private };
}

function fieldEducationStatus(ch) {
  const e = fieldEducationOf(ch, false) || { progress: 0, private: false, totalGuardSec: 0 };
  const members = fieldEducationActiveMembers(ch);
  const perSec = e.private ? 0 : (members > 0
    ? CONFIG.FIELD_EDUCATION.BASE_RATE * fieldEducationMemberFactor(members)
    : -CONFIG.FIELD_EDUCATION.EROSION_RATE) - CONFIG.FIELD_EDUCATION.PRESSURE_RATE;
  const stablePenalty = !e.private && (typeof fieldStableOf === "function" ? fieldStableOf(ch) : 100) < CONFIG.STABLE.LOW
    ? CONFIG.FIELD_EDUCATION.LOW_STABLE_EROSION : 0;
  return {
    progress: e.progress,
    percent: Math.floor(e.progress * 1000) / 10,
    private: !!e.private,
    members,
    totalGuardSec: e.totalGuardSec,
    ratePerHour: (perSec - stablePenalty) * 3600 * 100,
    remainingHours: e.private || perSec <= stablePenalty ? null : (1 - e.progress) / (perSec - stablePenalty) / 3600,
  };
}
