// ============================================================
// 《问长生》宗门完整版（v0.34.0）
// 宗门任务（每日）→ 贡献 → 藏经阁兑换；护法试炼（PvE）；宗门外交
// ============================================================

function ensureSectDaily() {
  const k = gameDayKey();
  if (!S.sectDaily || S.sectDaily.date !== k) S.sectDaily = { date: k, prog: {}, claimed: {} };
  if (!S.sectDaily.prog) S.sectDaily.prog = {};
  if (!S.sectDaily.claimed) S.sectDaily.claimed = {};
  return S.sectDaily;
}

function addContribution(n) {
  S.contribution = (S.contribution || 0) + n;
  save();
}

function sectTaskProgress(key, n) {
  const d = ensureSectDaily();
  d.prog[key] = (d.prog[key] || 0) + (n || 1);
}

function sectTaskState() {
  const d = ensureSectDaily();
  return CONFIG.SECT_TASKS.map(t => ({
    ...t,
    cur: d.prog[t.key] || 0,
    done: (d.prog[t.key] || 0) >= 1 || t.key === "donate",
    claimed: !!d.claimed[t.key],
  }));
}

// 供奉：直接扣灵石
function sectDonate() {
  const t = CONFIG.SECT_TASKS.find(x => x.key === "donate");
  const d = ensureSectDaily();
  if (d.claimed.donate) return { ok: false, msg: "今日已供奉" };
  if (S.stone < t.stone) return { ok: false, msg: `灵石不足（需 ${t.stone}）` };
  S.stone -= t.stone;
  d.claimed.donate = true;
  addContribution(t.contrib);
  save();
  return { ok: true, contrib: t.contrib };
}

// 领取任务奖励（mission/enter 需先完成行为）
function claimSectTask(key) {
  const t = CONFIG.SECT_TASKS.find(x => x.key === key);
  const d = ensureSectDaily();
  if (!t) return { ok: false, msg: "无此任务" };
  if (d.claimed[key]) return { ok: false, msg: "已领取" };
  if ((d.prog[key] || 0) < 1) return { ok: false, msg: "尚未完成" };
  d.claimed[key] = true;
  addContribution(t.contrib);
  save();
  return { ok: true, contrib: t.contrib, name: t.name };
}

// 藏经阁
function buySectItem(key) {
  const it = CONFIG.SECT_SHOP.find(x => x.key === key);
  if (!it) return { ok: false, msg: "无此物品" };
  if ((S.contribution || 0) < it.cost) return { ok: false, msg: `贡献不足（需 ${it.cost}）` };
  // v0.37.0：先校验储物袋空间，装不下不扣贡献
  const _mapKey = { talisman: "talisman", material: "material", herb: "herb", pill: "pill" }[it.type];
  if (_mapKey && typeof invRoomCheck === "function") {
    const _rc = invRoomCheck(_mapKey, it.amount);
    if (!_rc.ok) return _rc;
  }
  if (it.type === "frag" && typeof invRoomFor === "function") {
    const _setOf = (typeof highestClearedChapter === "function")
      ? (function () { const ch = highestClearedChapter(); return ch <= 2 ? "qingyun" : ch <= 4 ? "moyuan" : "hunyuan"; })()
      : "qingyun";
    const _rc2 = invRoomCheck("frag:" + _setOf, it.amount);
    if (!_rc2.ok) return _rc2;
  }
  S.contribution -= it.cost;
  if (it.type === "talisman") gainItem("talisman", it.amount);
  else if (it.type === "material") gainItem("material", it.amount);
  else if (it.type === "herb") gainItem("herb", it.amount);
  else if (it.type === "pill") gainItem("pill", it.amount);
  else if (it.type === "frag") {
    // 碎片按最高已探明章的套系发放
    const setOf = (typeof highestClearedChapter === "function")
      ? (function () { const ch = highestClearedChapter(); return ch <= 2 ? "qingyun" : ch <= 4 ? "moyuan" : "hunyuan"; })()
      : "qingyun";
    addAncientFrag(setOf, it.amount);
  }
  save();
  return { ok: true, item: it };
}

// 护法试炼：三波 PvE，按战力比判定
function sectTrialRun() {
  if (!S.sect || !S.sect.lv) return { ok: false, msg: "尚未立宗" };
  const T = CONFIG.SECT_TRIAL;
  if (S.stamina < T.STAMINA) return { ok: false, msg: "体力不足" };
  S.stamina -= T.STAMINA;
  const my = playerPower();
  let wave = 0, contrib = 0, stone = 0;
  const detail = [];
  for (let i = 0; i < T.WAVES.length; i++) {
    const enemy = my * T.WAVES[i];
    const win = my >= enemy * (0.9 + Math.random() * 0.2);
    detail.push({ wave: i + 1, win });
    if (!win) break;
    wave = i + 1;
    contrib += T.CONTRIB[i];
    stone += Math.floor(T.STONE * (i + 1) * 0.5);
  }
  if (wave === 0) {
    // 失败：护法受伤（忠诚下降）
    const guard = Object.keys(S.staff || {}).find(ch => S.staff[ch].office === "hu");
    if (guard) {
      const d = S.disciples.find(x => String(x.id) === String(S.staff[guard].discipleId));
      if (d) d.loyalty = Math.max(0, d.loyalty - T.FAIL_LOYALTY);
    }
  }
  if (contrib > 0) addContribution(contrib);
  S.stone += stone;
  const k = gameDayKey();
  if (!S.sectTrial || S.sectTrial.day !== k) S.sectTrial = { day: k, best: 0 };
  S.sectTrial.best = Math.max(S.sectTrial.best || 0, wave);
  save();
  return { ok: true, wave, contrib, stone, detail };
}

// 宗门外交：贡献换关系
function sectDiplomacy(factionKey) {
  const D = CONFIG.SECT_DIPLO;
  if (!S.factions || !S.factions[factionKey]) return { ok: false, msg: "无此势力" };
  if ((S.contribution || 0) < D.COST) return { ok: false, msg: `贡献不足（需 ${D.COST}）` };
  S.contribution -= D.COST;
  S.factions[factionKey].relation = (S.factions[factionKey].relation || 0) + D.REL;
  save();
  return { ok: true, rel: S.factions[factionKey].relation, faction: factionKey };
}

// ---------- 界面 ----------
function showSectPanel() {
  if (!S.sect || !S.sect.lv) {
    showModal(`<div class="result"><div class="result-title">宗门</div>
      <div class="result-line">尚未立宗。派弟子驻守 3 处已探明秘境后，在洞府页立宗。</div>
      <button class="btn-primary" data-action="closemodal">知道了</button></div>`);
    return;
  }
  const tasks = sectTaskState().map(t => {
    const btn = t.claimed
      ? `<span class="muted">已领取</span>`
      : t.key === "donate"
        ? `<button class="btn-sm" data-action="sectdonate">供奉（${t.stone} 石）</button>`
        : t.done
          ? `<button class="btn-sm" data-action="sectclaim" data-key="${t.key}">领取 +${t.contrib}</button>`
          : `<span class="muted">${t.cur}/1</span>`;
    return `<div class="shop-item"><span>${esc(t.name)}</span><span>${btn}</span></div>`;
  }).join("");
  const shop = CONFIG.SECT_SHOP.map(it => `
    <div class="shop-item">
      <span>${esc(it.name)}</span>
      <button class="btn-sm" data-action="sectbuy" data-key="${it.key}">${it.cost} 贡献</button>
    </div>`).join("");
  showModal(`<div class="result">
    <div class="result-title">${esc(S.sect.name)} Lv.${S.sect.lv}</div>
    <div class="result-line">贡献 <b>${S.contribution || 0}</b> ｜ 试炼最佳 ${S.sectTrial && S.sectTrial.best ? S.sectTrial.best : 0} 波</div>
    <div class="sec-title small">宗门任务（每日）</div>
    <div class="shop-list">${tasks}</div>
    <div class="sec-title small">藏经阁</div>
    <div class="shop-list">${shop}</div>
    <div class="sec-title small">护法试炼（PvE · 体力 ${CONFIG.SECT_TRIAL.STAMINA}）</div>
    <div class="shop-list">
      <div class="shop-item"><span>三波来犯，按战力判定；每波贡献 ${CONFIG.SECT_TRIAL.CONTRIB.join("/")}</span>
        <button class="btn-sm" data-action="secttrial">开战</button></div>
    </div>
    <div class="sec-title small">宗门外交（${CONFIG.SECT_DIPLO.COST} 贡献 → 关系 +${CONFIG.SECT_DIPLO.REL}）</div>
    <div class="build-row">
      <button class="btn-sm" data-action="sectdiplo" data-faction="qingyun">结交青云门</button>
      <button class="btn-sm" data-action="sectdiplo" data-faction="moyuan">安抚魔渊宗</button>
      <button class="btn-sm" data-action="sectdiplo" data-faction="sanxiu">结好散修联盟</button>
    </div>
    <button class="btn-primary" data-action="closemodal">关闭</button>
  </div>`);
}

// 攻打魔渊据点（v0.35.0）
function raidMoyuan() {
  const R = CONFIG.RAID;
  if (S.stamina < R.STAMINA) return { ok: false, msg: "体力不足" };
  S.stamina -= R.STAMINA;
  const my = playerPower();
  const enemy = my * R.ENEMY_MULT * (0.9 + Math.random() * 0.2);
  if (my >= enemy) {
    S.factions.moyuan.relation = (S.factions.moyuan.relation || 0) - R.REL_HIT;
    const gain = R.STONE_BASE * ((S.realm || 0) + 1);
    S.stone += gain;
    S.reputation = (S.reputation || 0) + R.REP_WIN;
    S.conquered = (S.conquered || 0) + 1;
    if (typeof addEventLog === "function") addEventLog(`攻破魔渊据点，缴获灵石 ${fmt(gain)}`);
    save();
    return { ok: true, win: true, gain, rep: R.REP_WIN };
  }
  S.reputation = Math.max(0, (S.reputation || 0) - R.REP_LOSE);
  if (typeof addEventLog === "function") addEventLog("攻打魔渊据点失利，声望受损");
  save();
  return { ok: true, win: false, rep: -R.REP_LOSE };
}
