// ============================================================
// 《问长生》气息战斗引擎 v2（v0.52.0）
// 一息=1秒；气息/真元/运功/术式循环；Canvas剪影小人。
// 复用秘境地图、怪物配置、关卡结算与存档，不再要求自由走位。
// ============================================================

const BREATH = {
  active: false, raf: 0, last: 0, acc: 0, tick: 0,
  playerGas: 0, enemyGas: 0, enemyIndex: 0, slotCursor: 0,
  cooldowns: {}, logs: [], action: null, ghosts: [], effects: [], buffs: {}, enemySlow: null,
  canvas: null, ctx: null, el: null, anim: 0, resultShown: false, profile: {},
};

function breathSlotCap() {
  const list = (CONFIG.BATTLE2 && CONFIG.BATTLE2.SLOT_BY_REALM) || [2, 3, 4, 5, 6, 7, 8, 8];
  return list[Math.min(list.length - 1, Math.max(0, S.realm || 0))] || 2;
}
function breathGasCost(sk) {
  if (sk.mult >= 1.8) return 150;
  if (sk.mult >= 1.25) return 150;
  return 60;
}
function breathConfiguredSlots() {
  const regular = (typeof artSlotList === "function") ? artSlotList()
    : (typeof fldNormalizeSlots === "function" ? fldNormalizeSlots(S.fieldSlots, S.realm)
      : (Array.isArray(S.fieldSlots) && S.fieldSlots.length ? S.fieldSlots : fldDefaultSlots(S.realm)));
  const slots = regular.slice(0, breathSlotCap());
  const fabao = typeof selectedFabaoSkill === "function" ? selectedFabaoSkill() : null;
  if (fabao && !slots.includes(fabao.key)) slots.push(fabao.key); // 独立第五格，不计入境界槽上限
  return slots;
}
function breathYungongRatio() {
  const n = Number(S.yungongRatio);
  return Math.max(0, Math.min(0.6, isFinite(n) ? n : 0));
}
function breathAvailableMana() {
  const p = BREATH.field.player;
  const reserve = p.manaMax * breathYungongRatio();
  return Math.max(0, p.mana - reserve);
}
// 运功附伤按基础攻击归一化：伤害=基础攻击×运功比例×0.15×(1+术法功法运功加成)。
// 等价于「运功额度×术法运功系数」，但该系数必须含 atk/manaMax 换算，不能把真元点数直接当伤害。
// 设计稿 §3.4 与 §7.3(6) 的量纲统一说明见 docs/04_战斗与功法系统设计.md。
function breathYungongDamage() {
  const p = BREATH.field.player;
  const rate = (CONFIG.BATTLE2 && CONFIG.BATTLE2.YUNGONG_RATE) || 0.15;
  return Math.max(0, p.atk * breathYungongRatio() * rate * (1 + (BREATH.profile.yungong || 0)));
}
function breathEnemy() {
  const f = BREATH.field;
  while (BREATH.enemyIndex < f.monsters.length && !f.monsters[BREATH.enemyIndex].alive) BREATH.enemyIndex++;
  return f.monsters[BREATH.enemyIndex] || null;
}
function breathLog(text, kind) {
  BREATH.logs.push({ text: String(text), kind: kind || "normal" });
  if (BREATH.logs.length > 7) BREATH.logs.shift();
  const box = BREATH.el && BREATH.el.querySelector(".bt-log");
  if (box) box.innerHTML = BREATH.logs.map(x => `<div class="bt-log-${x.kind}">${esc(x.text)}</div>`).join("");
}
function breathSetAction(side, key, color) {
  const now = performance.now();
  if (BREATH.action) {
    BREATH.ghosts.push({ side: BREATH.action.side, key: BREATH.action.key, color: BREATH.action.color, start: now, life: 250 });
    if (BREATH.ghosts.length > 2) BREATH.ghosts.shift();
  }
  BREATH.action = { side, key, color: color || (side === "player" ? "#c6a45b" : "#a65b4c"), start: now, duration: 560 };
}
function breathNormalizeEnemies(field) {
  // 旧地图敌人按自由走位+范围清怪标定；气息战改为单体节拍，需压缩敌方数值量级。
  // 保留章节间相对强弱，不改写原 CONFIG，旧战场回归路径仍可用原始数值。
  for (const m of (field.monsters || [])) {
    const hpScale = field.chapter >= 5 ? 0.01 : 0.05;
    const hpFloor = field.player.atk * (m.kind === "boss" ? 8 : m.kind === "elite" ? 3 : 1.2);
    m.hpMax = Math.max(1, m.hpMax * hpScale, hpFloor);
    m.hp = m.hpMax;
    const defenseRatio = m.kind === "boss" ? 1.35 : m.kind === "elite" ? 1.15 : 1.05;
    m.atk = Math.max(1, m.atk * 0.005, field.player.def * defenseRatio);
    m.def = Math.max(0, m.def * 0.03);
  }
}
function breathDamage(attacker, target, mult, side, name) {
  // 术式倍率必须进入伤害公式；旧实现虽接收 mult，却漏乘倍率，导致轻式/重式/绝式伤害相同。
  // hits 用于三叠浪等多段术式：逐击判定会心，汇总一次战报与飘字。
  const raw = Math.max(attacker.atk - target.def, attacker.atk * 0.05);
  const scale = Math.max(0, Number(mult) || 0);
  const hits = Math.max(1, Math.min(12, Math.floor(Number(attacker.hits) || 1)));
  const critRate = Math.max(0, Math.min(0.75, 0.06 + (BREATH.profile.crit || 0) + ((BREATH.buffs && BREATH.buffs.critPct) || 0)));
  let totalDamage = 0, anyCrit = false;
  for (let i = 0; i < hits && target.hp > 0; i++) {
    const crit = side === "player" && Math.random() < critRate;
    const damage = Math.max(1, Math.floor(raw * scale * (crit ? 1.65 : 1)));
    target.hp = Math.max(0, target.hp - damage);
    totalDamage += damage;
    anyCrit = anyCrit || crit;
  }
  if (side === "player") {
    BREATH.field.dmgDealt += totalDamage;
    const steal = Math.max(0, (BREATH.profile.lifesteal || 0) + (attacker.lifestealPct || 0));
    if (steal > 0) {
      const recovered = Math.floor(totalDamage * Math.min(0.5, steal));
      BREATH.field.player.hp = Math.min(BREATH.field.player.hpMax, BREATH.field.player.hp + recovered);
      if (recovered > 0) breathLog(`噬血回元，恢复气血 ${fmt(recovered)}`, "good");
    }
    if (target.hp <= 0 && target.alive) {
      target.alive = false;
      BREATH.field.killCount++;
      if (target.kind === "boss") BREATH.field.bossKilled = true;
      breathLog(`击败「${target.name}」 · ${name || "术式"}造成 ${fmt(totalDamage)} 伤害`, "good");
    } else {
      breathLog(`${name || "术式"}${hits > 1 ? `（${hits}击）` : ""}命中，造成 ${fmt(totalDamage)} 伤害${anyCrit ? " · 会心" : ""}`, anyCrit ? "good" : "normal");
    }
  } else {
    breathLog(`受到「${name || "妖兽攻击"}」${fmt(totalDamage)} 点伤害`, "bad");
  }
  breathSetAction(side, name || "普攻", side === "player" ? "#c6a45b" : "#a65b4c");
  BREATH.effects.push({ side, start: performance.now(), life: 420, damage: totalDamage, crit: anyCrit });
  return totalDamage;
}
function breathBuffValue(key) {
  const b = BREATH.buffs && BREATH.buffs[key];
  return b && b.left > 0 ? b.value : 0;
}
function breathApplySkillBuff(sk) {
  const duration = Math.max(1, Math.ceil(sk.buffSec || 1));
  for (const key of ["atkPct", "critPct", "dodgePct", "damageReducePct"]) {
    if (sk[key]) {
      const old = breathBuffValue(key);
      BREATH.buffs[key] = { value: Math.min(key === "damageReducePct" ? 0.6 : 0.5, old + sk[key]), left: duration };
      breathLog(`「${sk.name}」生效：${({atkPct:"攻伐提升",critPct:"会心提升",dodgePct:"闪避提升",damageReducePct:"伤害减免"})[key]}`, "good");
    }
  }
}
function breathUseSkill(key, manual) {
  const f = BREATH.field, sk = fldSkill(key), enemy = breathEnemy();
  if (!sk || !enemy || !enemy.alive) return { ok: false, msg: "当前没有可攻击目标" };
  const cd = BREATH.cooldowns[key] || 0;
  if (cd > 0) return { ok: false, msg: `术式尚需 ${cd} 息冷却` };
  if (breathAvailableMana() < sk.mana) return { ok: false, msg: "可用真元不足（运功占用部分真元）" };
  if (!manual && BREATH.playerGas < breathGasCost(sk)) return { ok: false, msg: "气息尚未蓄满" };
  // 手动催动不额外获得攻击次数：自身气息归零。
  if (manual) BREATH.playerGas = 0;
  else BREATH.playerGas -= breathGasCost(sk);
  f.player.mana = Math.max(0, f.player.mana - sk.mana);
  BREATH.cooldowns[key] = Math.max(1, Math.ceil(sk.cd || 1));
  const reserveDamage = breathYungongDamage();
  if (sk.manaRestorePct) {
    const restored = Math.floor(f.player.manaMax * sk.manaRestorePct);
    f.player.mana = Math.min(f.player.manaMax, f.player.mana + restored);
    breathLog(`施展「${sk.name}」，回复真元 ${fmt(restored)}`, "good");
    breathSetAction("player", sk.name, sk.color);
  }
  if (sk.healPct) {
    const heal = Math.floor(f.player.hpMax * sk.healPct);
    f.player.hp = Math.min(f.player.hpMax, f.player.hp + heal);
    breathLog(`施展「${sk.name}」，恢复气血 ${fmt(heal)}`, "good");
    breathSetAction("player", sk.name, sk.color);
  }
  if (sk.shieldPct) {
    const shield = Math.floor(f.player.hpMax * sk.shieldPct);
    f.player.shield = Math.max(f.player.shield || 0, shield);
    breathLog(`施展「${sk.name}」，凝成护体灵盾 ${fmt(shield)}`, "good");
    breathSetAction("player", sk.name, sk.color);
  }
  breathApplySkillBuff(sk);
  const hasSupport = !!(sk.manaRestorePct || sk.healPct || sk.shieldPct || sk.atkPct || sk.critPct || sk.dodgePct || sk.damageReducePct);
  if (!hasSupport || sk.mult > 0) {
    const atk = (f.player.atk + reserveDamage) * (1 + breathBuffValue("atkPct"));
    breathDamage({ atk, hits: sk.hits || 1, lifestealPct: sk.lifestealPct || 0 }, enemy, sk.mult || 1, "player", sk.name);
    // 控制类术式在敌方蓄力阶段可打断。
    if (sk.slow && enemy.alive) {
      BREATH.enemySlow = { value: Math.max(0, Math.min(0.8, sk.slow)), left: Math.max(1, Math.ceil(sk.slowSec || 1)) };
      breathLog(`「${sk.name}」迟滞敌方气息，持续 ${BREATH.enemySlow.left} 息`, "good");
    }
    if ((sk.control || sk.slow) && BREATH.enemyGas >= 70 && enemy.alive) {
      BREATH.enemyGas = 0;
      breathLog(`「${sk.name}」打断敌方蓄力！`, "good");
    }
  }
  if (BREATH.el) breathUpdateHud();
  return { ok: true };
}
function breathPlayerAct() {
  const f = BREATH.field, enemy = breathEnemy();
  if (!enemy) return false;
  const slots = f.slots || [];
  // 严格按槽位顺序选择第一个「CD 好且真元足够」的术式。
  // 选中后若气息未满，必须等待；不能跳过它去释放后续轻式，否则槽位排序失去策略意义。
  for (let i = 0; i < slots.length; i++) {
    const idx = (BREATH.slotCursor + i) % slots.length;
    const key = slots[idx], sk = fldSkill(key);
    if (!sk || (BREATH.cooldowns[key] || 0) > 0 || breathAvailableMana() < sk.mana) continue;
    if (BREATH.playerGas < breathGasCost(sk)) return false;
    BREATH.slotCursor = (idx + 1) % Math.max(1, slots.length);
    breathUseSkill(key, false);
    return true;
  }
  if (BREATH.playerGas >= 100) {
    BREATH.playerGas -= 100;
    const reserveDamage = breathYungongDamage();
    breathDamage({ atk: (f.player.atk + reserveDamage) * (1 + breathBuffValue("atkPct")) }, enemy, 1, "player", "基础剑击");
    return true;
  }
  return false;
}
function breathTick() {
  const f = BREATH.field, enemy = breathEnemy();
  if (!enemy) { breathComplete(true); return; }
  BREATH.tick++;
  for (const k in BREATH.cooldowns) BREATH.cooldowns[k] = Math.max(0, BREATH.cooldowns[k] - 1);
  // 一息=1秒。基础疾速100/息；身法功法接入后在此乘算。
  const qiMax = (CONFIG.BATTLE2 && CONFIG.BATTLE2.QI_MAX) || 200;
  const qiRegen = (CONFIG.BATTLE2 && CONFIG.BATTLE2.QI_REGEN) || 100;
  BREATH.playerGas = Math.min(qiMax, BREATH.playerGas + qiRegen * (1 + (BREATH.profile.speed || 0)));
  // 原地图怪物攻击值按自由走位玩法标定；回合化后降低其出手频率与单次伤害，避免玩家无法走位时被秒杀。
  const slowRatio = BREATH.enemySlow && BREATH.enemySlow.left > 0 ? BREATH.enemySlow.value : 0;
  BREATH.enemyGas = Math.min(150, BREATH.enemyGas + 70 * (1 - slowRatio));
  if (BREATH.enemySlow && BREATH.enemySlow.left > 0) {
    BREATH.enemySlow.left--;
    if (!BREATH.enemySlow.left) BREATH.enemySlow = null;
  }
  // 真元基础回复按设计稿 §7.5 固定为 12 点/秒；功法回复属性作为比例加成。
  // 旧实现按真元上限的 4.5% 回复，基准真元 200 时仅为 9 点/秒，与配置脱节。
  const manaRegenBase = (CONFIG.BATTLE2 && CONFIG.BATTLE2.MANA_REGEN) || 12;
  f.player.mana = Math.min(f.player.manaMax, f.player.mana + manaRegenBase * (1 + (BREATH.profile.manaRegen || 0)));
  breathPlayerAct();
  if (!enemy.alive) { breathEnemy(); if (!breathEnemy()) { breathComplete(true); return; } }
  const target = breathEnemy();
  if (target && BREATH.enemyGas >= 100) {
    BREATH.enemyGas -= 100;
    if (Math.random() < Math.min(0.75, (BREATH.profile.dodge || 0) + breathBuffValue("dodgePct"))) { breathLog(`身法发动，避开「${target.name}」的攻击`, "good"); breathSetAction("player", "闪避", "#547d9b"); breathUpdateHud(); return; }
    const shield = Math.max(0, f.player.shield || 0);
    const raw = Math.max(target.atk - f.player.def, target.atk * 0.05);
    const blocked = Math.min(shield, raw);
    if (blocked) f.player.shield -= blocked;
    const damageReduce = Math.min(0.6, Math.max(0, breathBuffValue("damageReducePct")));
    const damage = blocked >= raw ? 0 : Math.max(1, Math.floor((raw - blocked) * (1 - damageReduce)));
    f.player.hp = Math.max(0, f.player.hp - damage);
    breathLog(`${target.name} 出手，造成 ${fmt(damage)} 伤害${blocked ? `（灵盾吸收 ${fmt(blocked)}）` : ""}`, "bad");
    breathSetAction("enemy", "妖兽扑击", "#a65b4c");
  }
  // 增益持续时间在本息双方行动结算后递减，确保标注的 N 息覆盖 N 次完整敌方行动窗口。
  for (const k in (BREATH.buffs || {})) {
    BREATH.buffs[k].left = Math.max(0, BREATH.buffs[k].left - 1);
    if (!BREATH.buffs[k].left) delete BREATH.buffs[k];
  }
  if (f.player.hp <= 0) breathComplete(false);
  breathUpdateHud();
}
function breathUpdateHud() {
  if (!BREATH.el) return;
  const f = BREATH.field, enemy = breathEnemy();
  const set = (sel, val) => { const e = BREATH.el.querySelector(sel); if (e) e.style.width = `${Math.max(0, Math.min(100, val))}%`; };
  set(".bt-player-hp i", f.player.hp / f.player.hpMax * 100);
  set(".bt-player-mana i", f.player.mana / f.player.manaMax * 100);
  set(".bt-player-gas i", BREATH.playerGas / ((CONFIG.BATTLE2 && CONFIG.BATTLE2.QI_MAX) || 200) * 100);
  set(".bt-enemy-hp i", enemy ? enemy.hp / enemy.hpMax * 100 : 0);
  set(".bt-enemy-gas i", BREATH.enemyGas / 150 * 100);
  const name = BREATH.el.querySelector(".bt-enemy-name"); if (name) name.textContent = enemy ? enemy.name : "已清除";
  const info = BREATH.el.querySelector(".bt-turn"); if (info) info.textContent = `一息 ${BREATH.tick} · 妖兽 ${f.killCount}/${f.monsters.length}`;
  for (const b of BREATH.el.querySelectorAll("[data-bt-skill]")) {
    const key = b.dataset.btSkill, sk = fldSkill(key);
    const cd = BREATH.cooldowns[key] || 0;
    b.disabled = cd > 0 || breathAvailableMana() < sk.mana;
    const sub = b.querySelector("small"); if (sub) sub.textContent = cd > 0 ? `冷却 ${cd}` : `气息 ${breathGasCost(sk)} · 真元 ${sk.mana}`;
  }
}
function breathRender(now) {
  const c = BREATH.canvas, ctx = BREATH.ctx;
  if (!c || !ctx) return;
  const w = c.width, h = c.height;
  ctx.clearRect(0, 0, w, h);
  // 水墨擂台背景
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, "#e7e1d2"); g.addColorStop(1, "#c7c0ae");
  ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = "rgba(78,68,52,.08)";
  for (let i=0;i<6;i++) { ctx.beginPath(); ctx.ellipse(w*(.1+i*.17),h*.78,90+i*14,16+i*3,0,0,Math.PI*2); ctx.fill(); }
  ctx.strokeStyle = "rgba(75,65,50,.18)"; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(0,h*.82); ctx.quadraticCurveTo(w*.5,h*.72,w,h*.82); ctx.stroke();
  const action = BREATH.action;
  const progress = action ? Math.min(1,(now-action.start)/action.duration) : 1;
  const pose = action ? Math.sin(progress*Math.PI) : 0;
  // 旧术式残影只保留特效，不保留骨骼动作，最多两层。
  BREATH.ghosts = BREATH.ghosts.filter(x => now-x.start < x.life);
  for (const x of BREATH.ghosts) { const a=1-(now-x.start)/x.life; ctx.globalAlpha=a*.35; ctx.strokeStyle=x.color; ctx.lineWidth=5; ctx.beginPath(); ctx.arc(x.side==="player"?w*.28:w*.72,h*.54,28+(1-a)*45,0,Math.PI*2); ctx.stroke(); }
  ctx.globalAlpha=1;
  function stick(x,y,flip,color,active) {
    const lean=(active?pose*.42:0)*(flip?-1:1), arm=(active?pose*.65:0)*(flip?-1:1);
    ctx.save(); ctx.translate(x,y); ctx.scale(flip?-1:1,1); ctx.rotate(lean);
    ctx.strokeStyle=color; ctx.fillStyle=color; ctx.lineWidth=6; ctx.lineCap="round";
    ctx.beginPath(); ctx.arc(0,-66,11,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.moveTo(0,-54); ctx.lineTo(0,-12); ctx.moveTo(0,-43); ctx.lineTo(28+arm*22,-25-arm*10); ctx.moveTo(0,-43); ctx.lineTo(-25,-25); ctx.moveTo(0,-12); ctx.lineTo(22,25); ctx.moveTo(0,-12); ctx.lineTo(-20,25); ctx.stroke();
    ctx.restore();
  }
  stick(w*.27,h*.72,false,"#514936",!!(action&&action.side==="player"));
  stick(w*.73,h*.72,true,"#713f36",!!(action&&action.side==="enemy"));
  if (action && now-action.start < action.duration) {
    ctx.globalAlpha=1-progress; ctx.strokeStyle=action.color; ctx.lineWidth=5; ctx.beginPath(); ctx.moveTo(w*.36,h*.48); ctx.quadraticCurveTo(w*.5,h*.28,w*.64,h*.48); ctx.stroke(); ctx.globalAlpha=1;
  }
  BREATH.effects = BREATH.effects.filter(x=>now-x.start<x.life);
  for (const e of BREATH.effects) { const a=1-(now-e.start)/e.life; ctx.globalAlpha=a; ctx.fillStyle=e.side==="player"?"#9b7838":"#9c4e40"; ctx.font="bold 18px sans-serif"; ctx.textAlign="center"; ctx.fillText(`${e.crit?"会心 ":""}${fmt(e.damage)}`,e.side==="player"?w*.68:w*.32,h*.36-(1-a)*24); }
  ctx.globalAlpha=1;
}
function breathLoop(now) {
  if (!BREATH.active) return;
  let dt=(now-BREATH.last)/1000; BREATH.last=now;
  if (!isFinite(dt)||dt<0) dt=0;
  dt=Math.min(dt,.08);
  const speed=(S.settings&&[1,1.5,2].includes(Number(S.settings.combatSpeed)))?Number(S.settings.combatSpeed):1;
  BREATH.acc += dt*speed;
  while (BREATH.acc>=1 && BREATH.active) { BREATH.acc-=1; breathTick(); }
  breathRender(now); breathUpdateHud();
  BREATH.raf=requestAnimationFrame(breathLoop);
  FS.raf=BREATH.raf;
}
function breathComplete(win) {
  if (!BREATH.active || BREATH.resultShown) return;
  BREATH.resultShown=true; BREATH.active=false;
  const f=BREATH.field;
  f.over=true; f.win=!!win; f.explore=f.exploreMax; f.portal=win?{}:null; f.gathered=0;
  if (win) {
    breathLog("秘境妖兽已尽数清除。", "good");
    // 结算统一复用旧版通关函数，保证关卡、掉落、图鉴、首探奖励口径一致。
    setTimeout(()=>fsFinish(),450);
  } else {
    setTimeout(()=>fsFinish(),450);
  }
}
function startFieldBattle(chapter) {
  if (BREATH.active) breathClose();
  if (!fldChapterUnlocked(chapter)) { toast("该秘境尚未解锁 · 先通关上一章末关"); return; }
  if (S.stamina<1) { toast("体力不足，请稍候恢复"); return; }
  S.stamina--;
  if (typeof dailyProgress==="function") dailyProgress("field1",1);
  if (typeof sectTaskProgress==="function") sectTaskProgress("enter",1);
  save();
  const f=fldCreate(chapter);
  BREATH.profile = (typeof gongfaV2Profile === "function") ? gongfaV2Profile() : {};
  const gp = BREATH.profile;
  f.player.atk *= (1 + (gp.atk || 0));
  f.player.def *= (1 + (gp.def || 0));
  f.player.hpMax = Math.floor(f.player.hpMax * (1 + (gp.hp || 0)));
  f.player.hp = f.player.hpMax;
  f.player.manaMax = Math.floor(f.player.manaMax * (1 + (gp.mana || 0)));
  f.player.mana = f.player.manaMax;
  breathNormalizeEnemies(f);
  f.monsters.sort((a,b)=>({normal:0,elite:1,wild:2,boss:3}[a.kind]??0)-({normal:0,elite:1,wild:2,boss:3}[b.kind]??0));
  f.monsters.forEach(m=>{m.hp=m.hpMax; m.alive=true;});
  BREATH.field=f; BREATH.active=true; BREATH.raf=0; BREATH.last=performance.now(); BREATH.acc=0; BREATH.tick=0;
  BREATH.playerGas=0; BREATH.enemyGas=0; BREATH.enemyIndex=0; BREATH.slotCursor=0; BREATH.cooldowns={}; BREATH.logs=[]; BREATH.action=null; BREATH.ghosts=[]; BREATH.effects=[]; BREATH.buffs={}; BREATH.enemySlow=null; BREATH.resultShown=false;
  // 普通术式按境界容量配置；法宝技独立追加，不挤占普通槽位。
  const slots = breathConfiguredSlots();
  f.slots = slots;
  const el=document.createElement("div"); el.id="field-screen"; el.className="breath-screen";
  el.innerHTML=`
    <div class="bt-top"><b>${esc(f.map.name)} · 气息战</b><span class="bt-turn">一息 0</span><button class="fs-exit" data-bt="exit">✕</button></div>
    <div class="bt-fighters"><div class="bt-unit"><b>${esc(S.playerName||"修士")}</b><div class="bt-bar bt-player-hp"><i></i></div><small>气血</small><div class="bt-bar bt-player-mana"><i></i></div><small>真元</small><div class="bt-bar bt-player-gas"><i></i></div><small>气息</small></div>
    <div class="bt-unit bt-enemy-unit"><b class="bt-enemy-name">${esc(f.monsters[0]?.name||"妖兽")}</b><div class="bt-bar bt-enemy-hp"><i></i></div><small>气血</small><div class="bt-bar bt-enemy-gas"><i></i></div><small>气息</small></div></div>
    <canvas class="bt-canvas" width="900" height="430"></canvas>
    <div class="bt-yungong"><label>运功比例 <b class="bt-yungong-label">${Math.round(breathYungongRatio()*100)}%</b></label><input type="range" min="0" max="60" step="5" value="${Math.round(breathYungongRatio()*100)}" data-bt-yungong></div>
    <div class="bt-skills">${slots.filter(k=>{const sk=fldSkill(k);return sk && !sk.fromFabao;}).map(k=>{const sk=fldSkill(k);return `<button data-bt-skill="${k}"><b>${esc(sk.name)}</b><small>气息 ${breathGasCost(sk)} · 真元 ${sk.mana}</small></button>`;}).join("")}</div>
    ${slots.some(k=>{const sk=fldSkill(k);return sk && sk.fromFabao;}) ? `<div class="bt-fabao-skill"><small>法宝技 · 独立第五格</small>${slots.filter(k=>{const sk=fldSkill(k);return sk && sk.fromFabao;}).map(k=>{const sk=fldSkill(k);return `<button data-bt-skill="${k}"><b>${esc(sk.name)}</b><small>气息 ${breathGasCost(sk)} · 真元 ${sk.mana}</small></button>`;}).join("")}</div>` : ""}
    <div class="bt-log" aria-live="polite"></div><div class="bt-foot">自动按术式槽顺序循环 · 点击术式可手动催动（自身气息归零）</div>`;
  for(const old of document.querySelectorAll("#field-screen")) if(old.parentNode) old.parentNode.removeChild(old);
  document.body.appendChild(el); BREATH.el=el; FS.el=el; FS.field=f; FS.ended=false;
  BREATH.canvas=el.querySelector(".bt-canvas"); BREATH.ctx=BREATH.canvas.getContext("2d");
  el.addEventListener("click",ev=>{
    const b=ev.target.closest("[data-bt]"); if(b&&b.dataset.bt==="exit"){ if(confirm("确定退出本次秘境？已消耗体力不返还。")) breathComplete(false); return; }
    const sk=ev.target.closest("[data-bt-skill]"); if(sk){ const r=breathUseSkill(sk.dataset.btSkill,true); if(!r.ok) toast(r.msg); }
  });
  el.addEventListener("input",ev=>{ if(ev.target.matches("[data-bt-yungong]")){S.yungongRatio=Number(ev.target.value)/100; const l=el.querySelector(".bt-yungong-label"); if(l)l.textContent=ev.target.value+"%"; save(); }});
  breathLog("秘境已入。气息每息增长，术式按槽位顺序自动催动。", "normal");
  breathUpdateHud(); BREATH.raf=requestAnimationFrame(breathLoop); FS.raf=BREATH.raf;
}
function breathClose() {
  BREATH.active=false; if(BREATH.raf)cancelAnimationFrame(BREATH.raf); BREATH.raf=0;
  if(BREATH.el&&BREATH.el.parentNode)BREATH.el.parentNode.removeChild(BREATH.el);
  BREATH.el=null; BREATH.canvas=null; BREATH.ctx=null; BREATH.field=null;
  FS.el=null; FS.field=null; FS.raf=0;
}
