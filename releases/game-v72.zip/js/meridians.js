// ============================================================
// 《问长生》内视系统：经脉（三脉十八穴） + 丹田（九转）（v0.50.0）
// 点穴与丹阶必成；闸门只有灵石 / 灵材 / 境界
// 属性汇总唯一来源 meridianSum()，供 playerCombat / cultivationBreakdown /
// fldManaMax / tribulationRate 读取，UI 只读不重算
// ============================================================

function meridianState() {
  if (!S.meridian || typeof S.meridian !== "object") S.meridian = {};
  const MAX = CONFIG.MERIDIAN.MAX_PER;
  for (const d of CONFIG.MERIDIANS) {
    const v = Number(S.meridian[d.key]);
    S.meridian[d.key] = isFinite(v) ? Math.max(0, Math.min(MAX, Math.floor(v))) : 0;
  }
  return S.meridian;
}
function meridianDef(key) {
  return CONFIG.MERIDIANS.find(m => m.key === key) || null;
}
function meridianHoles(key) {
  return meridianState()[key] || 0;
}
function meridianTotal() {
  return CONFIG.MERIDIANS.reduce((s, d) => s + meridianHoles(d.key), 0);
}
function meridianMaxTotal() {
  return CONFIG.MERIDIANS.length * CONFIG.MERIDIAN.MAX_PER;
}
// 下一穴的成本（第 n 穴 = 已通数 + 1）
function meridianCost(key) {
  const M = CONFIG.MERIDIAN;
  const n = meridianHoles(key) + 1;
  const idx = Math.max(1, Math.min(M.MAX_PER, n));
  return {
    n: idx,
    stone: Math.round(M.COST_STONE * Math.pow(idx, M.COST_STONE_POW)),
    mat: M.COST_MAT * idx,
    realm: (M.GATE_REALM[idx - 1] != null ? M.GATE_REALM[idx - 1] : 2),
  };
}
function meridianNextName(key) {
  const def = meridianDef(key);
  if (!def) return "";
  const n = meridianHoles(key);
  return n >= CONFIG.MERIDIAN.MAX_PER ? "" : def.holes[n];
}

// 打通下一穴（顺序、必成、有境界门槛）
function openMeridianHole(key) {
  const def = meridianDef(key);
  if (!def) return { ok: false, msg: "无此经脉" };
  const M = CONFIG.MERIDIAN;
  const n = meridianHoles(key);
  if (n >= M.MAX_PER) return { ok: false, msg: `${def.name}已全通` };
  const c = meridianCost(key);
  if ((S.realm || 0) < c.realm) {
    return { ok: false, msg: `需${CONFIG.REALMS[c.realm]}期方可打通「${def.holes[n]}」` };
  }
  if ((S.stone || 0) < c.stone) return { ok: false, msg: `灵石不足（需 ${fmt(c.stone)}）` };
  if ((S.materials || 0) < c.mat) return { ok: false, msg: `灵材不足（需 ${c.mat}）` };
  if (typeof invRemove === "function") invRemove("material", c.mat);
  else S.materials -= c.mat;
  S.stone -= c.stone;
  // v0.51.0：记录打通前后的属性快照，供 UI 展示「本次开穴」增量
  const before = meridianSum();
  S.meridian[key] = n + 1;
  const after = meridianSum();
  save();
  return {
    ok: true,
    name: def.holes[n],
    hole: n + 1,
    attr: def.attr,
    before,
    after,
    zhoutian: n + 1 >= M.MAX_PER,
    allFull: meridianTotal() >= meridianMaxTotal(),
  };
}

// ---------- 丹田 ----------
function dantianLv() {
  const v = Number(S.dantian);
  return isFinite(v) ? Math.max(0, Math.min(CONFIG.DANTIAN.MAX, Math.floor(v))) : 0;
}
function dantianUnlocked() {
  return (S.realm || 0) >= CONFIG.DANTIAN.UNLOCK_REALM;
}
function dantianCost() {
  const D = CONFIG.DANTIAN;
  const n = Math.max(1, Math.min(D.MAX, dantianLv() + 1));
  return {
    n,
    stone: Math.round(D.COST_STONE * Math.pow(n, D.COST_STONE_POW)),
    mat: D.COST_MAT * n,
  };
}
// 凝丹 / 升阶（同一函数：0 → 1 为凝丹，其后为升阶）
function raiseDantian() {
  const D = CONFIG.DANTIAN;
  if (!dantianUnlocked()) {
    return { ok: false, msg: `需${CONFIG.REALMS[D.UNLOCK_REALM]}期方可凝丹` };
  }
  const lv = dantianLv();
  if (lv >= D.MAX) return { ok: false, msg: "丹已九转，圆满" };
  const c = dantianCost();
  if ((S.stone || 0) < c.stone) return { ok: false, msg: `灵石不足（需 ${fmt(c.stone)}）` };
  if ((S.materials || 0) < c.mat) return { ok: false, msg: `灵材不足（需 ${c.mat}）` };
  if (typeof invRemove === "function") invRemove("material", c.mat);
  else S.materials -= c.mat;
  S.stone -= c.stone;
  const before = meridianSum();
  S.dantian = lv + 1;
  const after = meridianSum();
  save();
  return { ok: true, lv: lv + 1, first: lv === 0, before, after };
}

// ---------- 属性汇总（唯一来源） ----------
// 每通 1 穴：该脉主属性 +2%；一脉全通：再 +5% 且修炼 +3%；
// 三脉全通：全属性 +5%、渡劫 +3%；丹田每阶：修炼 +2%、真元 +8、渡劫 +0.5%
function meridianSum() {
  const M = CONFIG.MERIDIAN;
  const out = { atk: 0, def: 0, hp: 0, cult: 0, trib: 0, mana: 0 };
  let allFull = true;
  for (const d of CONFIG.MERIDIANS) {
    const n = meridianHoles(d.key);
    if (n < M.MAX_PER) allFull = false;
    out[d.attr] += M.PER_HOLE * n + (n >= M.MAX_PER ? M.ZHOUTIAN : 0);
    if (n >= M.MAX_PER) out.cult += M.ZHOUTIAN_CULT;
  }
  if (allFull && CONFIG.MERIDIANS.length) {
    out.atk += M.GREAT_ATTR;
    out.def += M.GREAT_ATTR;
    out.hp += M.GREAT_ATTR;
    out.trib += M.GREAT_TRIB;
  }
  const D = CONFIG.DANTIAN;
  const dl = dantianLv();
  out.cult += dl * D.CULT;
  out.trib += dl * D.TRIB;
  out.mana += dl * D.MANA;
  return out;
}

// ---------- 人物简图几何（纯 SVG 线路，不依赖图片资源） ----------
// 坐标基于 viewBox "0 0 120 200"；每脉由下而上 6 个穴位
function meridianSvgData() {
  const xs = { chong: 54, ren: 60, du: 66 };
  const ys = {
    ren:   [110, 96, 82, 68, 56, 44],   // 会阴 → 承浆
    du:    [112, 98, 84, 66, 48, 30],   // 长强 → 百会
    chong: [104, 92, 80, 70, 60, 50],   // 气冲 → 幽门
  };
  return CONFIG.MERIDIANS.map(d => {
    const n = meridianHoles(d.key);
    const pts = ys[d.key].map((y, i) => ({
      x: xs[d.key], y,
      name: d.holes[i],
      on: i < n,
      next: i === n,
    }));
    return { def: d, holes: n, pts, line: pts.slice().sort((a, b) => a.y - b.y) };
  });
}

// 人体轮廓（一次性常量：头/躯干/四肢）
const MERIDIAN_BODY_PATHS = [
  "M60 13 a11 11 0 1 0 0.1 0",                 // 头
  "M60 35 L60 41",                              // 颈
  "M42 48 Q60 41 78 48",                        // 肩
  "M43 49 Q45 80 44 112 L76 112 Q75 80 77 49",  // 躯干
  "M42 49 Q30 70 25 106",                       // 左臂
  "M78 49 Q90 70 95 106",                       // 右臂
  "M48 112 Q45 145 43 182",                     // 左腿
  "M72 112 Q75 145 77 182",                     // 右腿
];
