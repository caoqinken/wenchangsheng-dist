// ============================================================
// 《问长生》五行流派与克制（v0.36.0）
// 功法按五行分属；主修流派克制秘境元素 → 伤害加成；流派专精加成
// ============================================================

function elementDef(key) {
  return CONFIG.ELEMENTS.find(e => e.key === key) || null;
}

// 功法元素：按配置表索引循环分配
function gongfaElementOf(key) {
  const idx = CONFIG.GONGFA_BOOKS.findIndex(b => b.key === key);
  if (idx < 0) return null;
  return CONFIG.GONGFA_ELEMENTS[idx % CONFIG.GONGFA_ELEMENTS.length];
}

// 相生：a 生 b（v0.46.0）
function elementGenerates(a, b) {
  if (!a || !b) return false;
  const da = elementDef(a);
  return !!da && da.gen === b;
}

function elementName(key) {
  const d = elementDef(key);
  return d ? d.name : "—";
}

function elementBeats(a, b) {
  const d = elementDef(a);
  return !!(d && d.beats === b);
}

// 主修流派：已领悟功法中（层数+1）累计最高的元素
function mainElement() {
  const books = S.gongfaBooks || {};
  const score = {};
  for (const k in books) {
    if (!books[k] || !books[k].learned) continue;
    const el = gongfaElementOf(k);
    if (!el) continue;
    score[el] = (score[el] || 0) + (books[k].lv || 0) + 1;
  }
  let best = null, bv = -1;
  for (const k in score) if (score[k] > bv) { bv = score[k]; best = k; }
  return best;
}

// 流派专精：主修元素功法总层数 → 伤害 +1%/层（上限 +20%）
function elementMasteryBonus() {
  const me = mainElement();
  if (!me) return 0;
  const books = S.gongfaBooks || {};
  let lv = 0;
  for (const k in books) {
    if (books[k] && books[k].learned && gongfaElementOf(k) === me) lv += (books[k].lv || 0);
  }
  return Math.min(0.20, lv * 0.01);
}

// 对某元素的伤害乘区
function elementCombatMult(targetElement) {
  const me = mainElement();
  if (!me || !targetElement) return 1;
  if (elementBeats(me, targetElement)) return 1 + CONFIG.ELEMENT_COUNTER;
  if (elementBeats(targetElement, me)) return 1 - CONFIG.ELEMENT_COUNTERED;
  return 1;
}

// 主修流派摘要（UI）
function elementSummary() {
  const me = mainElement();
  if (!me) return "主修：尚未定流派（领悟功法后确定）";
  const d = elementDef(me);
  const beats = elementDef(d.beats);
  return `主修 ${d.name}行流派 ｜ 克制 ${beats ? beats.name : "—"} ｜ 专精 +${Math.round(elementMasteryBonus() * 100)}%`;
}
