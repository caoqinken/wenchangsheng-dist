// ============================================================
// 《问长生》灵兽系统（v0.21.0）
// 跟宠形态：跟在角色身后、自动索敌攻击、不承伤
// 获取：在秘境中击败野生灵兽后按概率收服
// 养成：培养提升等级，等级放大攻击
// ============================================================

let petIdSeq = 1;

const PET_ICON = {
  chiyan: "assets/灵兽_赤焰狐.webp",
  qinglin: "assets/灵兽_青鳞蛇.webp",
  xuangui: "assets/灵兽_玄龟.webp",
  baiyu: "assets/灵兽_白羽鹤.webp",
  leiven: "assets/灵兽_雷纹豹.webp",
  youming: "assets/灵兽_幽冥狼.webp",
  jinjing: "assets/灵兽_金睛猿.webp",
  jiuwei: "assets/灵兽_九尾天狐.webp",
};

function petIcon(key, cls) {
  const src = PET_ICON[key];
  if (!src) return "";
  return `<img class="pet-ico ${cls || ""}" src="${src}" alt="">`;
}

function petDef(key) {
  return CONFIG.PETS.find(p => p.key === key) || null;
}

function petState() {
  if (!Array.isArray(S.pets)) S.pets = [];
  return S.pets;
}

function refreshPetSeq() {
  let maxId = 0;
  for (const p of petState()) {
    if (p && typeof p.id === "number" && p.id > maxId) maxId = p.id;
  }
  petIdSeq = maxId + 1;
}

// 生成一只灵兽实例（v0.24.0：+星级/亲密度/技能）
function makePet(key) {
  const def = petDef(key);
  if (!def) return null;
  return {
    id: petIdSeq++,
    key,
    lv: 1,
    exp: 0,
    star: 1,                                   // 星级 1~5（融合升星提升）
    bond: 0,                                   // 亲密度 0~100
    skills: (CONFIG.petSkillRoll ? CONFIG.petSkillRoll(def.tier) : []),  // 捕捉时按稀有度掷技能
    obtained: (typeof totalDays === "function") ? totalDays() : 0,
  };
}

// 当前出战灵兽（fldCreate 用）
function activePet() {
  const id = S.petActive;
  if (id == null) return null;
  return petState().find(p => p.id === id) || null;
}

// 出战灵兽的实战属性（v0.24.0：+星级/亲密度加成，技能透传）
function petCombat(inst) {
  if (!inst) return null;
  const def = petDef(inst.key);
  if (!def) return null;
  const player = playerCombat();
  const lvMul = 1 + (inst.lv - 1) * 0.07;
  const starMul = 1 + (CONFIG.PET_STAR_ATK * ((inst.star || 1) - 1));   // 每星 +8%
  const bondMul = 1 + (CONFIG.PET_BOND_ATK * (inst.bond || 0) / CONFIG.PET_BOND_MAX);  // 亲密度最高 +10%
  return {
    def,
    atk: player.attack * def.atkMul * lvMul * starMul * bondMul,
    speed: CONFIG.FIELD.PLAYER_SPEED * def.speedMul * 0.85,
    cd: def.cd,
    color: def.color,
    name: def.name,
    lv: inst.lv,
    star: inst.star || 1,
    bond: inst.bond || 0,
    skills: inst.skills || [],
  };
}

// 战力展示（养成评估用）：以基础攻倍率 × 等级/星/亲密加成的相对值
function petPower(inst) {
  const pc = petCombat(inst);
  if (!pc) return 0;
  return Math.round(pc.atk / pc.cd * 10);
}

// 收服（秘境击杀野生灵兽时调用）
function capturePet(key) {
  const def = petDef(key);
  if (!def) return { ok: false, msg: "未知灵兽" };
  const list = petState();
  if (list.length >= CONFIG.PET_MAX) {
    return { ok: false, msg: `灵兽栏已满（${CONFIG.PET_MAX} 只）` };
  }
  const inst = makePet(key);
  list.push(inst);
  if (S.petActive == null) S.petActive = inst.id;   // 首只自动出战
  if (typeof recordPetCodex === "function") recordPetCodex(key);
  save();
  return { ok: true, pet: inst, def };
}

// 出战 / 休息
function setActivePet(id) {
  if (id == null) {
    S.petActive = null;
    save();
    return { ok: true, pet: null };
  }
  const inst = petState().find(p => p.id === id);
  if (!inst) return { ok: false, msg: "灵兽不存在" };
  S.petActive = id;
  save();
  return { ok: true, pet: inst };
}

// 培养：消耗灵石提升经验，满即升级
function trainPet(id) {
  const inst = petState().find(p => p.id === id);
  if (!inst) return { ok: false, msg: "灵兽不存在" };
  if (inst.lv >= CONFIG.PET_MAX_LV) return { ok: false, msg: "灵兽已达等级上限" };
  const cost = CONFIG.PET_TRAIN_STONE * inst.lv;
  if (S.stone < cost) return { ok: false, msg: `灵石不足（需 ${fmt(cost)}）` };
  S.stone -= cost;
  if (typeof weeklyProgress === "function") weeklyProgress("pet3", 1);
  inst.exp += 1;
  const need = CONFIG.PET_EXP_PER_LV * inst.lv;
  let levelUp = false;
  if (inst.exp >= need) {
    inst.exp -= need;
    inst.lv++;
    levelUp = true;
  }
  save();
  return { ok: true, pet: inst, levelUp, cost };
}

// 放生
function releasePet(id) {
  const list = petState();
  const i = list.findIndex(p => p.id === id);
  if (i < 0) return { ok: false, msg: "灵兽不存在" };
  const p = list[i];
  list.splice(i, 1);
  if (S.petActive === id) S.petActive = list.length ? list[0].id : null;
  save();
  return { ok: true, pet: p };
}

// ---------- 灵兽深度养成（v0.24.0） ----------

// 融合升星：消耗 1 只同名灵兽 + 灵石，目标星级 +1（上限 5）
// 因果闭环：重复捕捉的个体成为升星素材，稀有灵兽的重复价值由此体现
function fuseStar(targetId, fodderId) {
  const list = petState();
  const target = list.find(p => p.id === targetId);
  const fodder = list.find(p => p.id === fodderId);
  if (!target || !fodder) return { ok: false, msg: "灵兽不存在" };
  if (targetId === fodderId) return { ok: false, msg: "不能与自身融合" };
  if (fodder.key !== target.key) return { ok: false, msg: "融合需要同名灵兽" };
  if ((target.star || 1) >= CONFIG.PET_STAR_MAX) return { ok: false, msg: "已达 5 星上限" };
  if (fodder.id === S.petActive) return { ok: false, msg: "出战中的灵兽不能作为素材" };
  const cost = CONFIG.PET_STAR_STONE * (target.star || 1);
  if (S.stone < cost) return { ok: false, msg: `灵石不足（需 ${fmt(cost)}）` };
  S.stone -= cost;
  target.star = (target.star || 1) + 1;
  // 素材灵兽消失（被吞噬融合）
  const fi = list.indexOf(fodder);
  if (fi >= 0) list.splice(fi, 1);
  if (S.petActive === fodderId) S.petActive = list.length ? list[0].id : null;
  save();
  return { ok: true, pet: target, cost, star: target.star };
}

// 喂食：1 灵草 → +8 亲密度（上限 100）
function feedBond(id) {
  const inst = petState().find(p => p.id === id);
  if (!inst) return { ok: false, msg: "灵兽不存在" };
  if ((inst.bond || 0) >= CONFIG.PET_BOND_MAX) return { ok: false, msg: "亲密度已满" };
  if (S.herbs < 1) return { ok: false, msg: "灵草不足" };
  invRemove("herb", 1);
  inst.bond = Math.min(CONFIG.PET_BOND_MAX, (inst.bond || 0) + CONFIG.PET_BOND_FEED_HERB);
  save();
  return { ok: true, pet: inst, bond: inst.bond };
}

// 秘境战斗结算：按击杀数积累亲密度（击杀 BOSS 额外奖励）
function petBondGain(inst, killCount, bossKilled) {
  if (!inst) return 0;
  if ((inst.bond || 0) >= CONFIG.PET_BOND_MAX) return 0;
  const gain = Math.min(
    CONFIG.PET_BOND_MAX - inst.bond,
    killCount * CONFIG.PET_BOND_PER_KILL + (bossKilled ? CONFIG.PET_BOND_BOSS_BONUS : 0)
  );
  if (gain <= 0) return 0;
  inst.bond = Math.min(CONFIG.PET_BOND_MAX, inst.bond + gain);
  return Math.round(gain * 10) / 10;
}

// 图鉴收录
function recordPetCodex(key) {
  if (typeof S.codex !== "object" || !S.codex) return;
  if (!S.codex.pets || typeof S.codex.pets !== "object") S.codex.pets = {};
  if (!S.codex.pets[key]) {
    S.codex.pets[key] = true;
    if (typeof save === "function") save();
  }
}

function petSeen(key) {
  return !!(S.codex && S.codex.pets && S.codex.pets[key]);
}

// ---------- 灵兽内丹（v0.35.0）----------
function petInnerOf(petId) { return (S.petInner && S.petInner[petId]) || null; }
function petInnerBonus(kind) {
  const p = (typeof activePet === "function") ? activePet() : null;
  if (!p) return 0;
  const k = petInnerOf(p.id);
  if (k === "atk" && kind === "atk") return 0.08;
  if (k === "guard" && kind === "guard") return 0.15;
  if (k === "mana" && kind === "mana") return 0.20;
  return 0;
}
function setPetInner(petId, kind) {
  const inst = petState().find(p => String(p.id) === String(petId));
  if (!inst) return { ok: false, msg: "灵兽不存在" };
  if (!CONFIG.PET_INNER.some(x => x.key === kind)) return { ok: false, msg: "无此内丹" };
  if (!S.petInner) S.petInner = {};
  S.petInner[inst.id] = kind;
  save();
  return { ok: true, kind };
}
function clearPetInner(petId) {
  if (!S.petInner) return { ok: false, msg: "无内丹" };
  delete S.petInner[petId];
  save();
  return { ok: true };
}
