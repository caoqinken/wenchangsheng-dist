// ============================================================
// 《问长生》数值配置 —— 单一数据源
// 与 docs/02_数值体系设计.md 严格对应，改数值只改这里。
// ============================================================

// 图鉴图标映射 (v0.23.1)
const CODEX_EVENT_ICON = {
  invasion: "assets/事迹_魔渊入侵.webp",
  beasttide: "assets/事迹_妖兽潮.webp",
  auction: "assets/事迹_散修拍卖会.webp",
  demonraid: "assets/事迹_魔道夺宝.webp",
  heartdemon: "assets/事迹_金丹心魔劫.webp",
};

const CODEX_BEAST_ICON = {
  wolf: "assets/妖兽_赤目狼王.webp",
  spider: "assets/妖兽_噬魂蛛后.webp",
  ape: "assets/妖兽_玄冰巨猿.webp",
  dragon: "assets/妖兽_幽冥蛟龙.webp",
  voidbeast: "assets/妖兽_虚空吞天兽.webp",
  tower_stone: "assets/妖兽_镇塔石灵.webp",
  tower_sword: "assets/妖兽_塔中剑魂.webp",
  tower_lord: "assets/妖兽_塔主无相.webp",
  starbeast: "assets/妖兽_星骸巨兽.webp",
  chaoslord: "assets/妖兽_混元守道人.webp",
};

const CODEX_REGION_ICON = {
  region_ch0: "assets/秘境_青云山门.webp",
  region_ch1: "assets/秘境_幽谷魔渊.webp",
  region_ch2: "assets/秘境_昆仑之巅.webp",
  region_ch3: "assets/秘境_九幽冥海.webp",
  region_ch4: "assets/秘境_天外仙墟.webp",
  region_ch5: "assets/秘境_星陨古域.webp",
  region_ch6: "assets/秘境_混元道场.webp",
};

function codexEventIcon(key) {
  return CODEX_EVENT_ICON[key] || "";
}

function codexBeastIcon(key) {
  return CODEX_BEAST_ICON[key] || "";
}

function codexRegionIcon(key) {
  return CODEX_REGION_ICON[key] || "";
}

const CONFIG = {
  REALMS: ["炼气", "筑基", "金丹", "元婴", "化神", "炼虚", "合体", "大乘", "渡劫", "真仙", "金仙"],
  LAYERS_PER_REALM: 9,

  // 每境基础属性（攻击/防御/血量），×4 增长
  realmBase(idx) {
    const att = 10 * Math.pow(4, idx);
    return { attack: att, defense: att / 2, hp: att * 10 };
  },
  // 层内属性：境基础 × (1 + (j)/8)，j=0..8
  playerAttr(realmIdx, layerIdx) {
    const b = CONFIG.realmBase(realmIdx);
    const f = 1 + layerIdx / 8;
    return { attack: b.attack * f, defense: b.defense * f, hp: b.hp * f };
  },

  // 突破所需灵气：cost(k) = 100 × BREAK_GROWTH^k
  // v0.10.0 由 1.35 下调至 1.318（9 境 80 层，常规经营 14.1 天）。
  // v0.13.0 境界扩至 11 境 99 层后，同样的系数会让常规经营涨到 81.3 天；
  // 为维持「常规约 2 周」，再下调至 1.29（实测 12.7 天）。
  // 注意：该常数是全局节奏阀门，改动会让所有时长数据等比例变化，必须重跑 §8.1 五档实测。
  BREAK_GROWTH: 1.29,
  breakCost(k) { return 100 * Math.pow(CONFIG.BREAK_GROWTH, k); },
  // 修炼速率（境界跃升）：base = 5^realm × 1.03^layer
  baseRate(realmIdx, layerIdx) {
    return Math.pow(5, realmIdx) * Math.pow(1.03, layerIdx);
  },

  // 战斗：怪物属性（关卡 n）
  // v0.13.0：第 30 关起（仙界段）改用更缓的增速，使金仙满层刚好收尾第 41 关
  _t2(n) { return n >= CONFIG.TIER2_START ? Math.pow(CONFIG.TIER2_GROWTH, n - (CONFIG.TIER2_START - 1)) : 1; },
  _t2base(n) { return Math.min(n, CONFIG.TIER2_START - 1); },
  enemyAttack(n) { return 5 * Math.pow(1.5, CONFIG._t2base(n)) * CONFIG._t2(n); },
  enemyDefense(n) { return 2 * Math.pow(1.5, CONFIG._t2base(n)) * CONFIG._t2(n); },
  enemyHp(n) { return 40 * Math.pow(1.6, CONFIG._t2base(n)) * CONFIG._t2(n); },
  // 掉落
  stoneDrop(n, isBoss) { return 10 * Math.pow(1.4, n) * (isBoss ? 5 : 1); },
  scrollDropChance(n, isBoss) { return isBoss ? 0.30 : 0.10; },

  // 战斗章节：每章 5 小关 + 1 BOSS（v0.7.0 由 3 章扩至 5 章 = 30 关）
  // 扩容依据：金丹~渡劫满层裸装可通 10/13/16/19/23/26/29 关，30 关正好由渡劫满层收尾
  STAGES_PER_CHAPTER: 5,
  // story：首次通关该章 BOSS 时弹出的一次性叙事（v0.11.0）
  // 设计：不再新增关卡（加关必须同步抬战力上限，会牵动已锁定的难度梯度），
  //      改用"叙事包装"提升既有 30 关的体验密度。
  CHAPTERS: [
    {
      name: "青云秘境",
      bg: "assets/秘境_青云山门.webp",
      story: {
        title: "第一章 · 青云秘境",
        text: "青云门的试炼场，云雾锁着三十三道石阶。守关的赤目狼王在此徘徊百年，专候初入道途者。你第一次握紧剑柄——不是为了杀人，是为了证明自己能走进这条路。",
        choices: [
          { key: "war", label: "执剑入世", desc: "以战证道，攻击 +2%（永久）" },
          { key: "dao", label: "守心问道", desc: "以静养道，修炼速率 +1.5%（永久）" },
        ],
      },
    },
    {
      name: "幽谷魔渊",
      bg: "assets/秘境_幽谷魔渊.webp",
      story: {
        title: "第二章 · 幽谷魔渊",
        text: "魔渊宗的边陲，瘴气里飘着未散的怨念。噬魂蛛后以修士的执念为食，那些死在半途的人都还在它腹中挣扎。你第一次明白，修仙路上真正会杀人的，往往不是妖，是别人没走完的心愿。",
        choices: [
          { key: "war", label: "斩尽残念", desc: "替他们了断，攻击 +2%（永久）" },
          { key: "dao", label: "超度亡魂", desc: "以慈悲化怨，修炼速率 +1.5%（永久）" },
        ],
      },
    },
    {
      name: "昆仑之巅",
      bg: "assets/秘境_昆仑之巅.webp",
      story: {
        title: "第三章 · 昆仑之巅",
        text: "万山之祖，风雪不化。玄冰巨猿守着上古碑文，碑上刻满飞升者的名字——没有一个是活着回来的。你在碑前站了很久，然后继续往上走。",
        choices: [
          { key: "war", label: "刻名于碑", desc: "求一个名字，攻击 +2%（永久）" },
          { key: "dao", label: "转身离去", desc: "不求虚名，修炼速率 +1.5%（永久）" },
        ],
      },
    },
    {
      name: "九幽冥海",
      bg: "assets/秘境_九幽冥海.webp",
      story: {
        title: "第四章 · 九幽冥海",
        text: "冥海无波，水面倒映的不是你的脸，是你这一路丢下的东西。幽冥蛟龙守着海底那条通往仙域的裂隙。它问你：你已经走了这么远，还知道自己为什么出发吗？",
        choices: [
          { key: "war", label: "答：为求己身长生", desc: "初心不改，攻击 +2%（永久）" },
          { key: "dao", label: "答：为不负所负", desc: "道心不移，修炼速率 +1.5%（永久）" },
        ],
      },
    },
    {
      name: "天外仙墟",
      bg: "assets/秘境_天外仙墟.webp",
      story: {
        title: "第五章 · 天外仙墟",
        text: "仙界崩塌后的废墟，漂浮着无数断裂的宫阙。虚空吞天兽在废墟间游荡。这里曾有人飞升至此，然后化为灰烬。你终于看清：长生不是终点，是另一场开始。",
        choices: [
          { key: "war", label: "踏碎废墟，另开新途", desc: "以战破局，攻击 +2%（永久）" },
          { key: "dao", label: "就此止步，归于本心", desc: "以静守成，修炼速率 +1.5%（永久）" },
        ],
      },
    },
    {
      name: "星陨古域",
      bg: "assets/秘境_星陨古域.webp",
      story: {
        title: "第六章 · 星陨古域",
        text: "陨落的星辰堆成一片荒原，每一颗都是一位没能走完的仙人的道果。这里的守关者不问你为何而来，只问你还剩几分道心。",
        choices: [
          { key: "war", label: "以道心为刃", desc: "以战证道，攻击 +2%（永久）" },
          { key: "dao", label: "以星辰为镜", desc: "以静养道，修炼速率 +1.5%（永久）" },
        ],
      },
    },
    {
      name: "混元道场",
      bg: "assets/秘境_混元道场.webp",
      story: {
        title: "第七章 · 混元道场",
        text: "万法归一的尽头，是一座空无一人的道场。道场中央只留一块无字碑。走到这里的人，都在碑上刻下自己的一生——而你还没想好要刻什么。",
        choices: [
          { key: "war", label: "刻下征伐", desc: "以战证道，攻击 +2%（永久）" },
          { key: "dao", label: "刻下空白", desc: "以静养道，修炼速率 +1.5%（永久）" },
        ],
      },
    },
  ],
  // ---------- 仙界段难度（v0.13.0）----------
  // 第 0~29 关沿用 1.5^n / 1.6^n；第 30 关起改用 TIER2_GROWTH（更低增速），
  // 使「金仙满层」刚好通过末关（第 41 关）。依据：分段实测见 docs/02 §3.5。
  TIER2_START: 30,
  TIER2_GROWTH: 1.22,

  // 关卡 n 是否为 BOSS：n % (5+1) === 5
  isBoss(n) { return n % (CONFIG.STAGES_PER_CHAPTER + 1) === CONFIG.STAGES_PER_CHAPTER; },
  chapterOf(n) { return Math.floor(n / (CONFIG.STAGES_PER_CHAPTER + 1)); },

  // 经营：建筑
  BUILDINGS: [
    { key: "farm",     name: "灵田",   desc: "产出灵草（炼丹原料）", unlockRealm: 0 },
    { key: "alchemy",  name: "炼丹房", desc: "消耗灵草炼制丹药",      unlockRealm: 1 },
    { key: "forge",    name: "炼器坊", desc: "锻造法宝，提升攻防",     unlockRealm: 2 },
    { key: "practice", name: "练功房", desc: "提升修炼速率",           unlockRealm: 0 },
    { key: "recruit",  name: "招募堂", desc: "招募弟子委派工作",      unlockRealm: 1 },
  ],
  // 建筑插画（v0.23.1）
  BUILDING_ART: {
    farm: "assets/建筑_灵田.webp",
    alchemy: "assets/建筑_炼丹房.webp",
    forge: "assets/建筑_炼器坊.webp",
    practice: "assets/建筑_练功房.webp",
    recruit: "assets/宗门山门.webp",
  },
  buildingCost(level) { return 50 * Math.pow(2, level); },   // 升级到 level+1 的成本
  recruitCost(count) { return 100 * Math.pow(1.5, count); }, // 招募第 count+1 名弟子的成本
  DISCIPLE_BONUS: 0.25,  // 每名委派弟子 +25% 建筑产出

  // 加成系数（v0.10.0：配合成本曲线下调，收窄加成区间，避免「极限配置」1 天飞升）
  // 数学约束：极限/常规倍率比必须 ≤ 约 5.6，否则常规 2 周时极限必然短于 2.5 天。
  PRACTICE_RATE_BONUS: 0.07,  // 练功房每级 +7% 修炼速率（v0.8.0 曾为 8%）
  GONGFA_RATE_BONUS: 0.07,    // 功法每级 +7% 修炼速率
  GONGFA_COST: 50,            // 功法升级基础灵石成本（×2 递增，自然限制上限）
  PILL_RATE_BONUS: 0.02,      // 每层药力 +2% 修炼速率
  PILL_BONUS_CAP: 1.0,        // 药力加成上限 +100%（即 ×2，50 层封顶；v0.8.0 曾为 2.0）
  PILL_BUFF_PER_USE: 1,       // 每服用 1 枚丹药获得 1 层药力

  // 体力
  MAX_STAMINA: 30,
  STAMINA_RECOVER_SEC: 6,     // 原型加速：6 秒恢复 1 点（正式版为 6 分钟）

  // 离线收益
  OFFLINE_CAP_SEC: 8 * 3600,  // 基础离线上限 8 小时
  OFFLINE_INCENSE_CAP_SEC: 13 * 3600, // 引魔香加持后本次离线上限 13 小时（P1）
  OFFLINE_INCENSE_DISPATCH_MULT: 1.5, // 引魔香期间秘境驻守产出 +50%
  OFFLINE_RATE: 0.5,          // 离线按 50% 速率

  // 存档（v0.25.0：改为按道号分档，每名角色独立存档）
  SAVE_KEY_PREFIX: "wenchangsheng_save_p_",   // + encodeURIComponent(道号)
  PROFILE_KEY: "wenchangsheng_profiles",      // { last: 道号, names: { 道号: {avatar, createdAt} } }
  LEGACY_KEYS: ["wenchangsheng_save_v1", "wenchangsheng_save_v2"],  // 旧单档键：不再读取，建角时清理

  // ---------- 开局建角（v0.25.0）----------
  NAME_MIN: 2,
  NAME_MAX: 8,
  RANDOM_NAMES: [
    "沈青霜", "李玄机", "鹤归云", "苏惊鸿", "陆听雪", "楚长歌",
    "云无咎", "柳寒烟", "燕南归", "江晚照", "顾长风", "白鹤眠",
    "叶知秋", "墨行舟", "温酒仙人", "折梅客",
  ],

  // 秘境探明 → 修炼加成（v0.25.0）：每探明一章 +1%，7 章满 +7%
  FIELD_CLEAR_CULT_BONUS: 0.01,

  // 坊市：功法要诀售价（v0.27.0：此前要诀唯一来源是秘境通关，玩家无处获取功法）
  TALISMAN_PRICE: 150,

  // 修炼方向（v0.29.0）：身份取舍，影响属性/修炼/真元
  DAO_PATHS: [
    { key: "fa",   name: "法修",   desc: "真元绵长，群攻刷图",     atk: 0.90, def: 1.00, hp: 0.90, cult: 1.08, mana: 1.25 },
    { key: "ti",   name: "体修",   desc: "气血浑厚，近战耐打",     atk: 1.10, def: 1.10, hp: 1.30, cult: 0.92, mana: 0.90 },
    { key: "jian", name: "剑修",   desc: "一击破敌，暴击最烈",     atk: 1.22, def: 0.95, hp: 0.95, cult: 0.98, mana: 1.00 },
    { key: "dual", name: "体法双修", desc: "全面但修行更慢（修炼 -25%）", atk: 1.00, def: 1.05, hp: 1.08, cult: 0.75, mana: 1.05 },
  ],

  // 吐纳（v0.29.0）：每日 100 次，长按松手，落点越靠后暴击越高
  TUNA: {
    DAILY: 100,
    BASE_QI: 1.2,          // 每次基础灵气（×当前每层突破所需的 1.2%）
    CRIT_CHANCE: 0.35,     // 松手在 90%~100% 区间的暴击概率
    CRIT_MIN: 2,
    CRIT_MAX: 10,
    FIRST5_TALISMAN: 1,    // 前 5 次额外给功法要诀
  },

  // 元神受损（v0.29.0）：渡劫失败的惩罚，期间不可再渡劫
  SOUL_HURT_MS: 30 * 60 * 1000,

  // ---------- 古宝体系（v0.30.0）----------
  // 三套遗宝 + 散件；升星/注灵/套装加成，接入战斗与修炼唯一来源
  ANCIENT_SETS: [
    { key: "qingyun",  name: "青云遗宝", bonus3: { cult: 0.05 }, bonus5: { atk: 0.05, def: 0.05 } },
    { key: "moyuan",   name: "魔渊遗宝", bonus3: { cult: 0.04 }, bonus5: { atk: 0.08 } },
    { key: "hunyuan",  name: "混元遗宝", bonus3: { cult: 0.06 }, bonus5: { atk: 0.06, def: 0.06, hp: 0.08 } },
  ],
  ANCIENT_TREASURES: [
    // 青云遗宝（第 1~3 章）
    { key: "qf_sword",  name: "青锋古剑", set: "qingyun", tier: 1, atk: 0.04, effect: { kind: "atk", v: 0.05 }, desc: "青云祖师佩剑余韵，锋锐内敛" },
    { key: "qf_jade",   name: "云纹玉佩", set: "qingyun", tier: 2, def: 0.04, effect: { kind: "reduce", v: 0.05 }, desc: "云纹流转，护体安神" },
    { key: "qf_mirror", name: "聚灵玉璧", set: "qingyun", tier: 2, cult: 0.06, desc: "聚四方灵气于一身" },
    { key: "qf_seal",   name: "青云古印", set: "qingyun", tier: 3, hp: 0.06, desc: "印落如山，气血自固" },
    { key: "qf_bell",   name: "清风古钟", set: "qingyun", tier: 3, atk: 0.03, cult: 0.03, effect: { kind: "cd", v: 0.05 }, desc: "钟鸣清心，攻守兼备" },
    // 魔渊遗宝（第 4~5 章）
    { key: "my_blade",  name: "幽冥血刃", set: "moyuan", tier: 4, atk: 0.07, effect: { kind: "crit", v: 0.05 }, desc: "刃上血痕不干，杀伐果决" },
    { key: "my_seal",   name: "魔渊古印", set: "moyuan", tier: 4, def: 0.05, effect: { kind: "thorns", v: 0.05 }, desc: "渊底寒铁铸印，坚不可摧" },
    { key: "my_lamp",   name: "噬魂古灯", set: "moyuan", tier: 5, atk: 0.05, hp: 0.05, effect: { kind: "lifesteal", v: 0.02 }, desc: "灯焰吞魂，愈战愈勇" },
    { key: "my_lotus",  name: "血莲宝座", set: "moyuan", tier: 5, hp: 0.10, desc: "血莲九品，生生不息" },
    { key: "my_armor",  name: "幽冥玄甲", set: "moyuan", tier: 5, def: 0.08, desc: "玄甲覆体，万法难侵" },
    // 混元遗宝（第 6~7 章）
    { key: "hy_umbrella", name: "混元宝伞", set: "hunyuan", tier: 6, def: 0.08, cult: 0.04, effect: { kind: "trib", v: 0.03 }, desc: "伞开阴阳，遮蔽劫雷" },
    { key: "hy_tower",  name: "天罡古塔", set: "hunyuan", tier: 6, atk: 0.06, hp: 0.06, effect: { kind: "skill", v: 0.04 }, desc: "塔镇八方，攻守同源" },
    { key: "hy_mirror", name: "太虚幻镜", set: "hunyuan", tier: 6, cult: 0.08, desc: "镜照虚妄，道心通明" },
    { key: "hy_ring",   name: "乾坤古环", set: "hunyuan", tier: 6, atk: 0.05, def: 0.05, desc: "环转乾坤，刚柔并济" },
    { key: "hy_pearl",  name: "混元道珠", set: "hunyuan", tier: 6, atk: 0.04, def: 0.04, hp: 0.04, cult: 0.04, desc: "一珠含万法，混元归一" },
  ],
  ANCIENT: {
    MAX_STAR: 5,            // 升星上限
    STAR_FRAG: 5,           // 升 1 星消耗碎片 = 当前星级 × 5
    INFUSE_MAX: 5,          // 注灵上限
    INFUSE_MAT: 20,         // 每级注灵消耗灵材
    INFUSE_STONE: 200,      // 每级注灵消耗灵石
    FRAG_FOR_ITEM: 10,      // 合成一件古宝所需碎片
    FRAG_PER_BOSS: 3,       // 每章 BOSS 首杀碎片
  },

  // ---------- 内视：经脉与丹田（v0.50.0）----------
  // 三脉十八穴 + 九阶丹田。点穴与丹阶必成，闸门只有灵石/灵材与境界。
  MERIDIAN: {
    MAX_PER: 6,             // 每脉 6 穴
    PER_HOLE: 0.02,         // 每通 1 穴：该脉主属性 +2%
    ZHOUTIAN: 0.05,         // 小周天（一脉全通）：该脉主属性再 +5%
    ZHOUTIAN_CULT: 0.03,    // 小周天：修炼 +3%
    GREAT_ATTR: 0.05,       // 大周天（三脉全通）：全属性 +5%
    GREAT_TRIB: 0.03,       // 大周天：渡劫 +3%
    COST_STONE: 800,        // 第 n 穴灵石 = COST_STONE × n^1.7
    COST_STONE_POW: 1.7,
    COST_MAT: 4,            // 第 n 穴灵材 = COST_MAT × n
    GATE_REALM: [0, 0, 1, 1, 2, 2],   // 各穴所需境界索引（0 炼气 / 1 筑基 / 2 金丹）
  },
  DANTIAN: {
    UNLOCK_REALM: 2,        // 金丹期方可凝丹
    MAX: 9,                 // 九转
    CULT: 0.02,             // 每阶修炼 +2%
    MANA: 8,                // 每阶真元上限 +8
    TRIB: 0.005,            // 每阶渡劫 +0.5%
    COST_STONE: 2000,       // 第 n 阶灵石 = COST_STONE × n^1.8
    COST_STONE_POW: 1.8,
    COST_MAT: 10,           // 第 n 阶灵材 = COST_MAT × n
  },
  MERIDIANS: [
    { key: "ren",   name: "任脉", attr: "hp",  alias: "阴脉之海",   note: "主气血 · 行于身前正中", holes: ["会阴", "关元", "气海", "中脘", "膻中", "承浆"] },
    { key: "du",    name: "督脉", attr: "atk", alias: "阳脉之海",   note: "主攻伐 · 行于脊背正中", holes: ["长强", "命门", "脊中", "大椎", "风府", "百会"] },
    { key: "chong", name: "冲脉", attr: "def", alias: "十二经之海", note: "主护体 · 行于少腹上行", holes: ["气冲", "横骨", "肓俞", "商曲", "通谷", "幽门"] },
  ],

  // ---------- 秘境建设 / 养成 / 立宗（v0.31.0）----------
  FIELD_BUILD: {
    MINE_RATE: 0.10,     // 矿场每级：该秘境驻守产出 +10%（灵石侧）
    GARDEN_RATE: 0.10,   // 药圃每级：该秘境驻守产出 +10%（灵草侧）
  },
  WARM: { MAX: 10, MAT: 30, STONE: 300, BONUS: 0.02 },       // 法宝温养：每级 +2% 评分
  INSIGHT: { MAX: 5, TALISMAN: 1, STONE: 500, BONUS: 0.03 }, // 神通参悟：每级 +3% 倍率
  SECT: {
    NEED_TERRITORY: 3,   // 立宗所需驻守秘境数
    BASE_STONE: 5000,    // 立宗灵石
    BASE_SPC: 5,         // 立宗特产（当前最高章）
    MAX_LV: 5,           // 宗门等级上限
    ATTR: 0.015,         // 每级全属性 +1.5%
    CULT: 0.01,          // 每级修炼 +1%
    UP_STONE: 8000,      // 升级基础灵石（×1.5/级）
    UP_SPC: 3,           // 升级特产
  },

  // 坊市今日特价（v0.30.0）：每日 3 件，7~9 折
  MARKET_DEALS: { COUNT: 3, MIN: 0.70, MAX: 0.90 },

  // ---------- 弟子与凡人体系 v2（v0.32.0）----------
  // 凡人只由驻守秘境繁衍；建筑升级需派驻凡人（工种固定）；招徒需到秘境凡人聚集地选拔
  LABOR: {
    PER_BUILD_LEVEL: 1,      // 每级建筑派驻 1 名凡人（灵脉师/矿工/药农）
    FOLK_CAP_BASE: 30,       // 每处驻守秘境凡人上限
    FOLK_CAP_SECT: 20,       // 宗门每级 +20
    FOLK_CAP_DYNASTY: 100,   // 立朝 +100
  },
  // 弟子名额：2 + 招募堂 + 境界 + 建筑总级/5 + 宗门×2 + 立朝 3
  SLOTS: { BASE: 5, PER_SECT: 2, DYNASTY: 3, BUILD_DIV: 5 },
  // 灵根品级（择优录用）
  SPIRIT_ROOTS: [
    { grade: 1, name: "下品灵根", w: 0.45, cost: 100, aptitude: 1 },
    { grade: 2, name: "中品灵根", w: 0.30, cost: 400, aptitude: 2 },
    { grade: 3, name: "上品灵根", w: 0.15, cost: 900, aptitude: 3 },
    { grade: 4, name: "优品灵根", w: 0.08, cost: 1800, aptitude: 4 },
    { grade: 5, name: "天品灵根", w: 0.02, cost: 3600, aptitude: 5 },  // 需立朝才可能出现
  ],
  RECRUIT: { CANDIDATES: 3, REFRESH_STONE: 50 },
  // 秘境安定度：低于 30 产出减半；建庙安抚
  STABLE: {
    INIT: 60, DAILY_DECAY: 3, LOW: 30, LOW_MULT: 0.5,
    TEMPLE_CHANCE: 0.15,       // 每级神庙额外 +15% 凡人繁衍
    TEMPLE_MAX: 3, TEMPLE_STONE: 1500, TEMPLE_GROWTH: 1.8, TEMPLE_LABOR: 5,
    SOOTHE_STONE: 300, SOOTHE_ADD: 30,
  },
  // ---------- 药园 / 化身 / 仙友 / 五行流派（v0.36.0）----------
  GARDEN: {
    BASE: 3, MAX: 5,                     // 3×3 起步，可开垦至 5×5
    EXPAND_COST: [1200, 3600],           // 3→4、4→5 的开垦灵石
    WATER_CD_SEC: 30,                    // 浇水冷却
    WATER_CUT: 0.2,                      // 浇水缩短 20% 生长
    WITHER_MULT: 3,                      // 成熟后超过 3 倍时长未收则枯萎（收益减半）
    HERB_PER_LEVEL: 0.15,                // 药童（弟子职务）每人加速 15%
    CROPS: [
      { key: "lingcao", name: "灵草", sec: 120, seed: 20,  herb: 20 },
      { key: "lingzhi", name: "灵芝", sec: 300, seed: 80,  pill: 1 },
      { key: "xiancan", name: "仙参", sec: 600, seed: 200, herb: 60, material: 5 },
      { key: "jiuye",   name: "九叶灵芝", sec: 900, seed: 600, pill: 4, material: 4, realm: 3 },
      { key: "zizhi",   name: "紫芝",     sec: 1200, seed: 1500, herb: 150, material: 12, realm: 5 },
    ],
    FERT: { matCost: 1, yieldBonus: 0.30, mutRate: 0.06, mutPerFert: 0.04, mutMult: 2, mutMat: 2 },  // 施肥与变异（v0.43.0）
    RARE_SEED_YIELD: 1.5,             // 异种灵种：产量 +50%，生长时间 -10%（v0.51.2）
  },
  AVATAR_BODY: {
    UNLOCK_REALM: 3,                     // 元婴解锁
    UNLOCK_STONE: 3000,
    MAX_LV: 5,
    LV_COST: [2000, 5000, 12000, 30000],
    RATE: 0.5,                           // 基础为驻地 50% 产出
    LV_BONUS: 0.2,                       // 每级 +20%
    CLAIM_HOURS: 25,                     // 化身离线累积上限 25 小时（P1 长挂机）
    // 化身职能（v0.44.0）：秘境挂机 / 代炼丹 / 代采药
    DUTIES: [
      { key: "field",  name: "秘境挂机", desc: "驻守秘境，积累灵石、灵气与灵草灵材" },
      { key: "dan",    name: "代炼丹",   desc: "以炼丹房火候自行开炉，耗灵草灵材产丹药" },
      { key: "garden", name: "代采药",   desc: "代管药园，按种植作物收获并留种" },
    ],
    DAN_HERB_PER_HOUR: 120,              // 代炼丹：每小时耗灵草
    DAN_MAT_PER_HOUR: 6,                 // 代炼丹：每小时耗灵材
    DAN_PILL_PER_HOUR: 5,                // 代炼丹：每小时产培元丹（随等级提升）
    GARDEN_CYCLES_PER_HOUR: 2,           // 代采药：每小时可收获次数（随等级提升）
  },
  FRIEND: {
    MAX: 6,                              // 仙友上限
    TRAIN_QI: 0.03,                      // 传功消耗当前突破的 3% 灵气
    TRAIN_REL: 4,                        // 传功好感 +4
    GIFT_STONE: 300,
    GIFT_REL: 10,
    LOVER_REL: 100,                      // 好感满可结道侣
    LOVER_CULT: 0.05,                    // 道侣修炼 +5%
    DUAL_CULT: 0.02,                     // 双修当日额外 +2%（可叠加单次）
    DAYS_PER_NEW: 3,                     // 每 3 天来一位新仙友
    // 仙友事件链（v0.45.0）：好感门槛解锁个人事件，给真实收益
    EVENTS: [
      { key: "ev1", rel: 30, title: "月下论道", text: "{name}与你对坐论道，讲了一夜吐纳要诀。", reward: { qiPct: 0.06 } },
      { key: "ev2", rel: 55, title: "赠丹之情", text: "{name}取出随身丹药相赠，说是丹房新成的一炉。", reward: { item: "pill", n: 6 } },
      { key: "ev3", rel: 80, title: "残卷相托", text: "{name}托你保管两卷残经，说日后自有缘法。", reward: { talisman: 2 } },
    ],
    HELP_CULT: 0.10,     // 请援加持：修炼 +10%
    HELP_HOURS: 2,       // 加持时长（小时）
    LOVER_GIFT_CD_H: 20, // 道侣机缘冷却（小时）
  },
  ELEMENTS: [
    { key: "metal", name: "金", color: "#B08A3E", beats: "wood",  gen: "water" },  // 金生水
    { key: "wood",  name: "木", color: "#5C7A6E", beats: "earth", gen: "fire" },   // 木生火
    { key: "water", name: "水", color: "#3E7EB8", beats: "fire",  gen: "wood" },   // 水生木
    { key: "fire",  name: "火", color: "#C1543A", beats: "metal", gen: "earth" },  // 火生土
    { key: "earth", name: "土", color: "#8B7355", beats: "water", gen: "metal" },  // 土生金
  ],
  ELEMENT_COUNTER: 0.15,
  // 五行相生连携（v0.46.0）：先用 A 再用 A 所生的 B，B 技能伤害提升
  ELEMENT_GEN_BONUS: 0.20,
  ELEMENT_GEN_WINDOW: 4.0,   // 连携窗口（秒）                 // 克制伤害 +15%
  ELEMENT_COUNTERED: 0.10,               // 被克 -10%
  CHAPTER_ELEMENTS: ["wood", "fire", "earth", "water", "metal", "water", "fire"],
  // 25 部功法按阶位分五行（同阶循环）
  GONGFA_ELEMENTS: ["metal", "wood", "water", "fire", "earth"],

  // ---------- 灵兽内丹 / 合击（v0.35.0）----------
  PET_INNER: [
    { key: "atk",   name: "锐金丹", desc: "出战灵兽内丹：主人攻击 +8%" },
    { key: "guard", name: "护体丹", desc: "出战灵兽内丹：进场获得 15% 气血护盾" },
    { key: "mana",  name: "回元丹", desc: "出战灵兽内丹：真元回复 +20%" },
  ],
  PET_COMBO: { BOND: 80, CD_SEC: 60, MULT: 3.0 },

  // ---------- 势力据点争夺（v0.35.0）----------
  RAID: { STAMINA: 2, ENEMY_MULT: 1.1, STONE_BASE: 2000, REP_WIN: 10, REP_LOSE: 5, REL_HIT: 10 },

  // ---------- 宗门完整版（v0.34.0）----------
  SECT_TASKS: [
    { key: "donate",  name: "供奉灵石 500", contrib: 15, stone: 500 },
    { key: "mission", name: "完成弟子任务 1 次", contrib: 10 },
    { key: "enter",   name: "入秘境 1 次", contrib: 10 },
  ],
  SECT_SHOP: [
    { key: "talisman", name: "功法残卷 ×1", cost: 30, type: "talisman", amount: 1 },
    { key: "material", name: "灵材 ×10",    cost: 20, type: "material", amount: 10 },
    { key: "herb",     name: "灵草 ×20",    cost: 15, type: "herb", amount: 20 },
    { key: "pill",     name: "丹药 ×2",     cost: 25, type: "pill", amount: 2 },
    { key: "frag",     name: "古宝碎片 ×5", cost: 60, type: "frag", amount: 5 },
  ],
  SECT_TRIAL: {
    STAMINA: 1,
    WAVES: [0.8, 1.0, 1.2],        // 三波敌人相对玩家战力的倍率
    CONTRIB: [5, 8, 12],
    STONE: 600,
    FAIL_LOYALTY: 3,               // 试炼失败护法忠诚 -3
  },
  SECT_DIPLO: { COST: 20, REL: 5 },  // 20 贡献换 5 点关系

  // ---------- 弟子职务 / 任务 / 争夺 / 王朝官职（v0.33.0）----------
  STAFF: {
    OFFICES: [
      { key: "miao",  name: "庙祝", desc: "安定每日 +1，凡人繁衍 +10%" },
      { key: "kuang", name: "矿正", desc: "该秘境灵石产出 +15%" },
      { key: "cheng", name: "城主", desc: "凡人容量 +20，繁衍 +5%" },
      { key: "hu",    name: "护法", desc: "抵御魔道争夺，失守概率大降" },
      { key: "yaotong", name: "药童", desc: "药园生长加速 +15%" },
    ],
    APT_SCALE: [0.6, 0.8, 1.0, 1.2, 1.4],   // 资质 1~5 的职务效果倍率
  },
  MISSION: {
    TYPES: [
      { key: "clear",  name: "清剿妖患", sec: 120, stamina: 1, stable: 20, rep: 8,  growth: 12, risk: 0.35, desc: "安定 +20、声望 +8、修为 +12" },
      { key: "escort", name: "护送商队", sec: 180, stamina: 1, stone: 800,  rep: 5, growth: 16, risk: 0.25, desc: "灵石 +800、声望 +5、修为 +16" },
      { key: "preach", name: "传道四方", sec: 300, stamina: 1, folk: 12,   rep: 3, growth: 20, risk: 0.15, desc: "凡人 +12、声望 +3、修为 +20" },
    ],
    BASE_RATE: 0.62, APT_RATE: 0.05, REALM_RATE: 0.03,
    FAIL_LOYALTY: 5,       // 失败忠诚 -5
    FAIL_REST: 180,        // 失败后休整秒数
    FAIL_GROWTH: 3,        // 任务失利仍积累少量历练
  },
  // 弟子成长与师门培养（v0.54.2）
  DISCIPLE_GROWTH: {
    IDLE_MULT: 1.0,        // 闲置：资质基础成长
    BUILD_MULT: 1.25,      // 洞府职守：熟悉生产
    DISPATCH_MULT: 1.5,    // 秘境驻守：实战与采集历练
    MISSION_MULT: 1.75,    // 任务期间：高强度历练
    QI_COST: 500,          // 师尊灌注灵气
    QI_EXP: 10,
    PILL_EXP: 20,          // 消耗 1 枚培元丹
  },
  CONFLICT: {
    REL_THRESHOLD: 20,     // 关系低于此值开始被窥伺
    BASE_CHANCE: 0.10,     // 低关系时每日触发概率
    LOW_REL_CHANCE: 0.25,  // 关系 <0 时概率
    LOSE_STABLE: 100,      // 失守安定归零
    RANSOM_MULT: 3,        // 赎回成本 = 该秘境 3 小时产出折算灵石
    REP_LOSS: 10,
  },
  DYNASTY_OFFICES: [
    { key: "zhoumu", name: "州牧", desc: "凡人繁衍 +20%" },
    { key: "sinong", name: "司农", desc: "灵草产出 +20%" },
    { key: "guoshi", name: "国师", desc: "修炼 +3%" },
  ],
  TAX_RATE: 0.005,          // 每日赋税：凡人 0.5% → 灵石

  // 立朝（凡间王朝）
  DYNASTY: { NEED_SECT: 3, NEED_FOLK: 100, STONE: 20000, FOLK_MULT: 2, ATTR: 0.02 },

  // 坊市刷新（v0.29.0）
  MARKET_REFRESH: { DAILY: 5, COST: 20 },
  // v0.54.3：境界货架每2小时（现实时间）自动换货，不追补离线期间错过的多轮库存。
  MARKET_SHELF: { INTERVAL_MS: 2 * 60 * 60 * 1000, MIN_ITEMS: 3, MAX_ITEMS: 5, STOCK_MIN: 1, STOCK_MAX: 3, PRICE_MIN: 1.05, PRICE_MAX: 1.35 },

  // 机缘与天机阁（v0.29.0）
  FATE: {
    FU_QI_COST: 3,        // 修为福袋：机缘 3 → 当前突破所需 15%
    FU_QI_RATE: 0.15,
    TALISMAN_COST: 4,     // 功法要诀：机缘 4 → 要诀 1
    INCENSE_COST: 3,      // 引魔香：机缘 3 → 下一次离线结算延长至 13h，并提升驻守产出
  },

  // 每日 / 周常任务（v0.29.0）
  DAILY_TASKS: [
    { key: "offline",  name: "领取离线收益",   need: 1, fate: 1 },
    { key: "tuna5",    name: "吐纳 5 次",      need: 5, fate: 1 },
    { key: "break1",   name: "突破/渡劫 1 次", need: 1, fate: 2 },
    { key: "field1",   name: "入秘境 1 次",    need: 1, fate: 2 },
    { key: "build1",   name: "建设洞府 1 次",  need: 1, fate: 1 },
    { key: "pill1",    name: "服用丹药 1 次",  need: 1, fate: 1 },
    { key: "dan1",     name: "丹房开炉 1 次",  need: 1, fate: 2 },
  ],
  WEEKLY_TASKS: [
    { key: "clear3",   name: "探明 3 处秘境",  need: 3, fate: 6 },
    { key: "tower5",   name: "试炼塔推进 5 层", need: 5, fate: 6 },
    { key: "pet3",     name: "培养灵兽 3 次",  need: 3, fate: 6 },
  ],

  // 章节特产（v0.29.0；v0.40.0 起为储物袋内真实物品 sp:<章节>）
  FIELD_SPECIALTIES: ["青云砂", "幽冥铁", "寒髓晶", "冥海珠", "仙墟玉", "星陨石", "混元露"],
  SPECIALTY_ITEM: { stack: 199, priceBase: 120, priceStep: 90, desc: "秘境特产，高阶洞府、法宝与秘方丹皆需此物" },

  // 弟子招募（v0.28.0）：名额随境界提升，招募需消耗秘境衍生的凡人
  DISCIPLE_SLOT_PER_REALM: 1,   // 每个大境界 +1 弟子名额
  DISCIPLE_FOLK_COST: 1,        // 每名弟子消耗凡人

  // ---------- 动态世界（v0.4.0） ----------
  // 时间：1 日 = 60 秒（原型加速），1 月 = 30 日，1 年 = 12 月
  DAY_SEC: 60,
  DAYS_PER_MONTH: 30,
  MONTHS_PER_YEAR: 12,

  // 势力
  FACTIONS: [
    { key: "qingyun", name: "青云门",   camp: "正道", color: "#5C7A6E", img: "assets/势力_青云门.webp" },
    { key: "moyuan",  name: "魔渊宗",   camp: "魔道", color: "#A93F2E", img: "assets/势力_魔渊宗.webp" },
    { key: "sanxiu",  name: "散修联盟", camp: "中立", color: "#B08A3E", img: "assets/势力_散修联盟.webp" },
  ],

  // 势力演化参数
  FACTION_RESOURCE_RATE: 3,      // 每领地每日资源产出
  FACTION_UPKEEP: 0.5,           // 每实力每日资源消耗
  FACTION_POWER_GROWTH: 0.01,    // 资源转实力的成长系数（×资源×此值）
  FACTION_WAR_POWER_GAP: 15,     // 势力争斗触发的最小实力差
  RELATION_RANGE: 100,           // 关系范围 -100~100
  BLESSING_THRESHOLD: 50,        // 获得势力庇护所需关系

  // 世界事件概率（每日）
  EVENT_BEAST_TIDE_CHANCE: 0.15, // 妖兽潮
  EVENT_SECRET_REALM_CHANCE: 0.05, // 秘境开启

  // ---------- 弟子（NPC，v0.4.1） ----------
  APTITUDES: [
    { level: 1, name: "凡品", color: "#8C8C8C", growth: 1, outputMult: 1.0 },
    { level: 2, name: "灵品", color: "#5C7A6E", growth: 2, outputMult: 1.3 },
    { level: 3, name: "仙品", color: "#B08A3E", growth: 3, outputMult: 1.6 },
  ],
  APTITUDE_WEIGHT: [0.6, 0.3, 0.1],   // 招募资质概率权重
  DISCIPLE_GROWTH_THRESHOLD: 50,       // 升一层所需修炼值
  DISCIPLE_OUTPUT_BASE: 0.25,          // 每名弟子基础产出加成
  DISCIPLE_REALM_OUTPUT: 0.1,          // 每境额外产出加成
  DISCIPLE_LOYALTY_LEAVE: 20,          // 忠诚低于此值可能离开
  DISCIPLE_LEAVE_CHANCE: 0.1,          // 每日离开概率
  // ---------- 弟子专精与师徒情谊（v0.10.0） ----------
  // 专精：招募时随机；委派到对应建筑时该弟子产出 +50%（不匹配不惩罚）
  SPECIALTIES: [
    { key: "farm",     name: "灵植", color: "#5C7A6E" },
    { key: "alchemy",  name: "丹道", color: "#B08A3E" },
    { key: "forge",    name: "器道", color: "#8B5E3C" },
    { key: "practice", name: "悟道", color: "#6A6A9A" },
  ],
  SPECIALTY_MATCH_BONUS: 0.5,     // 专精匹配额外产出
  // 情谊：与师尊相处日久而增长，取代「纯随机」的忠诚波动
  BOND_MAX: 100,
  BOND_GAIN_ASSIGNED: 2,          // 委派中每日 +2
  BOND_GAIN_IDLE: 1,              // 空闲每日 +1
  BOND_LOYALTY_GUARD: 60,         // 情谊达此值后忠诚不再自然下降
  BOND_ELITE_THRESHOLD: 90,       // 嫡传门槛
  BOND_ELITE_BONUS: 0.2,          // 嫡传额外产出
  DISCIPLE_NAMES: ["青玄", "白芷", "云逸", "灵均", "清音", "长风", "紫烟", "玄机", "素问", "无涯"],

  // ---------- 动态经济（v0.4.2） ----------
  MARKET_BASE: { herb: 10, pill: 50, tribPill: 500, material: 80 },  // 基准价（灵材 v0.6.0）
  MARKET_VOLATILITY: 0.08,              // 每日随机波动（±4%）
  MARKET_MEAN_REVERT: 0.1,              // 均值回归系数（冲击后逐步回落）
  MARKET_RANGE: [0.5, 3.0],             // 价格区间（基准价倍数）
  BUY_IMPACT: 0.01,                     // 玩家每买 1 个推高价格比例
  SELL_IMPACT: 0.01,                    // 玩家每卖 1 个压低价格比例
  TRADE_HERB_BATCH: 10,                 // 灵草交易批量

  // ---------- 无尽试炼塔（v0.8.0） ----------
  // 设计：绝对难度曲线（不随玩家战力自适应，否则永远打不过下一层）。
  // 锚点取「炼气1层玩家战力」≈190，第 1 层为锚点 ×0.55，每层 ×1.33。
  // 由此第 44 层左右约等于渡劫满层战力（≈2.5e7），构成天然上限。
  TOWER_ANCHOR: 190,          // 战力锚点（炼气1层裸装战力）
  TOWER_BASE: 0.55,           // 第 1 层相对锚点倍率
  TOWER_GROWTH: 1.33,         // 每层战力增长
  TOWER_STONE_BASE: 40,       // 灵石奖励基数
  TOWER_STONE_GROWTH: 1.16,   // 灵石奖励每层增长
  TOWER_MAT_EVERY: 5,         // 每 N 层给灵材
  TOWER_REP_EVERY: 10,        // 每 N 层给声望
  TOWER_BOSS_EVERY: 10,       // 每 N 层为守关妖兽（触发图鉴 + 额外奖励）
  // —— 塔币与塔阁（v0.9.0）——
  // 塔币是塔的专属货币：只能靠通关层数获得，只能换塔阁物品，不流入主线经济。
  TOWER_COIN_BASE: 1,         // 每通一层基础塔币
  TOWER_COIN_PER_10: 1,       // 每 10 层额外 +1 枚
  TOWER_SHOP: [
    { key: "art_attack",  name: "试炼·本命法宝", desc: "仙器阶本命法宝（必成，含词条）", cost: 30, kind: "artifact", type: "attack",  tier: 6 },
    { key: "art_defense", name: "试炼·护身法宝", desc: "仙器阶护身法宝（必成，含词条）", cost: 30, kind: "artifact", type: "defense", tier: 6 },
    { key: "art_support", name: "试炼·辅道法宝", desc: "仙器阶辅道法宝（必成，含词条）", cost: 30, kind: "artifact", type: "support", tier: 6 },
    { key: "mat20",  name: "灵材 ×20",  desc: "炼制法宝的基础材料", cost: 10, kind: "res", res: "mat", amount: 20 },
    { key: "stone2k", name: "灵石 ×2000", desc: "通用货币", cost: 5,  kind: "res", res: "stone", amount: 2000 },
  ],

  // ---------- 法宝库分页（v0.10.0） ----------
  // 法宝数量无上限，全量渲染会随件数线性变慢；分页后单页 DOM 固定 20 张卡片。
  ARTIFACT_PAGE_SIZE: 20,

  // ---------- 声望消耗出口（v0.8.0） ----------
  // 声望此前只有渡劫加成一个出口（上限 +10%，即 500 声望封顶），后期只涨不用必然溢出。
  REP_TO_TRIBPILL: 50,             // 声望兑换渡劫丹：50 声望 → 1 枚
  REP_APTITUDE_COST: { 1: 60, 2: 180 },  // 提弟子资质：凡品→灵品 60 声望、灵品→仙品 180 声望

  // ---------- 渡劫（v0.5.0） ----------
  TRIB_BASE_RATE: 0.85,      // 基础渡劫成功率
  TRIB_REALM_DECAY: 0.03,    // 每深入一境成功率衰减
  TRIB_MIN_RATE: 0.5,        // 成功率下限
  TRIB_MAX_RATE: 0.98,       // 成功率上限
  TRIB_PILL_BONUS: 0.15,     // 每枚渡劫丹加成
  TRIB_BLESS_BONUS: 0.10,    // 青云门庇护加成
  TRIB_REP_BONUS: 0.02,      // 每 100 声望加成
  TRIB_REP_CAP: 0.10,        // 声望加成上限
  TRIB_GONGFA_BONUS: 0.01,   // 每级功法加成
  TRIB_GONGFA_CAP: 0.10,     // 功法加成上限
  TRIB_FAIL_QI_LOSS: 0.3,    // 失败损失剩余灵气比例
  TRIB_PITY: 3,              // 保底：连败 2 次后第 3 次必成
  TRIB_SUCCESS_REP: 5,       // 渡劫成功声望奖励

  // ---------- 法宝品阶系统（v0.6.0） ----------
  // 品阶：主属性/副属性均为「百分比加成」，随境界自动缩放，全周期有效
  // main = 类型主属性（攻/防/修炼），sub = 血量副属性
  ARTIFACT_TIERS: [    { tier: 1, name: "凡品", color: "#8C8C8C", main: 0.03, sub: 0.015, material: 3,  stone: 80 },
    { tier: 2, name: "灵品", color: "#5C7A6E", main: 0.06, sub: 0.03,  material: 6,  stone: 240 },
    { tier: 3, name: "宝器", color: "#3E7EB8", main: 0.10, sub: 0.05,  material: 12, stone: 800 },
    { tier: 4, name: "法器", color: "#8B5FBF", main: 0.15, sub: 0.075, material: 24, stone: 2600 },
    { tier: 5, name: "灵宝", color: "#B08A3E", main: 0.21, sub: 0.105, material: 48, stone: 8000 },
    { tier: 6, name: "仙器", color: "#A93F2E", main: 0.28, sub: 0.14,  material: 96, stone: 24000 },
  ],
  ARTIFACT_TYPES: [
    { key: "attack",  slot: "本命", attr: "攻击", color: "#A93F2E" },
    { key: "defense", slot: "护身", attr: "防御", color: "#5C7A6E" },
    { key: "support", slot: "辅道", attr: "修炼", color: "#B08A3E" },
    { key: "relic",   slot: "古宝", attr: "均衡", color: "#7A5E9E" },
    { key: "fabao",   slot: "法宝", attr: "修炼+神通", color: "#3E6E9E" },
  ],
  // ---------- 装备栏位（v0.18.0，对标一念逍遥 12 格）----------
  // 3 件本体（本命/护身/辅道）+ 3 件古宝 + 6 件法宝，按境界（神识）逐格解锁
  LOADOUT_SLOTS: [
    { key: "weapon",  name: "本命",    accepts: ["attack"],  unlockRealm: 0 },
    { key: "armor",   name: "护身",    accepts: ["defense"], unlockRealm: 0 },
    { key: "trinket", name: "辅道",    accepts: ["support"], unlockRealm: 0 },
    { key: "relic0",  name: "古宝·壹", accepts: ["relic"],   unlockRealm: 2 },
    { key: "relic1",  name: "古宝·贰", accepts: ["relic"],   unlockRealm: 3 },
    { key: "relic2",  name: "古宝·叁", accepts: ["relic"],   unlockRealm: 4 },
    { key: "fabao0",  name: "法宝·壹", accepts: ["fabao"],   unlockRealm: 4 },
    { key: "fabao1",  name: "法宝·贰", accepts: ["fabao"],   unlockRealm: 5 },
    { key: "fabao2",  name: "法宝·叁", accepts: ["fabao"],   unlockRealm: 5 },
    { key: "fabao3",  name: "法宝·肆", accepts: ["fabao"],   unlockRealm: 6 },
    { key: "fabao4",  name: "法宝·伍", accepts: ["fabao"],   unlockRealm: 6 },
    { key: "fabao5",  name: "法宝·陆", accepts: ["fabao"],   unlockRealm: 7 },
  ],
  // 器纹（v0.18.0）：法宝专属成长线，消耗灵材淬灵出一条纹路
  ENGRAVE: {
    MAX_BY_TIER: [0, 1, 1, 2, 2, 3],       // index = tier-1，按品阶可刻器纹数
    COST_MAT: 6,                            // 灵材（×品阶）
    COST_STONE: 260,                        // 灵石（×品阶）
    ROLL_MIN: 0.8,
    ROLL_MAX: 1.2,
    TYPES: [
      { key: "atk",  name: "锋锐", value: 0.05, color: "#A93F2E", desc: "攻击提升" },
      { key: "def",  name: "坚壁", value: 0.05, color: "#5C7A6E", desc: "防御提升" },
      { key: "hp",   name: "生生", value: 0.06, color: "#8B2E4A", desc: "气血提升" },
      { key: "cult", name: "通玄", value: 0.08, color: "#B08A3E", desc: "修炼速度提升" },
    ],
  },
  // 共鸣（v0.18.0）：同品阶法宝达到件数 → 全属性共鸣加成
  RESONANCE_MIN_TIER: 3,        // 凡品/灵品不构成共鸣，避免早期凑低阶装备堆数值
  RESONANCE: [
    { count: 2, bonus: 0.04 },
    { count: 4, bonus: 0.09 },
    { count: 6, bonus: 0.15 },
  ],
  // 炼制时属性品质浮动（0.85~1.15 倍）
  ARTIFACT_ROLL_MIN: 0.85,
  ARTIFACT_ROLL_MAX: 1.15,
  // 炼制成功率 = 基础 - 每阶递减 + 炼器坊加成（封顶）
  ARTIFACT_FORGE_BASE_RATE: 0.90,
  ARTIFACT_FORGE_TIER_DECAY: 0.12,
  ARTIFACT_FORGE_LV_BONUS: 0.02,
  ARTIFACT_FORGE_LV_CAP: 0.20,
  ARTIFACT_RATE_MIN: 0.15,
  ARTIFACT_RATE_MAX: 0.98,
  // 炼器坊 Lv≥(tier-1)×2 才可炼制该品阶
  ARTIFACT_TIER_LV_STEP: 2,
  // 失败返还灵石比例
  ARTIFACT_FAIL_REFUND: 0.5,
  // 炼化升阶：祭品须同类型同品阶；消耗灵材 = 该阶材料/2
  REFINE_BASE_RATE: 0.60,
  REFINE_LV_BONUS: 0.02,
  REFINE_RATE_CAP: 0.90,
  // 分解返还灵材 = 该阶材料 × 此比例（最低 1）
  ARTIFACT_DISMANTLE_RATIO: 0.5,
  // 灵材：战斗掉落
  MATERIAL_DROP_CHANCE: 0.20,   // 小怪掉落概率
  MATERIAL_BOSS_DROP: 2,        // BOSS 必掉数量
  MATERIAL_TRADE_BATCH: 10,     // 坊市批量交易量
  // 法宝名称词库
  ARTIFACT_PREFIX: {
    attack:  ["赤霄", "青冥", "斩月", "裂云", "惊雷", "诛仙", "太阿", "流光"],
    defense: ["玄龟", "磐石", "云纹", "紫金", "太虚", "不动", "山河", "重明"],
    support: ["清心", "凝神", "紫府", "玄元", "太初", "坐忘", "明镜", "止水"],
    relic:   ["太古", "混沌", "鸿蒙", "先天", "无始", "开天", "镇岳", "玄黄"],
    fabao:   ["九幽", "玄天", "紫霄", "混元", "太清", "霄光", "碧落", "赤明"],
  },
  ARTIFACT_SUFFIX: {
    attack:  ["剑", "刀", "戟", "枪", "钩"],
    defense: ["甲", "袍", "盾", "铠", "珠"],
    support: ["珠", "印", "幡", "镜", "铃"],
    relic:   ["印", "碑", "鼎", "塔", "轮"],
    fabao:   ["绫", "葫芦", "钟", "幡", "灯"],
  },

  // ---------- 世界事件链扩展（v0.6.1） ----------
  // 每条链触发后进入冷却，避免同一事件连续刷屏
  EVENT_COOLDOWN_DAYS: 45,
  EVENT_CHANCE: {
    invasion:  0.15,     // 魔渊入侵（需魔渊实力显著压制青云门）
    beasttide: 0.10,     // 妖兽潮（自然事件，无条件）
    auction:   0.06,     // 散修拍卖会（需散修联盟关系达标）
    demonraid: 0.07,     // 魔道夺宝（需持有法宝）
    battleground: 0.06,  // 古战场遗迹（v0.11.0，需金丹以上）
    pillmeet:  0.05,     // 丹道大会（v0.11.0，需炼丹房 Lv3）
  },
  // ---------- 剧本化主线（v0.12.0）----------
  // 每章一次二选一，效果统一（战=攻击、道=修炼），文案各章不同。
  // 幅度刻意压小（5 章满配 攻击 +10% 或 修炼 +7.5%），不超过一件法宝的零头，不影响平衡。
  STORY_WAR_ATK: 0.02,      // 每次选「战」：攻击 +2%
  STORY_DAO_CULT: 0.015,    // 每次选「道」：修炼速率 +1.5%
  // 用「占比」而非「绝对次数」判定道心，章节数变化时无需重调
  STORY_ENDING_RATIO: 0.7,  // 战（或道）占比 ≥ 70% → 对应道心；否则心剑双修

  // ---------- 古战场遗迹（v0.11.0）----------
  BATTLEGROUND_MIN_REALM: 2,      // 需金丹期
  BATTLEGROUND_RATIO: 1.0,        // 探入战斗的敌方战力比
  BATTLEGROUND_MAT: 12,           // 探入胜利的灵材
  BATTLEGROUND_ART_TIER: 4,       // 探入胜利可得的法宝品阶（法器）
  BATTLEGROUND_SEARCH_MAT: 5,     // 外围搜刮的灵材（稳）
  BATTLEGROUND_BONE_REP: 20,      // 收敛遗骨的声望
  BATTLEGROUND_BONE_REL: 10,      // 收敛遗骨的青云门关系
  // ---------- 丹道大会（v0.11.0）----------
  PILLMEET_MIN_ALCHEMY: 3,        // 需炼丹房 Lv3
  PILLMEET_ENTRY_PILLS: 5,        // 赴会消耗丹药
  PILLMEET_CONTEST_PILLS: 3,      // 斗丹再消耗丹药
  PILLMEET_CONTEST_RATE: 0.55,    // 斗丹夺魁概率
  PILLMEET_WIN_REP: 40,           // 夺魁声望
  PILLMEET_WIN_STONE: 3000,       // 夺魁灵石
  PILLMEET_LOSE_REP: 8,           // 落败声望
  PILLMEET_WATCH_REP: 12,         // 观摩声望
  EVENT_MINERAL_CHANCE: 0.04,   // 灵矿现世（自动结算的正面事件）
  // 事件战斗胜率 = p/(p+enemy)，钳制在上下限内
  EVENT_WIN_RATE_MIN: 0.15,
  EVENT_WIN_RATE_MAX: 0.95,

  // 散修拍卖会
  AUCTION_REL_MIN: 20,          // 触发所需散修关系
  AUCTION_ENTRY_COST: 50,       // 入场灵石
  AUCTION_BID_COST: 200,        // 竞价灵石
  AUCTION_BASE_RATE: 0.40,      // 竞价成功率基数
  AUCTION_REL_BONUS: 0.002,     // 每点散修关系 +0.2%
  AUCTION_MATERIAL_REWARD: 15,  // 竞得灵材数量
  AUCTION_REL_WIN: 10,          // 竞得后散修关系 +
  AUCTION_REL_SKIP: -5,         // 不入场关系 -
  AUCTION_REL_PASS: 3,          // 放弃竞价关系 +

  // 妖兽潮
  BEASTTIDE_SCOUT_STAMINA: 3,     // 探查体力
  BEASTTIDE_FIGHT_STAMINA: 5,     // 迎战体力
  BEASTTIDE_AVOID_STONE: 80,      // 布阵避战灵石
  BEASTTIDE_RATIO_SCOUTED: 0.65,  // 探查后敌方战力比
  BEASTTIDE_RATIO_BLIND: 0.95,    // 未探查敌方战力比
  BEASTTIDE_HERB_LOSS: 0.4,       // 战败损失灵草比例
  BEASTTIDE_AVOID_HERB_LOSS: 0.1, // 避战损失灵草比例
  BEASTTIDE_REWARD_MAT: 3,        // 战胜灵材
  BEASTTIDE_REP: 8,               // 战胜声望

  // 魔道夺宝
  DEMONRAID_ARRAY_STONE: 150,     // 布阵灵石
  DEMONRAID_ARRAY_MATERIAL: 5,    // 布阵灵材
  DEMONRAID_RATIO_ARRAY: 0.85,    // 布阵后敌方战力比
  DEMONRAID_RATIO_DIRECT: 1.15,   // 直接迎击敌方战力比
  DEMONRAID_REL_PENALTY: 10,      // 击败魔修后魔渊关系 -
  DEMONRAID_LOSE_REL_PENALTY: 5,  // 败退后魔渊关系 -
  DEMONRAID_WIN_MAT: 12,          // 战胜灵材
  DEMONRAID_REP: 10,              // 战胜声望
  DEMONRAID_LOSE_STONE_RATIO: 0.3,// 无 spare 法宝时损失灵石比例

  // ---------- 战斗 v2：气息制（v0.15.0）----------
  // 核心约束（已验算，勿改）：气息填充 100/秒 × 普攻耗 100 = 每秒 1 次，
  // 与旧公式 max(攻-防,攻*0.05) 每秒一次严格等价，保证 v0.13.0 的 12.7 天飞升曲线不破。
  BATTLE2: {
    QI_MAX: 200,          // 气息上限（允许攒 1 次重式 + 余量）
    QI_REGEN: 100,        // 基准气息填充/秒（= 疾速 100）
    MANA_MAX: 200,        // 真元上限基准（实际由心法与境界决定）
    MANA_REGEN: 12,       // 真元回复/秒
    YUNGONG_MAX: 0.6,     // 运功比例上限 60%
    YUNGONG_RATE: 0.15,   // 运功转化率：运功比例 × 本值 → 攻击加成（0.6 满运功 = +9% 攻击）
    PUNCH_COST: 100,      // 普攻气息消耗
    PUNCH_MULT: 1.0,      // 普攻倍率
    SLOT_BY_REALM: [2, 3, 4, 5, 6, 7, 8, 8, 8, 8, 8],  // 11 境 → 术式槽数（自适应可扩展）
    SLOT_MAX: 8,          // 槽位硬上限（UI 一屏两行 × 4）
    TICK: 0.05,           // 逻辑步长（秒）
    MAX_SECONDS: 180,     // 单场战斗硬上限（防死循环）
    PUNCH_INTERVAL_GUARD: 0.2,  // 两招之间最小间隔（秒），防止同帧连发
  },

  // 术式库（v0.15.0：境界通用术式，逐境解锁；v0.16.0 起改由功法携带）
  // cost=气息消耗  mult=攻击倍率  cd=冷却(秒)  mana=真元消耗
  // kind: dmg 伤害 / heal 回复 / buff 增益 / ctrl 控制
  // tier: 视觉品阶 1~6，决定动画帧数与特效层级（见 docs/04 §6.3）
  ARTS: [
    { key: "yin_qi",   name: "引气诀",   tier: 1, kind: "dmg",  cost: 60,  mult: 0.60, cd: 0,  mana: 6,
      unlockRealm: 0, hits: 1, anim: "swipe",  desc: "最基础的术式，气息消耗低，可连续施展" },
    { key: "lie_shi",  name: "裂石式",   tier: 2, kind: "dmg",  cost: 150, mult: 1.52, cd: 2,  mana: 30,
      unlockRealm: 1, hits: 1, anim: "slam",   desc: "蓄势重击，需攒满气息方可施展" },
    { key: "hui_chun", name: "回春术",   tier: 2, kind: "heal", cost: 100, mult: 0,    cd: 8,  mana: 45,
      unlockRealm: 2, hits: 0, anim: "glow",   healPct: 0.18, desc: "引木灵之气，即刻回复一成八气血" },
    { key: "san_die",  name: "三叠浪",   tier: 3, kind: "dmg",  cost: 90,  mult: 0.45, cd: 5,  mana: 35,
      unlockRealm: 3, hits: 3, anim: "triple", desc: "连击三次，每击四成五倍，破盾利器" },
    { key: "xuan_jia", name: "玄甲术",   tier: 3, kind: "buff", cost: 100, mult: 0,    cd: 12, mana: 50,
      unlockRealm: 4, hits: 0, anim: "ring",   shieldPct: 0.15, shieldSec: 8, desc: "结玄甲护体，吸收一成五气血的伤害，持续八息" },
    { key: "ran_xue",  name: "燃血诀",   tier: 3, kind: "buff", cost: 100, mult: 0,    cd: 14, mana: 40,
      unlockRealm: 5, hits: 0, anim: "flame",  atkUp: 0.30, dur: 6, desc: "焚血催力，攻击提升三成，持续六息" },
    { key: "ding_shen",name: "定身诀",   tier: 3, kind: "ctrl", cost: 110, mult: 0.90, cd: 12, mana: 55,
      unlockRealm: 6, hits: 1, anim: "bind",   ctrlSec: 2.5, desc: "敕令定身，使敌两息半内无法出手（可打断蓄力）" },
    { key: "zhan_ling",name: "斩灵绝式", tier: 4, kind: "dmg",  cost: 150, mult: 2.05, cd: 9,  mana: 60,
      unlockRealm: 7, hits: 1, anim: "slash",  desc: "倾尽真元的绝杀一击，压血线时施展" },
  ],

  // ============================================================
  // 秘境战场（v0.16.0）：复刻《一念逍遥》战斗模式
  // 圆形角色图标 + 2.5D 斜俯视地图 + 自由走位 + 方向性技能
  // ============================================================
  FIELD: {
    WORLD: 1400,          // 参考地图边长（各图可覆盖）
    ISO_X: 0.86,          // 等轴测横向系数
    ISO_Y: 0.50,          // 等轴测纵向压缩
    TICK: 1 / 60,         // 逻辑步长（秒）
    MAX_SECONDS: 240,     // 单场上限

    PLAYER_R: 20,
    PLAYER_SPEED: 240,    // 世界单位/秒
    DASH_SPEED: 580,      // 遁速冲刺速度
    DASH_TIME: 0.26,
    DASH_CD: 2.4,

    AUTO_CD: 1.4,         // 普攻间隔（对齐一念「1.4 秒一回合」）
    AGGRO: 320,           // 仇恨半径（进入即被追击）
    LEASH: 560,           // 脱战半径（超出回巢并回血）

    MON_R: 18,
    MON_SPEED: 98,
    MON_ATTACK_CD: 1.6,
    MON_ATTACK_RANGE: 46,
    MON_HP_RESET: 0.35,   // 脱战后每秒回复比例

    PROJ_LIFE: 1.1,       // 投射物存活秒数
    SKILL_SLOTS: 8,       // v0.52.0：术式槽按境界 2→8 格自适应

    // 技能锁定类型（v0.26.0，参考王者荣耀技能分类）
    // target 强锁：锁定目标必中｜single 单体：直线弹道命中首个｜area 群体：范围伤害｜support 辅助：自身增益
    SKILL_LOCK_MAX_RANGE: 560,
  },

  // 技能类型标签（v0.26.0）
  SKILL_LOCKS: [
    { key: "target",  name: "强锁", color: "#C1543A", desc: "锁定目标，弹道必中" },
    { key: "single",  name: "单体", color: "#4A6B8A", desc: "直线弹道，命中首个目标" },
    { key: "area",    name: "群体", color: "#B08A3E", desc: "范围伤害，可命中多个目标" },
    { key: "support", name: "辅助", color: "#3E7A5E", desc: "自身增益，无需瞄准" },
  ],

  // 秘境驻守与灵脉经营（v0.26.0）
  FIELD_EDUCATION: {
    BASE_RATE: 0.000002,      // 单名有效驻守弟子每秒 +0.0002%（约5.8个在线日完成）
    MEMBER_MULTS: [1, 0.60, 0.55, 0.50, 0.45], // 第2/3/4/5名边际贡献，后续按0.4
    EXTRA_MEMBER_MULT: 0.40,
    EROSION_RATE: 0.0000001,  // 无弟子驻守时额外侵蚀约0.864%/日
    PRESSURE_RATE: 0.00000002, // 未私有化期间外部势力持续施压，约0.173%/日
    LOW_STABLE_EROSION: 0.00000004,
    PREACH_BONUS: 0.05,       // 成功完成传道四方，目标秘境教化度 +5%
    PRIVATE_AT: 1,
  },

  FIELD_VEIN: {
    MAX: 10,             // 灵脉最高等级
    COST_BASE: 120,      // 1 级灵脉造价（灵石），每级 ×1.6
    RATE_BONUS: 0.15,    // 每级驻守产出 +15%
    FOLK_RATE: 0.02,     // 凡人聚落：每级灵脉额外 灵草/秒
  },

  // 方向性技能库（v0.16.0）
  // shape: line 直线投射 / cone 扇形瞬发 / nova 自身圆环 / self 自身增益
  // range/width/angle 均为世界单位与弧度
  FIELD_SKILLS: [
    { key: "jian_qi",   name: "剑气斩", shape: "line", lock: "single", range: 300, width: 46, mult: 0.95, cd: 2.6, mana: 12,
      unlockRealm: 0, color: "#4A6B8A", tier: 1, element: "metal", desc: "沿指向斩出一道剑气" },
    { key: "lingxi_zhang", name: "灵息掌", shape: "line", lock: "single", range: 260, width: 54, mult: 0.60, cd: 3, mana: 8,
      gongfaKey: "changsheng", unlockRealm: 0, color: "#5C8A78", tier: 1, element: "wood", desc: "凝一缕灵息推出掌劲，低耗连发" },
    { key: "huo_hai",   name: "火海术", shape: "cone", lock: "area", range: 210, angle: 1.10, mult: 1.20, cd: 5.5, mana: 28,
      gongfaKey: "chiyang", unlockRealm: 2, color: "#C1543A", tier: 2, element: "fire", desc: "前方扇形火海，命中范围内所有敌人" },
    { key: "bing_huan", name: "冰棱环", shape: "nova", lock: "area", range: 175, mult: 0.85, cd: 7, mana: 34,
      gongfaKey: "jiuyou", unlockRealm: 3, color: "#3E7EB8", tier: 3, element: "water", slow: 0.45, slowSec: 2.5,
      desc: "以自身为心的冰棱爆环，并减缓敌人移动" },
    { key: "hui_chun",  name: "回春术", shape: "self", lock: "support", mult: 0, cd: 10, mana: 40,
      gongfaKey: "jiuzhuan", unlockRealm: 4, color: "#3E7A5E", tier: 3, element: "wood", healPct: 0.16, desc: "回复一成六气血" },
    { key: "yu_jian",   name: "御剑术", shape: "line", lock: "target", range: 470, width: 34, mult: 1.50, cd: 9, mana: 46,
      gongfaKey: "qingyun", unlockRealm: 5, color: "#B08A3E", tier: 4, element: "earth", pierce: 3,
      desc: "飞剑穿透，可贯穿三名敌人" },
    { key: "xuan_jia",  name: "玄甲术", shape: "self", lock: "support", mult: 0, cd: 13, mana: 44,
      gongfaKey: "hunyuan", unlockRealm: 6, color: "#3E6E9E", tier: 3, element: "earth", shieldPct: 0.15, shieldSec: 8, desc: "结玄甲护体，吸收伤害" },
    { key: "lei_ting", name: "雷霆一击", shape: "line", lock: "single", range: 520, width: 64, mult: 1.8, cd: 9, mana: 56,
      gongfaKey: "tianyan_jue", unlockRealm: 7, color: "#8A76A8", tier: 5, element: "metal", desc: "引雷贯体，蓄势一击" },
    { key: "hunyuan_jue", name: "混元绝式", shape: "nova", lock: "area", range: 250, mult: 2.05, cd: 9, mana: 60,
      gongfaKey: "jiuding", unlockRealm: 8, color: "#B08A3E", tier: 6, element: "earth", desc: "混元归一，倾注真元的绝式" },


    // ---- v0.53.2：补齐其余 23 个功法专属术式，按 §4.1 携带数量执行 ----
    { key: "sanhua_guard", name: "三花护顶", shape: "self", lock: "support", mult: 0, cd: 12, mana: 28,
      gongfaKey: "sanhua", unlockRealm: 1, color: "#6C9B83", tier: 2, element: "wood", shieldPct: 0.12, desc: "三花凝顶，结成护身灵盾" },
    { key: "wuqi_return", name: "五气归元", shape: "self", lock: "support", mult: 0, cd: 10, mana: 20,
      gongfaKey: "wuqi", unlockRealm: 1, color: "#5D9A75", tier: 2, element: "wood", manaRestorePct: 0.10, desc: "五气朝元，回复一成真元" },
    { key: "tiangang_pierce", name: "天罡破岳", shape: "line", lock: "single", range: 320, width: 42, mult: 1.35, cd: 6, mana: 30,
      gongfaKey: "tiangang", unlockRealm: 1, color: "#9B7547", tier: 2, element: "earth", desc: "天罡劲贯入一点，重创当前目标" },
    { key: "tiangang_qi", name: "罡气连震", shape: "nova", lock: "area", range: 160, mult: 0.62, hits: 2, cd: 8, mana: 34,
      gongfaKey: "tiangang", unlockRealm: 1, color: "#A88A58", tier: 2, element: "earth", desc: "罡气连震两次，连续冲击敌阵" },
    { key: "tianyan_oracle", name: "天衍观星", shape: "self", lock: "support", mult: 0, cd: 14, mana: 32,
      gongfaKey: "tianyan", unlockRealm: 2, color: "#8C78B5", tier: 3, element: "metal", critPct: 0.12, buffSec: 5, desc: "观星推演，短时提高会心" },
    { key: "ningshen_focus", name: "凝神守一", shape: "self", lock: "support", mult: 0, cd: 12, mana: 24,
      gongfaKey: "ningshen", unlockRealm: 2, color: "#718AA8", tier: 3, element: "water", manaRestorePct: 0.14, desc: "凝神归一，回复真元" },
    { key: "chiyang_burst", name: "赤阳焚空", shape: "cone", lock: "area", range: 230, angle: 1.0, mult: 1.60, cd: 9, mana: 48,
      gongfaKey: "chiyang", unlockRealm: 2, color: "#C45A32", tier: 3, element: "fire", desc: "赤阳真火倾泻，造成高额范围伤害" },
    { key: "huaxue_drain", name: "化血噬元", shape: "line", lock: "single", range: 300, width: 48, mult: 1.05, cd: 7, mana: 36,
      gongfaKey: "huaxue", unlockRealm: 2, color: "#9A3F50", tier: 3, element: "water", lifestealPct: 0.16, desc: "化血为引，伤敌并汲取部分气血" },
    { key: "huaxue_blood", name: "血河倒卷", shape: "nova", lock: "area", range: 190, mult: 1.25, cd: 11, mana: 48,
      gongfaKey: "huaxue", unlockRealm: 2, color: "#A33C4B", tier: 3, element: "water", desc: "血气倒卷，震击周身敌人" },
    { key: "yinming_soul", name: "阴冥摄魂", shape: "line", lock: "single", range: 360, width: 44, mult: 0.95, cd: 10, mana: 38,
      gongfaKey: "yinming", unlockRealm: 3, color: "#567B9C", tier: 4, element: "water", control: true, desc: "阴冥之气侵神，打断敌方蓄势" },
    { key: "tianyan_thunder", name: "天焱雷引", shape: "line", lock: "single", range: 420, width: 52, mult: 1.35, hits: 2, cd: 11, mana: 50,
      gongfaKey: "tianyan_jue", unlockRealm: 3, color: "#9B7AB8", tier: 4, element: "fire", desc: "引天焱雷火连击两次" },
    { key: "qingyun_frost", name: "青云寒锋", shape: "line", lock: "single", range: 420, width: 36, mult: 1.25, cd: 8, mana: 40,
      gongfaKey: "qingyun", unlockRealm: 3, color: "#6E9DB4", tier: 4, element: "water", slow: 0.35, slowSec: 2, desc: "剑气凝霜，命中后迟滞敌势" },
    { key: "panyun_step", name: "乘龙踏云", shape: "self", lock: "support", mult: 0, cd: 13, mana: 30,
      gongfaKey: "panyun", unlockRealm: 3, color: "#7C9C9A", tier: 4, element: "wind", dodgePct: 0.18, buffSec: 4, desc: "踏云避锋，短时提高闪避" },
    { key: "baihua_spring", name: "百花回春", shape: "self", lock: "support", mult: 0, cd: 14, mana: 42,
      gongfaKey: "baihua", unlockRealm: 4, color: "#B57D91", tier: 5, element: "wood", healPct: 0.22, desc: "百花生机汇聚，恢复气血" },
    { key: "shouyang_wall", name: "首阳金壁", shape: "self", lock: "support", mult: 0, cd: 16, mana: 46,
      gongfaKey: "shouyang", unlockRealm: 4, color: "#B08A4A", tier: 5, element: "earth", shieldPct: 0.22, desc: "首阳真气化壁，抵御后续伤害" },
    { key: "yijing_flow", name: "洗髓易筋", shape: "self", lock: "support", mult: 0, cd: 15, mana: 34,
      gongfaKey: "yijing", unlockRealm: 4, color: "#6D9C9A", tier: 5, element: "wood", healPct: 0.10, dodgePct: 0.10, buffSec: 4, desc: "易筋洗髓，回复气血并暂避锋芒" },
    { key: "wuse_guard", name: "五色护身光", shape: "self", lock: "support", mult: 0, cd: 15, mana: 42,
      gongfaKey: "wuse", unlockRealm: 4, color: "#9A82B2", tier: 5, element: "metal", shieldPct: 0.18, damageReducePct: 0.12, buffSec: 5, desc: "五色神光护体，结盾并减轻伤害" },
    { key: "xingyuan_star", name: "星元坠击", shape: "nova", lock: "area", range: 230, mult: 1.45, cd: 10, mana: 50,
      gongfaKey: "xingyuan", unlockRealm: 4, color: "#6E78A8", tier: 5, element: "metal", desc: "引星元坠落，震击敌阵" },
    { key: "zixiao_thunder", name: "紫霄神雷", shape: "line", lock: "single", range: 480, width: 58, mult: 1.55, hits: 2, cd: 12, mana: 58,
      gongfaKey: "zixiao", unlockRealm: 4, color: "#8A72B8", tier: 5, element: "metal", desc: "紫霄雷法连落两击" },
    { key: "jiuding_guard", name: "九鼎镇岳", shape: "self", lock: "support", mult: 0, cd: 18, mana: 54,
      gongfaKey: "jiuding", unlockRealm: 4, color: "#A68A52", tier: 6, element: "earth", shieldPct: 0.26, desc: "九鼎镇身，凝成厚重灵盾" },
    { key: "jingshou_hide", name: "静守归藏", shape: "self", lock: "support", mult: 0, cd: 18, mana: 48,
      gongfaKey: "jingshou", unlockRealm: 9, color: "#6E8C82", tier: 6, element: "wood", damageReducePct: 0.22, dodgePct: 0.10, buffSec: 5, desc: "静守归藏，短时减伤并提高闪避" },
    { key: "yuqing_ward", name: "玉清仙障", shape: "self", lock: "support", mult: 0, cd: 20, mana: 60,
      gongfaKey: "yuqing", unlockRealm: 9, color: "#8D9EB7", tier: 6, element: "metal", shieldPct: 0.30, damageReducePct: 0.10, buffSec: 5, desc: "玉清仙光护身，结盾并减伤" },
    { key: "yuhua_immortal", name: "羽化长生", shape: "self", lock: "support", mult: 0, cd: 22, mana: 64,
      gongfaKey: "yuhua", unlockRealm: 9, color: "#B59B6B", tier: 6, element: "wood", healPct: 0.28, desc: "羽化仙气滋养，恢复大量气血" },

    // ---- 法宝自带神通（v0.18.0）----
    // unlockRealm 99 = 不随境界解锁，只能通过装备带该神通的法宝获得
    { key: "fb_jinjiao", name: "金蛟剪", shape: "line", lock: "single", range: 340, width: 52, mult: 1.25, cd: 7, mana: 30,
      unlockRealm: 99, fromFabao: true, color: "#B08A3E", tier: 3, element: "metal", desc: "金蛟化光，贯穿直行" },
    { key: "fb_huntian", name: "混天绫", shape: "nova", lock: "area", range: 190, mult: 0.95, cd: 9, mana: 34,
      unlockRealm: 99, fromFabao: true, color: "#A93F2E", tier: 3, element: "fire", desc: "绫罗震荡，环身俱伤" },
    { key: "fb_fantian", name: "翻天印", shape: "nova", lock: "area", range: 230, mult: 1.35, cd: 12, mana: 48,
      unlockRealm: 99, fromFabao: true, color: "#5C7A6E", tier: 4, element: "earth", desc: "大印压顶，重创四周" },
    { key: "fb_zijin",   name: "紫金葫芦", shape: "cone", lock: "area", range: 260, angle: 0.7, mult: 1.05, cd: 10, mana: 36,
      unlockRealm: 99, fromFabao: true, color: "#7A5E9E", tier: 3, element: "wood", desc: "葫芦吐纳，扇形吞噬" },
    { key: "fb_qinglian", name: "青莲剑歌", shape: "line", lock: "single", range: 420, width: 36, mult: 1.6, cd: 11, mana: 44,
      unlockRealm: 99, fromFabao: true, color: "#3E7A5E", tier: 4, element: "wood", pierce: 3, desc: "剑气如莲，穿射三敌" },
    { key: "fb_luotian", name: "落天钟", shape: "nova", lock: "area", range: 210, mult: 1.1, cd: 10, mana: 40,
      unlockRealm: 99, fromFabao: true, color: "#8B2E4A", tier: 3, element: "water", desc: "钟鸣摄魂，环身震伤" },
  ],

  // ---------- 功法体系（v0.53.1：六阶目录正式数据）----------
  // 旧 tier 保留作掉落兼容；grade/layers/unlockRealm/category 是当前正式目录字段。
  GONGFA_CATALOG_VERSION: 1,
  GONGFA_GRADES: [
    null,
    { grade: 1, name: "凡品", layers: 3, unlockRealm: 0 },
    { grade: 2, name: "灵品", layers: 6, unlockRealm: 1 },
    { grade: 3, name: "玄品", layers: 9, unlockRealm: 2 },
    { grade: 4, name: "地品", layers: 9, unlockRealm: 3 },
    { grade: 5, name: "天品", layers: 12, unlockRealm: 4 },
    { grade: 6, name: "仙品", layers: 12, unlockRealm: 9 },
  ],
  GONGFA_LAYERS_OF_TIER: [0, 3, 6, 9, 9, 12, 12],
  GONGFA_FULL_MULT: 2,
  GONGFA_COST_STONE: 400, // v0.52.0 起保留为旧档兼容常量，不再用于功法升级
  GONGFA_COST_QI: 0.08,  // v0.52.0 起保留为旧档兼容常量，不再用于功法升级
  GONGFA_WUDAO_RATE: 0.2, // 悟道获取速率 = 基础修炼速率 × 20%
  GONGFA_WUDAO_COST: 20, // 一层基础悟道成本，按阶数与目标层数递增
  GONGFA_BOOKS: [
    { key: "changsheng", name: "长生诀", skillKeys: ["lingxi_zhang"], tier: 1, layers: 3, unlockRealm: 0, cost: 1, grade: 1, category: "xin", legacyLayers: 3, legacyUnlockRealm: 0,
      desc: "引气入体，道基之始。以恒久为要，不求速成。", stats: { cult: 0.02 },
      nodes: [{ at: 3, key: "cult", value: 0.04, desc: "洞府灵气 +4.0%" }] },
    { key: "sanhua", name: "三花聚顶", skillKeys: ["sanhua_guard"], tier: 2, layers: 6, unlockRealm: 1, cost: 1, grade: 2, category: "xin", legacyLayers: 6, legacyUnlockRealm: 0,
      desc: "精气神三华聚于顶上，道行与气血同长。", stats: { cult: 0.016, hp: 0.008 },
      nodes: [{ at: 3, key: "cult", value: 0.032, desc: "洞府灵气 +3.2%" }, { at: 6, key: "hp", value: 0.016, desc: "气血 +1.6%" }] },
    { key: "wuqi", name: "五气朝元", skillKeys: ["wuqi_return"], tier: 2, layers: 6, unlockRealm: 1, cost: 1, grade: 2, category: "xin", legacyLayers: 6, legacyUnlockRealm: 0,
      desc: "五脏之气朝会元海，吐纳之间药力自化。", stats: { cult: 0.014, pill: 0.02 },
      nodes: [{ at: 3, key: "cult", value: 0.028, desc: "洞府灵气 +2.8%" }, { at: 6, key: "pill", value: 0.04, desc: "丹效 +4.0%" }] },
    { key: "tiangang", name: "天罡培元功", skillKeys: ["tiangang_pierce", "tiangang_qi"], tier: 3, layers: 6, unlockRealm: 1, cost: 2, grade: 2, category: "shu", legacyLayers: 9, legacyUnlockRealm: 1,
      desc: "天罡三十六气锤炼真元，出手既重且稳。", stats: { atk: 0.008, cult: 0.012 },
      nodes: [{ at: 3, key: "atk", value: 0.016, desc: "攻伐 +1.6%" }, { at: 6, key: "cult", value: 0.024, desc: "洞府灵气 +2.4%" }, { at: 6, key: "atk", value: 0.016, desc: "攻伐 +1.6%" }] },
    { key: "hunyuan", name: "混元一气诀", skillKeys: ["xuan_jia"], tier: 3, layers: 6, unlockRealm: 1, cost: 2, grade: 2, category: "xin", legacyLayers: 9, legacyUnlockRealm: 1,
      desc: "混元未判之气护住周身，攻守兼备。", stats: { cult: 0.012, def: 0.01 },
      nodes: [{ at: 3, key: "cult", value: 0.024, desc: "洞府灵气 +2.4%" }, { at: 6, key: "def", value: 0.02, desc: "护体 +2.0%" }, { at: 6, key: "cult", value: 0.024, desc: "洞府灵气 +2.4%" }] },
    { key: "tianyan", name: "天衍术", skillKeys: ["tianyan_oracle"], tier: 4, layers: 9, unlockRealm: 2, cost: 2, grade: 3, category: "dao", legacyLayers: 12, legacyUnlockRealm: 2,
      desc: "推演天机，趋吉避凶，秘境之中多有收获。", stats: { field: 0.02, cult: 0.01 },
      nodes: [{ at: 3, key: "field", value: 0.04, desc: "秘境收获 +4.0%" }, { at: 6, key: "cult", value: 0.02, desc: "洞府灵气 +2.0%" }, { at: 9, key: "field", value: 0.04, desc: "秘境收获 +4.0%" }, { at: 9, key: "cult", value: 0.02, desc: "洞府灵气 +2.0%" }] },
    { key: "jiuzhuan", name: "九转金丹功", skillKeys: ["hui_chun"], tier: 4, layers: 9, unlockRealm: 2, cost: 2, grade: 3, category: "xin", legacyLayers: 12, legacyUnlockRealm: 2,
      desc: "九转还丹，一粒入腹，药力尽化。", stats: { pill: 0.03, cult: 0.01 },
      nodes: [{ at: 3, key: "pill", value: 0.06, desc: "丹效 +6.0%" }, { at: 6, key: "cult", value: 0.02, desc: "洞府灵气 +2.0%" }, { at: 9, key: "pill", value: 0.06, desc: "丹效 +6.0%" }, { at: 9, key: "cult", value: 0.02, desc: "洞府灵气 +2.0%" }] },
    { key: "ningshen", name: "凝神术", skillKeys: ["ningshen_focus"], tier: 4, layers: 9, unlockRealm: 2, cost: 2, grade: 3, category: "dao", legacyLayers: 12, legacyUnlockRealm: 2,
      desc: "凝神定志，神识外放，可驭古宝法宝。", stats: { atk: 0.007, crit: 0.02 },
      nodes: [{ at: 3, key: "atk", value: 0.014, desc: "攻伐 +1.4%" }, { at: 6, key: "crit", value: 0.04, desc: "会心 +4.0%" }, { at: 9, key: "atk", value: 0.014, desc: "攻伐 +1.4%" }, { at: 9, key: "crit", value: 0.04, desc: "会心 +4.0%" }] },
    { key: "jiuyou", name: "九幽诀", skillKeys: ["bing_huan"], tier: 5, layers: 9, unlockRealm: 2, cost: 2, grade: 3, category: "xin", legacyLayers: 12, legacyUnlockRealm: 3,
      desc: "九幽阴气入体，修行一日千里。", stats: { cult: 0.016 },
      nodes: [{ at: 3, key: "cult", value: 0.032, desc: "洞府灵气 +3.2%" }, { at: 6, key: "cult", value: 0.032, desc: "洞府灵气 +3.2%" }, { at: 9, key: "cult", value: 0.032, desc: "洞府灵气 +3.2%" }, { at: 9, key: "cult", value: 0.032, desc: "洞府灵气 +3.2%" }] },
    { key: "chiyang", name: "赤阳经", skillKeys: ["huo_hai", "chiyang_burst"], tier: 5, layers: 9, unlockRealm: 2, cost: 2, grade: 3, category: "shu", legacyLayers: 12, legacyUnlockRealm: 3,
      desc: "赤阳真火淬炼经脉，出手带灼。", stats: { atk: 0.011 },
      nodes: [{ at: 3, key: "atk", value: 0.022, desc: "攻伐 +2.2%" }, { at: 6, key: "atk", value: 0.022, desc: "攻伐 +2.2%" }, { at: 9, key: "atk", value: 0.022, desc: "攻伐 +2.2%" }, { at: 9, key: "atk", value: 0.022, desc: "攻伐 +2.2%" }] },
    { key: "huaxue", name: "化血神功", skillKeys: ["huaxue_drain", "huaxue_blood"], tier: 5, layers: 9, unlockRealm: 2, cost: 2, grade: 3, category: "shu", legacyLayers: 12, legacyUnlockRealm: 3,
      desc: "化血为力，伤敌即养己。", stats: { atk: 0.009, lifesteal: 0.02 },
      nodes: [{ at: 3, key: "atk", value: 0.018, desc: "攻伐 +1.8%" }, { at: 6, key: "lifesteal", value: 0.04, desc: "噬血 +4.0%" }, { at: 9, key: "atk", value: 0.018, desc: "攻伐 +1.8%" }, { at: 9, key: "lifesteal", value: 0.04, desc: "噬血 +4.0%" }] },
    { key: "yinming", name: "阴冥诀", skillKeys: ["yinming_soul"], tier: 6, layers: 9, unlockRealm: 3, cost: 3, grade: 4, category: "dao", legacyLayers: 12, legacyUnlockRealm: 4,
      desc: "阴冥之气凝于体表，刀兵难伤。", stats: { def: 0.013, hp: 0.01 },
      nodes: [{ at: 3, key: "def", value: 0.026, desc: "护体 +2.6%" }, { at: 6, key: "hp", value: 0.02, desc: "气血 +2.0%" }, { at: 9, key: "def", value: 0.026, desc: "护体 +2.6%" }, { at: 9, key: "hp", value: 0.02, desc: "气血 +2.0%" }] },
    { key: "tianyan_jue", name: "天焱诀", skillKeys: ["lei_ting", "tianyan_thunder"], tier: 6, layers: 9, unlockRealm: 3, cost: 3, grade: 4, category: "shu", legacyLayers: 12, legacyUnlockRealm: 4,
      desc: "天焱附于兵刃，一击见血。", stats: { atk: 0.012, crit: 0.015 },
      nodes: [{ at: 3, key: "atk", value: 0.024, desc: "攻伐 +2.4%" }, { at: 6, key: "crit", value: 0.03, desc: "会心 +3.0%" }, { at: 9, key: "atk", value: 0.024, desc: "攻伐 +2.4%" }, { at: 9, key: "crit", value: 0.03, desc: "会心 +3.0%" }] },
    { key: "qingyun", name: "青云剑诀", skillKeys: ["yu_jian", "qingyun_frost"], tier: 6, layers: 9, unlockRealm: 3, cost: 3, grade: 4, category: "shu", legacyLayers: 12, legacyUnlockRealm: 4,
      desc: "青云直上，剑意通神。", stats: { atk: 0.014, crit: 0.015 },
      nodes: [{ at: 3, key: "atk", value: 0.028, desc: "攻伐 +2.8%" }, { at: 6, key: "crit", value: 0.03, desc: "会心 +3.0%" }, { at: 9, key: "atk", value: 0.028, desc: "攻伐 +2.8%" }, { at: 9, key: "crit", value: 0.03, desc: "会心 +3.0%" }] },
    { key: "panyun", name: "攀云乘龙术", skillKeys: ["panyun_step"], tier: 6, layers: 9, unlockRealm: 3, cost: 3, grade: 4, category: "shen", legacyLayers: 12, legacyUnlockRealm: 4,
      desc: "乘龙攀云，来去无踪，闭关所得更丰。", stats: { field: 0.025, offline: 0.04 },
      nodes: [{ at: 3, key: "field", value: 0.05, desc: "秘境收获 +5.0%" }, { at: 6, key: "offline", value: 0.08, desc: "闭关收益 +8.0%" }, { at: 9, key: "field", value: 0.05, desc: "秘境收获 +5.0%" }, { at: 9, key: "offline", value: 0.08, desc: "闭关收益 +8.0%" }] },
    { key: "baihua", name: "百花春日诀", skillKeys: ["baihua_spring"], tier: 7, layers: 12, unlockRealm: 4, cost: 3, grade: 5, category: "xin", legacyLayers: 12, legacyUnlockRealm: 5,
      desc: "百花逢春，生生不息，道行自长。", stats: { cult: 0.018 },
      nodes: [{ at: 3, key: "cult", value: 0.036, desc: "洞府灵气 +3.6%" }, { at: 6, key: "cult", value: 0.036, desc: "洞府灵气 +3.6%" }, { at: 9, key: "cult", value: 0.036, desc: "洞府灵气 +3.6%" }, { at: 12, key: "cult", value: 0.036, desc: "洞府灵气 +3.6%" }] },
    { key: "shouyang", name: "大首阳真经", skillKeys: ["shouyang_wall"], tier: 7, layers: 12, unlockRealm: 4, cost: 3, grade: 5, category: "xin", legacyLayers: 12, legacyUnlockRealm: 5,
      desc: "首阳之精，正气浩然，气血充盈。", stats: { cult: 0.014, hp: 0.014 },
      nodes: [{ at: 3, key: "cult", value: 0.028, desc: "洞府灵气 +2.8%" }, { at: 6, key: "hp", value: 0.028, desc: "气血 +2.8%" }, { at: 9, key: "cult", value: 0.028, desc: "洞府灵气 +2.8%" }, { at: 12, key: "hp", value: 0.028, desc: "气血 +2.8%" }] },
    { key: "yijing", name: "易经洗髓经", skillKeys: ["yijing_flow"], tier: 7, layers: 12, unlockRealm: 4, cost: 3, grade: 5, category: "shen", legacyLayers: 12, legacyUnlockRealm: 5,
      desc: "易筋洗髓，脱胎换骨，体魄胜于法宝。", stats: { hp: 0.016, def: 0.012 },
      nodes: [{ at: 3, key: "hp", value: 0.032, desc: "气血 +3.2%" }, { at: 6, key: "def", value: 0.024, desc: "护体 +2.4%" }, { at: 9, key: "hp", value: 0.032, desc: "气血 +3.2%" }, { at: 12, key: "def", value: 0.024, desc: "护体 +2.4%" }] },
    { key: "wuse", name: "五色神光诀", skillKeys: ["wuse_guard"], tier: 8, layers: 12, unlockRealm: 4, cost: 3, grade: 5, category: "dao", legacyLayers: 12, legacyUnlockRealm: 6,
      desc: "五行五色，神光刷落万物，药力亦为之增。", stats: { cult: 0.015, pill: 0.035 },
      nodes: [{ at: 3, key: "cult", value: 0.03, desc: "洞府灵气 +3.0%" }, { at: 6, key: "pill", value: 0.07, desc: "丹效 +7.0%" }, { at: 9, key: "cult", value: 0.03, desc: "洞府灵气 +3.0%" }, { at: 12, key: "pill", value: 0.07, desc: "丹效 +7.0%" }] },
    { key: "xingyuan", name: "星元秘法", skillKeys: ["xingyuan_star"], tier: 8, layers: 12, unlockRealm: 4, cost: 3, grade: 5, category: "dao", legacyLayers: 12, legacyUnlockRealm: 6,
      desc: "周天星辰之力加身，秘境之中如鱼得水。", stats: { field: 0.035, offline: 0.04 },
      nodes: [{ at: 3, key: "field", value: 0.07, desc: "秘境收获 +7.0%" }, { at: 6, key: "offline", value: 0.08, desc: "闭关收益 +8.0%" }, { at: 9, key: "field", value: 0.07, desc: "秘境收获 +7.0%" }, { at: 12, key: "offline", value: 0.08, desc: "闭关收益 +8.0%" }] },
    { key: "zixiao", name: "紫霄真经", skillKeys: ["zixiao_thunder"], tier: 8, layers: 12, unlockRealm: 4, cost: 3, grade: 5, category: "dao", legacyLayers: 12, legacyUnlockRealm: 6,
      desc: "紫霄为天地至极，洞悉演化之律。", stats: { cult: 0.02, field: 0.025 },
      nodes: [{ at: 3, key: "cult", value: 0.04, desc: "洞府灵气 +4.0%" }, { at: 6, key: "field", value: 0.05, desc: "秘境收获 +5.0%" }, { at: 9, key: "cult", value: 0.04, desc: "洞府灵气 +4.0%" }, { at: 12, key: "field", value: 0.05, desc: "秘境收获 +5.0%" }] },
    { key: "jiuding", name: "九鼎炼神诀", skillKeys: ["hunyuan_jue", "jiuding_guard"], tier: 8, layers: 12, unlockRealm: 4, cost: 3, grade: 5, category: "shu", legacyLayers: 12, legacyUnlockRealm: 6,
      desc: "九鼎镇神魂，攻守皆如渊岳。", stats: { atk: 0.012, def: 0.012 },
      nodes: [{ at: 3, key: "atk", value: 0.024, desc: "攻伐 +2.4%" }, { at: 6, key: "def", value: 0.024, desc: "护体 +2.4%" }, { at: 9, key: "atk", value: 0.024, desc: "攻伐 +2.4%" }, { at: 12, key: "def", value: 0.024, desc: "护体 +2.4%" }] },
    { key: "jingshou", name: "静守谷神术", skillKeys: ["jingshou_hide"], tier: 9, layers: 12, unlockRealm: 9, cost: 4, grade: 6, category: "shen", legacyLayers: 12, legacyUnlockRealm: 7,
      desc: "谷神不死，是谓玄牝。静守之间，天地自归。", stats: { cult: 0.022, offline: 0.05 },
      nodes: [{ at: 3, key: "cult", value: 0.044, desc: "洞府灵气 +4.4%" }, { at: 6, key: "offline", value: 0.1, desc: "闭关收益 +10.0%" }, { at: 9, key: "cult", value: 0.044, desc: "洞府灵气 +4.4%" }, { at: 12, key: "offline", value: 0.1, desc: "闭关收益 +10.0%" }] },
    { key: "yuqing", name: "玉清仙诀", skillKeys: ["yuqing_ward"], tier: 9, layers: 12, unlockRealm: 9, cost: 4, grade: 6, category: "dao", legacyLayers: 12, legacyUnlockRealm: 7,
      desc: "玉清仙光护体，雷劫亦需避锋。", stats: { cult: 0.018, trib: 0.03 },
      nodes: [{ at: 3, key: "cult", value: 0.036, desc: "洞府灵气 +3.6%" }, { at: 6, key: "trib", value: 0.06, desc: "渡劫 +6.0%" }, { at: 9, key: "cult", value: 0.036, desc: "洞府灵气 +3.6%" }, { at: 12, key: "trib", value: 0.06, desc: "渡劫 +6.0%" }] },
    { key: "yuhua", name: "羽化飞仙术", skillKeys: ["yuhua_immortal"], tier: 10, layers: 12, unlockRealm: 9, cost: 4, grade: 6, category: "dao", legacyLayers: 12, legacyUnlockRealm: 8,
      desc: "羽化而登仙，一身道基尽数圆满。", stats: { atk: 0.01, def: 0.01, hp: 0.01, cult: 0.02, trib: 0.04 },
      nodes: [{ at: 3, key: "atk", value: 0.02, desc: "攻伐 +2.0%" }, { at: 6, key: "def", value: 0.02, desc: "护体 +2.0%" }, { at: 9, key: "hp", value: 0.02, desc: "气血 +2.0%" }, { at: 12, key: "cult", value: 0.04, desc: "洞府灵气 +4.0%" }] },
  ],

  // ---------- 角色形象（v0.22.0）----------
  // 纯外观选择，附带极小的初始倾向（±3%），不构成强度差
  AVATARS: [
    { key: "qingshan", name: "青衫剑客", desc: "一袭青衫，剑走轻灵。出手最快。", img: "assets/角色_青衫剑客.webp" },
    { key: "baishang", name: "白衣仙子", desc: "素衣若雪，气机清冷。道心最定。", img: "assets/角色_白衣仙子.webp" },
    { key: "xuandao",  name: "玄袍道人", desc: "鹤发玄袍，阅尽沧桑。护体最厚。", img: "assets/角色_玄袍道人.webp" },
    { key: "hongyi",   name: "红衣魔修", desc: "赤衣如血，行事不羁。攻伐最烈。", img: "assets/角色_红衣魔修.webp" },
    { key: "shaonian", name: "少年修士", desc: "初入仙途，气血正盛。生机最旺。", img: "assets/角色_少年修士.webp" },
    { key: "suyi",     name: "素衣女修", desc: "布衣素簪，温婉自持。修行最稳。", img: "assets/角色_素衣女修.webp" },
  ],

  // ---------- 灵兽（v0.21.0）----------
  // 跟宠形态：跟在角色身后，自动索敌攻击，不承伤
  PETS: [
    { key: "chiyan",  name: "赤焰狐", tier: 1, realm: 0, atkMul: 0.55, speedMul: 1.15, cd: 1.15,
      capture: 0.55, color: "#C1502A", desc: "生于火山之隙，性烈如火，扑咬迅捷。" },
    { key: "qinglin", name: "青鳞蛇", tier: 1, realm: 1, atkMul: 0.60, speedMul: 1.05, cd: 1.25,
      capture: 0.50, color: "#3E7A5E", desc: "鳞如青玉，吐息含毒，缠斗不休。" },
    { key: "xuangui", name: "玄龟", tier: 2, realm: 2, atkMul: 0.70, speedMul: 0.80, cd: 1.60,
      capture: 0.40, color: "#3E6E9E", desc: "负山而行，一击沉重，慢而不乱。" },
    { key: "baiyu",  name: "白羽鹤", tier: 2, realm: 3, atkMul: 0.78, speedMul: 1.30, cd: 1.05,
      capture: 0.35, color: "#C8C4B4", desc: "云中白鹤，一啄如电，来去无痕。" },
    { key: "leiven", name: "雷纹豹", tier: 3, realm: 4, atkMul: 0.95, speedMul: 1.35, cd: 0.95,
      capture: 0.28, color: "#8B5FBF", desc: "身负雷纹，奔袭时电光随行。" },
    { key: "youming",name: "幽冥狼", tier: 3, realm: 5, atkMul: 1.05, speedMul: 1.20, cd: 1.10,
      capture: 0.22, color: "#5E4A7A", desc: "自幽冥裂隙而出，眼中无光，只余杀意。" },
    { key: "jinjing",name: "金睛猿", tier: 4, realm: 6, atkMul: 1.25, speedMul: 0.95, cd: 1.30,
      capture: 0.16, color: "#B08A3E", desc: "金睛照破虚妄，一臂可撼山岳。" },
    { key: "jiuwei", name: "九尾天狐", tier: 5, realm: 8, atkMul: 1.60, speedMul: 1.25, cd: 1.00,
      capture: 0.10, color: "#A93F2E", desc: "九尾摇曳，幻术天成，千年方得一遇。" },
  ],
  PET_MAX: 6,               // 最多携带灵兽数
  PET_FOLLOW_DIST: 46,      // 跟随时与主人的距离
  PET_SEEK_RANGE: 380,      // 索敌范围
  PET_EXP_PER_LV: 60,       // 每级所需经验（×等级）
  PET_MAX_LV: 30,
  PET_WILD_RATE: 0.45,      // 每张秘境出现野生灵兽的概率
  PET_TRAIN_STONE: 260,     // 培养一次消耗灵石（×等级）

  // —— 灵兽深度养成（v0.24.0）——
  PET_STAR_MAX: 5,          // 星级上限
  PET_STAR_ATK: 0.08,       // 每星攻击加成（乘算）
  PET_STAR_STONE: 900,      // 融合升星灵石消耗（×目标星数）
  PET_BOND_MAX: 100,        // 亲密度上限
  PET_BOND_PER_KILL: 0.6,   // 秘境每击杀 +亲密度
  PET_BOND_BOSS_BONUS: 3,   // 通关秘境（杀 BOSS）额外亲密度
  PET_BOND_FEED_HERB: 8,    // 喂食 1 灵草 +8 亲密度
  PET_BOND_ATK: 0.10,       // 满亲密度攻击加成（线性：10% × bond/100）
  // 技能池：捕捉时按稀有度随机获得
  // type: active=主动（独立 cd）｜passive=被动（常驻乘算）｜kill=击杀触发
  PET_SKILLS: [
    { key: "smash",  name: "猛扑", type: "active", cd: 6,  mult: 2.2,
      desc: "每 6 秒扑向目标，造成 220% 伤害的一击。" },
    { key: "guard",  name: "护主", type: "active", cd: 12, mult: 2.5,
      desc: "每 12 秒为主人张开护盾，可吸收一次伤害。" },
    { key: "roar",   name: "战嚎", type: "active", cd: 15, nextMult: 1.6,
      desc: "每 15 秒长啸，主人下次普攻伤害 ×1.6。" },
    { key: "fang",   name: "獠牙", type: "passive", mult: 1.30,
      desc: "獠牙淬毒，灵兽普攻伤害永久 +30%。" },
    { key: "devour", name: "嗜血", type: "kill", mana: 8,
      desc: "灵兽每击杀一名敌人，主人回复 8 点真元。" },
  ],
  // 按稀有度（tier）掷技能：t1-2 30% 得 1 个；t3 必得 1 个 + 25% 第 2 个；t4-5 必得 2 个
  petSkillRoll(tier) {
    const pool = CONFIG.PET_SKILLS.map(s => s.key);
    const out = [];
    const tryOnce = () => {
      const rest = pool.filter(k => out.indexOf(k) < 0);
      if (!rest.length) return;
      out.push(rest[Math.floor(Math.random() * rest.length)]);
    };
    if (tier >= 4) { tryOnce(); tryOnce(); }
    else if (tier === 3) { tryOnce(); if (Math.random() < 0.25) tryOnce(); }
    else if (Math.random() < 0.30) tryOnce();
    return out;
  },
  petSkillDef(key) {
    return CONFIG.PET_SKILLS.find(s => s.key === key) || null;
  },

  // 秘境地图生成（每章一张，规模随章节增长）
  // 难度不绑章节：fldCreate 内按玩家当前进度（bestStage）取基准关，
  // 章节只决定地图皮肤与结算推进目标，避免「章节指数跳跃」导致怪打不动。
  fieldMap(ch) {
    const def = CONFIG.CHAPTERS[ch];
    const per = CONFIG.STAGES_PER_CHAPTER + 1;
    return {
      ch,
      name: def ? def.name : "未知秘境",
      bg: def ? def.bg : "assets/秘境_青云山门.webp",
      w: 800 + ch * 50,
      spawn: 3 + Math.floor(ch / 2),          // 普通怪数量（控制清图时长）
      elite: 1 + Math.floor(ch / 4),          // 精英数量
      boss: true,                             // 守阵 BOSS
      bossStage: Math.min(41, ch * per + CONFIG.STAGES_PER_CHAPTER),  // 结算推进到该章末关
    };
  },

  // 秘境交互节点（v0.17.0）：矿脉 / 灵脉 / 灵植 / 遗迹
  // yield 为「每点资源量」，实际产出 = base × (1 + 境界×0.35) × 随机波动
  FIELD_NODES: [
    { key: "ore",  name: "灵石矿脉", color: "#9A927E", glow: "#C9B98F",
      gatherTime: 1.1, explore: 6, res: "stone", base: 120, r: 20,
      desc: "地脉凝结的灵石，持续产出灵石" },
    { key: "vein", name: "灵气灵脉", color: "#4E8A7E", glow: "#7FC9B4",
      gatherTime: 1.4, explore: 6, res: "qi", base: 60, r: 20,
      desc: "天地灵气汇聚之处，吐纳可增修为" },
    { key: "herb", name: "灵植丛", color: "#5E9A56", glow: "#9CD48F",
      gatherTime: 0.9, explore: 5, res: "herb", base: 2, r: 17,
      desc: "野生灵草，可用于炼丹" },
    { key: "ruin", name: "古迹遗迹", color: "#9A7A46", glow: "#E0C070",
      gatherTime: 2.0, explore: 15, res: "material", base: 3, r: 22,
      relic: true, desc: "上古修士洞府残迹，或藏法宝图纸" },
  ],

  // 探索度：满 EXPLORE_MAX 即通关（自动结算）
  FIELD_EXPLORE_MAX: 100,
  FIELD_KILL_EXPLORE: { normal: 6, elite: 8, boss: 20 },
  FIELD_MAP_NODES: [4, 5, 5, 6, 6, 7, 7],   // 各章节点数量

  // 传送阵：探索度达标后出现在 BOSS 位置
  FIELD_PORTAL_R: 34,

  // 派遣（通关后派弟子挂机采集）
  DISPATCH: {
    // 驻守人数不再设置秘境单独上限；总人数受玩家弟子名册约束。
    BASE_RATE: 0.02,          // 每人每秒基础产出系数（×2 后约为灵石/秒）
    REALM_RATE: 0.22,         // 弟子境界每级 +22%
    SPECIALTY_BONUS: 0.5,     // 专精匹配额外 +50%
    BOND_BONUS: 0.2,          // 情谊≥90 再 +20%
    OFFLINE_CAP_HOURS: 8,     // 离线产出上限（小时）
    FOLK_RATE: 0.02,          // v0.28.0：每名驻守弟子每秒繁衍凡人（≈1.2 人/分）
    // 秘境教化：一人基础进度/秒；后续弟子边际贡献递减。
    FOLK_VEIN_BONUS: 0.2,     // 灵脉每级再 +20% 凡人繁衍
    NODE_INTERVAL: 180,       // v0.28.0：驻守秘境资源点刷新间隔（秒）
    NODE_OFFLINE_CAP: 20,     // 离线最多补算的资源点刷新间隔次数
    // v0.51.0：驻守结算单。产出仍实时入账，结算单只做「自上次结算以来的账目汇总」，
    // 不重复发钱（避免双计），用于让挂机产出可被玩家看见。
    SETTLE_MIN_SEC: 60,       // 累计满 60 秒才允许出一张结算单
    SETTLE_KEEP_SEC: 86400,   // 结算单最多汇总 24 小时（防御异常长挂机）
  },

  // ---------- 法宝词条（v0.6.2） ----------
  // 同阶法宝的差异来源：品阶决定「词条条数」，随机决定「词条种类」
  // tier 1-2 → 0 条 ｜ tier 3-4 → 1 条 ｜ tier 5-6 → 2 条
  AFFIX_COUNT: [0, 0, 1, 1, 2, 2],   // index = tier-1
  AFFIX_CRIT_MULT: 1.5,              // 暴击伤害倍率
  AFFIX_TYPES: [
    { key: "crit",      name: "暴击", color: "#A93F2E", desc: "攻击有几率造成 1.5 倍伤害" },
    { key: "lifesteal", name: "吸血", color: "#8B2E4A", desc: "造成伤害的一部分转为自身气血" },
    { key: "thorns",    name: "反伤", color: "#5C7A6E", desc: "受击时反弹部分伤害给敌人" },
  ],
  // 词条数值基准（按品阶），实际值 = 基准 × 词条浮动(0.85~1.15)
  // 平衡：满配三槽极限词条约相当于 +20% 综合战力，属锦上添花而非必需品
  AFFIX_BASE: {
    crit:      [0, 0, 0.035, 0.055, 0.080, 0.110],
    lifesteal: [0, 0, 0.030, 0.045, 0.065, 0.090],
    thorns:    [0, 0, 0.050, 0.075, 0.105, 0.140],
  },
  AFFIX_ROLL_MIN: 0.85,
  AFFIX_ROLL_MAX: 1.15,
  // 词条汇总上限（防止三槽叠满失衡）
  AFFIX_CAP: { crit: 0.40, lifesteal: 0.30, thorns: 0.40 },

  // ---------- 境界专属剧情事件（v0.6.2） ----------
  // 每个大境界只触发一次，由 milestones 记录，不复刷
  REALM_EVENTS: [
    { realm: 2, key: "heartdemon", name: "心魔劫" },
    { realm: 3, key: "zifu",      name: "紫府洞天" },
    { realm: 4, key: "huashen",   name: "神识化虚" },
    { realm: 5, key: "lianxu",    name: "虚空裂缝" },
    { realm: 6, key: "heti",      name: "道基归一" },
    { realm: 7, key: "dacheng",   name: "众生愿力" },
    { realm: 8, key: "dujie",     name: "九霄雷劫" },
  ],
  // 金丹·心魔劫
  HEARTDEMON_STONE: 200,          // 静心守一消耗灵石
  HEARTDEMON_RATIO: 1.05,         // 直面心魔的敌方战力比
  HEARTDEMON_REWARD_MAT: 10,      // 胜后灵材
  HEARTDEMON_REWARD_QI: 0.15,     // 胜后灵气（占当前突破所需比例）
  HEARTDEMON_FAIL_QI: 0.5,        // 败后灵气损失比例
  // 元婴·紫府洞天
  ZIFU_ENTER_STONE: 500,          // 入洞天消耗灵石
  ZIFU_REWARD_MAT: 20,            // 探索所得灵材
  ZIFU_REWARD_REP: 15,            // 探索所得声望
  ZIFU_ARTIFACT_TIER: 4,          // 洞天法宝品阶（法器）
  ZIFU_SEAL_QI: 0.25,             // 闭关稳固所得灵气（占突破所需比例）
  // 化神·神识化虚（v0.6.3）
  HUASHEN_QI_LOSS: 0.10,          // 凝练神识消耗灵气（占当前灵气比例）
  HUASHEN_RATIO: 0.95,            // 参悟虚空敌方战力比
  HUASHEN_REWARD_MAT: 16,         // 参悟所得灵材
  HUASHEN_RATIO_REP: 12,          // 参悟所得声望
  HUASHEN_SEAL_QI: 0.10,          // 稳守本心得灵气（占突破所需比例）
  // 炼虚·虚空裂缝（v0.6.3）
  LIANXU_ENTER_STONE: 800,        // 探入裂缝消耗灵石
  LIANXU_RATIO: 1.10,             // 深入虚空敌方战力比
  LIANXU_ARTIFACT_TIER: 5,        // 虚空所得法宝品阶（灵宝）
  LIANXU_REWARD_MAT: 24,          // 深入所得灵材
  LIANXU_REP: 18,                 // 深入所得声望
  LIANXU_ECHO_QI: 0.18,           // 回溯虚影得灵气（占突破所需比例）
  LIANXU_SEAL_REP: 10,            // 封印裂缝得声望
  LIANXU_SEAL_REL: 8,             // 封印裂缝得青云门关系
  // 合体·道基归一（v0.6.4）：元婴与肉身合一，需以灵材固本或硬抗崩解
  HETI_MAT: 30,                   // 以灵材固本的灵材消耗
  HETI_STONE: 1500,               // 以灵材固本的灵石消耗
  HETI_QI: 0.15,                  // 固本所得灵气（占突破所需比例）
  HETI_RATIO: 1.05,               // 硬合肉身的敌方战力比
  HETI_WIN_QI: 0.25,              // 硬合成功得灵气
  HETI_WIN_REP: 20,               // 硬合成功得声望
  HETI_WIN_MAT: 20,               // 硬合成功得灵材
  HETI_FAIL_QI: 0.20,             // 硬合失败损失灵气比例
  // 大乘·众生愿力（v0.6.4）：渡化众生，以愿力稳固道果
  DACHENG_STONE: 2000,            // 下山传道消耗灵石
  DACHENG_QI: 0.10,               // 闭关自守所得灵气
  DACHENG_REP: 30,                // 广开法会所得声望
  DACHENG_REL: 15,                // 广开法会所得青云门关系
  DACHENG_MAT: 30,                // 广开法会所得灵材
  DACHENG_QI_GATHER: 0.20,        // 只取愿力所得灵气
  // 渡劫·九霄雷劫（v0.6.4）：飞升前最后一劫
  DUJIE_RATIO: 1.20,              // 硬抗雷劫的敌方战力比
  DUJIE_WIN_QI: 0.40,             // 硬抗成功得灵气
  DUJIE_WIN_REP: 50,              // 硬抗成功得声望
  DUJIE_WIN_TIER: 5,              // 硬抗成功所得法宝品阶（灵宝）
  DUJIE_FAIL_QI: 0.30,            // 硬抗失败损失灵气比例
  DUJIE_SAC_QI: 0.25,             // 法宝挡劫所得灵气
  DUJIE_SAC_REP: 20,              // 法宝挡劫所得声望
  DUJIE_WAIT_QI: 0.08,            // 静待雷消所得灵气

  // ---------- 词条洗练（v0.6.3） ----------
  // 消耗灵材 + 灵石重掷该法宝全部词条，无失败风险，结果即时生效
  REROLL_MAT_RATIO: 0.5,          // 灵材消耗 = 该阶材料 × 此比例
  REROLL_STONE_RATIO: 0.3,        // 灵石消耗 = 该阶灵石 × 此比例
  REROLL_MIN_TIER: 3,             // 低于该品阶无词条，不可洗练
  REROLL_LOCK_MULT: 2,            // 锁定一条词条再洗，消耗翻倍
  REROLL_LOCK_MIN_COUNT: 2,       // 词条数达到该值才可锁定洗练

  // ---------- 道途录：成就（v0.6.5） ----------
  // 条件判定在 codex.js 的 CHECKERS，此处只存文案与奖励（数值单一来源）
  // reward 字段：rep 声望 / mat 灵材 / stone 灵石
  ACHIEVEMENTS: [
    // —— 境界（9）——
    { key: "realm_1", name: "筑基之始", desc: "初次突破至筑基期", reward: { rep: 5 } },
    { key: "realm_2", name: "金丹初结", desc: "突破至金丹期", reward: { rep: 8 } },
    { key: "realm_3", name: "元婴出窍", desc: "突破至元婴期", reward: { rep: 10 } },
    { key: "realm_4", name: "神游化虚", desc: "突破至化神期", reward: { rep: 12 } },
    { key: "realm_5", name: "虚空炼形", desc: "突破至炼虚期", reward: { rep: 15 } },
    { key: "realm_6", name: "道基归一", desc: "突破至合体期", reward: { rep: 18 } },
    { key: "realm_7", name: "众生愿力", desc: "突破至大乘期", reward: { rep: 20 } },
    { key: "realm_8", name: "九霄雷劫", desc: "突破至渡劫期", reward: { rep: 25 } },
    { key: "realm_9", name: "真仙临世", desc: "突破至真仙期", reward: { rep: 30, mat: 20 } },
    { key: "realm_10", name: "金仙不朽", desc: "突破至金仙期", reward: { rep: 40, mat: 30 } },
    { key: "ascend", name: "飞升问道", desc: "金仙圆满，飞升超脱", reward: { rep: 50, mat: 50 } },
    // —— 战斗（5）——
    { key: "battle_first", name: "初战告捷", desc: "首次在历练中取胜", reward: { stone: 200 } },
    { key: "battle_boss", name: "首斩妖王", desc: "首次击败秘境守关 BOSS", reward: { stone: 500, mat: 5 } },
    { key: "battle_ch1", name: "秘境初探", desc: "通关第一章「青云秘境」", reward: { stone: 800 } },
    { key: "battle_ch3", name: "踏遍三境", desc: "通关第三章「昆仑之巅」", reward: { stone: 3000, mat: 20 } },
    { key: "battle_ch5", name: "登临仙墟", desc: "通关第五章「天外仙墟」", reward: { stone: 8000, mat: 30 } },
    { key: "battle_ch7", name: "道场留名", desc: "通关第七章「混元道场」", reward: { stone: 30000, mat: 80 } },
    { key: "battle_50", name: "百战之身", desc: "累计取胜 50 场", reward: { rep: 20 } },
    // —— 经营（4）——
    { key: "build_5", name: "立派之基", desc: "任一建筑升至 Lv5", reward: { mat: 10 } },
    { key: "build_10", name: "洞府大成", desc: "任一建筑升至 Lv10", reward: { mat: 30 } },
    { key: "disciple_5", name: "桃李满门", desc: "门下弟子达 5 名", reward: { rep: 15 } },
    { key: "gongfa_10", name: "功法通玄", desc: "将任意一门功法修至圆满", reward: { rep: 15 } },
    // —— 法宝（5）——
    { key: "art_first", name: "初炼法宝", desc: "炼成首件法宝", reward: { rep: 5 } },
    { key: "art_t4", name: "法器在手", desc: "炼成首件法器阶（4 品）以上法宝", reward: { mat: 10 } },
    { key: "art_t6", name: "仙器在握", desc: "炼成首件仙器（6 品）", reward: { mat: 40 } },
    { key: "art_full", name: "三宝齐身", desc: "本命/护身/辅道三槽全部装备", reward: { rep: 20 } },
    { key: "art_affix", name: "词条初现", desc: "获得首件带词条的法宝", reward: { mat: 10 } },
    // —— 世界（4）——
    { key: "event_first", name: "亲历奇事", desc: "首次处理世界事件", reward: { rep: 5 } },
    { key: "event_six", name: "见多识广", desc: "经历 6 种以上不同的世界事件", reward: { rep: 25 } },
    { key: "rel_50", name: "交好一方", desc: "与任一势力关系达到 50", reward: { rep: 15 } },
    { key: "rep_100", name: "名动一方", desc: "声望达到 100", reward: { mat: 15 } },
    // —— 收集（2）——
    { key: "codex_half", name: "图鉴半成", desc: "法宝图鉴收录过半（≥9 格）", reward: { mat: 20 } },
    { key: "codex_full", name: "图鉴大成", desc: "法宝图鉴全部收录（18 格）", reward: { mat: 60, stone: 5000 } },
    // —— 试炼（3，v0.8.0）——
    { key: "tower_10", name: "初登塔影", desc: "试炼塔通关第 10 层", reward: { rep: 20, mat: 15 } },
    { key: "tower_25", name: "直上高层", desc: "试炼塔通关第 25 层", reward: { rep: 50, mat: 50 } },
    { key: "tower_40", name: "塔巅问道", desc: "试炼塔通关第 40 层", reward: { rep: 100, mat: 100, stone: 20000 } },
    // —— 图鉴补全（2，v0.8.0）——
    { key: "beast_all", name: "妖兽尽录", desc: "妖兽图鉴全部收录", reward: { rep: 40, mat: 40 } },
    { key: "region_all", name: "秘境尽览", desc: "秘境图鉴全部收录", reward: { rep: 40, stone: 8000 } },
    // —— 剧情与见闻（4，v0.11.0）——
    { key: "story_all", name: "五章亲历", desc: "读完五章的全部叙事", reward: { rep: 30, mat: 30 } },
    { key: "battleground_win", name: "古战场拾遗", desc: "在古战场遗迹中有所收获", reward: { mat: 20 } },
    { key: "pillmeet_win", name: "丹道夺魁", desc: "在丹道大会上夺魁", reward: { rep: 30, stone: 3000 } },
    { key: "art_t6_x3", name: "三仙加身", desc: "本命/护身/辅道三槽全为仙器", reward: { mat: 60, rep: 30 } },
    // —— 长线（3，v0.11.0）——
    { key: "disciple_elite", name: "衣钵有传", desc: "培养出一名嫡传弟子（情谊 ≥ 90）", reward: { rep: 25 } },
    { key: "rep_500", name: "名动九州", desc: "声望达到 500", reward: { mat: 40 } },
    { key: "tower_44", name: "塔顶观天", desc: "试炼塔通关第 44 层", reward: { rep: 120, mat: 100 } },
    { key: "tower_54", name: "塔外有天", desc: "试炼塔通关第 54 层", reward: { rep: 200, mat: 200, stone: 50000 } },
    // —— 道心（3，v0.12.0）——
    { key: "story_war", name: "剑心通明", desc: "五章中至少四章选择执剑入世", reward: { rep: 40, stone: 5000 } },
    { key: "story_dao", name: "道心澄澈", desc: "五章中至少四章选择守心问道", reward: { rep: 40, mat: 40 } },
    { key: "story_balance", name: "心剑双修", desc: "五章选完且战道均衡（2~3 章执剑）", reward: { rep: 30, mat: 20 } },
  ],

  // 事件图鉴条目（key 与事件链 chain 对应；secretrealm/mineral 为自动事件）
  CODEX_EVENTS: [
    { key: "invasion",   name: "魔渊入侵" },
    { key: "beasttide",  name: "妖兽潮" },
    { key: "auction",    name: "散修拍卖会" },
    { key: "demonraid",  name: "魔道夺宝" },
    { key: "heartdemon", name: "金丹·心魔劫" },
    { key: "zifu",       name: "元婴·紫府洞天" },
    { key: "huashen",    name: "化神·神识化虚" },
    { key: "lianxu",     name: "炼虚·虚空裂缝" },
    { key: "heti",       name: "合体·道基归一" },
    { key: "dacheng",    name: "大乘·众生愿力" },
    { key: "dujie",      name: "渡劫·九霄雷劫" },
    { key: "secretrealm", name: "秘境开启" },
    { key: "mineral",    name: "灵矿现世" },
    { key: "battleground", name: "古战场遗迹" },
    { key: "pillmeet",   name: "丹道大会" },
  ],

  // ---------- 妖兽图鉴（v0.8.0）----------
  // chapter：击杀该章末关 BOSS 收录；tower：试炼塔该层守关收录
  CODEX_BEASTS: [
    { key: "wolf",     name: "赤目狼王",   chapter: 0 },
    { key: "spider",   name: "噬魂蛛后",   chapter: 1 },
    { key: "ape",      name: "玄冰巨猿",   chapter: 2 },
    { key: "dragon",   name: "幽冥蛟龙",   chapter: 3 },
    { key: "voidbeast", name: "虚空吞天兽", chapter: 4 },
    { key: "tower_stone", name: "镇塔石灵", tower: 10 },
    { key: "tower_sword", name: "塔中剑魂", tower: 25 },
    { key: "tower_lord",  name: "塔主·无相", tower: 40 },
    { key: "starbeast",   name: "星骸巨兽",   chapter: 5 },
    { key: "chaoslord",   name: "混元守道人", chapter: 6 },
  ],

  // ---------- 秘境图鉴（v0.8.0）----------
  // 通关该章末关 BOSS 时收录
  CODEX_REGIONS: [
    { key: "region_ch0", name: "青云秘境", chapter: 0 },
    { key: "region_ch1", name: "幽谷魔渊", chapter: 1 },
    { key: "region_ch2", name: "昆仑之巅", chapter: 2 },
    { key: "region_ch3", name: "九幽冥海", chapter: 3 },
    { key: "region_ch4", name: "天外仙墟", chapter: 4 },
    { key: "region_ch5", name: "星陨古域", chapter: 5 },
    { key: "region_ch6", name: "混元道场", chapter: 6 },
  ],

  // ---------- 储物法器与物品（v0.37.0）----------
  // 修仙设定：储物袋/储物戒按炼制材质分品级，内部空间（格数）与单格堆叠上限各不相同
  INV: {
    CONTAINERS: [
      { key: "cloth", name: "布囊",       grade: "凡品", slots: 12, stack: 500,   price: 0,         realm: 0, desc: "凡俗绢布缝制，只装得下随身杂物" },
      { key: "bag1",  name: "下品储物袋", grade: "下品", slots: 18, stack: 1000,  price: 800,       realm: 1, desc: "粗麻绣符，内藏一丈见方" },
      { key: "bag2",  name: "中品储物袋", grade: "中品", slots: 24, stack: 2000,  price: 6000,      realm: 2, desc: "蚕丝织纹配聚灵符，三丈空间" },
      { key: "bag3",  name: "上品储物袋", grade: "上品", slots: 30, stack: 4000,  price: 30000,     realm: 3, desc: "鲛绡为面、储物阵为里，十丈空间" },
      { key: "ring1", name: "精铁储物戒", grade: "灵器", slots: 40, stack: 8000,  price: 150000,    realm: 4, desc: "精铁锻纹嵌储物符，随指而动" },
      { key: "ring2", name: "灵玉储物戒", grade: "灵器", slots: 50, stack: 16000, price: 600000,    realm: 5, desc: "灵玉为骨，内成小洞天" },
      { key: "ring3", name: "紫金储物戒", grade: "宝器", slots: 64, stack: 32000, price: 2400000,   realm: 6, desc: "紫金掺星砂，空间自愈不崩" },
      { key: "kun",   name: "乾坤袋",    grade: "灵宝", slots: 80, stack: 99999, price: 9000000,   realm: 7, desc: "袖里乾坤，纳须弥于芥子" },
    ],
    OVERFLOW_SELL: 0.6,   // 袋满时散卖折算（按售价 60%）
    NOTICE_CD: 20000,     // 袋满提示节流（毫秒）
    MAX_STACK_SALE: 1,    // 出售/丢弃按整数处理
  },
  ITEMS: {
    herb:     { key: "herb",     name: "灵草",     cat: "material", stack: 9999, price: 3,   icon: "assets/图标_灵草.webp",     desc: "炼丹主料，炼丹房自动消耗" },
    material: { key: "material", name: "灵材",     cat: "material", stack: 9999, price: 8,   icon: "assets/图标_灵材.webp",     desc: "炼制法宝与古宝注灵之料" },
    talisman: { key: "talisman", name: "功法残卷", cat: "book",     stack: 99,  price: 200, icon: "assets/图标_功法要诀.webp", desc: "残缺经卷：3 卷可在功法页参悟，随机得一本未习秘籍" },
    // ---------- 丹药（v0.38.0 丹方物品化，各有效果）----------
    pill:      { key: "pill",      name: "培元丹", cat: "pill", stack: 999, price: 20,  icon: "assets/图标_丹药.webp", char: "元", desc: "基础丹方：炼化药力 +1 层，每层 +2% 修炼" },
    qiPill:    { key: "qiPill",    name: "聚气丹", cat: "pill", stack: 999, price: 60,  icon: "assets/图标_丹药.webp", char: "气", desc: "服下立得当前境界突破所需灵气的 5%" },
    breakPill: { key: "breakPill", name: "破境丹", cat: "pill", stack: 99,  price: 260, icon: "assets/图标_丹药.webp", char: "破", desc: "下次渡劫成功率 +10%（与渡劫丹叠加）" },
    healPill:  { key: "healPill",  name: "回春丹", cat: "pill", stack: 99,  price: 120, icon: "assets/图标_丹药.webp", char: "春", desc: "服下后下次入秘境自带 30% 气血护盾" },
    marrowPill:{ key: "marrowPill",name: "洗髓丹", cat: "pill", stack: 49,  price: 500, icon: "assets/图标_丹药.webp", char: "髓", desc: "法宝洗练免灵石 1 次（词条照常刷新）" },
    daoPill:   { key: "daoPill",   name: "悟道丹", cat: "pill", stack: 49,  price: 500, icon: "assets/图标_丹药.webp", char: "道", desc: "功法升一层的悟道消耗 -30%（1 次）" },
    incense:   { key: "incense",   name: "引魔香", cat: "consumable", stack: 99, price: 0, char: "香", desc: "燃香闭关：下一次离线结算上限提升至 13 小时，秘境驻守离线产出提高 50%。" },
    tribPill:  { key: "tribPill",  name: "渡劫丹", cat: "pill", stack: 99,  price: 300, char: "劫",                        desc: "下次渡劫成功率 +15%，可叠加" },
  },
  ITEM_CATS: [
    { key: "all",      name: "全部" },
    { key: "consumable", name: "消耗品" },
    { key: "material", name: "材料" },
    { key: "pill",     name: "丹药" },
    { key: "book",     name: "秘籍" },
    { key: "gear",     name: "装备" },
    { key: "seed",     name: "种子" },
    { key: "frag",     name: "碎片" },
  ],
  // ---------- 丹方与秘籍发放（v0.38.0）----------
  PILLS: {
    QI_PILL: 0.05,        // 聚气丹：突破所需灵气 5%
    BREAK_PILL: 0.10,     // 破境丹：渡劫 +10%
    HEAL_SHIELD: 0.30,    // 回春丹：秘境气血护盾 30%
    MARROW_STONE_SAVE: 1, // 洗髓丹：洗练免费 1 次
    DAO_WUDAO_CUT: 0.30,  // 悟道丹：功法悟道消耗 -30%
    DAO_STONE_CUT: 0.30, // 旧版本兼容别名；新逻辑不再扣灵石
    ALCHEMY_EXTRA: 0.12,  // 炼丹房每次产丹额外产出稀有丹的概率（按等级提升）
    REFINE_TALISMAN: 3,   // 参悟残卷：3 卷换 1 本随机未习秘籍
  },
  // 章节 → 可掉落秘籍阶数上限（越高章节越可能出高阶秘籍）
  BOOK_DROP_TIER: [1, 2, 3, 4, 5, 6, 7],
  // ---------- 新手引路（v0.47.0）----------
  // 七步引路：把已有系统按「先做什么」串成一条线，每步都有实物奖励
  GUIDE: [
    { key: "g1", name: "吐纳养气", desc: "在修炼页按住「吐纳」读完一次读条", reward: { stone: 300, qiPct: 0.2 },
      hint: "吐纳是一天里最划算的事，先做一次", tab: "home" },
    { key: "g2", name: "开辟灵田", desc: "在洞府建造或升级灵田至少一级", reward: { stone: 500 },
      hint: "灵田产灵草，是炼丹与炼器的根", tab: "build" },
    { key: "g3", name: "初入秘境", desc: "进入秘境打赢任意一关", reward: { pill: 5, talisman: 1 },
      hint: "秘境是资源与秘籍的主要来源", tab: "battle" },
    { key: "g4", name: "再悟一法", desc: "领悟第二部功法（需对应秘籍）", reward: { stone: 800 },
      hint: "秘籍来自秘境 BOSS，也可用残卷参悟", tab: "char" },
    { key: "g5", name: "开炉炼丹", desc: "在丹房开炉并收取一次丹药", reward: { qiPct: 0.5 },
      hint: "需要炼丹房，成功后记得收丹", tab: "build" },
    { key: "g6", name: "亲手炼器", desc: "炼制出第一件法宝", reward: { material: 30 },
      hint: "炼器坊需金丹期，灵材来自秘境与分解", tab: "build" },
    { key: "g7", name: "结识仙友", desc: "结识第一位仙友并完成一次交游", reward: { fate: 3 },
      hint: "仙友会传功、赠礼，好感满可结道侣", tab: "build" },
  ],

  // ---------- 法宝套装（v0.41.0）----------
  // 同源法器成套炼制，集齐 2 件/3 件触发套装词条；套装由炼制时的器韵决定
  ARTIFACT_SETS: [
    { key: "qingyun_gear", name: "青云剑匣", from: 2, to: 3, rate: 0.40,
      bonus2: { atk: 0.04 }, bonus3: { atk: 0.06, cult: 0.05 },
      desc: "青云门制式三宝，剑匣相合可引山林灵气" },
    { key: "moyuan_gear", name: "魔渊血器", from: 4, to: 5, rate: 0.35,
      bonus2: { atk: 0.05 }, bonus3: { atk: 0.08, hp: 0.05 },
      desc: "魔渊祭炼之器，血气相连，愈战愈凶" },
    { key: "hunyuan_gear", name: "混元道器", from: 6, to: 9, rate: 0.30,
      bonus2: { def: 0.05 }, bonus3: { def: 0.08, cult: 0.06 },
      desc: "混元道场遗器，刚柔并济，道法自然" },
  ],

  // ---------- 丹方配伍（v0.39.0：主动炼丹）----------
  // 灵田/炼丹房自动产出基础培元丹；主动开炉可按古方炼出高阶丹药，成败由丹道修为与炉火决定
  DAN: {
    BASE_RATE: 0.55,       // 基础成功率
    LV_BONUS: 0.05,        // 炼丹房每级 +5%
    MAX_RATE: 0.95,        // 成功率上限（天妒，不可必成）
    CRIT_RATE: 0.15,       // 上品丹成（产量 ×2）
    FAIL_REFUND: 0.5,      // 失败返还半数材料
    CRIT_MULT: 2,
    // 加料档位（v0.42.0）：多下料提纯度，成功率与上品率上升、材料成倍消耗
    MULTS: [
      { mult: 1, name: "标准", rate: 0.00, crit: 0.00, desc: "按古方原配投料" },
      { mult: 2, name: "双料", rate: 0.10, crit: 0.06, desc: "灵草灵材加倍，提纯增稳" },
      { mult: 3, name: "精料", rate: 0.16, crit: 0.12, desc: "三倍投料，丹成上品之望大增" },
    ],
    SLOT_PER_LEVEL: 3,   // 每 3 级炉火多开一炉位（上限 3）
    RECIPES: [
      { key: "recipe_pill",      out: "pill",       n: 5, herb: 25,  material: 0,  sec: 45,  realm: 0, alchemy: 1, base: 0.78, name: "培元丹方",  desc: "最基础的固本丹方，可练手" },
      { key: "recipe_qi",        out: "qiPill",     n: 2, herb: 20,  material: 0,  sec: 60,  realm: 1, alchemy: 1, base: 0.62, name: "聚气丹方",  desc: "引灵入丹，服之直补突破所需灵气" },
      { key: "recipe_heal",      out: "healPill",   n: 2, herb: 30,  material: 2,  sec: 120, realm: 1, alchemy: 2, base: 0.58, name: "回春丹方",  desc: "草木回春，入秘境前必备" },
      { key: "recipe_trib",      out: "tribPill",   n: 1, herb: 80,  material: 10, sec: 300, realm: 3, alchemy: 4, base: 0.45, name: "渡劫丹方",  desc: "雷劫之前服之，可增一线生机" },
      { key: "recipe_break",     out: "breakPill",  n: 1, herb: 60,  material: 8,  sec: 240, realm: 3, alchemy: 4, base: 0.48, name: "破境丹方",  desc: "破开境界桎梏之丹" },
      { key: "recipe_marrow",    out: "marrowPill", n: 1, herb: 80,  material: 12, sec: 300, realm: 4, alchemy: 5, base: 0.42, name: "洗髓丹方",  desc: "洗髓伐骨，法宝洗练可免灵石" },
      { key: "recipe_dao",       out: "daoPill",    n: 1, herb: 100, material: 15, sec: 360, realm: 5, alchemy: 6, base: 0.40, spc: { ch: 6, n: 3 }, name: "悟道丹方",  desc: "以草木之理入丹，需混元露引药，助人参悟功法" },
      { key: "recipe_marrow_top",out: "marrowPill", n: 2, herb: 140, material: 20, sec: 420, realm: 6, alchemy: 7, base: 0.36, spc: { ch: 5, n: 5 }, name: "洗髓丹方·精", desc: "以星陨石提纯古方，一炉双丹" },
    ],
  },
};

// 全局层序号 k = realm*9 + layer
function globalLayer(realmIdx, layerIdx) {
  return realmIdx * CONFIG.LAYERS_PER_REALM + layerIdx;
}
