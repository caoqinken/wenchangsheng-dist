// ============================================================
// 《问长生》日常与周常 + 机缘 + 天机阁（v0.29.0）
// 目的：把「每天上线做什么」说清楚，并给硬通货「机缘」一个出口
// ============================================================

// ---------- 周期键 ----------
function weekKeyOf() {
  const t = S.gameTime || { year: 1, month: 1, day: 1 };
  const totalDay = (t.year - 1) * 360 + (t.month - 1) * 30 + t.day;
  return "W" + Math.floor((totalDay - 1) / 7);
}

function ensureDaily() {
  const k = gameDayKey();
  if (!S.daily || S.daily.date !== k) S.daily = { date: k, tasks: {}, claimed: {} };
  if (!S.daily.claimed) S.daily.claimed = {};
  return S.daily;
}

function ensureWeekly() {
  const k = weekKeyOf();
  if (!S.weekly || S.weekly.week !== k) S.weekly = { week: k, tasks: {}, claimed: {} };
  if (!S.weekly.claimed) S.weekly.claimed = {};
  return S.weekly;
}

// ---------- 进度 ----------
function dailyProgress(key, amount) {
  ensureDaily();
  S.daily.tasks[key] = (S.daily.tasks[key] || 0) + (amount || 1);
}

function weeklyProgress(key, amount) {
  ensureWeekly();
  S.weekly.tasks[key] = (S.weekly.tasks[key] || 0) + (amount || 1);
}

function dailyState() {
  const d = ensureDaily();
  return CONFIG.DAILY_TASKS.map(t => ({
    ...t,
    cur: d.tasks[t.key] || 0,
    claimed: !!d.claimed[t.key],
    done: (d.tasks[t.key] || 0) >= t.need,
  }));
}

function weeklyState() {
  const w = ensureWeekly();
  return CONFIG.WEEKLY_TASKS.map(t => ({
    ...t,
    cur: w.tasks[t.key] || 0,
    claimed: !!w.claimed[t.key],
    done: (w.tasks[t.key] || 0) >= t.need,
  }));
}

// ---------- 领取 ----------
function claimTask(kind, key) {
  const isDaily = kind === "daily";
  const defs = isDaily ? CONFIG.DAILY_TASKS : CONFIG.WEEKLY_TASKS;
  const box = isDaily ? ensureDaily() : ensureWeekly();
  const def = defs.find(t => t.key === key);
  if (!def) return { ok: false, msg: "无此任务" };
  if ((box.tasks[key] || 0) < def.need) return { ok: false, msg: "尚未完成" };
  if (box.claimed[key]) return { ok: false, msg: "已领取" };
  box.claimed[key] = true;
  S.fate = (S.fate || 0) + def.fate;
  save();
  return { ok: true, fate: def.fate, name: def.name };
}

// ---------- 天机阁（机缘出口）----------
function fateFuQi() {
  const cost = CONFIG.FATE.FU_QI_COST;
  if ((S.fate || 0) < cost) return { ok: false, msg: "机缘不足" };
  S.fate -= cost;
  const gain = CONFIG.breakCost(kNow()) * CONFIG.FATE.FU_QI_RATE;
  S.qi += gain;
  save();
  return { ok: true, gain, cost };
}

function fateIncense() {
  const cost = CONFIG.FATE.INCENSE_COST;
  if ((S.fate || 0) < cost) return { ok: false, msg: "机缘不足" };
  if (S.huntingIncense) return { ok: false, msg: "已有引魔香加持，先完成一次离线结算" };
  const room = invRoomFor("incense");
  if (room < 1) return { ok: false, msg: "储物袋空间不足" };
  S.fate -= cost;
  gainItem("incense", 1);
  save();
  return { ok: true, cost };
}

function fateTalisman() {
  const cost = CONFIG.FATE.TALISMAN_COST;
  if ((S.fate || 0) < cost) return { ok: false, msg: "机缘不足" };
  S.fate -= cost;
  gainItem("talisman", 1);
  save();
  return { ok: true, cost };
}

// ---------- 界面 ----------
function dailyListHtml(list, kind) {
  return list.map(t => {
    const btn = t.claimed
      ? `<span class="muted">已领取</span>`
      : t.done
        ? `<button class="btn-sm" data-action="claimtask" data-kind="${kind}" data-key="${t.key}">领取 +${t.fate}机缘</button>`
        : `<span class="muted">${t.cur}/${t.need}</span>`;
    return `<div class="shop-item">
      <span>${esc(t.name)} <span class="muted">（${t.cur}/${t.need}）</span></span>
      <span>${btn}</span>
    </div>`;
  }).join("");
}

function showDailyPanel() {
  const dl = dailyState(), wl = weeklyState();
  showModal(`
    <div class="result">
      <div class="result-title">日常 · 机缘 ${S.fate || 0}</div>
      <div class="result-line muted-line">${S.huntingIncense ? "引魔香已点燃：下次离线最多结算 13 小时" : "引魔香未点燃"}</div>
      <div class="sec-title small">每日任务（随游戏日重置）</div>
      <div class="shop-list">${dailyListHtml(dl, "daily")}</div>
      <div class="sec-title small">周常任务（每 7 日重置）</div>
      <div class="shop-list">${dailyListHtml(wl, "weekly")}</div>
      <div class="sec-title small">天机阁（机缘兑换）</div>
      <div class="shop-list">
        <div class="shop-item"><span>修为福袋（当前突破的 ${Math.round(CONFIG.FATE.FU_QI_RATE * 100)}%）</span>
          <button class="btn-sm" data-action="fatefuqi">${CONFIG.FATE.FU_QI_COST} 机缘</button></div>
        <div class="shop-item"><span>功法残卷 ×1</span>
          <button class="btn-sm" data-action="fatetalisman">${CONFIG.FATE.TALISMAN_COST} 机缘</button></div>
        <div class="shop-item"><span>引魔香 ×1（下次离线上限 13h，驻守产出 +50%）</span>
          <button class="btn-sm" data-action="fateincense" ${S.huntingIncense ? "disabled" : ""}>${CONFIG.FATE.INCENSE_COST} 机缘</button></div>
      </div>
      <div class="tip">机缘来源：日常/周常任务、首次探明秘境、世界事件。只用于加速与领悟，不卖数值。</div>
      <button class="btn-primary" data-action="closemodal">收起</button>
    </div>`);
}

// 可领取数量（入口红点用）
function claimableCount() {
  const d = dailyState().filter(t => t.done && !t.claimed).length;
  const w = weeklyState().filter(t => t.done && !t.claimed).length;
  return d + w;
}
