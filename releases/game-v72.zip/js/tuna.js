// ============================================================
// 《问长生》吐纳（v0.29.0）
// 每日 100 次：长按进度条，落点越靠后越可能暴击（2~10 倍）
// 前 5 次额外给功法要诀，首日即可领悟第二部功法
// ============================================================

function gameDayKey() {
  const t = S.gameTime || { year: 1, month: 1, day: 1 };
  return t.year + "-" + t.month + "-" + t.day;
}

// 跨日重置吐纳次数
function tunaDailyReset() {
  const k = gameDayKey();
  if (S.tunaDate !== k) {
    S.tunaDate = k;
    S.tunaLeft = CONFIG.TUNA.DAILY;
    S.tunaCount = 0;
  }
}

function tunaLeftToday() {
  tunaDailyReset();
  return S.tunaLeft;
}

// 执行一次吐纳：holdRatio 为松手时的进度（0~1）
function tunaPerform(holdRatio) {
  tunaDailyReset();
  if (S.tunaLeft <= 0) return { ok: false, msg: "今日吐纳已尽，明日再来" };
  const T = CONFIG.TUNA;
  const cost = CONFIG.breakCost(kNow());
  let gain = cost * (T.BASE_QI / 100);          // 基础：当前突破所需的 0.6%
  let crit = 1;
  const r = Math.max(0, Math.min(1, Number(holdRatio) || 0));
  if (r >= 0.9) {
    const chance = Math.min(1, T.CRIT_CHANCE + (r - 0.9) * 3);   // 90%→35%，100%→65%
    if (Math.random() < chance) {
      crit = T.CRIT_MIN + Math.floor(Math.random() * (T.CRIT_MAX - T.CRIT_MIN + 1));
    }
  }
  gain *= crit;
  S.qi += gain;
  S.tunaLeft -= 1;
  S.tunaCount = (S.tunaCount || 0) + 1;
  let talisman = 0;
  if (S.tunaCount <= 5) {
    talisman = T.FIRST5_TALISMAN;
    gainItem("talisman", talisman);
  }
  if (typeof dailyProgress === "function") dailyProgress("tuna5", 1);
  save();
  return { ok: true, gain, crit, talisman, left: S.tunaLeft };
}

// ---------- 吐纳界面 ----------
function showTunaModal() {
  tunaDailyReset();
  const left = S.tunaLeft;
  showModal(`
    <div class="tuna-box">
      <div class="result-title">吐纳</div>
      <div class="result-line">今日剩余 <b id="tuna-left">${left}</b>/${CONFIG.TUNA.DAILY} 次 ｜ 松手时机越靠后，越易暴击（2~10 倍）</div>
      <div class="tuna-track" id="tuna-track">
        <div class="tuna-fill" id="tuna-fill"></div>
        <div class="tuna-crit-zone"></div>
      </div>
      <div class="tuna-hint" id="tuna-hint">按住下方按钮蓄气，将满时松手</div>
      <div class="tuna-result" id="tuna-result"></div>
      <button class="btn-primary big" id="tuna-hold" ${left > 0 ? "" : "disabled"}>按住吐纳</button>
      <div class="result-line muted-line">前 5 次额外获得功法要诀 · 次数随游戏日重置</div>
      <button class="btn-sm" data-action="closemodal">收起</button>
    </div>`);
  bindTunaHold();
}

function bindTunaHold() {
  const btn = el("tuna-hold");
  const fill = el("tuna-fill");
  const hint = el("tuna-hint");
  const res = el("tuna-result");
  if (!btn || !fill) return;
  // 测试/无 DOM 环境防护：stub 元素没有事件方法
  if (typeof btn.addEventListener !== "function") return;
  let raf = null, start = 0, active = false;
  const DURATION = 1600;   // 蓄满所需毫秒
  const stop = () => {
    if (raf) { cancelAnimationFrame(raf); raf = null; }
  };
  const tick = () => {
    const ratio = Math.min(1, (Date.now() - start) / DURATION);
    fill.style.width = (ratio * 100) + "%";
    if (ratio >= 1 && hint) hint.textContent = "气机已满 · 此刻松手最易暴击";
    raf = requestAnimationFrame(tick);
  };
  const finish = () => {
    // 防重复结算：pointerup 与 window 兜底只生效一次
    if (!active) return;
    active = false;
    const ratio = Math.min(1, (Date.now() - start) / DURATION);
    stop();
    if (typeof window !== "undefined" && window.removeEventListener) {
      window.removeEventListener("pointerup", onWinUp);
      window.removeEventListener("pointercancel", onWinCancel);
    }
    const r = tunaPerform(ratio);
    if (!r.ok) {
      if (res) res.textContent = r.msg;
      if (hint) hint.textContent = r.msg;
      return;
    }
    const txt = r.crit > 1
      ? `暴击 ×${r.crit}！灵气 +${fmt(r.gain)}`
      : `灵气 +${fmt(r.gain)}（松手 ${Math.round(ratio * 100)}%）`;
    // 弹窗内结果直接可见（toast 可能被弹窗遮挡）
    if (res) res.textContent = txt + (r.talisman ? ` ｜ 功法要诀 +${r.talisman}` : "");
    if (typeof toast === "function") toast(txt + (r.talisman ? ` ｜ 功法要诀 +${r.talisman}` : ""));
    const l = el("tuna-left");
    if (l) l.textContent = r.left;
    if (fill) fill.style.width = "0%";
    if (hint) hint.textContent = r.left > 0 ? "继续吐纳（按住蓄气）" : "今日吐纳已尽";
    if (r.left <= 0) btn.disabled = true;
  };
  const onWinUp = () => finish();
  const onWinCancel = () => finish();   // 手势被系统打断也按当前进度结算，避免"松手无反应"
  btn.addEventListener("pointerdown", ev => {
    ev.preventDefault();
    if (btn.disabled || active) return;
    active = true;
    start = Date.now();
    if (hint) hint.textContent = "蓄气中…";
    if (res) res.textContent = "";
    // 指针捕获：手指滑出按钮时仍能收到 pointerup
    try { if (btn.setPointerCapture && ev.pointerId !== undefined) btn.setPointerCapture(ev.pointerId); } catch (e) {}
    if (typeof window !== "undefined" && window.addEventListener) {
      window.addEventListener("pointerup", onWinUp);
      window.addEventListener("pointercancel", onWinCancel);
    }
    tick();
  });
  btn.addEventListener("pointerup", ev => { ev.preventDefault(); finish(); });
  btn.addEventListener("pointercancel", () => finish());
}
