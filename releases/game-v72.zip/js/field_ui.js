// ============================================================
// 《问长生》秘境战场操作层（v0.16.0）
// 摇杆/键盘移动 + 技能盘定向释放 + HUD + 结算
// ============================================================

const FS = {
  el: null,
  field: null,
  raf: 0,
  last: 0,
  ended: false,

  keys: {},
  joy: { active: false, id: null, cx: 0, cy: 0, dx: 0, dy: 0 },
  dashPulse: false,

  aimWorld: null,     // 鼠标/指针指向的世界坐标
  aimDir: { x: 0, y: -1 },   // 当前瞄准方向（世界坐标，供扇形指示使用）
  dragging: null,     // 正在拖拽定向的技能 key
  dragId: null,       // 拖拽手指的 pointerId（多点触控隔离）
  dragOrigin: null,   // 技能按钮中心（方向轮盘原点）
  dragDir: null,      // 拖拽得出的方向；null = 未拖动


  autoSkill: false,
  skillTimer: 0,
  bossMax: 0,
};

// ---------- 入口 ----------
function startFieldBattle(chapter) {
  if (FS.el) fsClose(false);   // 清掉上次残留，避免异常退出后无法再进秘境
  // 章节解锁校验（v0.24.0）：与秘境列表共用同一判定，未解锁拒绝且不扣体力
  if (!fldChapterUnlocked(chapter)) { toast("该秘境尚未解锁 · 先通关上一章末关"); return; }
  if (S.stamina < 1) { toast("体力不足，请稍候恢复"); return; }
  S.stamina--;
  if (typeof dailyProgress === "function") dailyProgress("field1", 1);
  if (typeof sectTaskProgress === "function") sectTaskProgress("enter", 1);
  save();

  const field = fldCreate(chapter);
  FS.field = field;
  FS.ended = false;
  FS.autoSkill = false;
  FS.aimWorld = null;
  FS.dragging = null;
  FS.dragId = null;
  FS.dragOrigin = null;
  FS.dragDir = null;
  FS.aimDir = { x: 0, y: -1 };
  FS.joy = { active: false, id: null, cx: 0, cy: 0, dx: 0, dy: 0 };
  FS.bossMax = field.monsters.filter(m => m.kind === "boss").length;

  // 兜底清理：DOM 里若残留旧的战场层（异常退出、热重载），
  // 会出现两个同 id 节点，querySelector 可能拿到旧 canvas，新画布永远不绘制
  for (const old of document.querySelectorAll("#field-screen")) {
    if (old.parentNode) old.parentNode.removeChild(old);
  }

  const el = document.createElement("div");
  el.id = "field-screen";
  el.innerHTML = `
    <div class="fs-top">
      <span class="fs-name">${esc(field.map.name)}</span>
      <span class="fs-count"></span>
      <button class="fs-exit" data-fs="exit">✕</button>
    </div>

    <canvas id="fs-canvas"></canvas>

    <div class="fs-hud">
      <div class="fs-bar hp"><i class="fs-hpfill"></i><b class="fs-hptext"></b></div>
      <div class="fs-bar mana"><i class="fs-manafill"></i></div>
      <div class="fs-explore"><i></i><b></b></div>
    </div>

    <div class="fs-joy"><div class="fs-joy-knob"></div></div>

    <div class="fs-actions">
      <button class="fs-btn fs-dash" data-fs="dash">遁速</button>
      <button class="fs-btn fs-auto" data-fs="auto">自动</button>
    </div>

    <div class="fs-skills"></div>
  `;
  document.body.appendChild(el);
  FS.el = el;

  const canvas = el.querySelector("#fs-canvas");
  flvInit(canvas, field);
  requestAnimationFrame(() => flvResize());

  fsRenderSkills();
  fsBindEvents();

  window.addEventListener("resize", flvResize);
  window.addEventListener("keydown", fsKeyDown);
  window.addEventListener("keyup", fsKeyUp);

  FS.last = performance.now();
  FS.raf = requestAnimationFrame(fsLoop);
}

// ---------- 技能盘 ----------
function fsRenderSkills() {
  const box = FS.el.querySelector(".fs-skills");
  const slots = FS.field.slots;
  if (!slots.length) {
    box.innerHTML = `<div class="fs-noskill">尚未习得神通</div>`;
    return;
  }
  box.innerHTML = slots.map(k => {
    const s = fldSkill(k);
    const lk = (CONFIG.SKILL_LOCKS || []).find(x => x.key === s.lock) || { name: "群", color: "#B08A3E" };
    const elDef = (s.element && typeof elementDef === "function") ? elementDef(s.element) : null;
    const chain = (s.element && FS.field && FS.field.lastElem && typeof elementGenerates === "function"
      && elementGenerates(FS.field.lastElem, s.element)) ? " gen" : "";
    return `<button class="fs-skill tier-${s.tier}${chain}" data-skill="${k}">
      <span class="fs-skill-lock" style="background:${lk.color}">${esc(lk.name)}</span>
      <span class="fs-skill-name">${esc(s.name)}${elDef ? `<i class="fs-elem" style="color:${elDef.color}">${esc(elDef.name)}</i>` : ""}</span>
      <span class="fs-skill-cd"></span>
    </button>`;
  }).join("");
}

// ---------- 事件绑定 ----------
function fsBindEvents() {
  const el = FS.el;
  const canvas = el.querySelector("#fs-canvas");

  // —— 普通按钮 ——
  el.addEventListener("click", ev => {
    const b = ev.target.closest("[data-fs]");
    if (!b) return;
    const a = b.dataset.fs;
    if (a === "exit") fsClose(true);
    else if (a === "dash") FS.dashPulse = true;
    else if (a === "auto") {
      FS.autoSkill = !FS.autoSkill;
      b.classList.toggle("on", FS.autoSkill);
      toast(FS.autoSkill ? "已开启自动神通" : "已关闭自动神通");
    }
  });

  // —— 技能：按住不放 → 以按钮中心为原点拖出方向 → 松手释放 ——
  const skills = el.querySelector(".fs-skills");
  skills.addEventListener("pointerdown", ev => {
    const btn = ev.target.closest("[data-skill]");
    if (!btn) return;
    ev.preventDefault();
    const r = btn.getBoundingClientRect();
    FS.dragging = btn.dataset.skill;
    FS.dragId = ev.pointerId;
    FS.dragOrigin = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    FS.dragDir = null;
    btn.classList.add("aiming");
  });

  // —— 摇杆 ——
  const joy = el.querySelector(".fs-joy");
  joy.addEventListener("pointerdown", ev => {
    ev.preventDefault();
    const r = joy.getBoundingClientRect();
    FS.joy.active = true;
    FS.joy.id = ev.pointerId;
    FS.joy.cx = r.left + r.width / 2;
    FS.joy.cy = r.top + r.height / 2;
    fsJoyMove(ev.clientX, ev.clientY);
  });

  // —— 全局指针事件：按 pointerId 分流，摇杆与技能互不干扰 ——
  fsBindGlobalPointers();

  // —— 鼠标指向（桌面）：鼠标位置即瞄准方向 ——
  canvas.addEventListener("pointermove", ev => {
    const r = canvas.getBoundingClientRect();
    FS.aimWorld = flvToWorld(ev.clientX - r.left, ev.clientY - r.top);
  });
}

// —— 全局指针事件（具名函数，便于关闭秘境时解绑）——
// 用匿名函数绑定会导致二次进图重复累积监听：一次操作触发 N 次，技能重复释放
function fsBindGlobalPointers() {
  window.addEventListener("pointermove", fsWinPointerMove);
  window.addEventListener("pointerup", fsWinPointerUp);
  window.addEventListener("pointercancel", fsWinPointerCancel);
}

function fsUnbindGlobalPointers() {
  window.removeEventListener("pointermove", fsWinPointerMove);
  window.removeEventListener("pointerup", fsWinPointerUp);
  window.removeEventListener("pointercancel", fsWinPointerCancel);
}

function fsWinPointerMove(ev) {
  // 技能定向
  if (FS.dragging && ev.pointerId === FS.dragId && FS.dragOrigin) {
    const dx = ev.clientX - FS.dragOrigin.x;
    const dy = ev.clientY - FS.dragOrigin.y;
    if (Math.hypot(dx, dy) > 5) {
      FS.dragDir = fsScreenDirToWorld(dx, dy);
      FS.aimDir = FS.dragDir;
    }
  }
  // 摇杆
  if (FS.joy.active && ev.pointerId === FS.joy.id) {
    fsJoyMove(ev.clientX, ev.clientY);
  }
}

function fsWinPointerUp(ev) {
  if (FS.dragging && ev.pointerId === FS.dragId) fsReleaseSkill();
  if (FS.joy.active && ev.pointerId === FS.joy.id) {
    FS.joy.active = false;
    FS.joy.id = null;
    FS.joy.dx = 0;
    FS.joy.dy = 0;
    const knob = FS.el && FS.el.querySelector(".fs-joy-knob");
    if (knob) knob.style.transform = "translate(-50%,-50%)";
  }
}

function fsWinPointerCancel(ev) {
  if (FS.dragging && ev.pointerId === FS.dragId) {
    FS.dragging = null;
    FS.dragId = null;
    if (FS.el) for (const b of FS.el.querySelectorAll(".fs-skill")) b.classList.remove("aiming");
  }
  if (FS.joy.active && ev.pointerId === FS.joy.id) {
    FS.joy.active = false;
    FS.joy.dx = 0;
    FS.joy.dy = 0;
  }
}

function fsJoyMove(x, y) {
  const max = 46;
  let dx = x - FS.joy.cx;
  let dy = y - FS.joy.cy;
  const d = Math.hypot(dx, dy);
  if (d > max) { dx = dx / d * max; dy = dy / d * max; }
  FS.joy.dx = dx / max;
  FS.joy.dy = dy / max;
  const knob = FS.el.querySelector(".fs-joy-knob");
  if (knob) knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
}

// ---------- 瞄准与释放 ----------
// 方向指示由渲染层按 FS.aimDir 每帧绘制扇形，这里不再单独处理
function fsShowAim() {}

function fsGetAimDir() {
  // 1) 拖拽拖动过 → 用拖动方向（用户主动控制）
  if (FS.dragDir) return FS.dragDir;
  // 2) 桌面鼠标指向
  if (FS.aimWorld && FS.field) {
    const p = FS.field.player;
    const dx = FS.aimWorld.x - p.x;
    const dy = FS.aimWorld.y - p.y;
    if (Math.hypot(dx, dy) > 20) return fldNorm(dx, dy);
  }
  // 3) 摇杆方向（跑向哪就朝哪打）
  if (FS.joy.active && (FS.joy.dx || FS.joy.dy)) {
    return fsScreenDirToWorld(FS.joy.dx * 300, FS.joy.dy * 300);
  }
  // 4) 自动瞄准最近目标，最差回退当前朝向
  if (FS.field) {
    const near = fldNearest(FS.field, FS.field.player.x, FS.field.player.y, 460);
    if (near) return fldNorm(near.x - FS.field.player.x, near.y - FS.field.player.y);
    const p = FS.field.player;
    return { x: Math.cos(p.facing), y: Math.sin(p.facing) };
  }
  return { x: 0, y: -1 };
}

function fsReleaseSkill() {
  const key = FS.dragging;
  FS.dragging = null;
  FS.dragId = null;
  FS.dragOrigin = null;
  const btns = FS.el.querySelectorAll(".fs-skill");
  for (const b of btns) b.classList.remove("aiming");

  const d = fsGetAimDir();
  FS.dragDir = null;
  const r = fldCast(FS.field, key, d.x, d.y);
  if (!r.ok) { toast(r.msg); return; }
  fsTickEvents();
}

// ---------- 键盘 ----------
function fsKeyDown(ev) {
  const k = ev.key.toLowerCase();
  if (["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright", " "].indexOf(k) >= 0) {
    ev.preventDefault();
  }
  FS.keys[k] = true;
  if (k === " ") FS.dashPulse = true;
  // 数字键放技能
  if (/^[1-6]$/.test(k)) {
    const idx = parseInt(k, 10) - 1;
    const key = FS.field.slots[idx];
    if (key) {
      const d = fsGetAimDir();
      const r = fldCast(FS.field, key, d.x, d.y);
      if (!r.ok) toast(r.msg);
      else fsTickEvents();
    }
  }
}
function fsKeyUp(ev) { FS.keys[ev.key.toLowerCase()] = false; }

function fsKeyboardVec() {
  let x = 0, y = 0;
  if (FS.keys["a"] || FS.keys["arrowleft"]) x -= 1;
  if (FS.keys["d"] || FS.keys["arrowright"]) x += 1;
  if (FS.keys["w"] || FS.keys["arrowup"]) y -= 1;
  if (FS.keys["s"] || FS.keys["arrowdown"]) y += 1;
  if (!x && !y) return { x: 0, y: 0 };
  // 屏幕方向 → 世界方向
  return fsScreenDirToWorld(x, y);
}

// ---------- 主循环 ----------
function fsLoop(now) {
  if (!FS.el) return;
  let dt = (now - FS.last) / 1000;
  FS.last = now;
  const speed = (S.settings && [1, 1.5, 2].includes(Number(S.settings.combatSpeed))) ? Number(S.settings.combatSpeed) : 1;
  dt *= speed;
  if (!isFinite(dt) || dt < 0) dt = 0;   // 时间回退/异常保护，避免负 dt 让抖动累积
  if (dt > 0.05) dt = 0.05;

  if (!FS.ended) {
    // 输入合成：摇杆优先，其次键盘
    let mx = 0, my = 0;
    if (FS.joy.active && (FS.joy.dx || FS.joy.dy)) {
      const w = fsScreenDirToWorld(FS.joy.dx * 300, FS.joy.dy * 300);
      mx = w.x; my = w.y;
    } else {
      const kv = fsKeyboardVec();
      mx = kv.x; my = kv.y;
    }

    // 自动神通：按槽位循环
    if (FS.autoSkill) {
      FS.skillTimer -= dt;
      if (FS.skillTimer <= 0) {
        for (const k of FS.field.slots) {
          if ((FS.field.cds[k] || 0) <= 0) {
            const sk = fldSkill(k);
            if (FS.field.player.mana >= sk.mana) {
              const near = fldNearest(FS.field, FS.field.player.x, FS.field.player.y, 420);
              let d;
              if (near) d = fldNorm(near.x - FS.field.player.x, near.y - FS.field.player.y);
              else d = { x: Math.cos(FS.field.player.facing), y: Math.sin(FS.field.player.facing) };
              fldCast(FS.field, k, d.x, d.y);
              FS.skillTimer = 0.35;
              break;
            }
          }
        }
        if (FS.skillTimer <= 0) FS.skillTimer = 0.3;
      }
    }

    fldStep(FS.field, dt, { mx, my, dash: FS.dashPulse });
    FS.dashPulse = false;
    // 关键修复：只消费本帧事件并清空缓冲。
    // 旧写法直接遍历 fldStep 的返回值（整个历史事件数组），
    // 导致每帧重放全部历史事件 → 屏震与特效无限叠加 → 全场持续抖动。
    const evs = fldDrainEvents(FS.field);
    for (const e of evs) flvOnEvent(e);
    // 每帧刷新瞄准方向：拖拽中由指针写入，其余按鼠标/摇杆/自动锁敌
    if (!FS.dragging) FS.aimDir = fsGetAimDir();
    fsUpdateHud();

    if (FS.field.over) { FS.ended = true; fsFinish(); }
  }

  FLDV.aim = FS.aimDir;
  // 渲染异常绝不能打断主循环：旧版一旦某帧抛错，raf 链断裂，
  // 画面就永久停在半帧状态（表现为“进图后图标全乱”）
  try {
    flvDraw(dt);
  } catch (err) {
    FLDV.drawErrors = (FLDV.drawErrors | 0) + 1;
    if (FLDV.drawErrors <= 3) console.error("秘境界面渲染异常", err);
  }
  FS.raf = requestAnimationFrame(fsLoop);
}

function fsTickEvents() {
  const evs = fldDrainEvents(FS.field);
  for (const e of evs) flvOnEvent(e);
  fsUpdateHud();
}

// ---------- HUD ----------
function fsUpdateHud() {
  if (!FS.el) return;
  const f = FS.field;
  const q = s => FS.el.querySelector(s);
  const pct = (v, m) => Math.max(0, Math.min(100, (v / m) * 100));

  const hp = q(".fs-hpfill"), ht = q(".fs-hptext");
  if (hp) hp.style.width = pct(f.player.hp, f.player.hpMax) + "%";
  if (ht) ht.textContent = fmt(Math.max(0, f.player.hp)) + " / " + fmt(f.player.hpMax);

  const mf = q(".fs-manafill");
  if (mf) mf.style.width = pct(f.player.mana, f.player.manaMax) + "%";

  const alive = f.monsters.filter(m => m.alive).length;
  const total = f.monsters.length;
  const c = q(".fs-count");
  if (c) c.textContent = `妖兽 ${total - alive}/${total}`;

  // 探索度
  const exFill = q(".fs-explore i");
  const exText = q(".fs-explore b");
  const exPct = f.exploreMax > 0 ? Math.min(100, (f.explore / f.exploreMax) * 100) : 0;
  if (exFill) exFill.style.width = exPct + "%";
  if (exText) {
    exText.textContent = f.portal
      ? "探索 " + Math.round(exPct) + "% · 传送阵已开"
      : "探索 " + Math.round(exPct) + "%";
  }

  // 技能冷却
  for (const btn of FS.el.querySelectorAll(".fs-skill")) {
    const k = btn.dataset.skill;
    const cd = f.cds[k] || 0;
    const sk = fldSkill(k);
    const cdEl = btn.querySelector(".fs-skill-cd");
    if (cd > 0) {
      btn.classList.add("cooling");
      if (cdEl) cdEl.textContent = cd.toFixed(1);
    } else {
      btn.classList.remove("cooling");
      if (cdEl) cdEl.textContent = "";
    }
    if (f.player.mana < sk.mana) btn.classList.add("nomana");
    else btn.classList.remove("nomana");
  }

  const dashBtn = FS.el.querySelector(".fs-dash");
  if (dashBtn) {
    if (f.dashCd > 0) { dashBtn.classList.add("cooling"); dashBtn.textContent = f.dashCd.toFixed(1); }
    else { dashBtn.classList.remove("cooling"); dashBtn.textContent = "遁速"; }
  }
}

// ---------- 结束 ----------
function fsFinish() {
  const f = FS.field;
  const win = f.win;
  const stage = f.map.bossStage;
  // 清怪追加奖励：每 2 只额外 1 灵材（鼓励把图清干净）
  const bonusMat = Math.floor(f.killCount / 2);

  setTimeout(() => {
    fsClose(false);
    if (win) {
      const st = settleStageWin(stage);
      if (bonusMat > 0) {
        gainItem("material", bonusMat);
      }
      // 标记该秘境已通关（解锁弟子派遣）；v0.25.0：首次探明另给常驻修炼加成
      if (!S.clearedMaps) S.clearedMaps = {};
      const firstClear = !S.clearedMaps[f.chapter];
      S.clearedMaps[f.chapter] = true;
      // v0.29.0：首次探明记周常并给机缘
      if (firstClear) {
        if (typeof weeklyProgress === "function") weeklyProgress("clear3", 1);
        S.fate = (S.fate || 0) + 3;
        // 古宝（v0.30.0）：首探明必得一件对应古宝；击杀 BOSS 另得碎片
        if (typeof ancientByChapter === "function") {
          const anc = ancientByChapter(f.chapter);
          if (anc) {
            const g = grantAncient(anc.key);
            if (g.ok && !g.dup) {
              st.dropText = (st.dropText ? st.dropText + "、" : "") + "古宝「" + anc.name + "」";
            } else if (g.ok && g.dup) {
              const setKey = anc.set;
              addAncientFrag(setKey, g.frag);
              st.dropText = (st.dropText ? st.dropText + "、" : "") + "古宝碎片 ×" + g.frag;
            }
          }
          if (f.bossKilled) {
            const setOf = f.chapter <= 2 ? "qingyun" : f.chapter <= 4 ? "moyuan" : "hunyuan";
            addAncientFrag(setOf, CONFIG.ANCIENT.FRAG_PER_BOSS);
            st.dropText = (st.dropText ? st.dropText + "、" : "") + "古宝碎片 ×" + CONFIG.ANCIENT.FRAG_PER_BOSS;
          }
        }
      }
      // v0.24.0：出战灵兽按击杀积累亲密度（击杀 BOSS 额外奖励）
      const bondPet = (typeof activePet === "function") ? activePet() : null;
      const bondGain = (typeof petBondGain === "function" && bondPet)
        ? petBondGain(bondPet, f.killCount, f.bossKilled) : 0;
      save();

      if (st.dropText !== undefined) {
        st.dropText = (st.dropText ? st.dropText + "、" : "")
          + "灵材 ×" + bonusMat
          + "、采集 " + f.gathered + " 处（探索 " + Math.round(f.explore) + "%）";
        // v0.24.0：灵兽亲密度收益入结算文案
        if (bondGain > 0 && bondPet) {
          const bd = (typeof petDef === "function") ? petDef(bondPet.key) : null;
          st.dropText += "、" + (bd ? bd.name : "灵兽") + "亲密度 +" + bondGain;
        }
      }
      showStageReward(stage, st, "秘境");
      if (f.portal) {
        setTimeout(() => toast(firstClear
          ? `秘境已探明 · 修炼速率永久 +${Math.round(CONFIG.FIELD_CLEAR_CULT_BONUS * 100)}% · 可派遣弟子前往采集`
          : "秘境已探明 · 可派遣弟子前往采集"), 900);
      }
    } else {
      showModal(`
        <div class="result lose">
          <div class="result-title">✘ 力竭退出秘境</div>
          <div class="result-line">斩杀妖兽 ${f.killCount} 只</div>
          <div class="result-line">提示：善用「遁速」拉开距离躲红圈，回春/玄甲可续命</div>
          <button class="btn-primary" data-action="closemodal">继续</button>
        </div>`);
    }
    showView(currentTab);
  }, 600);
}

// ---------- 关闭 ----------
function fsClose(silent) {
  if (FS.raf) cancelAnimationFrame(FS.raf);
  FS.raf = 0;
  window.removeEventListener("resize", flvResize);
  window.removeEventListener("keydown", fsKeyDown);
  window.removeEventListener("keyup", fsKeyUp);
  fsUnbindGlobalPointers();
  if (FS.el && FS.el.parentNode) FS.el.parentNode.removeChild(FS.el);
  FS.el = null;
  FS.field = null;
  FS.dragging = null;
  FS.dragId = null;
  FS.dragOrigin = null;
  FS.dragDir = null;
  FS.joy.active = false;
  FS.joy.id = null;
  FS.joy.dx = 0;
  FS.joy.dy = 0;
  FLDV.field = null;
  if (typeof BREATH !== "undefined") {
    BREATH.active = false; BREATH.raf = 0; BREATH.el = null; BREATH.canvas = null; BREATH.ctx = null; BREATH.field = null;
  }
  if (silent) {
    toast("你退出了秘境（体力已消耗）");
    showView(currentTab);
  }
}
