// ============================================================
// 《问长生》章节特产与坊市刷新（v0.29.0）
// 特产：只在对应章节产出，用于高阶练功房与坊市高价交易
// 坊市刷新：每日 5 次手动刷新，制造"逛市场"的节奏
// ============================================================

function specialtyName(ch) {
  return CONFIG.FIELD_SPECIALTIES[ch] || "秘境特产";
}
// v0.40.0：特产为储物袋内真实物品（sp:<章节>），S.specialty 只是派生镜像
function specialtyCount(ch) {
  return (typeof invCount === "function") ? Math.floor(invCount("sp:" + ch)) : ((S.specialty && S.specialty[ch]) || 0);
}
function addSpecialty(ch, n) {
  if (typeof gainItem === "function") { gainItem("sp:" + ch, n); return; }
  if (!S.specialty) S.specialty = {};
  S.specialty[ch] = (S.specialty[ch] || 0) + n;
}

// 秘境产出：BOSS 3 个 / 采集 1 个 / 普通通关 2 个
function specialtyDrop(ch, source) {
  const n = source === "boss" ? 3 : source === "gather" ? 1 : 2;
  addSpecialty(ch, n);
  return n;
}

// 练功房高阶门槛：Lv6 起每 2 级需要下一章特产 3 个
function practiceSpecialtyNeed(targetLv) {
  if (targetLv < 6) return null;
  const ch = Math.min(CONFIG.CHAPTERS.length - 1, Math.floor((targetLv - 6) / 2) + 1);
  return { ch, n: 3, name: specialtyName(ch) };
}

// 特产在坊市的价格（越后章越贵）
function specialtyPrice(ch) {
  return 120 + ch * 90;
}

function buySpecialty(ch, n) {
  n = n || 1;
  const price = specialtyPrice(ch) * n;
  if (S.stone < price) return { ok: false, msg: "灵石不足" };
  if (!S.clearedMaps || !S.clearedMaps[ch]) return { ok: false, msg: "该章尚未探明，坊市无货" };
  const _rc = (typeof invRoomCheck === "function") ? invRoomCheck("sp:" + ch, n) : { ok: true };
  if (!_rc.ok) return _rc;
  S.stone -= price;
  addSpecialty(ch, n);
  save();
  return { ok: true, cost: price, n };
}

function sellSpecialty(ch, n) {
  n = Math.min(n || 1, specialtyCount(ch));
  if (n <= 0) return { ok: false, msg: "没有该特产" };
  const gain = Math.floor(specialtyPrice(ch) * n * 0.8);
  if (typeof invRemove === "function") invRemove("sp:" + ch, n);
  else S.specialty[ch] -= n;
  S.stone += gain;
  save();
  return { ok: true, gain, n };
}

// ---------- 坊市刷新 ----------
function ensureMarketRefresh() {
  const k = gameDayKey();
  if (!S.marketRefresh || S.marketRefresh.date !== k) {
    S.marketRefresh = { date: k, left: CONFIG.MARKET_REFRESH.DAILY };
  }
  return S.marketRefresh;
}

function refreshMarket() {
  const r = ensureMarketRefresh();
  if (r.left <= 0) return { ok: false, msg: "今日刷新次数已用尽" };
  if (S.stone < CONFIG.MARKET_REFRESH.COST) return { ok: false, msg: "灵石不足" };
  S.stone -= CONFIG.MARKET_REFRESH.COST;
  r.left -= 1;
  if (typeof economyTick === "function") economyTick();   // 重新走一轮行情
  save();
  return { ok: true, left: r.left };
}


// ---------- 境界货架（v0.54.3）----------
// 每2小时现实时间自动换货；离线跨过多个周期只生成当前一轮，不补发历史货架。
function marketShelfPool(realm) {
  const pools = [
    ["herb", "material", "pill", "talisman"],
    ["herb", "material", "pill", "talisman", "qiPill", "healPill"],
    ["material", "pill", "qiPill", "breakPill", "healPill", "tribPill"],
    ["material", "pill", "breakPill", "healPill", "tribPill", "daoPill"],
    ["material", "tribPill", "breakPill", "marrowPill", "daoPill", "qiPill"],
    ["material", "tribPill", "marrowPill", "daoPill", "breakPill", "healPill"],
  ];
  return pools[Math.max(0, Math.min(pools.length - 1, Math.floor((Number(realm) || 0) / 2)))].slice();
}

function marketShelfUnitPrice(key) {
  if (key === "herb") return Math.max(1, Math.ceil(S.market.herb));
  if (key === "pill") return Math.max(1, Math.ceil(S.market.pill));
  if (key === "tribPill") return Math.max(1, Math.ceil(S.market.tribPill));
  if (key === "material") return Math.max(1, Math.ceil(S.market.material));
  if (key === "talisman") return CONFIG.TALISMAN_PRICE;
  const def = CONFIG.ITEMS && CONFIG.ITEMS[key];
  return Math.max(1, Number(def && def.price) || 1);
}

function rollMarketShelf(now) {
  const pool = marketShelfPool(S.realm || 0);
  // Fisher-Yates，避免 sort(Math.random) 的非均匀随机排序。
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  const count = Math.min(pool.length, CONFIG.MARKET_SHELF.MIN_ITEMS + Math.floor(Math.random() * (CONFIG.MARKET_SHELF.MAX_ITEMS - CONFIG.MARKET_SHELF.MIN_ITEMS + 1)));
  const items = pool.slice(0, count).map(key => {
    const base = marketShelfUnitPrice(key);
    const mult = CONFIG.MARKET_SHELF.PRICE_MIN + Math.random() * (CONFIG.MARKET_SHELF.PRICE_MAX - CONFIG.MARKET_SHELF.PRICE_MIN);
    return { key, name: (CONFIG.ITEMS[key] && CONFIG.ITEMS[key].name) || (key === "talisman" ? "功法残卷" : key), stock: CONFIG.MARKET_SHELF.STOCK_MIN + Math.floor(Math.random() * (CONFIG.MARKET_SHELF.STOCK_MAX - CONFIG.MARKET_SHELF.STOCK_MIN + 1)), price: Math.max(1, Math.ceil(base * mult)) };
  });
  return { realm: Number(S.realm) || 0, refreshedAt: now, items };
}

function ensureMarketShelf(now) {
  now = Number.isFinite(Number(now)) ? Number(now) : Date.now();
  const interval = CONFIG.MARKET_SHELF.INTERVAL_MS;
  const old = S.marketShelf;
  if (!old || !Array.isArray(old.items) || !Number.isFinite(Number(old.refreshedAt))) {
    S.marketShelf = rollMarketShelf(now);
    if (typeof save === "function") save();
    return S.marketShelf;
  }
  const realmChanged = Number(old.realm) !== (Number(S.realm) || 0);
  const elapsed = now - Number(old.refreshedAt);
  if (realmChanged || elapsed >= interval || elapsed < 0) {
    // 维持两小时节拍；离线错过多轮时只换一次当前货架，不追补库存。
    const refreshedAt = elapsed >= interval && !realmChanged && elapsed >= 0
      ? Number(old.refreshedAt) + Math.floor(elapsed / interval) * interval
      : now;
    S.marketShelf = rollMarketShelf(refreshedAt);
    if (typeof save === "function") save();
  }
  return S.marketShelf;
}

function marketShelfRemaining(now) {
  const shelf = ensureMarketShelf(now);
  return Math.max(0, CONFIG.MARKET_SHELF.INTERVAL_MS - (Number(now == null ? Date.now() : now) - shelf.refreshedAt));
}

function buyMarketShelf(idx) {
  const shelf = ensureMarketShelf();
  const item = shelf.items[idx];
  if (!item) return { ok: false, msg: "货架商品不存在" };
  if (item.stock <= 0) return { ok: false, msg: "该商品已售罄" };
  const key = item.key;
  const room = invRoomCheck(key, 1);
  if (!room.ok) return room;
  if (S.stone < item.price) return { ok: false, msg: "灵石不足" };
  S.stone -= item.price;
  gainItem(key, 1);
  item.stock -= 1;
  save();
  return { ok: true, item, price: item.price, remaining: item.stock };
}

function marketShelfCountdownText(ms) {
  const sec = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
  return h > 0 ? `${h}小时${m}分后换货` : `${m}分后换货`;
}

// ---------- 坊市今日特价（v0.30.0）----------
// 每日 3 件随机商品，7~9 折，每件限购 1 次；制造「逛市场」的期待感
function ensureDeals() {
  const k = gameDayKey();
  if (!S.marketDeals || S.marketDeals.date !== k) {
    const pool = [
      { key: "herb", name: "灵草 ×10", batch: 10 },
      { key: "pill", name: "丹药 ×1", batch: 1 },
      { key: "material", name: "灵材 ×10", batch: 10 },
      { key: "talisman", name: "功法要诀 ×1", batch: 1 },
    ];
    const shuffled = pool.slice().sort(() => Math.random() - 0.5).slice(0, CONFIG.MARKET_DEALS.COUNT);
    const items = shuffled.map(it => ({
      key: it.key, name: it.name, batch: it.batch,
      mult: +(CONFIG.MARKET_DEALS.MIN + Math.random() * (CONFIG.MARKET_DEALS.MAX - CONFIG.MARKET_DEALS.MIN)).toFixed(2),
      bought: false,
    }));
    S.marketDeals = { date: k, items };
  }
  return S.marketDeals;
}

function dealBasePrice(item) {
  if (item.key === "herb") return S.market.herb * item.batch;
  if (item.key === "pill") return S.market.pill * item.batch;
  if (item.key === "material") return S.market.material * item.batch;
  return CONFIG.TALISMAN_PRICE * item.batch;
}

function dealPrice(item) {
  return Math.max(1, Math.floor(dealBasePrice(item) * item.mult));
}

function buyDeal(idx) {
  const d = ensureDeals();
  const it = d.items[idx];
  if (!it) return { ok: false, msg: "特价商品不存在" };
  if (it.bought) return { ok: false, msg: "今日已售罄" };
  const price = dealPrice(it);
  if (S.stone < price) return { ok: false, msg: "灵石不足" };
  S.stone -= price;
  if (it.key === "herb") gainItem("herb", it.batch);
  else if (it.key === "pill") gainItem("pill", it.batch);
  else if (it.key === "material") gainItem("material", it.batch);
  else if (it.key === "talisman") gainItem("talisman", it.batch);
  it.bought = true;
  save();
  return { ok: true, price, item: it };
}
