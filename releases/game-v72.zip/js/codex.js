// ============================================================
// 《问长生》道途录：成就系统 + 图鉴（v0.6.5）
// 成就：条件达成即自动记录并发放奖励（不做"领取"按钮，减少空转点击）
// 图鉴：法宝按「品阶_类型」收录 18 格；事件按事件链收录 13 条
// 设计约束：条件必须是"已发生的真实状态"，禁止为了成就去伪造数据
// ============================================================

// 安全的累计天数（codex.js 可能先于 event.js 被单独引用）
function codexDay() {
  return (typeof totalDays === "function") ? totalDays() : 0;
}

// ---------- 图鉴收录 ----------
function recordArtifactCodex(a) {
  if (!a) return;
  if (!S.codex) S.codex = { artifacts: {}, events: {} };
  if (!S.codex.artifacts) S.codex.artifacts = {};
  const key = `${a.tier}_${a.type}`;
  if (S.codex.artifacts[key] == null) S.codex.artifacts[key] = codexDay();
  if (Array.isArray(a.affixes) && a.affixes.length > 0) S.codex.affixSeen = true;
}

function recordEventCodex(key) {
  if (!key) return;
  if (!S.codex) S.codex = { artifacts: {}, events: {} };
  if (!S.codex.events) S.codex.events = {};
  if (S.codex.events[key] == null) S.codex.events[key] = codexDay();
}

// ---------- 图鉴查询（UI 用） ----------
function codexArtifactKeys() {
  return Object.keys((S.codex && S.codex.artifacts) || {});
}

function codexArtifactCount() {
  return codexArtifactKeys().length;
}

function codexArtifactTotal() {
  return CONFIG.ARTIFACT_TIERS.length * CONFIG.ARTIFACT_TYPES.length;
}

function codexArtifactSeen(tier, typeKey) {
  return !!((S.codex && S.codex.artifacts) || {})[`${tier}_${typeKey}`];
}

function codexEventCount() {
  return Object.keys((S.codex && S.codex.events) || {}).length;
}

function codexEventTotal() {
  return CONFIG.CODEX_EVENTS.length;
}

function codexEventSeen(key) {
  return !!((S.codex && S.codex.events) || {})[key];
}

// ---------- 妖兽 / 秘境图鉴（v0.8.0） ----------
function recordBeastCodex(key) {
  if (!key) return;
  if (!S.codex) S.codex = {};
  if (!S.codex.beasts) S.codex.beasts = {};
  if (S.codex.beasts[key] == null) S.codex.beasts[key] = codexDay();
}

function recordRegionCodex(key) {
  if (!key) return;
  if (!S.codex) S.codex = {};
  if (!S.codex.regions) S.codex.regions = {};
  if (S.codex.regions[key] == null) S.codex.regions[key] = codexDay();
}

function codexBeastCount() {
  return Object.keys((S.codex && S.codex.beasts) || {}).length;
}
function codexBeastTotal() { return CONFIG.CODEX_BEASTS.length; }
function codexBeastSeen(key) { return !!((S.codex && S.codex.beasts) || {})[key]; }

function codexRegionCount() {
  return Object.keys((S.codex && S.codex.regions) || {}).length;
}
function codexRegionTotal() { return CONFIG.CODEX_REGIONS.length; }
function codexRegionSeen(key) { return !!((S.codex && S.codex.regions) || {})[key]; }

// ---------- 成就条件（key 必须与 CONFIG.ACHIEVEMENTS 一一对应） ----------
const ACHIEVEMENT_CHECKERS = {
  // 境界
  realm_1: () => S.realm >= 1,
  realm_2: () => S.realm >= 2,
  realm_3: () => S.realm >= 3,
  realm_4: () => S.realm >= 4,
  realm_5: () => S.realm >= 5,
  realm_6: () => S.realm >= 6,
  realm_7: () => S.realm >= 7,
  realm_8: () => S.realm >= 8,
  realm_9: () => S.realm >= 9,
  realm_10: () => S.realm >= 10,
  ascend: () => S.ascended === true,
  // 战斗
  battle_first: () => ((S.stats && S.stats.battleWins) || 0) >= 1,
  battle_boss: () => ((S.stats && S.stats.bossWins) || 0) >= 1,
  battle_ch1: () => (S.bestStage || 0) >= 6,
  battle_ch3: () => (S.bestStage || 0) >= 18,
  battle_ch5: () => (S.bestStage || 0) >= 30,
  battle_ch7: () => (S.bestStage || 0) >= 42,
  battle_50: () => ((S.stats && S.stats.battleWins) || 0) >= 50,
  // 经营
  build_5: () => Object.keys(S.buildings || {}).some(k => (S.buildings[k] || 0) >= 5),
  build_10: () => Object.keys(S.buildings || {}).some(k => (S.buildings[k] || 0) >= 10),
  disciple_5: () => ((S.disciples || []).length) >= 5,
  gongfa_10: () => CONFIG.GONGFA_BOOKS.some(b => gongfaLv(b.key) >= b.layers),
  // 法宝
  art_first: () => codexArtifactCount() >= 1,
  art_t4: () => codexArtifactKeys().some(k => parseInt(k.split("_")[0], 10) >= 4),
  art_t6: () => codexArtifactKeys().some(k => parseInt(k.split("_")[0], 10) >= 6),
  art_full: () => {
    const e = S.equipped || {};
    return e.attack != null && e.defense != null && e.support != null;
  },
  art_affix: () => !!(S.codex && S.codex.affixSeen),
  // 世界
  event_first: () => codexEventCount() >= 1,
  event_six: () => codexEventCount() >= 6,
  rel_50: () => CONFIG.FACTIONS.some(f => ((S.factions[f.key] || {}).relation || 0) >= 50),
  rep_100: () => (S.reputation || 0) >= 100,
  // 收集
  codex_half: () => codexArtifactCount() >= Math.ceil(codexArtifactTotal() / 2),
  codex_full: () => codexArtifactCount() >= codexArtifactTotal(),
  // 试炼塔（v0.8.0）
  tower_10: () => (S.towerBest || 0) >= 10,
  tower_25: () => (S.towerBest || 0) >= 25,
  tower_40: () => (S.towerBest || 0) >= 40,
  // 图鉴补全（v0.8.0）
  beast_all: () => codexBeastCount() >= codexBeastTotal(),
  region_all: () => codexRegionCount() >= codexRegionTotal(),
  // 剧情与见闻（v0.11.0）
  story_all: () => Object.keys(S.storySeen || {}).length >= CONFIG.CHAPTERS.length,
  battleground_win: () => ((S.stats && S.stats.battlegroundWins) || 0) >= 1,
  pillmeet_win: () => ((S.stats && S.stats.pillmeetWins) || 0) >= 1,
  art_t6_x3: () => {
    const e = S.equipped || {};
    const arr = S.artifacts || [];
    return ["attack", "defense", "support"].every(t => {
      const id = e[t];
      if (id == null) return false;
      const a = arr.find(x => x.id === id);
      return !!(a && a.tier >= 6);
    });
  },
  // 长线（v0.11.0）
  disciple_elite: () => (S.disciples || []).some(d => (d.bond || 0) >= CONFIG.BOND_ELITE_THRESHOLD),
  rep_500: () => (S.reputation || 0) >= 500,
  tower_44: () => (S.towerBest || 0) >= 44,
  tower_54: () => (S.towerBest || 0) >= 54,
  // 道心（v0.12.0）
  story_war: () => {
    const b = storyBonus();
    return b.chosen >= CONFIG.CHAPTERS.length && b.war / b.chosen >= CONFIG.STORY_ENDING_RATIO;
  },
  story_dao: () => {
    const b = storyBonus();
    return b.chosen >= CONFIG.CHAPTERS.length && b.dao / b.chosen >= CONFIG.STORY_ENDING_RATIO;
  },
  story_balance: () => {
    const b = storyBonus();
    if (b.chosen < CONFIG.CHAPTERS.length) return false;
    const r = b.war / b.chosen;
    return r < CONFIG.STORY_ENDING_RATIO && (1 - r) < CONFIG.STORY_ENDING_RATIO;
  },
};

// ---------- 奖励发放 ----------
function achievementRewardText(reward) {
  if (!reward) return "";
  const parts = [];
  if (reward.rep) parts.push(`声望 +${reward.rep}`);
  if (reward.mat) parts.push(`灵材 +${reward.mat}`);
  if (reward.stone) parts.push(`灵石 +${fmt(reward.stone)}`);
  return parts.length ? "（" + parts.join("、") + "）" : "";
}

function grantAchievementReward(def) {
  const r = def.reward || {};
  if (r.rep) S.reputation = (S.reputation || 0) + r.rep;
  if (r.mat) gainItem("material", r.mat);
  if (r.stone) S.stone = (S.stone || 0) + r.stone;
}

// ---------- 成就判定（每次 tick 调用；已达成直接跳过） ----------
function codexTick() {
  if (!S.achievements) S.achievements = {};
  const newly = [];
  for (const def of CONFIG.ACHIEVEMENTS) {
    if (S.achievements[def.key] != null) continue;
    const fn = ACHIEVEMENT_CHECKERS[def.key];
    if (typeof fn !== "function") continue;
    let ok = false;
    try { ok = !!fn(); } catch (e) { ok = false; }
    if (!ok) continue;
    S.achievements[def.key] = codexDay();
    grantAchievementReward(def);
    if (typeof addEventLog === "function") {
      addEventLog(`【道途录】成就「${def.name}」达成${achievementRewardText(def.reward)}`);
    }
    newly.push(def);
  }
  if (newly.length) save();
  return newly;
}

// 已达成数量
function achievementCount() {
  return Object.keys(S.achievements || {}).length;
}

function achievementTotal() {
  return CONFIG.ACHIEVEMENTS.length;
}

// 按分类取成就（"分类"由 key 前缀决定，避免再维护一份分类表）
function achievementGroup(def) {
  const k = def.key;
  if (k.startsWith("realm_") || k === "ascend") return "境界";
  if (k.startsWith("battle_")) return "历练";
  if (k.startsWith("build_") || k.startsWith("disciple_") || k.startsWith("gongfa_")) return "洞府";
  if (k.startsWith("art_")) return "法宝";
  if (k.startsWith("event_") || k.startsWith("rel_") || k.startsWith("rep_")) return "世间";
  if (k.startsWith("codex_") || k === "beast_all" || k === "region_all") return "图鉴";
  if (k.startsWith("tower_")) return "试炼";
  if (k === "story_all" || k === "battleground_win" || k === "pillmeet_win"
      || k === "story_war" || k === "story_dao" || k === "story_balance") return "剧情";
  return "其他";
}
