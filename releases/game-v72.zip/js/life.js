// ============================================================
// 《问长生》生活与社交完整版（v0.36.0）
// 药园（格子种植/浇水/枯萎/开垦/药童）· 化身（独立挂机）
// 仙友/道侣（传功/赠礼/双修）· 五行流派在 element.js
// ============================================================

// ================= 药园 =================
function gardenState() {
  if (!S.garden || typeof S.garden !== "object" || !S.garden.size) {
    S.garden = { size: CONFIG.GARDEN.BASE, plots: [] };
  }
  if (!Array.isArray(S.garden.plots)) S.garden.plots = [];
  return S.garden;
}
function gardenPlotCount() { return gardenState().size * gardenState().size; }
function gardenCrop(key) { return CONFIG.GARDEN.CROPS.find(c => c.key === key) || null; }

// 药童职务：全局药园加速
function gardenLaborBonus() {
  let n = 0;
  for (const ch in (S.staff || {})) {
    if (S.staff[ch] && S.staff[ch].office === "yaotong") n++;
  }
  return n * CONFIG.GARDEN.HERB_PER_LEVEL;
}

function gardenGrowMs(plot) {
  const c = gardenCrop(plot.crop);
  if (!c) return 1;
  const cut = plot.watered ? CONFIG.GARDEN.WATER_CUT : 0;
  return Math.max(15000, c.sec * 1000 * (1 - cut) / (1 + gardenLaborBonus()));
}

function gardenPlotInfo(idx) {
  const g = gardenState();
  const p = g.plots[idx];
  if (!p) return { empty: true };
  const c = gardenCrop(p.crop);
  const grow = gardenGrowMs(p) * (p.rare ? 0.9 : 1);
  const elapsed = Date.now() - p.plantedAt;
  const ripe = elapsed >= grow;
  const withered = elapsed >= grow * CONFIG.GARDEN.WITHER_MULT;
  return {
    empty: false, crop: c, rare: !!p.rare, pct: Math.min(100, (elapsed / grow) * 100),
    ripe, withered, leftSec: Math.max(0, Math.ceil((grow - elapsed) / 1000)),
  };
}

// 购买种子：入储物袋（v0.37.0 物品化，种植消耗袋内种子）
function seedKeyOf(cropKey, rare) { return "seed:" + (rare ? "rare:" : "") + cropKey; }

function buySeed(cropKey, n) {
  const c = gardenCrop(cropKey);
  if (!c) return { ok: false, msg: "无此作物" };
  const cnt = Math.max(1, Math.floor(Number(n) || 1));
  const cost = c.seed * cnt;
  if ((S.stone || 0) < cost) return { ok: false, msg: `灵石不足（${cnt} 包需 ${fmt(cost)}）` };
  const room = invRoomFor(seedKeyOf(cropKey));
  if (room < cnt) return { ok: false, msg: `储物袋放不下（还需 ${cnt - Math.floor(room)} 格位）` };
  S.stone -= cost;
  invAdd(seedKeyOf(cropKey), cnt);
  save();
  return { ok: true, name: c.name + "种子", count: cnt, cost };
}

function gardenPlant(idx, cropKey, rare) {
  const g = gardenState();
  const c = gardenCrop(cropKey);
  if (!c) return { ok: false, msg: "无此作物" };
  if (idx < 0 || idx >= gardenPlotCount()) return { ok: false, msg: "地块不存在" };
  if (g.plots[idx]) return { ok: false, msg: "该地块已种植" };
  if (c.realm && (S.realm || 0) < c.realm) {
    return { ok: false, msg: `需 ${CONFIG.REALMS[c.realm]}期方可培植${c.name}` };
  }
  const rareSeed = !!rare;
  const seedKey = seedKeyOf(cropKey, rareSeed);
  if (typeof invCount === "function" && invCount(seedKey) < 1) {
    return { ok: false, msg: `袋中无${rareSeed ? "异种" : ""}${c.name}种子，先去药园获取` };
  }
  if (typeof invRemove === "function") invRemove(seedKey, 1);
  g.plots[idx] = { crop: cropKey, plantedAt: Date.now(), watered: 0, rare: rareSeed ? 1 : 0 };
  save();
  return { ok: true, crop: c, rare: rareSeed };
}

function gardenWater(idx) {
  const g = gardenState();
  const p = g.plots[idx];
  if (!p) return { ok: false, msg: "地块为空" };
  const now = Date.now();
  if (p.wateredAt && now - p.wateredAt < CONFIG.GARDEN.WATER_CD_SEC * 1000) {
    return { ok: false, msg: "浇水冷却中" };
  }
  p.watered = 1;
  p.wateredAt = now;
  // 浇水直接缩短 20% 生长期
  p.plantedAt -= gardenGrowMs({ ...p, watered: 0 }) * CONFIG.GARDEN.WATER_CUT;
  save();
  return { ok: true };
}

// 施肥（v0.43.0）：耗 1 灵材，产量 +30% 且变异概率提升
function gardenFert(idx) {
  const g = gardenState();
  const p = g.plots[idx];
  if (!p) return { ok: false, msg: "地块为空" };
  if (p.fert) return { ok: false, msg: "此地块已施过肥" };
  const cost = CONFIG.GARDEN.FERT.matCost;
  if (Math.floor(S.materials || 0) < cost) return { ok: false, msg: `灵材不足（需 ${cost}）` };
  invRemove("material", cost);
  p.fert = 1;
  save();
  return { ok: true, cost };
}

function gardenHarvest(idx) {
  const g = gardenState();
  const info = gardenPlotInfo(idx);
  if (info.empty) return { ok: false, msg: "地块为空" };
  if (!info.ripe) return { ok: false, msg: `尚未成熟（剩 ${info.leftSec} 秒）` };
  const c = info.crop;
  const plot = g.plots[idx] || {};
  const fert = plot.fert ? 1 : 0;
  let mult = info.withered ? 0.5 : 1;
  if (fert) mult *= (1 + CONFIG.GARDEN.FERT.yieldBonus);
  if (plot.rare) mult *= CONFIG.GARDEN.RARE_SEED_YIELD;
  // 灵植变异（v0.43.0）：概率大幅增产并得灵材
  const F = CONFIG.GARDEN.FERT;
  const mutRate = F.mutRate + fert * F.mutPerFert;
  const mutated = !info.withered && Math.random() < mutRate;
  if (mutated) mult *= F.mutMult;
  const out = {};
  if (c.herb) { const n = Math.floor(c.herb * mult); gainItem("herb", n); out.herb = n; }
  if (c.pill) { const n = Math.floor(c.pill * mult); gainItem("pill", n); out.pill = n; }
  if (c.material) { const n = Math.floor(c.material * mult); gainItem("material", n); out.material = n; }
  if (mutated) {
    gainItem("material", F.mutMat); out.material = (out.material || 0) + F.mutMat;
    // 变异灵植额外结出同作物异种灵种，形成「变异 → 留种 → 优质种植」闭环。
    gainItem(seedKeyOf(c.key, true), 1);
    out.rareSeed = 1;
  }
  g.plots[idx] = null;
  if (mutated) {
    if (!g.mutated) g.mutated = 0;
    g.mutated += 1;
    if (typeof dailyProgress === "function") dailyProgress("gardenMut", 1);
  }
  save();
  return { ok: true, out, withered: info.withered, mutated, fert, rare: !!plot.rare };
}

function gardenExpand() {
  const g = gardenState();
  if (g.size >= CONFIG.GARDEN.MAX) return { ok: false, msg: "药园已达最大（5×5）" };
  const cost = CONFIG.GARDEN.EXPAND_COST[g.size - CONFIG.GARDEN.BASE];
  if (S.stone < cost) return { ok: false, msg: `灵石不足（需 ${fmt(cost)}）` };
  S.stone -= cost;
  g.size += 1;
  save();
  return { ok: true, size: g.size, cost };
}

// 地块操作（生长中）：浇水 / 施肥（v0.43.0）
function showGardenPlot(idx) {
  const g = gardenState();
  const p = g.plots[idx];
  if (!p) { showGardenPanel(); return; }
  const info = gardenPlotInfo(idx);
  const c = gardenCrop(p.crop);
  const waterReady = !p.wateredAt || (Date.now() - p.wateredAt >= CONFIG.GARDEN.WATER_CD_SEC * 1000);
  showModal(`<div class="result">
    <div class="result-title">${esc(c.name)}</div>
    <div class="result-line">生长 ${Math.round(info.pct)}% ｜ 剩余 ${info.leftSec} 秒 ｜ ${p.fert ? "已施肥（产量 +" + Math.round(CONFIG.GARDEN.FERT.yieldBonus * 100) + "%）" : "未施肥"}</div>
    <div class="result-line muted-line">施肥（灵材 ${CONFIG.GARDEN.FERT.matCost}）可增产并提高变异概率；变异时产量翻倍并额外得灵材。</div>
    <div class="build-row">
      <button class="btn-sm" data-action="gardenwater" data-i="${idx}" ${waterReady ? "" : "disabled"}>浇水（缩短生长）</button>
      <button class="btn-sm" data-action="gardenfert" data-i="${idx}" ${p.fert ? "disabled" : ""}>施肥</button>
    </div>
    <button class="btn-primary" data-action="garden">返回药园</button>
  </div>`);
}

// ================= 化身 =================
function avatarBodyState() {
  if (!S.avatarBody || typeof S.avatarBody !== "object") S.avatarBody = {};
  return S.avatarBody;
}
function avatarUnlock() {
  const A = CONFIG.AVATAR_BODY;
  const ab = avatarBodyState();
  if (ab.unlocked) return { ok: false, msg: "化身已开辟" };
  if ((S.realm || 0) < A.UNLOCK_REALM) return { ok: false, msg: `需 ${CONFIG.REALMS[A.UNLOCK_REALM]} 期方可开辟化身` };
  if (S.stone < A.UNLOCK_STONE) return { ok: false, msg: `灵石不足（需 ${fmt(A.UNLOCK_STONE)}）` };
  S.stone -= A.UNLOCK_STONE;
  ab.unlocked = true; ab.lv = 1; ab.map = null; ab.lastClaim = Date.now();
  save();
  return { ok: true };
}
function avatarUpgrade() {
  const A = CONFIG.AVATAR_BODY;
  const ab = avatarBodyState();
  if (!ab.unlocked) return { ok: false, msg: "尚未开辟化身" };
  if (ab.lv >= A.MAX_LV) return { ok: false, msg: "化身已满级" };
  const cost = A.LV_COST[ab.lv - 1];
  if (S.stone < cost) return { ok: false, msg: `灵石不足（需 ${fmt(cost)}）` };
  S.stone -= cost;
  ab.lv += 1;
  save();
  return { ok: true, lv: ab.lv };
}
function avatarSetMap(ch) {
  const ab = avatarBodyState();
  if (!ab.unlocked) return { ok: false, msg: "尚未开辟化身" };
  if (!S.clearedMaps || !S.clearedMaps[ch]) return { ok: false, msg: "该秘境尚未探明" };
  ab.map = parseInt(ch, 10);
  save();
  return { ok: true, map: ab.map };
}
// 化身职能（v0.44.0）
function avatarDuty() {
  const ab = avatarBodyState();
  return ab.duty || "field";
}

function avatarSetDuty(duty) {
  const ab = avatarBodyState();
  if (!ab.unlocked) return { ok: false, msg: "尚未开辟化身" };
  const def = CONFIG.AVATAR_BODY.DUTIES.find(d => d.key === duty);
  if (!def) return { ok: false, msg: "无此职能" };
  if (duty === "dan" && (S.buildings.alchemy || 0) < 1) return { ok: false, msg: "尚无炼丹房，无法代炼" };
  if (duty === "garden") {
    const planted = gardenState().plots.filter(Boolean).length;
    if (!planted) return { ok: false, msg: "药园没有在地作物，代采药无从下手" };
  }
  // 切换职能结算前置：先把已累积产出收走（避免跨职能错算）
  const pend = avatarPending();
  if (pend && pend.sec >= 60) return { ok: false, msg: "先收取当前职能的产出，再改派职能" };
  ab.duty = duty;
  ab.lastClaim = Date.now();
  save();
  return { ok: true, duty: def.name };
}

// 化身累积产出（独立计时，最多 8 小时）
function avatarPending() {
  const A = CONFIG.AVATAR_BODY;
  const ab = avatarBodyState();
  if (!ab.unlocked) return null;
  const duty = avatarDuty();
  if (duty === "field" && (ab.map === null || ab.map === undefined)) return null;
  if (duty === "dan" && (S.buildings.alchemy || 0) < 1) return null;
  if (duty === "garden") {
    const planted = gardenState().plots.filter(Boolean).length;
    if (!planted) return null;
  }
  const sec = Math.min(A.CLAIM_HOURS * 3600, Math.max(0, (Date.now() - (ab.lastClaim || Date.now())) / 1000));
  const k = A.RATE * (1 + A.LV_BONUS * ((ab.lv || 1) - 1));
  const lv = ab.lv || 1;
  if (duty === "dan") {
    // 代炼丹：按小时折算消耗与产出（材料不足则按比例衰减）
    const hours = sec / 3600;
    const eff = 0.6 + 0.12 * lv;
    const herbNeed = A.DAN_HERB_PER_HOUR * hours * eff;
    const matNeed = A.DAN_MAT_PER_HOUR * hours * eff;
    const herbOk = Math.min(1, (S.herbs || 0) / Math.max(1e-6, herbNeed));
    const matOk = Math.min(1, (S.materials || 0) / Math.max(1e-6, matNeed));
    const ratio = Math.max(0, Math.min(herbOk, matOk));
    return {
      sec, duty: "dan", rate: eff, ratio,
      herb: 0, qi: 0, stone: 0, material: 0,
      useHerb: herbNeed * ratio, useMat: matNeed * ratio,
      pill: A.DAN_PILL_PER_HOUR * hours * eff * ratio,
      rare: Math.floor(hours * lv * 0.12 * ratio),
    };
  }
  if (duty === "garden") {
    // 代采药：按当前在地作物估算收获
    const cycles = Math.min(A.GARDEN_CYCLES_PER_HOUR * lv, sec / 600);
    const g = gardenState();
    const planted = g.plots.filter(Boolean);
    let herb = 0, pill = 0, material = 0;
    for (const p of planted) {
      const c = gardenCrop(p.crop);
      if (!c) continue;
      const perCycle = 1 / Math.max(1, planted.length);
      herb += (c.herb || 0) * cycles * perCycle;
      pill += (c.pill || 0) * cycles * perCycle;
      material += (c.material || 0) * cycles * perCycle;
    }
    return { sec, duty: "garden", rate: 1, herb, pill, material, stone: 0, qi: 0 };
  }
  const r = dispatchRate(ab.map);
  return {
    sec, duty: "field",
    stone: r.stone * k * sec,
    qi: r.qi * k * sec,
    herb: r.herb * k * sec,
    material: r.material * k * sec,
    rate: k,
  };
}
function avatarClaim() {
  const A = CONFIG.AVATAR_BODY;
  const ab = avatarBodyState();
  const p = avatarPending();
  if (!p) return { ok: false, msg: "化身尚未派出" };
  if (p.sec < 60) return { ok: false, msg: "化身产出不足 1 分钟" };
  if (p.duty === "dan") {
    invRemove("herb", p.useHerb);
    invRemove("material", p.useMat);
    gainItem("pill", Math.floor(p.pill));
    if (p.rare > 0) {
      const _rare = ["qiPill", "healPill", "breakPill"];
      const pick = _rare[Math.min(_rare.length - 1, Math.floor((ab.lv || 1) / 2))];
      gainItem(pick, p.rare);
    }
  } else if (p.duty === "garden") {
    gainItem("herb", p.herb);
    gainItem("pill", p.pill);
    gainItem("material", p.material);
  } else {
    S.stone += p.stone;
    S.qi += p.qi;
    gainItem("herb", p.herb);
    gainItem("material", p.material);
  }
  ab.lastClaim = Date.now();
  save();
  return { ok: true, gain: p };
}

// ================= 仙友 / 道侣 =================
function friendPoolName() {
  return CONFIG.DISCIPLE_NAMES[Math.floor(Math.random() * CONFIG.DISCIPLE_NAMES.length)];
}
// 每 3 个游戏日自动结识一位仙友（上限 6）
function ensureFriends() {
  const F = CONFIG.FRIEND;
  if (!Array.isArray(S.friends)) S.friends = [];
  const t = S.gameTime || { year: 1, month: 1, day: 1 };
  const totalDay = (t.year - 1) * 360 + (t.month - 1) * 30 + t.day;
  const want = Math.min(F.MAX, Math.floor(totalDay / F.DAYS_PER_NEW));
  while (S.friends.length < want) {
    S.friendSeq = (S.friendSeq || 0) + 1;
    S.friends.push({
      id: S.friendSeq, name: friendPoolName(), rel: 10, lover: false,
      lastTrain: "", lastGift: "", lastDual: "", events: [],
    });
  }
  return S.friends;
}

function friendFind(id) { return (S.friends || []).find(f => String(f.id) === String(id)) || null; }

function friendTrain(id) {
  const f = friendFind(id);
  if (!f) return { ok: false, msg: "仙友不存在" };
  const k = gameDayKey();
  if (f.lastTrain === k) return { ok: false, msg: "今日已传功" };
  const cost = CONFIG.breakCost(kNow()) * CONFIG.FRIEND.TRAIN_QI;
  if (S.qi < cost) return { ok: false, msg: "灵气不足" };
  S.qi -= cost;
  S.qi += cost * 0.6;              // 传功回流：双方共修，损耗四成
  f.rel = Math.min(100, f.rel + CONFIG.FRIEND.TRAIN_REL);
  f.lastTrain = k;
  save();
  return { ok: true, rel: f.rel };
}

function friendGift(id) {
  const f = friendFind(id);
  if (!f) return { ok: false, msg: "仙友不存在" };
  const k = gameDayKey();
  if (f.lastGift === k) return { ok: false, msg: "今日已赠礼" };
  if (S.stone < CONFIG.FRIEND.GIFT_STONE) return { ok: false, msg: "灵石不足" };
  S.stone -= CONFIG.FRIEND.GIFT_STONE;
  f.rel = Math.min(100, f.rel + CONFIG.FRIEND.GIFT_REL);
  f.lastGift = k;
  save();
  return { ok: true, rel: f.rel };
}

function friendBeLover(id) {
  const f = friendFind(id);
  if (!f) return { ok: false, msg: "仙友不存在" };
  if (f.lover) return { ok: false, msg: "已是道侣" };
  if (f.rel < CONFIG.FRIEND.LOVER_REL) return { ok: false, msg: `好感不足（${f.rel}/${CONFIG.FRIEND.LOVER_REL}）` };
  if ((S.friends || []).some(x => x.lover)) return { ok: false, msg: "已有道侣" };
  f.lover = true;
  save();
  return { ok: true, name: f.name };
}

// 双修：道侣每日一次，直接获得灵气
function friendDualCultivate(id) {
  const f = friendFind(id);
  if (!f || !f.lover) return { ok: false, msg: "仅道侣可双修" };
  const k = gameDayKey();
  if (f.lastDual === k) return { ok: false, msg: "今日已双修" };
  const gain = CONFIG.breakCost(kNow()) * CONFIG.FRIEND.DUAL_CULT;
  S.qi += gain;
  f.rel = Math.min(100, f.rel + 2);
  f.lastDual = k;
  save();
  return { ok: true, gain };
}

// ================= 仙友事件链（v0.45.0）=================
function friendNextEvent(f) {
  if (!f) return null;
  const done = f.events || [];
  return (CONFIG.FRIEND.EVENTS || []).find(e => !done.includes(e.key) && (f.rel || 0) >= e.rel) || null;
}

function friendEventDo(id) {
  const f = friendFind(id);
  if (!f) return { ok: false, msg: "仙友不存在" };
  const e = friendNextEvent(f);
  if (!e) return { ok: false, msg: "暂无新的交游（好感不足或已尽）" };
  if (!Array.isArray(f.events)) f.events = [];
  f.events.push(e.key);
  const gains = [];
  if (e.reward.qiPct) {
    const q = Math.max(1, Math.floor(CONFIG.breakCost(kNow()) * e.reward.qiPct));
    S.qi += q;
    gains.push("灵气 +" + fmt(q));
  }
  if (e.reward.item) { gainItem(e.reward.item, e.reward.n); gains.push((invItemDef(e.reward.item) || {}).name + " +" + e.reward.n); }
  if (e.reward.talisman) { gainItem("talisman", e.reward.talisman); gains.push("功法残卷 +" + e.reward.talisman); }
  save();
  return { ok: true, event: e, gains, text: e.text.replace(/\{name\}/g, f.name), title: e.title };
}

// 请援：每日一次，好感 ≥50 可请好友相助（修炼 +10%，2 小时）
function friendHelp(id) {
  const F = CONFIG.FRIEND;
  const f = friendFind(id);
  if (!f) return { ok: false, msg: "仙友不存在" };
  if ((f.rel || 0) < 50) return { ok: false, msg: `好感不足 50（当前 ${f.rel || 0}），请不动人家` };
  if (!S.friendHelp || typeof S.friendHelp !== "object") S.friendHelp = { date: "", used: 0 };
  const k = gameDayKey();
  if (S.friendHelp.date !== k) { S.friendHelp = { date: k, used: 0 }; }
  if (S.friendHelp.used >= 1) return { ok: false, msg: "今日已请过援手" };
  S.friendHelp.used += 1;
  S.helpBuffUntil = Date.now() + F.HELP_HOURS * 3600 * 1000;
  save();
  return { ok: true, name: f.name, hours: F.HELP_HOURS, bonus: F.HELP_CULT };
}

function helpBuffActive() {
  return (S.helpBuffUntil || 0) > Date.now();
}

// 道侣机缘：与道侣同修，冷却内一次随机馈赠
function loverGift() {
  const F = CONFIG.FRIEND;
  const lover = (S.friends || []).find(x => x.lover);
  if (!lover) return { ok: false, msg: "尚无道侣" };
  const cdMs = F.LOVER_GIFT_CD_H * 3600 * 1000;
  if (Date.now() - (S.loverGiftAt || 0) < cdMs) {
    const left = Math.ceil((cdMs - (Date.now() - (S.loverGiftAt || 0))) / 3600000);
    return { ok: false, msg: `机缘未至（约 ${left} 小时后再来）` };
  }
  S.loverGiftAt = Date.now();
  const roll = Math.random();
  let text = "";
  if (roll < 0.4) {
    const q = Math.max(1, Math.floor(CONFIG.breakCost(kNow()) * 0.12));
    S.qi += q; text = "道侣与你同参一夜，灵气 +" + fmt(q);
  } else if (roll < 0.75) {
    const n = 3 + Math.floor((S.realm || 0) * 2);
    gainItem("pill", n); text = "道侣炼了一炉丹相赠，培元丹 +" + n;
  } else {
    const st = 500 * (1 + (S.realm || 0));
    S.stone += st; text = "道侣以私房灵石助你，灵石 +" + fmt(st);
  }
  if (!lover.events) lover.events = [];
  save();
  return { ok: true, text, name: lover.name };
}

function loverBonus() {
  return (S.friends || []).some(f => f.lover) ? CONFIG.FRIEND.LOVER_CULT : 0;
}

// ================= 界面 =================
function showGardenPanel() {
  const g = gardenState();
  const cells = [];
  for (let i = 0; i < gardenPlotCount(); i++) {
    const info = gardenPlotInfo(i);
    if (info.empty) {
      cells.push(`<button class="garden-cell empty" data-action="gardenplant" data-i="${i}">＋</button>`);
    } else if (!info.ripe) {
      cells.push(`<button class="garden-cell growing" data-action="gardenplot" data-i="${i}">${info.rare ? "异种" : ""}${esc(info.crop.name)}${info.fert ? '<i class="garden-fert">肥</i>' : ""}<span>${Math.round(info.pct)}%</span></button>`);
    } else {
      cells.push(`<button class="garden-cell ripe ${info.withered ? "withered" : ""}" data-action="gardenharvest" data-i="${i}">${info.rare ? "异种" : ""}${esc(info.crop.name)}${info.withered ? "（枯）" : "✔"}</button>`);
    }
  }
  const crops = CONFIG.GARDEN.CROPS.map(c => `
    <div class="shop-item">
      <span>${esc(c.name)} <span class="muted">${Math.round(c.sec / 60)} 分钟 ｜ 种子 ${c.seed} 石</span></span>
      <span class="muted">产 ${[c.herb ? "灵草" + c.herb : "", c.pill ? "丹药" + c.pill : "", c.material ? "灵材" + c.material : ""].filter(Boolean).join(" · ")}</span>
      ${c.realm && (S.realm || 0) < c.realm ? `<span class="muted">需 ${CONFIG.REALMS[c.realm]}期</span>` : `<button class="btn-xs" data-action="invbuy" data-crop="${c.key}" data-n="1">买 1 包</button>`}
      <button class="btn-xs" data-action="invbuy" data-crop="${c.key}" data-n="5">买 5 包</button>
    </div>
    <div class="shop-item shop-sub">
      <span class="muted">袋内种子 <b>${Math.floor(invCount("seed:" + c.key))}</b> ｜ 异种灵种 <b>${Math.floor(invCount(seedKeyOf(c.key, true)))}</b></span>
    </div>`).join("");
  const expand = g.size < CONFIG.GARDEN.MAX
    ? `<button class="btn-sm" data-action="gardenexpand">开垦至 ${g.size + 1}×${g.size + 1}（${fmt(CONFIG.GARDEN.EXPAND_COST[g.size - CONFIG.GARDEN.BASE])} 石）</button>`
    : `<span class="muted">已满 5×5</span>`;
  showModal(`<div class="result">
    <div class="result-title">药园 ${g.size}×${g.size}</div>
    <div class="result-line">点空格种植 · 点生长中浇水/施肥 · 成熟点收获（枯萎收益减半）</div>
    <div class="result-line muted-line">施肥 +${Math.round(CONFIG.GARDEN.FERT.yieldBonus * 100)}% 产量并提升变异率；异种灵种种植产量 +${Math.round((CONFIG.GARDEN.RARE_SEED_YIELD - 1) * 100)}%、生长缩短 10%；已变异 ${g.mutated || 0} 次</div>
    <div class="garden-grid">${cells.join("")}</div>
    <div class="result-line muted-line">药童加速 +${Math.round(gardenLaborBonus() * 100)}%（弟子任药童）</div>
    <div class="sec-title small">种子</div>
    <div class="shop-list">${crops}</div>
    <div class="build-row">${expand}</div>
    <button class="btn-primary" data-action="closemodal">关闭</button>
  </div>`);
}

function showAvatarPanel() {
  const ab = avatarBodyState();
  const A = CONFIG.AVATAR_BODY;
  if (!ab.unlocked) {
    showModal(`<div class="result">
      <div class="result-title">化身</div>
      <div class="result-line">元婴期可开辟化身（独立挂机，离线累积上限 ${A.CLAIM_HOURS} 小时）</div>
      <div class="result-line">消耗灵石 ${fmt(A.UNLOCK_STONE)}</div>
      <button class="btn-sm" data-action="avatarmake" ${(S.realm || 0) >= A.UNLOCK_REALM && S.stone >= A.UNLOCK_STONE ? "" : "disabled"}>开辟化身</button>
      <button class="btn-primary" data-action="closemodal">关闭</button>
    </div>`);
    return;
  }
  const pend = avatarPending();
  const duty = avatarDuty();
  const dutyBtns = CONFIG.AVATAR_BODY.DUTIES.map(d => `
    <button class="btn-sm ${duty === d.key ? "on" : ""}" data-action="avatarduty" data-duty="${d.key}">${esc(d.name)}</button>`).join("");
  const dutyDesc = (CONFIG.AVATAR_BODY.DUTIES.find(d => d.key === duty) || {}).desc || "";
  const maps = duty !== "field" ? "" : Object.keys(S.clearedMaps || {}).filter(k => S.clearedMaps[k]).map(ch => `
    <button class="btn-sm" data-action="avatarmap" data-ch="${ch}">${esc(CONFIG.fieldMap(parseInt(ch, 10)).name)}</button>`).join("");
  const up = ab.lv < A.MAX_LV
    ? `<button class="btn-sm" data-action="avatarup">提升化身（${fmt(A.LV_COST[ab.lv - 1])} 石）</button>`
    : `<span class="muted">已满级</span>`;
  showModal(`<div class="result">
    <div class="result-title">化身 Lv.${ab.lv}</div>
    <div class="result-line">驻地：${ab.map === null || ab.map === undefined ? "未派出" : esc(CONFIG.fieldMap(ab.map).name)} ｜ 系数 ${(A.RATE * (1 + A.LV_BONUS * (ab.lv - 1))).toFixed(2)}</div>
    <div class="sec-title small">职能</div>
    <div class="build-row">${dutyBtns}</div>
    <div class="build-desc">${esc(dutyDesc)}</div>
    ${pend ? `<div class="result-line">待收产出（${Math.floor(pend.sec / 60)} 分钟）：
      ${pend.duty === "dan"
        ? `耗灵草 ${fmt(pend.useHerb)} 灵材 ${fmt(pend.useMat)} → 培元丹 ${fmt(pend.pill)}${pend.rare ? " ／ 稀有丹 " + pend.rare : ""}${pend.ratio < 1 ? "（材料不足 " + Math.round(pend.ratio * 100) + "%）" : ""}`
        : pend.duty === "garden"
          ? `灵草 ${fmt(pend.herb)} ｜ 丹药 ${fmt(pend.pill)} ｜ 灵材 ${fmt(pend.material)}`
          : `灵石 ${fmt(pend.stone)} ｜ 灵气 ${fmt(pend.qi)} ｜ 灵草 ${fmt(pend.herb)}`}</div>
      <button class="btn-sm" data-action="avatarclaim">收取</button>` : `<div class="result-line muted">${duty === "field" ? "派往已探明秘境后开始挂机" : duty === "dan" ? "需炼丹房方可代炼" : "药园需有在地作物"}</div>`}
    ${duty === "field" ? `<div class="sec-title small">派驻秘境</div><div class="build-row">${maps || '<span class="muted">尚无已探明秘境</span>'}</div>` : ""}
    <div class="build-row">${up}</div>
    <button class="btn-primary" data-action="closemodal">关闭</button>
  </div>`);
}

function showFriendPanel() {
  ensureFriends();
  const rows = (S.friends || []).map(f => {
    const k = gameDayKey();
    return `<div class="friend-row">
      <div class="friend-main">
        <div class="friend-name">${esc(f.name)} ${f.lover ? '<span class="friend-lover">道侣</span>' : ""}</div>
        <div class="friend-rel">好感 ${f.rel}/100${friendNextEvent(f) ? " ｜ <b>有新交游</b>" : ""}</div>
      </div>
      <div class="friend-btns">
        ${friendNextEvent(f) ? `<button class="btn-xs" data-action="friendevent" data-id="${f.id}">交游</button>` : ""}
        <button class="btn-xs" data-action="friendhelp" data-id="${f.id}" ${(f.rel || 0) >= 50 ? "" : "disabled"}>请援</button>
        <button class="btn-xs" data-action="friendtrain" data-id="${f.id}" ${f.lastTrain === k ? "disabled" : ""}>传功</button>
        <button class="btn-xs" data-action="friendgift" data-id="${f.id}" ${f.lastGift === k ? "disabled" : ""}>赠礼</button>
        ${f.lover
          ? `<button class="btn-xs" data-action="frienddual" data-id="${f.id}" ${f.lastDual === k ? "disabled" : ""}>双修</button>`
          : `<button class="btn-xs" data-action="friendlover" data-id="${f.id}" ${f.rel >= CONFIG.FRIEND.LOVER_REL ? "" : "disabled"}>结道侣</button>`}
      </div>
    </div>`;
  }).join("") || `<div class="build-out muted">尚无仙友，每 ${CONFIG.FRIEND.DAYS_PER_NEW} 日会结识一位</div>`;
  showModal(`<div class="result">
    <div class="result-title">仙友</div>
    <div class="result-line">${(S.friends || []).length}/${CONFIG.FRIEND.MAX} ｜ 道侣加成：${loverBonus() ? "+" + Math.round(loverBonus() * 100) + "% 修炼" : "无"}</div>
    <div class="shop-list">${rows}</div>
    <div class="build-row">
      <button class="btn-sm" data-action="lovergift" ${(S.friends || []).some(x => x.lover) ? "" : "disabled"}>道侣机缘</button>
      <span class="muted" style="font-size:11px">${helpBuffActive() ? "请援加持中（修炼 +" + Math.round(CONFIG.FRIEND.HELP_CULT * 100) + "%）" : "请援：好感 ≥50，每日一次"}</span>
    </div>
    <div class="tip">传功耗灵气得好感、赠礼耗灵石；好感 30/55/80 各解锁一段交游（有实质收获）；好感满 100 可结道侣（修炼 +5%）</div>
    <button class="btn-primary" data-action="closemodal">关闭</button>
  </div>`);
}
