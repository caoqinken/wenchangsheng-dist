// ============================================================
// 《问长生》经营养成系统：建筑 / 弟子 / 丹药
// ============================================================

// 升级建筑
function upgradeBuilding(key) {
  const lv = S.buildings[key];
  const cost = CONFIG.buildingCost(lv);
  if (S.stone < cost) return { ok: false, msg: "灵石不足" };
  // 练功房高阶（v0.29.0）：目标等级 ≥6 起需对应章节特产，逼玩家回秘境探索
  if (key === "practice" && typeof practiceSpecialtyNeed === "function") {
    const need = practiceSpecialtyNeed(lv + 1);
    if (need && specialtyCount(need.ch) < need.n) {
      return { ok: false, msg: `${need.name}不足（需 ${need.n}）· 可在第 ${need.ch + 1} 章秘境获取` };
    }
    if (need) invRemove("sp:" + need.ch, need.n);
  }
  S.stone -= cost;
  S.buildings[key]++;
  if (typeof dailyProgress === "function") dailyProgress("build1", 1);
  save();
  return { ok: true, lv: S.buildings[key] };
}

// 招募弟子（v0.4.1：生成有资质/忠诚/心境的个体 NPC）
function recruitDisciple() {
  if (S.disciples.length >= discipleSlots()) {
    return { ok: false, msg: `弟子名额已满（${discipleSlots()}），提升境界或升级招募堂可扩招` };
  }
  const cost = CONFIG.recruitCost(S.disciples.length);
  if (S.stone < cost) return { ok: false, msg: "灵石不足" };
  // v0.28.0：招募来源为秘境衍生的凡人（弟子驻守已探明秘境即有人口繁衍）
  const needFolk = CONFIG.DISCIPLE_FOLK_COST;
  if ((S.folk || 0) < needFolk || (typeof consumeFolk === "function" && !consumeFolk(needFolk))) {
    return { ok: false, msg: `凡人不足（需 ${needFolk} 名）：派弟子驻守已探明秘境可繁衍凡人` };
  }
  S.stone -= cost;
  const d = createDisciple();
  S.disciples.push(d);
  save();
  return { ok: true, disciple: d };
}

// 委派一名空闲弟子到建筑
function assignDisciple(key) {
  // 排除已在秘境采集队伍中的弟子，否则同一人双挂两套产出
  const inField = (typeof dispatchTeamIds === "function") ? dispatchTeamIds() : [];
  const idle = S.disciples.find(d => d.assignedTo === null && inField.indexOf(d.id) < 0);
  if (!idle) return { ok: false, msg: "没有空闲弟子" };
  idle.assignedTo = key;
  save();
  return { ok: true, disciple: idle };
}

// 撤回某建筑的一名弟子
function unassignDisciple(key) {
  const d = S.disciples.find(x => x.assignedTo === key);
  if (!d) return { ok: false, msg: "该建筑无委派弟子" };
  d.assignedTo = null;
  save();
  return { ok: true };
}

// 服用丹药：积累药力（v0.8.0 重做）
// 旧逻辑"立即获得当前突破所需 5% 灵气"存在指数级漏洞：
// 丹药价格是常数级（坊市 50 灵石），突破成本却按 1.35^k 指数增长，
// 而灵石掉落按 1.4^n 增长 —— 后期刷一场 BOSS 的灵石可换上千枚丹药，
// 直接跳过整段修炼。因此改为"药力"长线增益，不再与突破成本挂钩。
// 药力上限与炼丹房等级挂钩（每级 10 层），让炼丹房成为真实的经营目标。
function pillBuffCapLayers() {
  const byAlchemy = 10 * (S.buildings.alchemy || 0);
  const byConfig = Math.floor(CONFIG.PILL_BONUS_CAP / CONFIG.PILL_RATE_BONUS);
  return Math.min(byAlchemy, byConfig);
}

function usePill() {
  if (S.pills < 1) return { ok: false, msg: "没有丹药" };
  if ((S.buildings.alchemy || 0) < 1) return { ok: false, msg: "需先建造炼丹房，方可炼化药力" };
  const cap = pillBuffCapLayers();
  const before = S.pillBuff || 0;
  if (before >= cap) return { ok: false, msg: `药力已满（${before}/${cap}），可升级炼丹房扩容` };
  invRemove("pill", 1);
  S.pillBuff = Math.min(cap, before + CONFIG.PILL_BUFF_PER_USE);
  save();
  return { ok: true, buff: S.pillBuff, cap, gain: 0 };
}

// 功法升级已迁移至 gongfa.js（v0.19.0 多功法分层体系）

// 灵田—炼丹房实时原料净流量（每秒）；倍率与 buildTick 保持同源。
function herbFlowSnapshot() {
  const blessingMult = blessed("sanxiu") ? 1.1 : 1;
  const sinong = (S.dynasty && S.dynasty.name && S.dynastyOffice && S.dynastyOffice.sinong) ? 1.2 : 1;
  const farmIn = buildingOutput("farm") * blessingMult * sinong;
  const alchemyLv = S.buildings.alchemy || 0;
  const consume = alchemyLv > 0 ? 2 * alchemyLv : 0;
  const net = farmIn - consume;
  const stock = Math.max(0, Number(S.herbs) || 0);
  return { farmIn, consume, net, stock, coverageSec: net < 0 ? stock / -net : Infinity, blessingMult, sinong };
}

// 经营产出 tick（每秒）
function buildTick(dt) {
  // 势力庇护：与散修联盟关系达标，经营产出 +10%
  const blessingMult = blessed("sanxiu") ? 1.1 : 1;
  // 灵田产灵草（v0.33.0：王朝司农 +20%）
  const sinong = (S.dynasty && S.dynasty.name && S.dynastyOffice && S.dynastyOffice.sinong) ? 1.2 : 1;
  gainItem("herb", buildingOutput("farm") * dt * blessingMult * sinong);
  // 炼丹房：消耗灵草产丹药
  const alch = S.buildings.alchemy;
  if (alch > 0) {
    const consumePerSec = 2 * alch;
    const producePerSec = buildingOutput("alchemy") * blessingMult;
    const herbsUsed = Math.min(S.herbs, consumePerSec * dt);
    if (herbsUsed > 0) {
      invRemove("herb", herbsUsed);
      const _pillOut = (herbsUsed / consumePerSec) * producePerSec;
      gainItem("pill", _pillOut);
      // v0.38.0：炼丹房等级越高，越可能额外炼出稀有丹方
      if (Math.random() < CONFIG.PILLS.ALCHEMY_EXTRA * (S.buildings.alchemy || 0)) {
        const _rare = ["qiPill", "healPill", "breakPill", "marrowPill", "daoPill"];
        const _lv = S.buildings.alchemy || 1;
        const _cap = Math.min(_rare.length, Math.max(1, Math.ceil(_lv / 2)));
        const _pick = _rare[Math.floor(Math.random() * _cap)];
        gainItem(_pick, 1);
        if (typeof invOverflowNotice === "function" && Math.random() < 0.25 && typeof toast === "function") {
          toast("炼丹房炉火纯青，另炼出 " + invItemDef(_pick).name + " ×1");
        }
      }
    }
  }
}
