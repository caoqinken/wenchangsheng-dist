// ============================================================
// 《问长生》秘境派遣（v0.17.0）
// 秘境探明后可派弟子前往采集，离线持续产出
// ============================================================

function dispatchTeam(ch) {
  return (S.mapTeam && S.mapTeam[ch]) || [];
}

// 当前所有在秘境中的弟子 id（建筑委派需要排除他们）
function dispatchTeamIds() {
  const ids = [];
  if (!S.mapTeam) return ids;
  for (const ch in S.mapTeam) for (const id of S.mapTeam[ch]) ids.push(id);
  return ids;
}

// 单个弟子的产出系数
function dispatchRateOne(d) {
  const D = CONFIG.DISPATCH;
  if (!d) return 0;
  // v0.17.4：弟子对象的境界字段是 realm（旧代码误用 realmIdx，恒为 0，境界加成从未生效）
  let k = D.BASE_RATE * (1 + (d.realm || 0) * D.REALM_RATE);
  k *= (0.7 + 0.006 * (d.loyalty || 0));
  // 灵植/丹道专精更适合采集
  if (d.specialty === "farm" || d.specialty === "alchemy") k *= (1 + D.SPECIALTY_BONUS);
  if ((d.bond || 0) >= CONFIG.BOND_ELITE_THRESHOLD) k *= (1 + D.BOND_BONUS);
  return k;
}

// 灵脉等级（v0.26.0：秘境建设经营基础）
function fieldVeinLv(ch) { return (S.fieldVein && S.fieldVein[ch]) || 0; }
function fieldVeinCost(ch) {
  return Math.floor(CONFIG.FIELD_VEIN.COST_BASE * Math.pow(1.6, fieldVeinLv(ch)));
}
function upgradeFieldVein(ch) {
  if (!S.clearedMaps || !S.clearedMaps[ch]) return { ok: false, msg: "该秘境尚未探明" };
  const lv = fieldVeinLv(ch);
  if (lv >= CONFIG.FIELD_VEIN.MAX) return { ok: false, msg: "灵脉已至顶级" };
  const cost = fieldVeinCost(ch);
  if (S.stone < cost) return { ok: false, msg: "灵石不足" };
  // v0.32.0：升级需派驻灵脉师（凡人）
  const need = (typeof laborNeed === "function") ? laborNeed(lv + 1) : 0;
  if (need > 0 && (S.folk || 0) < need) return { ok: false, msg: `凡人不足（需 ${need} 名灵脉师）· 弟子驻守秘境可繁衍凡人` };
  if (need > 0 && typeof consumeFolk === "function" && !consumeFolk(need, ch)) return { ok: false, msg: `本地聚落凡人不足（需 ${need} 名灵脉师）` };
  S.stone -= cost;
  if (need > 0) { if (typeof addFieldLabor === "function") addFieldLabor(ch, "vein", need); }
  if (!S.fieldVein) S.fieldVein = {};
  S.fieldVein[ch] = lv + 1;
  save();
  return { ok: true, lv: lv + 1, cost, need };
}

// 我的领地：每处有弟子驻守的已探明秘境计 1 块领地
function playerTerritory() {
  let n = 0;
  if (!S.mapTeam) return 0;
  for (const ch in S.mapTeam) {
    if (S.mapTeam[ch] && S.mapTeam[ch].length && S.clearedMaps && S.clearedMaps[ch]) n++;
  }
  return n;
}

// 某秘境的每秒产出
function dispatchRate(ch) {
  // 失守秘境（v0.33.0）：产出清零，需赎回
  if (S.lostFields && S.lostFields[ch]) {
    return { stone: 0, qi: 0, herb: 0, material: 0, total: 0, vein: 0, folk: 0, folkHerb: 0, lost: true };
  }
  let k = 0;
  for (const id of dispatchTeam(ch)) {
    k += dispatchRateOne(S.disciples.find(x => x.id === id));
  }
  const vein = fieldVeinLv(ch);
  const mine = (typeof fieldMineLv === "function") ? fieldMineLv(ch) : 0;
  const garden = (typeof fieldGardenLv === "function") ? fieldGardenLv(ch) : 0;
  const st = (typeof stableMult === "function") ? stableMult(ch) : 1;
  const mul = (1 + (parseInt(ch, 10) || 0) * 0.3)
    * (1 + vein * CONFIG.FIELD_VEIN.RATE_BONUS)
    * (1 + mine * CONFIG.FIELD_BUILD.MINE_RATE)
    * (1 + garden * CONFIG.FIELD_BUILD.GARDEN_RATE)
    * st;
  // 凡人聚落：灵脉每级孵化一处凡人居所，额外产灵草（须有弟子驻守，否则秘境无人经营）
  const folkHerb = k > 0 ? vein * CONFIG.FIELD_VEIN.FOLK_RATE : 0;
  // 凡人繁衍（v0.28.0）：弟子驻守即开垦灵脉周边，凡人聚落逐日繁衍，可招募为弟子
  const temple = 1 + ((typeof fieldTempleLv === "function" ? fieldTempleLv(ch) : 0) * CONFIG.STABLE.TEMPLE_CHANCE);
  const dynMul = (S.dynasty && S.dynasty.name) ? CONFIG.DYNASTY.FOLK_MULT : 1;
  // 弟子职务（v0.33.0）：矿正加灵石、庙祝/城主加繁衍；王朝州牧再加两成
  const stoneOff = (typeof officeBonus === "function") ? 1 + officeBonus(ch, "stone") : 1;
  const folkOff = (typeof officeBonus === "function") ? 1 + officeBonus(ch, "folk") : 1;
  const dynFolk = (typeof dynastyFolkMult === "function") ? dynastyFolkMult() : 1;
  const folk = k > 0 ? k * CONFIG.DISPATCH.FOLK_RATE * (1 + vein * CONFIG.DISPATCH.FOLK_VEIN_BONUS) * temple * dynMul * st * folkOff * dynFolk : 0;
  return {
    stone: k * mul * 2 * stoneOff,
    qi: k * mul * 0.6,
    herb: k * mul * 0.12 + folkHerb,
    material: k * mul * 0.08,
    total: k,
    vein,
    folk,
    folkHerb,
  };
}

// 驻守离线效率：computeOffline() 在通用离线率之外再乘 0.5；引魔香只额外提高驻守产出。
function dispatchOfflineRate(ch, incense) {
  const off = (typeof gongfaBonus === "function") ? (gongfaBonus().offline || 0) : 0;
  const factor = CONFIG.OFFLINE_RATE * (1 + off) * 0.5 * (incense ? CONFIG.OFFLINE_INCENSE_DISPATCH_MULT : 1);
  const r = dispatchRate(ch);
  return { stone: r.stone * factor, qi: r.qi * factor, herb: r.herb * factor, material: r.material * factor, folk: r.folk * factor, factor };
}

// 主循环调用
// v0.51.0：产出照旧实时入账，同时把本帧产出累进「驻守结算单」，让玩家能看见挂机账目
function dispatchTick(dt) {
  if (typeof fieldEducationTick === "function") fieldEducationTick(dt, 1);
  if (!S.mapTeam || !S.clearedMaps) return;
  for (const ch in S.mapTeam) {
    if (!S.clearedMaps[ch]) continue;
    const r = dispatchRate(ch);
    if (!r.total) continue;
    const localStone = r.stone * dt;
    const societyLevy = typeof fieldSocietyCollectLevy === "function" ? fieldSocietyCollectLevy(ch, localStone) : 0;
    S.stone += localStone - societyLevy;
    S.qi += r.qi * dt;
    gainItem("herb", r.herb * dt);
    gainItem("material", r.material * dt);
    const addedFolk = typeof addFolk === "function" ? addFolk(r.folk * dt, ch) : 0;
    const settleRate = Object.assign({}, r, { stone: dt > 0 ? (localStone - societyLevy) / dt : 0, folk: dt > 0 ? addedFolk / dt : 0 });
    dispatchSettleAcc(ch, dt, settleRate);
  }
}

// 累计进结算单（供 tick / 离线共用）
function dispatchSettleAcc(ch, dt, r) {
  if (!S.settle || typeof S.settle !== "object") S.settle = {};
  const cap = CONFIG.DISPATCH.SETTLE_KEEP_SEC;
  const old = S.settle[ch] || { sec: 0, stone: 0, qi: 0, herb: 0, material: 0, folk: 0 };
  const rec = {
    sec: Math.min(cap, (old.sec || 0) + dt),
    stone: (old.stone || 0) + r.stone * dt,
    qi: (old.qi || 0) + r.qi * dt,
    herb: (old.herb || 0) + r.herb * dt,
    material: (old.material || 0) + r.material * dt,
    folk: (old.folk || 0) + r.folk * dt,
  };
  S.settle[ch] = rec;
  return rec;
}

// 只读：某秘境当前累计（无则零单）
function dispatchSettleInfo(ch) {
  const r = (S.settle && S.settle[ch]) || null;
  if (!r) return { sec: 0, stone: 0, qi: 0, herb: 0, material: 0, folk: 0 };
  return { sec: r.sec || 0, stone: r.stone || 0, qi: r.qi || 0, herb: r.herb || 0, material: r.material || 0, folk: r.folk || 0 };
}

// 是否够格出一张结算单
function dispatchSettleReady(ch) {
  const r = dispatchSettleInfo(ch);
  return r.sec >= CONFIG.DISPATCH.SETTLE_MIN_SEC && (r.stone + r.qi + r.herb + r.material + r.folk) > 0;
}

// 全部待结算汇总（历练页 / 弹窗入口提示用）
function dispatchSettleAll() {
  const out = { maps: 0, sec: 0, stone: 0, qi: 0, herb: 0, material: 0, folk: 0, ready: 0 };
  if (!S.mapTeam || !S.clearedMaps) return out;
  for (const ch in S.mapTeam) {
    if (!S.clearedMaps[ch]) continue;
    const r = dispatchSettleInfo(ch);
    if (!r.sec) continue;
    out.maps++;
    out.sec += r.sec;
    out.stone += r.stone; out.qi += r.qi; out.herb += r.herb; out.material += r.material; out.folk += r.folk;
    if (dispatchSettleReady(ch)) out.ready++;
  }
  return out;
}

// 时长文案（逻辑层自带，不依赖 UI 的 fmtTime）
function dsDur(sec) {
  const s = Math.max(0, Math.floor(sec || 0));
  if (s < 60) return s + " 秒";
  if (s < 3600) return Math.floor(s / 60) + " 分";
  return (s / 3600).toFixed(1) + " 小时";
}

// 出结算单：返回账目快照并把该秘境累计清零（资源不回收、不重发）
function dispatchSettle(ch) {
  if (!S.clearedMaps || !S.clearedMaps[ch]) return { ok: false, msg: "该秘境尚未探明" };
  if (!dispatchSettleReady(ch)) {
    return { ok: false, msg: `累计需满 ${CONFIG.DISPATCH.SETTLE_MIN_SEC} 秒` };
  }
  const rec = dispatchSettleInfo(ch);
  const nm = (CONFIG.fieldMap(parseInt(ch, 10)) || {}).name || "秘境";
  S.settle[ch] = { sec: 0, stone: 0, qi: 0, herb: 0, material: 0, folk: 0 };
  if (typeof addEventLog === "function") {
    addEventLog(`驻守结算·${nm}：弟子驻守 ${dsDur(rec.sec)}，采得灵石 ${fmt(rec.stone)}、灵气 ${fmt(rec.qi)}、灵草 ${fmt(rec.herb)}、灵材 ${fmt(rec.material)}，聚凡人 ${Math.floor(rec.folk)} 名`);
  }
  save();
  return { ok: true, name: nm, rec };
}

// 驻守收益明细（v0.51.0）：把「每秒一个数」拆成玩家看得懂的来源与倍率
function dispatchDetail(ch) {
  const D = CONFIG.DISPATCH;
  const team = dispatchTeam(ch).map(id => S.disciples.find(x => String(x.id) === String(id))).filter(Boolean);
  const r = dispatchRate(ch);
  const vein = fieldVeinLv(ch);
  const mine = (typeof fieldMineLv === "function") ? fieldMineLv(ch) : 0;
  const garden = (typeof fieldGardenLv === "function") ? fieldGardenLv(ch) : 0;
  const temple = (typeof fieldTempleLv === "function") ? fieldTempleLv(ch) : 0;
  const stable = (typeof fieldStableOf === "function") ? fieldStableOf(ch) : 100;
  const st = (typeof stableMult === "function") ? stableMult(ch) : 1;
  const idx = parseInt(ch, 10) || 0;
  // 弟子逐人贡献
  const members = team.map(d => {
    const k = dispatchRateOne(d);
    const tags = [];
    if (d.specialty === "farm" || d.specialty === "alchemy") tags.push("专精");
    if ((d.bond || 0) >= CONFIG.BOND_ELITE_THRESHOLD) tags.push("嫡传");
    return {
      id: d.id, name: d.name, realmName: (typeof discipleRealmName === "function") ? discipleRealmName(d) : ("境" + (d.realm || 0)),
      loyalty: Math.round(d.loyalty || 0), k, tags,
      share: r.total > 0 ? k / r.total : 0,
    };
  });
  // 倍率链：每一项都是乘区，逐条列出才能让玩家知道该升什么
  const chain = [
    { name: "秘境深度", mul: 1 + idx * 0.3, note: `第 ${idx + 1} 章 ×${(1 + idx * 0.3).toFixed(1)}` },
    { name: "灵脉", mul: 1 + vein * CONFIG.FIELD_VEIN.RATE_BONUS, note: `Lv.${vein} 每级 +${Math.round(CONFIG.FIELD_VEIN.RATE_BONUS * 100)}%` },
    { name: "矿场", mul: 1 + mine * CONFIG.FIELD_BUILD.MINE_RATE, note: `Lv.${mine} 每级 +${Math.round(CONFIG.FIELD_BUILD.MINE_RATE * 100)}%` },
    { name: "药圃", mul: 1 + garden * CONFIG.FIELD_BUILD.GARDEN_RATE, note: `Lv.${garden} 每级 +${Math.round(CONFIG.FIELD_BUILD.GARDEN_RATE * 100)}%` },
    { name: "安定度", mul: st, note: `${stable}/100${stable < CONFIG.STABLE.LOW ? "（动乱，产出减半）" : ""}` },
  ];
  const stoneOff = (typeof officeBonus === "function") ? 1 + officeBonus(ch, "stone") : 1;
  if (stoneOff > 1) chain.push({ name: "职务", mul: stoneOff, note: `矿正/城主 灵石 +${Math.round((stoneOff - 1) * 100)}%` });
  const templeMul = 1 + temple * CONFIG.STABLE.TEMPLE_CHANCE;
  return {
    team: members,
    chain,
    temple, templeMul, stable,
    rate: r,
    nodeLeft: dispatchNodeLeft(ch),
    settle: dispatchSettleInfo(ch),
    settleReady: dispatchSettleReady(ch),
    lost: !!(S.lostFields && S.lostFields[ch]),
  };
}


// 显式离线派遣结算兼容入口（主流程统一由 idle.js 的 computeOffline 调用）
function dispatchOffline(seconds) {
  const cap = CONFIG.DISPATCH.OFFLINE_CAP_HOURS * 3600;
  const t = Math.min(cap, Math.max(0, seconds));
  const out = { stone: 0, qi: 0, herb: 0, material: 0, folk: 0 };
  if (!S.mapTeam || !S.clearedMaps) return out;
  for (const ch in S.mapTeam) {
    if (!S.clearedMaps[ch]) continue;
    const r = dispatchRate(ch);
    out.stone += r.stone * t;
    out.qi += r.qi * t;
    out.herb += r.herb * t;
    out.material += r.material * t;
    const addedFolk = typeof addFolk === "function" ? addFolk(r.folk * t, ch) : 0;
    out.folk += addedFolk;
    const settleRate = Object.assign({}, r, { folk: t > 0 ? addedFolk / t : 0 });
    dispatchSettleAcc(ch, t, settleRate);
  }
  // 资源点刷新离线补算（v0.28.0，封顶 NODE_OFFLINE_CAP 次）
  const _iv = CONFIG.DISPATCH.NODE_INTERVAL;
  const _cycles = Math.min(CONFIG.DISPATCH.NODE_OFFLINE_CAP, Math.floor(t / _iv));
  if (_cycles > 0) {
    for (const ch in S.mapTeam) {
      if (!S.clearedMaps[ch]) continue;
      if (!dispatchRate(ch).total) continue;
      const vein = fieldVeinLv(ch);
      out.material += (1 + vein) * _cycles;
      out.herb += (3 + vein * 2) * _cycles;
      // 资源点补算同样计入结算单（否则结算单账目会小于背包实际增幅）
      dispatchSettleAcc(ch, 0, { stone: 0, qi: 0, herb: (3 + vein * 2) * _cycles, material: (1 + vein) * _cycles, folk: 0 });
    }
  }
  // 直接入账：旧版本只返回不落账，而运行时无任何调用方处理返回值 → 离线产出实际为 0
  S.stone += out.stone;
  S.qi += out.qi;
  gainItem("herb", out.herb);
  gainItem("material", out.material);
  return out;
}

function assignDispatch(ch, discipleId) {
  // v0.28.0 修复：UI 传的是字符串 id，旧代码用 === 比较 number 永远不相等 → 误报「弟子不存在」
  // 统一转字符串比较，兼容数字与字符串两种 id
  const pid = String(discipleId);
  const d = S.disciples.find(x => String(x.id) === pid);
  if (!d) return { ok: false, msg: "弟子不存在" };
  if (!S.clearedMaps || !S.clearedMaps[ch]) return { ok: false, msg: "该秘境尚未探明" };
  if (!S.mapTeam) S.mapTeam = {};
  const team = S.mapTeam[ch] || [];
  if (team.map(String).indexOf(pid) >= 0) return { ok: false, msg: "已在队伍中" };

  // 一个弟子只能在一处（先从其它秘境/建筑撤回）
  for (const k in S.mapTeam) {
    const i = S.mapTeam[k].map(String).indexOf(pid);
    if (i >= 0) S.mapTeam[k].splice(i, 1);
  }
  if (d.assignedTo !== null) d.assignedTo = null;

  team.push(discipleId);
  S.mapTeam[ch] = team;
  save();
  return { ok: true };
}

function removeDispatch(ch, discipleId) {
  const team = (S.mapTeam && S.mapTeam[ch]) || [];
  const i = team.map(String).indexOf(String(discipleId));
  if (i >= 0) { team.splice(i, 1); save(); return { ok: true }; }
  return { ok: false, msg: "不在队伍中" };
}

// 驻守产出描述（UI 用）
function dispatchText(ch) {
  const r = dispatchRate(ch);
  if (!r.total) return "未驻守";
  const vein = r.vein ? ` ｜ 灵脉 Lv.${r.vein}` : "";
  const folk = r.folk > 0 ? ` ｜ 凡人 ${(r.folk * 60).toFixed(1)}/分` : "";
  return `灵石 ${r.stone.toFixed(1)}/秒 · 灵气 ${r.qi.toFixed(1)}/秒 · 灵草 ${r.herb.toFixed(2)}/秒 · 灵材 ${r.material.toFixed(2)}/秒${vein}${folk}`;
}

// ---------- 驻守资源点刷新（v0.28.0）----------
// 弟子驻守秘境后，秘境内采集点按固定间隔刷新：每次产出一小包灵材/灵草并写入世界大事，
// 让「驻守」从抽象数值变成可感知的事件；离线补算有封顶，避免材料产出失控。
function dispatchNodeTick(dt) {
  if (!S.mapTeam || !S.clearedMaps) return;
  if (!S.mapNodeT) S.mapNodeT = {};
  const interval = CONFIG.DISPATCH.NODE_INTERVAL;
  for (const ch in S.mapTeam) {
    if (!S.clearedMaps[ch]) continue;
    if (!dispatchRate(ch).total) continue;
    S.mapNodeT[ch] = (S.mapNodeT[ch] || 0) + dt;
    let guard = 0;
    while (S.mapNodeT[ch] >= interval && guard < 20) {
      S.mapNodeT[ch] -= interval;
      guard++;
      const vein = fieldVeinLv(ch);
      const mat = 1 + vein;
      const herb = 3 + vein * 2;
      gainItem("material", mat);
      gainItem("herb", herb);
      if (typeof addEventLog === "function") {
        const nm = (CONFIG.fieldMap(parseInt(ch, 10)) || {}).name || "秘境";
        addEventLog(`驻守·${nm} 采集点刷新，弟子采得灵材 ${mat}、灵草 ${herb}`);
      }
    }
  }
}

// 资源点刷新剩余秒数（UI 用）
function dispatchNodeLeft(ch) {
  const interval = CONFIG.DISPATCH.NODE_INTERVAL;
  const t = (S.mapNodeT && S.mapNodeT[ch]) || 0;
  return Math.max(0, Math.ceil(interval - t));
}
