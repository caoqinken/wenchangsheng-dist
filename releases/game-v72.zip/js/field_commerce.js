// ============================================================
// 《问长生》私有秘境经营：拍卖行 / 丹药阁 / 炼器阁（v0.56.2）
// NPC 需求是每日有限订单；所有商品从玩家统一储物法器库存扣除。
// ============================================================
const FIELD_COMMERCE = {
  FACILITIES: {
    auction: { name: "拍卖行", cost: 360, desc: "综合收购灵草、灵材与丹药；每日订单有限。" },
    alchemy: { name: "丹药阁", cost: 480, desc: "收购培元丹与渡劫丹，直接对接洞府炼丹产出。" },
    forge: { name: "炼器阁", cost: 720, desc: "收购未装备的真实法宝成品，不生成虚构货物。" },
    cave: { name: "修行洞府", cost: 900, desc: "修士可迁入修行；洞府容量决定本地修士人口上限。" },
  },
  GOODS: {
    auction: ["herb", "material", "pill", "tribPill"],
    alchemy: ["pill", "tribPill"],
    forge: [],
    cave: [],
  },
};

function fieldCommerceDayKey() {
  const t = S.gameTime || {};
  return `${t.year || 1}-${t.month || 1}-${t.day || 1}`;
}

function fieldCommerceOf(ch, create) {
  if (!S.fieldCommerce || typeof S.fieldCommerce !== "object") S.fieldCommerce = {};
  const k = String(ch);
  if (!S.fieldCommerce[k] && create !== false) S.fieldCommerce[k] = { buildings: {}, market: {} };
  const c = S.fieldCommerce[k] || null;
  if (c) {
    if (!c.buildings || typeof c.buildings !== "object") c.buildings = {};
    if (!c.market || typeof c.market !== "object") c.market = {};
    for (const key of Object.keys(FIELD_COMMERCE.FACILITIES)) c.buildings[key] = Math.max(0, Math.min(1, Math.floor(Number(c.buildings[key]) || 0)));
  }
  return c;
}

function fieldCommerceEnsureBudget(ch) {
  const c = fieldCommerceOf(ch, true);
  const day = fieldCommerceDayKey();
  if (!c.budget || c.budget.day !== day) {
    const residents = typeof fieldResidentsSummary === "function" ? fieldResidentsSummary(ch).cultivators : 0;
    const shops = Object.keys(c.buildings || {}).filter(k => c.buildings[k] > 0).length;
    // 有限外来商旅采购金：基础商旅额度 + 本地修士消费力 + 已营业设施吸引力；每日封顶。
    const issued = Math.min(700, 100 + residents * 35 + shops * 25);
    // 本地修士消费金是共享采购预算中的专属划拨，不是第二套货币发行。
    const residentBook = typeof fieldResidentsOf === "function" ? fieldResidentsOf(ch, false) : null;
    const jobs = typeof fieldResidentJobPlan === "function" ? fieldResidentJobPlan(ch, residentBook) : { employed: 0 };
    const residentAllocation = Math.min(issued, jobs.employed * 35);
    c.budget = { day, issued, remaining: issued - residentAllocation, spent: residentAllocation, residentAllocation, residentFunded: 0, rentReserved: 0 };
  }
  const b = c.budget;
  b.issued = Math.max(0, Number(b.issued) || 0);
  b.remaining = Math.max(0, Math.min(b.issued, Number(b.remaining) || 0));
  b.spent = Math.max(0, Math.min(b.issued, Number(b.spent) || 0));
  b.residentAllocation = Math.max(0, Math.min(b.issued, Number(b.residentAllocation) || 0));
  b.residentFunded = Math.max(0, Math.floor(Number(b.residentFunded) || 0));
  b.rentReserved = 0; // v0.56.8 起租金由修士个人钱包支付；兼容旧字段但不再预留。
  return b;
}

function fieldCommerceEnsureMarket(ch, facility) {
  const c = fieldCommerceOf(ch, true);
  const day = fieldCommerceDayKey();
  let m = c.market[facility];
  if (!m || m.day !== day) {
    const chapter = Math.max(0, Number(ch) || 0);
    const demand = {};
    for (const key of FIELD_COMMERCE.GOODS[facility] || []) {
      demand[key] = key === "pill" ? 2 + Math.floor(chapter / 2)
        : key === "tribPill" ? 1 + Math.floor(chapter / 3)
        : 4 + chapter;
    }
    if (facility === "forge") demand.artifact = 1;
    m = c.market[facility] = { day, demand, sold: {} };
  }
  if (!m.demand || typeof m.demand !== "object") m.demand = {};
  if (!m.sold || typeof m.sold !== "object") m.sold = {};
  return m;
}

function fieldCommerceCanOperate(ch) {
  return !!(S.clearedMaps && S.clearedMaps[ch] && typeof fieldEducationOf === "function" && fieldEducationOf(ch, false) && fieldEducationOf(ch, false).private);
}

function buildFieldCommerce(ch, facility) {
  const def = FIELD_COMMERCE.FACILITIES[facility];
  if (!def) return { ok: false, msg: "未知经营设施" };
  if (!fieldCommerceCanOperate(ch)) return { ok: false, msg: "秘境尚未完成教化私有化，暂不能开设商铺" };
  const c = fieldCommerceOf(ch, true);
  if (c.buildings[facility] >= 1) return { ok: false, msg: `${def.name}已建成` };
  if ((Number(S.stone) || 0) < def.cost) return { ok: false, msg: `灵石不足：需要 ${def.cost} 灵石` };
  S.stone -= def.cost;
  c.buildings[facility] = 1;
  fieldCommerceEnsureMarket(ch, facility);
  if (typeof addEventLog === "function") addEventLog(`【秘境经营】${mapNameOf(ch)}建成${def.name}，开始接待往来修士。`);
  if (typeof save === "function") save();
  return { ok: true, facility, lv: 1, cost: def.cost };
}

function fieldCommercePrice(ch, facility, key, artifact) {
  let base = 0;
  if (artifact) {
    const t = typeof tierInfo === "function" ? tierInfo(artifact.tier) : null;
    base = t ? Number(t.stone) || 0 : 0;
    return Math.max(1, Math.floor(base * 1.25));
  }
  if (key === "herb") base = Number(S.market.herb) || 0;
  else if (key === "pill") base = Number(S.market.pill) || 0;
  else if (key === "tribPill") base = Number(S.market.tribPill) || 0;
  else if (key === "material") base = Number(S.market.material) || 0;
  const facilityLv = fieldCommerceOf(ch, true).buildings[facility] || 1;
  return Math.max(1, Math.floor(base * (1.08 + facilityLv * 0.04)));
}

function fieldCommerceSell(ch, facility, key, quantity) {
  if (!fieldCommerceCanOperate(ch)) return { ok: false, msg: "秘境未私有化，无法交易" };
  const c = fieldCommerceOf(ch, true);
  if (!(c.buildings[facility] > 0)) return { ok: false, msg: `${(FIELD_COMMERCE.FACILITIES[facility] || {}).name || "设施"}尚未建成` };
  const n = Number(quantity);
  if (!Number.isInteger(n) || n <= 0) return { ok: false, msg: "交易数量必须为正整数" };
  const market = fieldCommerceEnsureMarket(ch, facility);
  let artifact = null;
  let demandKey = key;
  if (facility === "forge") {
    if (!/^art:\d+$/.test(String(key))) return { ok: false, msg: "炼器阁只收购未装备的法宝成品" };
    const id = Number(String(key).slice(4));
    artifact = (S.artifacts || []).find(a => Number(a.id) === id);
    if (!artifact || n !== 1) return { ok: false, msg: "法宝不存在或数量无效" };
    if (typeof slotOfArtifact === "function" && slotOfArtifact(artifact.id)) return { ok: false, msg: "已装备法宝不可出售，请先卸下" };
    if (!S.bag.slots.some(st => st && st.key === key && st.n >= 1)) return { ok: false, msg: "法宝不在储物法器内" };
    demandKey = "artifact";
  } else if (!(FIELD_COMMERCE.GOODS[facility] || []).includes(key)) {
    return { ok: false, msg: "该商铺不收购此类商品" };
  }
  const left = Math.max(0, Number(market.demand[demandKey]) || 0);
  if (left < n) return { ok: false, msg: `今日收购余量不足：还可出售 ${left} 件` };
  const unit = fieldCommercePrice(ch, facility, key, artifact);
  const total = unit * n;
  const budget = fieldCommerceEnsureBudget(ch);
  const spendable = budget.remaining;
  if (spendable < total) return { ok: false, msg: `今日NPC可用采购预算不足：可用${spendable}灵石（修士消费金已独立划拨），本笔需${total}灵石` };
  // 法宝实体和库存格必须同步移除；普通商品通过统一库存严格扣除。
  const removed = fieldWarehouseTake(key, n);
  if (!removed.ok) return removed;
  if (artifact) S.artifacts = (S.artifacts || []).filter(a => Number(a.id) !== Number(artifact.id));
  market.demand[demandKey] = left - n;
  market.sold[demandKey] = (Number(market.sold[demandKey]) || 0) + n;
  S.stone = (Number(S.stone) || 0) + total;
  budget.remaining -= total;
  budget.spent += total;
  if (typeof save === "function") save();
  return { ok: true, key, n, unit, total, remaining: market.demand[demandKey], name: artifact ? artifact.name : ((invItemDef(key) || {}).name || key) };
}

function fieldCommercePanelHtml(ch) {
  const c = fieldCommerceOf(ch, true);
  const map = FIELD_COMMERCE.FACILITIES;
  if (!fieldCommerceCanOperate(ch)) return `<div class="sec-title small">秘境经营</div><div class="build-out muted">完成教化并私有化后，方可建设拍卖行、丹药阁、炼器阁与修行洞府。</div>`;
  const budget = fieldCommerceEnsureBudget(ch);
  const sections = Object.keys(map).map(facility => {
    const def = map[facility];
    const lv = c.buildings[facility] || 0;
    if (!lv) return `<div class="shop-row"><span class="shop-body"><b>${def.name}</b><span class="shop-desc">${def.desc}</span></span><button class="btn-sm" data-action="fieldcommercebuild" data-ch="${ch}" data-facility="${facility}">建设（${def.cost}灵石）</button></div>`;
    const market = fieldCommerceEnsureMarket(ch, facility);
    let offers = [];
    if (facility === "cave") {
      const residents = typeof fieldResidentsSummary === "function" ? fieldResidentsSummary(ch) : { cultivators: 0, capacity: 0, progress: 0 };
      offers.push(`<div class="shop-row"><span class="shop-body"><b>本地修士</b><span class="shop-desc">${Math.floor(residents.cultivators)} / ${residents.capacity} 人 · 流入进度 ${(residents.progress * 100).toFixed(1)}% · 累计迁入 ${residents.totalArrived || 0} · 迁出 ${residents.totalDeparted || 0} · 凡人转化 ${residents.converted || 0} · 就业 ${residents.employed || 0}人 / 待业 ${residents.unemployed || 0}人 · 钱包余额 ${residents.walletBalance || 0}灵石</span></span><span class="muted">每日自然流入</span></div>`);
      offers.push(`<div class="shop-row"><span class="shop-body"><b>洞府租赁</b><span class="shop-desc">每名本地修士每日租金2灵石，由个人钱包支付；累计收取 ${residents.totalRentPaid || 0} 灵石，本日实收 ${residents.lastRentPaid || 0} 灵石；钱包累计收入 ${residents.walletIncome || 0}，支出 ${residents.walletSpent || 0}。</span></span><span class="muted">个人钱包结算</span></div>`);
      for (const key of ["pill", "tribPill"]) {
        const have = Math.floor(invCount(key));
        if (have <= 0) continue;
        const defn = invItemDef(key), unit = Math.max(1, Math.floor((Number(key === "pill" ? S.market.pill : S.market.tribPill) || 0) * 1.25));
        const day = fieldCommerceDayKey();
        const eligible = (fieldResidentsOf(ch, false).wallets || []).filter(w => w.purchasesDay !== day && w.balance >= unit).length;
        const afford = Math.min(eligible, Math.floor((residents.walletBalance || 0) / unit));
        const n = Math.min(have, afford, 3);
        if (n > 0) offers.push(`<div class="shop-row"><span class="shop-body"><b>居民购买${esc(defn.name)}</b><span class="shop-desc">玩家库存 ${have} · 居民报价 ${unit}/枚 · 钱包可购 ${afford}</span></span><button class="btn-sm" data-action="fieldresidentbuy" data-ch="${ch}" data-key="${key}" data-n="${n}">出售 ${n} 枚</button></div>`);
      }
      const folk = typeof settlementPopulation === "function" ? settlementPopulation(ch) : 0;
      offers.push(`<div class="shop-row"><span class="shop-body"><b>教化引修</b><span class="shop-desc">本地凡人 ${Math.floor(folk)} 人；需教化≥25%、安定度≥50。每次消耗10名凡人与800灵石，培养1名修士。</span></span><button class="btn-sm" data-action="fieldresidentconvert" data-ch="${ch}" ${residents.cultivators >= residents.capacity || folk < 10 ? "disabled" : ""}>转化修士</button></div>`);
    } else if (facility === "forge") {
      for (const st of S.bag.slots || []) {
        if (!st || !/^art:\d+$/.test(st.key)) continue;
        const a = (S.artifacts || []).find(x => Number(x.id) === Number(st.key.slice(4)));
        if (!a || (typeof slotOfArtifact === "function" && slotOfArtifact(a.id))) continue;
        const remaining = Number(market.demand.artifact) || 0;
        const price = fieldCommercePrice(ch, facility, st.key, a);
        offers.push(`<div class="shop-row"><span class="shop-body"><b>${esc(a.name)}</b><span class="shop-desc">${esc((tierInfo(a.tier) || {}).name || "法宝")} · NPC报价 ${price} 灵石 · 今日余量 ${remaining}</span></span><button class="btn-sm" data-action="fieldcommercesell" data-ch="${ch}" data-facility="forge" data-key="${esc(st.key)}" data-n="1" ${remaining < 1 ? "disabled" : ""}>出售</button></div>`);
      }
    } else {
      for (const key of FIELD_COMMERCE.GOODS[facility]) {
        const have = invCount(key), remaining = Number(market.demand[key]) || 0;
        if (have <= 0 || remaining <= 0) continue;
        const defn = invItemDef(key), price = fieldCommercePrice(ch, facility, key);
        const n = Math.min(Math.floor(have), remaining);
        offers.push(`<div class="shop-row"><span class="shop-body"><b>${esc(defn.name)}</b><span class="shop-desc">持有 ${Math.floor(have)} · NPC报价 ${price}/件 · 今日收购 ${remaining}</span></span><button class="btn-sm" data-action="fieldcommercesell" data-ch="${ch}" data-facility="${facility}" data-key="${esc(key)}" data-n="${n}">出售 ${n} 件</button></div>`);
      }
    }
    const caveTip = facility === "cave" ? "修士流入受教化、安定度与商铺繁荣影响；人口独立于凡人聚落和弟子名册。" : "今日需求每日刷新；售出商品从统一库房扣除。";
    return `<div class="shop-row"><span class="shop-body"><b>${def.name} · 已建成</b><span class="shop-desc">${def.desc} ${caveTip}</span></span><span class="muted">Lv.${lv}</span></div>${offers.join("") || `<div class="build-out muted">暂无可成交商品（可能库存不足或今日订单已售罄）。</div>`}`;
  }).join("");
  return `<div class="sec-title small">秘境经营设施</div><div class="build-out">今日NPC共享资金池：${budget.remaining} / ${budget.issued} 灵石（已划拨/支出 ${budget.spent}，岗位工资划拨 ${budget.residentAllocation || 0}）；修士钱包与商铺采购均来自同一发行额度。</div><div class="shop-list">${sections}</div><div class="tip">NPC 订单与采购预算均有每日上限；每日发行额度拆分为设施岗位工资与商铺采购金，二者不重复铸币。洞府租金由修士钱包支付，居民消费则把钱包余额转给玩家。炼器阁仅收未装备且真实存在于储物法器中的法宝。</div>`;
}
