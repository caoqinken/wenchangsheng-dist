// ============================================================
// 《问长生》弟子系统（NPC 自主行为，v0.4.1）
// 弟子：有资质/境界/忠诚/心境/委派，自主修炼成长，低忠诚可能流失
// ============================================================

let discipleIdSeq = 1;

// 读档后按已有最大 id 同步序列（旧版从不同步，刷新页面后新弟子必然与旧弟子撞号）
function refreshDiscipleSeq() {
  let maxId = 0;
  for (const d of (S.disciples || [])) {
    if (d && typeof d.id === "number" && d.id > maxId) maxId = d.id;
  }
  discipleIdSeq = maxId + 1;
}

// 生成一名新弟子（资质按权重随机）
function createDisciple() {
  return {
    id: discipleIdSeq++,
    name: CONFIG.DISCIPLE_NAMES[Math.floor(Math.random() * CONFIG.DISCIPLE_NAMES.length)],
    aptitude: rollAptitude(),
    realm: 0, layer: 0,
    loyalty: 60, mood: 80,
    assignedTo: null,
    cultivation: 0,
    specialty: rollSpecialty(),   // v0.10.0 专精
    bond: 0,                      // v0.10.0 师徒情谊
  };
}

function rollAptitude() {
  const w = CONFIG.APTITUDE_WEIGHT;
  const r = Math.random();
  let acc = 0;
  for (let i = 0; i < w.length; i++) {
    acc += w[i];
    if (r < acc) return i + 1;
  }
  return 1;
}

// 专精随机（均匀分布，避免早期就锁死玩法）
function rollSpecialty() {
  const list = CONFIG.SPECIALTIES;
  return list[Math.floor(Math.random() * list.length)].key;
}

function specialtyInfo(key) {
  return CONFIG.SPECIALTIES.find(x => x.key === key) || CONFIG.SPECIALTIES[0];
}

function aptitudeInfo(level) {
  return CONFIG.APTITUDES.find(a => a.level === level) || CONFIG.APTITUDES[0];
}

// 弟子修为成长统一入口：任务、职守、师尊培养都走同一套升层规则。
function discipleAddGrowth(d, amount) {
  if (!d || !isFinite(Number(amount)) || Number(amount) <= 0) return { gained: 0, levels: 0 };
  const threshold = Math.max(1, Number(CONFIG.DISCIPLE_GROWTH_THRESHOLD) || 50);
  const maxRealm = CONFIG.REALMS.length - 1;
  if ((d.realm || 0) >= maxRealm && (d.layer || 0) >= CONFIG.LAYERS_PER_REALM - 1) return { gained: 0, levels: 0 };
  d.cultivation = Math.max(0, Number(d.cultivation) || 0) + Number(amount);
  let levels = 0;
  while (d.cultivation >= threshold && levels < 1000) {
    if ((d.realm || 0) >= maxRealm && (d.layer || 0) >= CONFIG.LAYERS_PER_REALM - 1) {
      d.cultivation = Math.min(d.cultivation, threshold - 1);
      break;
    }
    d.cultivation -= threshold;
    d.layer = (d.layer || 0) + 1;
    if (d.layer >= CONFIG.LAYERS_PER_REALM) {
      d.layer = 0;
      d.realm = Math.min((d.realm || 0) + 1, maxRealm);
    }
    levels++;
  }
  return { gained: Number(amount), levels };
}

function discipleGrowthWorkMult(d) {
  const G = CONFIG.DISCIPLE_GROWTH || {};
  if (typeof discipleBusy === "function" && discipleBusy(d.id)) return G.MISSION_MULT || 1;
  if (typeof dispatchTeamIds === "function" && dispatchTeamIds().map(String).includes(String(d.id))) return G.DISPATCH_MULT || 1;
  if (d.assignedTo) return G.BUILD_MULT || 1;
  return G.IDLE_MULT || 1;
}

// 师尊亲自培养：不设每日次数/经验上限，资源充足即可持续培养。
// 灵气与培元丹仍按次扣除，资源不足时不会产生修为。
function trainDisciple(id, method, requestedCount = 1) {
  const d = S.disciples.find(x => String(x.id) === String(id));
  if (!d) return { ok: false, msg: "弟子不存在" };
  const G = CONFIG.DISCIPLE_GROWTH || {};
  const gain = method === "qi" ? G.QI_EXP : method === "pill" ? G.PILL_EXP : 0;
  if (!gain) return { ok: false, msg: "未知培养方式" };
  const threshold = Math.max(1, Number(CONFIG.DISCIPLE_GROWTH_THRESHOLD) || 50);
  const maxRealm = CONFIG.REALMS.length - 1;
  const layersLeft = (maxRealm - (d.realm || 0)) * CONFIG.LAYERS_PER_REALM + (CONFIG.LAYERS_PER_REALM - 1 - (d.layer || 0));
  const expCapacity = Math.max(0, layersLeft * threshold - (Number(d.cultivation) || 0));
  if (expCapacity <= 0) return { ok: false, msg: "该弟子已达当前体系最高境界" };

  const resourceCount = method === "qi"
    ? Math.floor((Number(S.qi) || 0) / Math.max(1, G.QI_COST))
    : (typeof invCount === "function" ? invCount("pill") : Math.max(0, Number(S.pills) || 0));
  const maxAffordable = Math.max(0, Math.floor(resourceCount));
  const maxUseful = Math.max(1, Math.ceil(expCapacity / gain));
  const wanted = requestedCount === "max" ? maxUseful : Math.max(1, Math.floor(Number(requestedCount) || 1));
  const count = Math.min(wanted, maxAffordable, maxUseful);
  if (count <= 0) return { ok: false, msg: method === "qi" ? `灵气不足（每次需 ${fmt(G.QI_COST)}）` : "培元丹不足" };

  const totalGain = gain * count;
  const cost = method === "qi" ? G.QI_COST * count : count;
  if (method === "qi") S.qi -= cost;
  else if (typeof invRemove === "function") invRemove("pill", count);
  else S.pills -= count;

  const before = `${CONFIG.REALMS[d.realm] || "未知"}${(d.layer || 0) + 1}层`;
  const result = discipleAddGrowth(d, totalGain);
  const after = `${CONFIG.REALMS[d.realm] || "未知"}${(d.layer || 0) + 1}层`;
  save();
  return { ok: true, gain: totalGain, unitGain: gain, count, cost, method, before, after, levels: result.levels, cultivation: d.cultivation };
}

// 每日 NPC 自主行为：闲置/洞府职守/秘境驻守/任务获得不同成长。
function npcTick() {
  const leaveList = [];
  for (const d of S.disciples) {
    const apt = aptitudeInfo(d.aptitude);
    const workMult = discipleGrowthWorkMult(d);
    const growth = apt.growth * (d.mood / 100) * workMult;
    discipleAddGrowth(d, growth);
    // 师徒情谊：委派中增长更快；情谊深者忠诚不再自然下降
    const bondGain = (d.assignedTo || (typeof dispatchTeamIds === "function" && dispatchTeamIds().map(String).includes(String(d.id))))
      ? CONFIG.BOND_GAIN_ASSIGNED : CONFIG.BOND_GAIN_IDLE;
    d.bond = Math.min(CONFIG.BOND_MAX, (d.bond || 0) + bondGain);
    // 心境波动
    d.mood = Math.max(0, Math.min(100, d.mood + (Math.random() * 10 - 5)));
    // 忠诚随心境缓慢变化
    if (d.mood > 70) d.loyalty = Math.min(100, d.loyalty + 0.5);
    else if (d.mood < 40 && (d.bond || 0) < CONFIG.BOND_LOYALTY_GUARD) {
      d.loyalty = Math.max(0, d.loyalty - 1);
    }
    if (d.loyalty < CONFIG.DISCIPLE_LOYALTY_LEAVE && Math.random() < CONFIG.DISCIPLE_LEAVE_CHANCE) leaveList.push(d);
  }
  if (leaveList.length) {
    S.disciples = S.disciples.filter(d => !leaveList.includes(d));
    addEventLog(`${leaveList.map(d => d.name).join("、")} 因忠诚低下而离山`);
  }
}

// 弟子产出加成：基础 × 资质 × 境界 × 忠诚
function discipleOutputBonus(d) {
  const apt = aptitudeInfo(d.aptitude);
  const realmMult = 1 + CONFIG.DISCIPLE_REALM_OUTPUT * d.realm;
  const loyaltyMult = 0.7 + 0.006 * d.loyalty;  // 0.7 ~ 1.3
  // 专精匹配（v0.10.0）：委派到自身专精建筑，产出 +50%
  const specMult = (d.specialty && d.assignedTo === d.specialty)
    ? (1 + CONFIG.SPECIALTY_MATCH_BONUS) : 1;
  // 嫡传（v0.10.0）：情谊 ≥ 90 再 +20%
  const bondMult = (d.bond || 0) >= CONFIG.BOND_ELITE_THRESHOLD
    ? (1 + CONFIG.BOND_ELITE_BONUS) : 1;
  return CONFIG.DISCIPLE_OUTPUT_BASE * apt.outputMult * realmMult * loyaltyMult * specMult * bondMult;
}

// 专精是否匹配当前委派（UI 用）
function specialtyMatched(d) {
  return !!(d && d.specialty && d.assignedTo === d.specialty);
}

// 师徒称号（UI 用）
function bondTitle(d) {
  const b = d.bond || 0;
  if (b >= CONFIG.BOND_ELITE_THRESHOLD) return "嫡传";
  if (b >= CONFIG.BOND_LOYALTY_GUARD) return "亲近";
  if (b >= 30) return "相熟";
  return "生疏";
}

// 空闲弟子数
function idleDisciples() {
  return S.disciples.filter(d => d.assignedTo === null).length;
}

// 某建筑委派弟子数
function assignedCount(key) {
  return S.disciples.filter(d => d.assignedTo === key).length;
}

// ---------- 声望提弟子资质（v0.8.0） ----------
// 比"直接招募仙品"更有意义：玩家可以定向培养已有弟子，声望获得长期用途
function repAptitudeCost(d) {
  if (!d) return null;
  if (d.aptitude >= 3) return null;                       // 已是仙品
  return CONFIG.REP_APTITUDE_COST[d.aptitude] || null;
}

function upgradeDiscipleAptitude(id) {
  const d = S.disciples.find(x => x.id === id);
  if (!d) return { ok: false, msg: "弟子不存在" };
  if (d.aptitude >= 3) return { ok: false, msg: "已是仙品，无需再提" };
  const cost = repAptitudeCost(d);
  if (cost == null) return { ok: false, msg: "无法提升资质" };
  if ((S.reputation || 0) < cost) return { ok: false, msg: `声望不足（需 ${cost}）` };
  S.reputation -= cost;
  const before = aptitudeInfo(d.aptitude).name;
  d.aptitude++;
  save();
  return { ok: true, cost, name: d.name, before, after: aptitudeInfo(d.aptitude).name };
}
