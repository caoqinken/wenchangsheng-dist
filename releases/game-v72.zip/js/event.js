// ============================================================
// 《问长生》世界事件系统
// v0.4.2 引入多阶段事件链；v0.6.1 扩展为四条链 + 两个自动事件
// 每条链：起因（条件 + 概率 + 冷却）→ 多阶段过程（玩家逐段抉择）
//        → 终局结算（势力 / 经济 / 资产 / 因果记录）
// 设计约束：起因可解释、过程可感知、后果落到具体资源，禁止无意义随机刷屏
// ============================================================

// 记录事件（因果追溯）
function addEventLog(text) {
  S.eventLog.unshift({ day: dateStr(), text });
  if (S.eventLog.length > 30) S.eventLog.length = 30;
}

// ---------- 冷却与判定辅助 ----------

// 累计天数（用于事件链冷却计时）
function totalDays() {
  const g = S.gameTime;
  return ((g.year - 1) * CONFIG.MONTHS_PER_YEAR + (g.month - 1)) * CONFIG.DAYS_PER_MONTH + g.day;
}

// 该事件链是否已过冷却
function eventChainReady(chain) {
  const cd = S.eventCooldown || {};
  if (cd[chain] == null) return true;
  return totalDays() - cd[chain] >= CONFIG.EVENT_COOLDOWN_DAYS;
}

// 记录该链本次触发日
function markChain(chain) {
  if (!S.eventCooldown) S.eventCooldown = {};
  S.eventCooldown[chain] = totalDays();
  // 事件图鉴收录（v0.6.5）
  if (typeof recordEventCodex === "function") recordEventCodex(chain);
}

// 事件战斗判定：ratio = 敌方战力 / 我方战力
// 胜率 = p/(p+enemy)，钳制在 [MIN, MAX]，避免碾压必胜或必败
function eventCombat(ratio) {
  const p = Math.max(1, playerPower());
  const enemy = p * ratio;
  const rate = Math.max(CONFIG.EVENT_WIN_RATE_MIN, Math.min(CONFIG.EVENT_WIN_RATE_MAX, p / (p + enemy)));
  return { win: Math.random() < rate, rate, enemyPower: enemy };
}

// 下一个待触发的境界专属事件（已达境界且未完成）
function pendingRealmEvent() {
  if (!S.milestones) S.milestones = {};
  for (const e of CONFIG.REALM_EVENTS) {
    if (S.realm >= e.realm && !S.milestones[e.key]) return e;
  }
  return null;
}

// ---------- 每日事件判定 ----------
function eventTick() {
  if (S.activeEvent) return;   // 已有待处理事件则不叠加

  // ⓪ 境界专属剧情事件：达成境界即触发一次（最高优先级，不受冷却限制）
  const re = pendingRealmEvent();
  if (re) {
    S.activeEvent = { chain: re.key, stage: 1, flags: {} };
    S.milestones[re.key] = totalDays();
    if (typeof recordEventCodex === "function") recordEventCodex(re.key);
    addEventLog(re.key === "heartdemon"
      ? "【金丹·心魔劫】金丹初结，道心不稳，心魔自幻象中生出。"
      : "【元婴·紫府洞天】元婴初成可神游，你在紫府深处窥见一处上古禁制。");
    return;
  }

  const qingyun = S.factions.qingyun, moyuan = S.factions.moyuan, sanxiu = S.factions.sanxiu;

  // ① 魔渊入侵：魔渊实力明显强于青云门时才可能进犯（v0.4.2 原链）
  if (moyuan.power > qingyun.power + 10 && eventChainReady("invasion")
      && Math.random() < (CONFIG.EVENT_CHANCE.invasion || 0)) {
    S.activeEvent = { chain: "invasion", stage: 1, flags: {} };
    markChain("invasion");
    addEventLog("【魔渊入侵·集结】魔渊宗兵力异动，意图进犯青云门领地！");
    return;
  }

  // ② 妖兽潮：自然事件，与势力无关（v0.6.1）
  if (eventChainReady("beasttide") && Math.random() < CONFIG.EVENT_CHANCE.beasttide) {
    S.activeEvent = { chain: "beasttide", stage: 1, flags: {} };
    markChain("beasttide");
    addEventLog("【妖兽潮·异动】山外妖云翻滚，兽群正朝洞府聚拢！");
    return;
  }

  // ③ 散修拍卖会：需与散修联盟关系达标（v0.6.1）
  if (sanxiu.relation >= CONFIG.AUCTION_REL_MIN && eventChainReady("auction")
      && Math.random() < CONFIG.EVENT_CHANCE.auction) {
    S.activeEvent = { chain: "auction", stage: 1, flags: {} };
    markChain("auction");
    addEventLog("【散修拍卖会】散修联盟传讯：坊市即将开槌，有上古灵材压轴。");
    return;
  }

  // ④ 魔道夺宝：持有法宝才会被魔修盯上（v0.6.1，法宝系统的风险面）
  if (S.artifacts && S.artifacts.length > 0 && eventChainReady("demonraid")
      && Math.random() < CONFIG.EVENT_CHANCE.demonraid) {
    S.activeEvent = { chain: "demonraid", stage: 1, flags: {} };
    markChain("demonraid");
    addEventLog("【魔道夺宝·窥伺】有魔修在洞府外徘徊，觊觎你的法宝。");
    return;
  }

  // ④b 古战场遗迹（v0.11.0）：金丹以上才有资格踏入
  if (S.realm >= CONFIG.BATTLEGROUND_MIN_REALM && eventChainReady("battleground")
      && Math.random() < CONFIG.EVENT_CHANCE.battleground) {
    S.activeEvent = { chain: "battleground", stage: 1, flags: {} };
    markChain("battleground");
    addEventLog("【古战场遗迹·现世】山崩露出一角残破战阵，断兵锈甲间仍有残魂游走。");
    return;
  }

  // ④c 丹道大会（v0.11.0）：需有一定炼丹根基
  if ((S.buildings.alchemy || 0) >= CONFIG.PILLMEET_MIN_ALCHEMY && eventChainReady("pillmeet")
      && Math.random() < CONFIG.EVENT_CHANCE.pillmeet) {
    S.activeEvent = { chain: "pillmeet", stage: 1, flags: {} };
    markChain("pillmeet");
    addEventLog("【丹道大会·请柬】散修联盟递来请柬：三日后丹道大会，以丹会友。");
    return;
  }

  // ⑤ 秘境开启：正向自动结算（v0.4.0 原事件）
  if (Math.random() < CONFIG.EVENT_SECRET_REALM_CHANCE) {
    const gain = CONFIG.breakCost(kNow()) * 0.1;
    S.qi += gain;
    S.reputation += 5;
    marketShock("pill", 0.7);   // 秘境丹药流出 → 丹药跌价
    if (typeof recordEventCodex === "function") recordEventCodex("secretrealm");
    addEventLog(`一处上古秘境开启，你入内参悟，灵气 +${fmt(gain)}，声望 +5；坊市丹药价格回落`);
    return;
  }

  // ⑥ 灵矿现世：正向自动结算，灵材供给增加（v0.6.1）
  if (Math.random() < CONFIG.EVENT_MINERAL_CHANCE) {
    const n = 5 + Math.floor(Math.random() * 6);
    gainItem("material", n);
    marketShock("material", 0.8);
    if (typeof recordEventCodex === "function") recordEventCodex("mineral");
    addEventLog(`一处灵矿现世，你抢先开采灵材 ×${n}；坊市灵材价格回落`);
  }
}

// ---------- 事件卡描述（数据驱动，UI 只负责渲染） ----------
function eventMeta(ev) {
  const c = ev.chain;

  if (c === "battleground") {
    if (ev.stage === 1) {
      return {
        title: "⚔ 古战场遗迹",
        desc: "残破战阵下埋着上古修士的遗物，也埋着未散的杀意。是深入探取，还是在外围捡些便宜？",
        choices: [
          { key: "enter", label: "探入战阵（体力 -1，一战）", primary: true },
          { key: "search", label: `外围搜刮（灵材 +${CONFIG.BATTLEGROUND_SEARCH_MAT}）` },
        ],
      };
    }
    return {
      title: "⚔ 古战场遗迹 · 阵心",
      desc: "你破开阵眼，残兵堆里有两样东西值得带走：一具尚可用的器胚，与一排无人收敛的骨灰。",
      choices: [
        { key: "loot", label: `掘取残兵（灵材 +${CONFIG.BATTLEGROUND_MAT}、法宝）`, primary: true },
        { key: "bury", label: `收敛遗骨（声望 +${CONFIG.BATTLEGROUND_BONE_REP}、青云门关系 +${CONFIG.BATTLEGROUND_BONE_REL}）` },
      ],
    };
  }

  if (c === "pillmeet") {
    if (ev.stage === 1) {
      return {
        title: "🏮 丹道大会",
        desc: `群修云集，以丹论道。赴会需备 ${CONFIG.PILLMEET_ENTRY_PILLS} 枚丹药作礼。`,
        choices: [
          { key: "attend", label: `赴会（丹药 -${CONFIG.PILLMEET_ENTRY_PILLS}）`, primary: true },
          { key: "skip", label: "不出席" },
        ],
      };
    }
    return {
      title: "🏮 丹道大会 · 比试",
      desc: `台上比的是丹，台下比的是道。斗丹需再耗 ${CONFIG.PILLMEET_CONTEST_PILLS} 枚丹药开炉。`,
      choices: [
        { key: "contest", label: `开炉斗丹（丹药 -${CONFIG.PILLMEET_CONTEST_PILLS}）`, primary: true },
        { key: "watch", label: `台下观摩（声望 +${CONFIG.PILLMEET_WATCH_REP}）` },
      ],
    };
  }

  if (c === "heartdemon") {
    return {
      title: "☯ 金丹·心魔劫",
      desc: "金丹初结，道心不稳，心魔化作旧日幻象缠身。是直面它，还是以灵石静心守一？",
      choices: [
        { key: "face", label: "直面心魔（一战）", primary: true },
        { key: "calm", label: `静心守一（灵石 -${CONFIG.HEARTDEMON_STONE}）` },
      ],
    };
  }

  if (c === "zifu") {
    if (ev.stage === 1) {
      return {
        title: "☯ 元婴·紫府洞天",
        desc: "元婴可离体神游，你在紫府深处窥见一处上古洞天禁制。",
        choices: [
          { key: "enter", label: `破禁而入（灵石 -${CONFIG.ZIFU_ENTER_STONE}）`, primary: true },
          { key: "meditate", label: "仅在外围吐纳" },
        ],
      };
    }
    return {
      title: "☯ 元婴·洞天内景",
      desc: "洞天深处宝光隐现，亦有凶险气息盘踞。",
      choices: [
        { key: "treasure", label: "探取洞天宝物（一战）", primary: true },
        { key: "material", label: "采灵材即退" },
      ],
    };
  }

  if (c === "huashen") {
    return {
      title: "☯ 化神·神识化虚",
      desc: "神识初成却未凝实，虚空中生出无数杂念回声，扰你道心。如何应对？",
      choices: [
        { key: "gaze", label: "参悟虚空（一战）", primary: true },
        { key: "condense", label: `凝练神识（灵气 -${Math.round(CONFIG.HUASHEN_QI_LOSS * 100)}%）` },
        { key: "hold", label: "稳守本心" },
      ],
    };
  }

  if (c === "lianxu") {
    if (ev.stage === 1) {
      return {
        title: "☯ 炼虚·虚空裂缝",
        desc: "炼虚之际，天地间裂开一道虚空缝隙，内有灵气与凶险同存。",
        choices: [
          { key: "enter", label: `探入裂缝（灵石 -${CONFIG.LIANXU_ENTER_STONE}）`, primary: true },
          { key: "seal", label: "封镇裂缝" },
        ],
      };
    }
    return {
      title: "☯ 炼虚·虚空深处",
      desc: "虚空深处有宝物浮沉，亦有守御之灵窥视来者。",
      choices: [
        { key: "deepen", label: "深入取宝（一战）", primary: true },
        { key: "echo", label: "回溯虚影" },
      ],
    };
  }

  if (c === "heti") {
    return {
      title: "☯ 合体·道基归一",
      desc: "元婴与肉身需合而为一，此番肉身将寸寸崩解重塑。要稳妥固本，还是硬抗过去？",
      choices: [
        { key: "harden", label: `以灵材固本（灵材 -${CONFIG.HETI_MAT}、灵石 -${fmt(CONFIG.HETI_STONE)}）`, primary: true },
        { key: "force", label: "硬合肉身（一战）" },
      ],
    };
  }

  if (c === "dacheng") {
    if (ev.stage === 1) {
      return {
        title: "☯ 大乘·众生愿力",
        desc: "大乘道果需众生愿力滋养。是下山传道，还是闭关自守？",
        choices: [
          { key: "preach", label: `下山传道（灵石 -${fmt(CONFIG.DACHENG_STONE)}）`, primary: true },
          { key: "seclude", label: "闭关自守" },
        ],
      };
    }
    return {
      title: "☯ 大乘·法会",
      desc: "你于人间广开法会，众生叩首，愿力汇聚如潮。",
      choices: [
        { key: "gather", label: "广纳愿力", primary: true },
        { key: "quiet", label: "只取一缕" },
      ],
    };
  }

  if (c === "dujie") {
    return {
      title: "☯ 渡劫·九霄雷劫",
      desc: "飞升在即，九霄雷云压顶。此劫一过，便登仙途。",
      choices: [
        { key: "resist", label: "硬抗雷劫（一战）", primary: true },
        { key: "sacrifice", label: "以法宝挡劫（消耗一件未装备法宝）" },
        { key: "wait", label: "静待雷消" },
      ],
    };
  }

  if (c === "invasion") {
    if (ev.stage === 1) {
      return {
        title: "⚠ 魔渊入侵 · 传信",
        desc: "魔渊宗兵力异动，意图进犯青云门领地。是否提前示警？",
        choices: [
          { key: "warn", label: "传信青云门（-20灵石）", primary: true },
          { key: "wait", label: "静观其变" },
        ],
      };
    }
    return {
      title: "⚠ 魔渊入侵 · 妖兽潮",
      desc: "妖兽潮涌向青云门领地，战火将起。是否出手相助？",
      choices: [
        { key: "help", label: "援助青云门（体力-5）", primary: true },
        { key: "ignore", label: "袖手旁观" },
      ],
    };
  }

  if (c === "beasttide") {
    if (ev.stage === 1) {
      return {
        title: "⚠ 妖兽潮 · 异动",
        desc: "妖云压境，兽群正朝洞府聚拢。是否出洞探查？",
        choices: [
          { key: "scout", label: `出洞探查（体力 -${CONFIG.BEASTTIDE_SCOUT_STAMINA}）`, primary: true },
          { key: "closer", label: "紧闭山门" },
        ],
      };
    }
    return {
      title: "⚠ 妖兽潮 · 冲击",
      desc: ev.flags.scouted
        ? "你已摸清兽群规模与路线，此时迎战胜算更高。"
        : "兽群情况不明，贸然迎战风险极大。",
      choices: [
        { key: "fight", label: `迎战（体力 -${CONFIG.BEASTTIDE_FIGHT_STAMINA}）`, primary: true },
        { key: "avoid", label: `布阵避战（灵石 -${CONFIG.BEASTTIDE_AVOID_STONE}）` },
      ],
    };
  }

  if (c === "auction") {
    if (ev.stage === 1) {
      return {
        title: "◈ 散修拍卖会 · 开槌",
        desc: "散修联盟广邀同道，压轴是一批上古灵材（法宝炼制原料）。",
        choices: [
          { key: "enter", label: `入场（灵石 -${CONFIG.AUCTION_ENTRY_COST}）`, primary: true },
          { key: "skip", label: "过门不入" },
        ],
      };
    }
    return {
      title: "◈ 散修拍卖会 · 竞价",
      desc: `压轴灵材开拍（灵材 ×${CONFIG.AUCTION_MATERIAL_REWARD}）。你要出价吗？`,
      choices: [
        { key: "bid", label: `竞价（灵石 -${CONFIG.AUCTION_BID_COST}）`, primary: true },
        { key: "pass", label: "按兵不动" },
      ],
    };
  }

  if (c === "demonraid") {
    if (ev.stage === 1) {
      return {
        title: "☠ 魔道夺宝 · 窥伺",
        desc: "魔修盯上了你的法宝。是布阵设伏，还是正面迎击？",
        choices: [
          { key: "array", label: `布迷阵（灵石 -${CONFIG.DEMONRAID_ARRAY_STONE}、灵材 -${CONFIG.DEMONRAID_ARRAY_MATERIAL}）`, primary: true },
          { key: "direct", label: "正面迎击" },
        ],
      };
    }
    return {
      title: "☠ 魔道夺宝 · 交手",
      desc: ev.flags.array ? "迷阵已成，魔修踏入彀中。" : "魔修杀至洞府门前，气势汹汹。",
      choices: [
        { key: "fight", label: "出手一战", primary: true },
        { key: "yield", label: "以宝换命（交出法宝）" },
      ],
    };
  }

  return { title: "未知事件", desc: "", choices: [{ key: "ignore", label: "置之不理" }] };
}

// ---------- 玩家介入（按事件链分发） ----------
function resolveEvent(choice) {
  if (!S.activeEvent) return { ok: false, msg: "当前无待处理事件" };
  const ev = S.activeEvent;
  let r;
  switch (ev.chain) {
    case "invasion":  r = resolveInvasion(ev, choice); break;
    case "beasttide": r = resolveBeastTide(ev, choice); break;
    case "auction":   r = resolveAuction(ev, choice); break;
    case "demonraid": r = resolveDemonRaid(ev, choice); break;
    case "heartdemon": r = resolveHeartDemon(ev, choice); break;
    case "zifu":       r = resolveZifu(ev, choice); break;
    case "huashen":    r = resolveHuashen(ev, choice); break;
    case "lianxu":     r = resolveLianxu(ev, choice); break;
    case "heti":       r = resolveHeti(ev, choice); break;
    case "dacheng":    r = resolveDacheng(ev, choice); break;
    case "dujie":      r = resolveDujie(ev, choice); break;
    case "battleground": r = resolveBattleground(ev, choice); break;
    case "pillmeet":   r = resolvePillMeet(ev, choice); break;
    default:          r = { ok: true, summary: "事件已了结" };
  }
  if (r.ok) {
    save();
    if (!r.next) S.activeEvent = null;   // 终局结算后关闭事件
  }
  return r;
}

// ---------- 「魔渊入侵」三阶段事件链（v0.4.2） ----------
function resolveInvasion(ev, choice) {
  // ---- 阶段 1：传信（情报抉择）----
  if (ev.stage === 1) {
    if (choice === "warn") {
      if (S.stone < 20) return { ok: false, msg: "灵石不足（需 20）" };
      S.stone -= 20;
      S.factions.qingyun.relation = clampRel(S.factions.qingyun.relation + 10);
      ev.flags.warned = true;
      addEventLog("【魔渊入侵】你快马传信青云门（-20灵石）：青云门关系 +10，早有防备");
      ev.stage = 2;
      return { ok: true, next: true, summary: "已传信青云门，关系 +10" };
    }
    addEventLog("【魔渊入侵】你静观其变，青云门对即将到来的危机一无所知");
    ev.stage = 2;
    return { ok: true, next: true, summary: "你选择静观其变" };
  }
  // ---- 阶段 2：妖兽潮（介入抉择）----
  if (ev.stage === 2) {
    if (choice === "help") {
      if (S.stamina < 5) return { ok: false, msg: "体力不足（需 5 点）" };
      S.stamina -= 5;
      S.factions.qingyun.relation = clampRel(S.factions.qingyun.relation + 30);
      S.factions.qingyun.power += 5;
      S.factions.qingyun.resource += 30;
      S.reputation += 10;
      const reward = 50 + S.bestStage * 20;
      S.stone += reward;
      ev.flags.helped = true;
      addEventLog(`【魔渊入侵】你出手击退妖兽潮：青云门关系 +30，声望 +10，获灵石 ${fmt(reward)}`);
    } else {
      S.factions.qingyun.power -= 10;
      S.factions.qingyun.resource -= 20;
      if (S.factions.qingyun.resource < 0) S.factions.qingyun.resource = 0;
      S.factions.moyuan.power += 5;
      addEventLog("【魔渊入侵】你袖手旁观，青云门损失惨重（实力 -10），魔渊宗得势（实力 +5）");
    }
    const text = resolveInvasionEnd(ev);   // 阶段 3：终局结算
    return { ok: true, title: "魔渊入侵 · 尘埃落定", summary: text, tone: ev.flags.helped ? "win" : "lose" };
  }
  return { ok: true, summary: "事件已了结" };
}

// 事件链终局结算：势力格局 + 经济冲击（因果联动）
function resolveInvasionEnd(ev) {
  // 战乱 → 灵草短缺涨价（出手相助则涨幅更小）
  marketShock("herb", ev.flags.helped ? 1.3 : 1.6);
  let text = "";
  if (ev.flags.warned && ev.flags.helped) {
    S.factions.moyuan.power = Math.max(5, S.factions.moyuan.power - 10);
    S.factions.qingyun.power += 5;
    S.reputation += 5;
    text = "大胜！因你通风报信并出手相助，青云门大破魔渊宗。魔渊宗实力 -10，声望 +5";
  } else if (ev.flags.helped) {
    text = "击退！妖兽潮被击退，但青云门元气大伤";
  } else if (ev.flags.warned) {
    S.factions.qingyun.power -= 5;
    text = "重创！青云门虽有防备仍遭重创（实力 -5）";
  } else {
    text = "惨败！青云门措手不及，损失惨重";
  }
  addEventLog("【魔渊入侵·终局】" + text);
  return text;
}

// ---------- 「妖兽潮」三阶段事件链（v0.6.1） ----------
function resolveBeastTide(ev, choice) {
  // ---- 阶段 1：异动（情报抉择）----
  if (ev.stage === 1) {
    if (choice === "scout") {
      if (S.stamina < CONFIG.BEASTTIDE_SCOUT_STAMINA) {
        return { ok: false, msg: `体力不足（需 ${CONFIG.BEASTTIDE_SCOUT_STAMINA}）` };
      }
      S.stamina -= CONFIG.BEASTTIDE_SCOUT_STAMINA;
      ev.flags.scouted = true;
      addEventLog("【妖兽潮】你出洞探查，摸清兽群规模与路线（下一战更从容）");
    } else {
      ev.flags.scouted = false;
      addEventLog("【妖兽潮】你紧闭山门，对外面情况一无所知");
    }
    ev.stage = 2;
    return { ok: true, next: true, summary: ev.flags.scouted ? "探查完成，知己知彼" : "山门紧闭，情况不明" };
  }
  // ---- 阶段 2：冲击（迎战 / 避战）----
  if (ev.stage === 2) {
    if (choice === "fight") {
      if (S.stamina < CONFIG.BEASTTIDE_FIGHT_STAMINA) {
        return { ok: false, msg: `体力不足（需 ${CONFIG.BEASTTIDE_FIGHT_STAMINA}）` };
      }
      S.stamina -= CONFIG.BEASTTIDE_FIGHT_STAMINA;
      const ratio = ev.flags.scouted ? CONFIG.BEASTTIDE_RATIO_SCOUTED : CONFIG.BEASTTIDE_RATIO_BLIND;
      const c = eventCombat(ratio);
      marketShock("herb", 1.25);   // 战乱 → 灵草涨价
      if (c.win) {
        const reward = 100 + S.bestStage * 30;
        S.stone += reward;
        gainItem("material", CONFIG.BEASTTIDE_REWARD_MAT);
        S.reputation += CONFIG.BEASTTIDE_REP;
        addEventLog(`【妖兽潮·大胜】你击退兽群：灵石 +${fmt(reward)}、灵材 +${CONFIG.BEASTTIDE_REWARD_MAT}、声望 +${CONFIG.BEASTTIDE_REP}；灵草借势涨价`);
        return {
          ok: true, win: true, rate: c.rate, tone: "win",
          title: "妖兽潮 · 大胜",
          summary: `你击退兽群：灵石 +${fmt(reward)}、灵材 +${CONFIG.BEASTTIDE_REWARD_MAT}、声望 +${CONFIG.BEASTTIDE_REP}（胜率 ${Math.round(c.rate * 100)}%）；灵草涨价`,
        };
      }
      const lostHerb = Math.floor(S.herbs * CONFIG.BEASTTIDE_HERB_LOSS);
      invRemove("herb", lostHerb);
      S.stamina = 0;
      addEventLog(`【妖兽潮·败退】兽群冲毁灵田，灵草 -${lostHerb}，你力竭退守；灵草价格飙升`);
      return {
        ok: true, win: false, rate: c.rate, tone: "lose",
        title: "妖兽潮 · 败退",
        summary: `你不敌兽群（胜率 ${Math.round(c.rate * 100)}%）：灵草 -${lostHerb}，体力耗尽，灵草价格飙升`,
      };
    }
    if (choice === "avoid") {
      const cost = CONFIG.BEASTTIDE_AVOID_STONE;
      if (S.stone < cost) return { ok: false, msg: `灵石不足（需 ${cost}）` };
      S.stone -= cost;
      const lostHerb = Math.floor(S.herbs * CONFIG.BEASTTIDE_AVOID_HERB_LOSS);
      invRemove("herb", lostHerb);
      marketShock("herb", 1.15);
      addEventLog(`【妖兽潮·避战】你布阵驱散兽群（-${cost} 灵石），灵草轻微受损 ${lostHerb}`);
      return {
        ok: true, avoided: true, tone: "win",
        title: "妖兽潮 · 避战",
        summary: `你布阵驱散兽群：灵石 -${cost}，灵草 -${lostHerb}`,
      };
    }
    return { ok: false, msg: "无效选择" };
  }
  return { ok: true, summary: "事件已了结" };
}

// ---------- 「散修拍卖会」三阶段事件链（v0.6.1） ----------
function resolveAuction(ev, choice) {
  // ---- 阶段 1：是否入场 ----
  if (ev.stage === 1) {
    if (choice === "enter") {
      const cost = CONFIG.AUCTION_ENTRY_COST;
      if (S.stone < cost) return { ok: false, msg: `灵石不足（需 ${cost}）` };
      S.stone -= cost;
      ev.flags.entered = true;
      ev.stage = 2;
      addEventLog(`【拍卖会】你付出入场灵石，坐入雅间（-${cost} 灵石）`);
      return { ok: true, next: true, summary: `已入场，灵石 -${cost}` };
    }
    S.factions.sanxiu.relation = clampRel(S.factions.sanxiu.relation + CONFIG.AUCTION_REL_SKIP);
    addEventLog("【拍卖会】你过门不入，散修联盟略感不悦（关系 -5）");
    return {
      ok: true, tone: "lose",
      title: "拍卖会 · 错过",
      summary: `你过门不入，散修联盟略感不悦（关系 ${CONFIG.AUCTION_REL_SKIP}）`,
    };
  }
  // ---- 阶段 2：竞价 ----
  if (ev.stage === 2) {
    if (choice === "bid") {
      const cost = CONFIG.AUCTION_BID_COST;
      if (S.stone < cost) return { ok: false, msg: `灵石不足（需 ${cost}）` };
      S.stone -= cost;
      const rel = Math.max(0, S.factions.sanxiu.relation);
      const rate = Math.min(0.95, CONFIG.AUCTION_BASE_RATE + rel * CONFIG.AUCTION_REL_BONUS);
      if (Math.random() < rate) {
        const n = CONFIG.AUCTION_MATERIAL_REWARD;
        gainItem("material", n);
        S.reputation += 5;
        S.factions.sanxiu.relation = clampRel(S.factions.sanxiu.relation + CONFIG.AUCTION_REL_WIN);
        marketShock("material", 0.85);
        addEventLog(`【拍卖会·得手】你竞得上古灵材 ×${n}，声望 +5，散修关系 +${CONFIG.AUCTION_REL_WIN}；坊市灵材价格回落`);
        return {
          ok: true, win: true, rate, tone: "win",
          title: "拍卖会 · 得手",
          summary: `竞得灵材 ×${n}，声望 +5，散修关系 +${CONFIG.AUCTION_REL_WIN}（成功率 ${Math.round(rate * 100)}%）；灵材价格回落`,
        };
      }
      addEventLog(`【拍卖会·失手】灵材被他人截胡，灵石白花（成功率 ${Math.round(rate * 100)}%）`);
      return {
        ok: true, win: false, rate, tone: "lose",
        title: "拍卖会 · 失手",
        summary: `灵材被他人截胡，灵石白花（成功率 ${Math.round(rate * 100)}%）`,
      };
    }
    S.factions.sanxiu.relation = clampRel(S.factions.sanxiu.relation + CONFIG.AUCTION_REL_PASS);
    addEventLog("【拍卖会】你按兵不动，散修联盟觉得你识趣（关系 +3）");
    return {
      ok: true, tone: "win",
      title: "拍卖会 · 收手",
      summary: `你没有出价，散修联盟觉得你识趣（关系 +${CONFIG.AUCTION_REL_PASS}）`,
    };
  }
  return { ok: true, summary: "事件已了结" };
}

// ---------- 「魔道夺宝」三阶段事件链（v0.6.1） ----------
function resolveDemonRaid(ev, choice) {
  // ---- 阶段 1：应敌方式 ----
  if (ev.stage === 1) {
    if (choice === "array") {
      const needStone = CONFIG.DEMONRAID_ARRAY_STONE;
      const needMat = CONFIG.DEMONRAID_ARRAY_MATERIAL;
      if (S.stone < needStone) return { ok: false, msg: `灵石不足（需 ${needStone}）` };
      if ((S.materials || 0) < needMat) return { ok: false, msg: `灵材不足（需 ${needMat}）` };
      S.stone -= needStone;
      invRemove("material", needMat);
      ev.flags.array = true;
      ev.stage = 2;
      addEventLog("【魔道夺宝】你以灵材布下迷阵，静候魔修入彀");
      return { ok: true, next: true, summary: `迷阵已布（灵石 -${needStone}、灵材 -${needMat}）` };
    }
    ev.flags.array = false;
    addEventLog("【魔道夺宝】你不设埋伏，正面迎敌");
    ev.stage = 2;
    return { ok: true, next: true, summary: "你决定正面迎敌" };
  }
  // ---- 阶段 2：交手 / 以宝换命 ----
  if (ev.stage === 2) {
    if (choice === "yield") {
      const r = takeSpareArtifact();
      S.factions.moyuan.relation = clampRel(S.factions.moyuan.relation + 5);
      if (r) {
        addEventLog(`【魔道夺宝·求和】你交出法宝「${r.name}」换得平安（魔渊关系 +5）`);
        return {
          ok: true, win: false, tone: "lose",
          title: "魔道夺宝 · 以宝换命",
          summary: `你交出法宝「${r.name}」，魔修放过你（魔渊关系 +5）`,
        };
      }
      const lostStone = Math.floor(S.stone * CONFIG.DEMONRAID_LOSE_STONE_RATIO);
      S.stone -= lostStone;
      addEventLog(`【魔道夺宝·求和】你无宝可献，被迫献上灵石 ${fmt(lostStone)}（魔渊关系 +5）`);
      return {
        ok: true, win: false, tone: "lose",
        title: "魔道夺宝 · 破财",
        summary: `你无宝可献，被迫献上灵石 ${fmt(lostStone)}（魔渊关系 +5）`,
      };
    }
    // 出手一战
    const ratio = ev.flags.array ? CONFIG.DEMONRAID_RATIO_ARRAY : CONFIG.DEMONRAID_RATIO_DIRECT;
    const c = eventCombat(ratio);
    if (c.win) {
      const mat = CONFIG.DEMONRAID_WIN_MAT;
      const stone = 60 + S.bestStage * 20;
      gainItem("material", mat);
      S.stone += stone;
      S.reputation += CONFIG.DEMONRAID_REP;
      S.factions.moyuan.relation = clampRel(S.factions.moyuan.relation - CONFIG.DEMONRAID_REL_PENALTY);
      addEventLog(`【魔道夺宝·反杀】你击溃魔修：灵材 +${mat}、灵石 +${fmt(stone)}、声望 +${CONFIG.DEMONRAID_REP}；魔渊宗怀恨（关系 -${CONFIG.DEMONRAID_REL_PENALTY}）`);
      return {
        ok: true, win: true, rate: c.rate, tone: "win",
        title: "魔道夺宝 · 反杀",
        summary: `你击溃魔修：灵材 +${mat}、灵石 +${fmt(stone)}、声望 +${CONFIG.DEMONRAID_REP}（胜率 ${Math.round(c.rate * 100)}%）；魔渊关系 -${CONFIG.DEMONRAID_REL_PENALTY}`,
      };
    }
    S.factions.moyuan.relation = clampRel(S.factions.moyuan.relation - CONFIG.DEMONRAID_LOSE_REL_PENALTY);
    const lost = takeSpareArtifact();
    if (lost) {
      addEventLog(`【魔道夺宝·失宝】你败退，法宝「${lost.name}」被魔修夺走（魔渊关系 -${CONFIG.DEMONRAID_LOSE_REL_PENALTY}）`);
      return {
        ok: true, win: false, rate: c.rate, tone: "lose",
        title: "魔道夺宝 · 失宝",
        summary: `你不敌魔修（胜率 ${Math.round(c.rate * 100)}%），法宝「${lost.name}」被夺走；魔渊关系 -${CONFIG.DEMONRAID_LOSE_REL_PENALTY}`,
      };
    }
    const lostStone = Math.floor(S.stone * CONFIG.DEMONRAID_LOSE_STONE_RATIO);
    S.stone -= lostStone;
    addEventLog(`【魔道夺宝·败走】你败退，损失灵石 ${fmt(lostStone)}（魔渊关系 -${CONFIG.DEMONRAID_LOSE_REL_PENALTY}）`);
    return {
      ok: true, win: false, rate: c.rate, tone: "lose",
      title: "魔道夺宝 · 败走",
      summary: `你不敌魔修（胜率 ${Math.round(c.rate * 100)}%），损失灵石 ${fmt(lostStone)}；魔渊关系 -${CONFIG.DEMONRAID_LOSE_REL_PENALTY}`,
    };
  }
  return { ok: true, summary: "事件已了结" };
}

// 取一件未装备法宝（优先品质最低者），没有则返回 null
function takeSpareArtifact() {
  const eq = S.equipped || {};
  const spare = (S.artifacts || []).filter(a =>
    eq.attack !== a.id && eq.defense !== a.id && eq.support !== a.id);
  if (!spare.length) return null;
  spare.sort((x, y) => artifactScore(x) - artifactScore(y));
  const lost = spare[0];
  invTakeArtifact(lost.id);
  S.artifacts = S.artifacts.filter(a => a.id !== lost.id);
  return lost;
}

// ---------- 「金丹·心魔劫」境界专属事件（v0.6.2） ----------
// 一次性的道心试炼：硬闯有风险高回报，静心守一稳但需灵石
function resolveHeartDemon(ev, choice) {
  if (choice === "face") {
    const c = eventCombat(CONFIG.HEARTDEMON_RATIO);
    if (c.win) {
      const qiGain = CONFIG.breakCost(kNow()) * CONFIG.HEARTDEMON_REWARD_QI;
      S.qi += qiGain;
      gainItem("material", CONFIG.HEARTDEMON_REWARD_MAT);
      S.reputation += 10;
      addEventLog(`【心魔劫·破妄】你斩破心魔幻象：灵气 +${fmt(qiGain)}、灵材 +${CONFIG.HEARTDEMON_REWARD_MAT}、声望 +10`);
      return {
        ok: true, win: true, rate: c.rate, tone: "win",
        title: "心魔劫 · 破妄",
        summary: `你斩破心魔（胜率 ${Math.round(c.rate * 100)}%）：灵气 +${fmt(qiGain)}、灵材 +${CONFIG.HEARTDEMON_REWARD_MAT}、声望 +10`,
      };
    }
    const lost = Math.floor(S.qi * CONFIG.HEARTDEMON_FAIL_QI);
    S.qi -= lost;
    S.stamina = 0;
    addEventLog(`【心魔劫·走火】你不敌心魔，灵气逸散 ${fmt(lost)}，力竭昏沉`);
    return {
      ok: true, win: false, rate: c.rate, tone: "lose",
      title: "心魔劫 · 走火入魔",
      summary: `你不敌心魔（胜率 ${Math.round(c.rate * 100)}%）：灵气 -${fmt(lost)}，体力耗尽`,
    };
  }
  if (choice === "calm") {
    const cost = CONFIG.HEARTDEMON_STONE;
    if (S.stone < cost) return { ok: false, msg: `灵石不足（需 ${cost}）` };
    S.stone -= cost;
    gainItem("material", 5);
    S.reputation += 5;
    addEventLog(`【心魔劫·守一】你以灵石为引静心守一，平稳渡过（灵石 -${cost}、灵材 +5、声望 +5）`);
    return {
      ok: true, win: true, tone: "win",
      title: "心魔劫 · 静心守一",
      summary: `你平稳渡过心魔：灵石 -${cost}、灵材 +5、声望 +5`,
    };
  }
  return { ok: true, summary: "心魔已散" };
}

// ---------- 「元婴·紫府洞天」境界专属事件（v0.6.2） ----------
function resolveZifu(ev, choice) {
  if (ev.stage === 1) {
    if (choice === "enter") {
      const cost = CONFIG.ZIFU_ENTER_STONE;
      if (S.stone < cost) return { ok: false, msg: `灵石不足（需 ${cost}）` };
      S.stone -= cost;
      ev.stage = 2;
      addEventLog(`【紫府洞天】你以灵石破开禁制，踏入洞天（灵石 -${cost}）`);
      return { ok: true, next: true, summary: `禁制已破，灵石 -${cost}` };
    }
    const gain = CONFIG.breakCost(kNow()) * 0.08;
    S.qi += gain;
    addEventLog(`【紫府洞天·吐纳】你在洞天外围吐纳，灵气 +${fmt(gain)}（未入内）`);
    return {
      ok: true, tone: "win",
      title: "紫府洞天 · 吐纳",
      summary: `你仅在外围吐纳：灵气 +${fmt(gain)}`,
    };
  }
  if (ev.stage === 2) {
    if (choice === "treasure") {
      const c = eventCombat(1.0);
      if (c.win) {
        const types = CONFIG.ARTIFACT_TYPES;
        const type = types[Math.floor(Math.random() * types.length)].key;
        const art = makeArtifact(CONFIG.ZIFU_ARTIFACT_TIER, type);
        S.artifacts.push(art);
        gainItem("material", 10);
        S.reputation += CONFIG.ZIFU_REWARD_REP;
        addEventLog(`【紫府洞天·得宝】你破开洞天守护，获得「${art.name}」（${artifactAttrText(art)}）、灵材 +10、声望 +${CONFIG.ZIFU_REWARD_REP}`);
        return {
          ok: true, win: true, rate: c.rate, tone: "win",
          title: "紫府洞天 · 得宝",
          summary: `得洞天法宝「${art.name}」（${artifactAttrText(art)}）、灵材 +10、声望 +${CONFIG.ZIFU_REWARD_REP}`,
        };
      }
      const lost = Math.floor(S.stone * 0.2);
      S.stone -= lost;
      S.reputation = Math.max(0, S.reputation - 5);
      addEventLog(`【紫府洞天·铩羽】洞天守护之力过强，你受创退出（灵石 -${fmt(lost)}、声望 -5）`);
      return {
        ok: true, win: false, rate: c.rate, tone: "lose",
        title: "紫府洞天 · 铩羽",
        summary: `你不敌洞天守护（胜率 ${Math.round(c.rate * 100)}%）：灵石 -${fmt(lost)}、声望 -5`,
      };
    }
    const n = CONFIG.ZIFU_REWARD_MAT;
    gainItem("material", n);
    S.reputation += 5;
    addEventLog(`【紫府洞天·采撷】你采得洞天灵材 ×${n}，全身而退（声望 +5）`);
    return {
      ok: true, tone: "win",
      title: "紫府洞天 · 采撷",
      summary: `你采得灵材 ×${n}，声望 +5`,
    };
  }
  return { ok: true, summary: "洞天已闭" };
}

// ---------- 「化神·神识化虚」境界专属事件（v0.6.3） ----------
// 三选一：搏收益（一战）/ 灵气换灵材声望 / 保守求稳（白得灵气）
function resolveHuashen(ev, choice) {
  if (choice === "gaze") {
    const c = eventCombat(CONFIG.HUASHEN_RATIO);
    if (c.win) {
      const qiGain = CONFIG.breakCost(kNow()) * 0.10;
      S.qi += qiGain;
      gainItem("material", CONFIG.HUASHEN_REWARD_MAT);
      S.reputation += CONFIG.HUASHEN_RATIO_REP;
      addEventLog(`【神识化虚·证道】你于杂念回声中断出真意：灵气 +${fmt(qiGain)}、灵材 +${CONFIG.HUASHEN_REWARD_MAT}、声望 +${CONFIG.HUASHEN_RATIO_REP}`);
      return {
        ok: true, win: true, rate: c.rate, tone: "win",
        title: "神识化虚 · 证道",
        summary: `你于虚空中断出真意（胜率 ${Math.round(c.rate * 100)}%）：灵气 +${fmt(qiGain)}、灵材 +${CONFIG.HUASHEN_REWARD_MAT}、声望 +${CONFIG.HUASHEN_RATIO_REP}`,
      };
    }
    const lost = Math.floor(S.qi * 0.15);
    S.qi -= lost;
    S.stamina = 0;
    addEventLog(`【神识化虚·神乱】杂念反噬，神识震荡：灵气 -${fmt(lost)}，力竭昏沉`);
    return {
      ok: true, win: false, rate: c.rate, tone: "lose",
      title: "神识化虚 · 神乱",
      summary: `杂念反噬（胜率 ${Math.round(c.rate * 100)}%）：灵气 -${fmt(lost)}，体力耗尽`,
    };
  }
  if (choice === "condense") {
    const cost = Math.floor(S.qi * CONFIG.HUASHEN_QI_LOSS);
    if (cost <= 0) return { ok: false, msg: "灵气不足，无法凝练神识" };
    S.qi -= cost;
    gainItem("material", 10);
    S.reputation += 8;
    addEventLog(`【神识化虚·凝神】你散去浮华灵气凝实神识：灵气 -${fmt(cost)}、灵材 +10、声望 +8`);
    return {
      ok: true, tone: "win",
      title: "神识化虚 · 凝神",
      summary: `你凝实神识：灵气 -${fmt(cost)}、灵材 +10、声望 +8`,
    };
  }
  // hold：稳守本心
  const gain = CONFIG.breakCost(kNow()) * CONFIG.HUASHEN_SEAL_QI;
  S.qi += gain;
  addEventLog(`【神识化虚·守心】你闭塞神识独守本心，杂念渐消：灵气 +${fmt(gain)}`);
  return {
    ok: true, tone: "win",
    title: "神识化虚 · 守心",
    summary: `你稳守本心，杂念渐消：灵气 +${fmt(gain)}`,
  };
}

// ---------- 「炼虚·虚空裂缝」境界专属事件（v0.6.3） ----------
function resolveLianxu(ev, choice) {
  if (ev.stage === 1) {
    if (choice === "enter") {
      const cost = CONFIG.LIANXU_ENTER_STONE;
      if (S.stone < cost) return { ok: false, msg: `灵石不足（需 ${cost}）` };
      S.stone -= cost;
      ev.stage = 2;
      addEventLog(`【虚空裂缝】你以灵石为锚探入裂缝（灵石 -${cost}）`);
      return { ok: true, next: true, summary: `已探入裂缝，灵石 -${cost}` };
    }
    S.reputation += CONFIG.LIANXU_SEAL_REP;
    S.factions.qingyun.relation = clampRel(S.factions.qingyun.relation + CONFIG.LIANXU_SEAL_REL);
    addEventLog(`【虚空裂缝·封镇】你以自身道基封镇裂缝，护一方安宁：声望 +${CONFIG.LIANXU_SEAL_REP}、青云门关系 +${CONFIG.LIANXU_SEAL_REL}`);
    return {
      ok: true, tone: "win",
      title: "虚空裂缝 · 封镇",
      summary: `你封镇裂缝：声望 +${CONFIG.LIANXU_SEAL_REP}、青云门关系 +${CONFIG.LIANXU_SEAL_REL}`,
    };
  }
  if (ev.stage === 2) {
    if (choice === "deepen") {
      const c = eventCombat(CONFIG.LIANXU_RATIO);
      if (c.win) {
        const types = CONFIG.ARTIFACT_TYPES;
        const type = types[Math.floor(Math.random() * types.length)].key;
        const art = makeArtifact(CONFIG.LIANXU_ARTIFACT_TIER, type);
        S.artifacts.push(art);
        gainItem("material", CONFIG.LIANXU_REWARD_MAT);
        S.reputation += CONFIG.LIANXU_REP;
        addEventLog(`【虚空裂缝·得宝】你击溃守御之灵，取回「${art.name}」（${artifactAttrText(art)}）、灵材 +${CONFIG.LIANXU_REWARD_MAT}、声望 +${CONFIG.LIANXU_REP}`);
        return {
          ok: true, win: true, rate: c.rate, tone: "win",
          title: "虚空裂缝 · 得宝",
          summary: `得灵宝「${art.name}」（${artifactAttrText(art)}）、灵材 +${CONFIG.LIANXU_REWARD_MAT}、声望 +${CONFIG.LIANXU_REP}`,
        };
      }
      const lost = Math.floor(S.stone * 0.25);
      S.stone -= lost;
      S.reputation = Math.max(0, S.reputation - 5);
      addEventLog(`【虚空裂缝·受创】守御之灵远强于预料，你被虚空乱流迫退（灵石 -${fmt(lost)}、声望 -5）`);
      return {
        ok: true, win: false, rate: c.rate, tone: "lose",
        title: "虚空裂缝 · 受创",
        summary: `你不敌守御之灵（胜率 ${Math.round(c.rate * 100)}%）：灵石 -${fmt(lost)}、声望 -5`,
      };
    }
    // echo：回溯虚影
    const gain = CONFIG.breakCost(kNow()) * CONFIG.LIANXU_ECHO_QI;
    S.qi += gain;
    gainItem("material", 8);
    addEventLog(`【虚空裂缝·观虚】你不取宝物，只静观虚空流转：灵气 +${fmt(gain)}、灵材 +8`);
    return {
      ok: true, tone: "win",
      title: "虚空裂缝 · 观虚",
      summary: `你静观虚空流转：灵气 +${fmt(gain)}、灵材 +8`,
    };
  }
  return { ok: true, summary: "裂缝已闭" };
}

// ---------- 「合体·道基归一」境界专属事件（v0.6.4） ----------
// 两选一：灵材固本（稳，有成本）vs 硬合肉身（搏，有风险有额外收益）
function resolveHeti(ev, choice) {
  if (choice === "harden") {
    if ((S.materials || 0) < CONFIG.HETI_MAT) return { ok: false, msg: `灵材不足（需 ${CONFIG.HETI_MAT}）` };
    if (S.stone < CONFIG.HETI_STONE) return { ok: false, msg: `灵石不足（需 ${fmt(CONFIG.HETI_STONE)}）` };
    invRemove("material", CONFIG.HETI_MAT);
    S.stone -= CONFIG.HETI_STONE;
    const gain = CONFIG.breakCost(kNow()) * CONFIG.HETI_QI;
    S.qi += gain;
    addEventLog(`【道基归一·固本】你以灵材温养肉身，稳渡合体：灵材 -${CONFIG.HETI_MAT}、灵石 -${fmt(CONFIG.HETI_STONE)}、灵气 +${fmt(gain)}`);
    return {
      ok: true, tone: "win",
      title: "道基归一 · 固本",
      summary: `你以灵材固本稳渡合体：灵材 -${CONFIG.HETI_MAT}、灵石 -${fmt(CONFIG.HETI_STONE)}、灵气 +${fmt(gain)}`,
    };
  }
  if (choice === "force") {
    const c = eventCombat(CONFIG.HETI_RATIO);
    if (c.win) {
      const gain = CONFIG.breakCost(kNow()) * CONFIG.HETI_WIN_QI;
      S.qi += gain;
      S.reputation += CONFIG.HETI_WIN_REP;
      gainItem("material", CONFIG.HETI_WIN_MAT);
      addEventLog(`【道基归一·破障】你硬合肉身成功，道基愈发圆融：灵气 +${fmt(gain)}、灵材 +${CONFIG.HETI_WIN_MAT}、声望 +${CONFIG.HETI_WIN_REP}`);
      return {
        ok: true, win: true, rate: c.rate, tone: "win",
        title: "道基归一 · 破障",
        summary: `你硬合肉身成功（胜率 ${Math.round(c.rate * 100)}%）：灵气 +${fmt(gain)}、灵材 +${CONFIG.HETI_WIN_MAT}、声望 +${CONFIG.HETI_WIN_REP}`,
      };
    }
    const lost = Math.floor(S.qi * CONFIG.HETI_FAIL_QI);
    S.qi -= lost;
    S.stamina = 0;
    addEventLog(`【道基归一·崩解】肉身承受不住强行合一，你重伤退守：灵气 -${fmt(lost)}`);
    return {
      ok: true, win: false, rate: c.rate, tone: "lose",
      title: "道基归一 · 崩解",
      summary: `肉身崩解受创（胜率 ${Math.round(c.rate * 100)}%）：灵气 -${fmt(lost)}，体力耗尽`,
    };
  }
  return { ok: true, summary: "道基已定" };
}

// ---------- 「大乘·众生愿力」境界专属事件（v0.6.4） ----------
function resolveDacheng(ev, choice) {
  if (ev.stage === 1) {
    if (choice === "preach") {
      const cost = CONFIG.DACHENG_STONE;
      if (S.stone < cost) return { ok: false, msg: `灵石不足（需 ${fmt(cost)}）` };
      S.stone -= cost;
      ev.stage = 2;
      addEventLog(`【众生愿力】你散尽灵石设坛讲道（灵石 -${fmt(cost)}），四方修士云集`);
      return { ok: true, next: true, summary: `法坛已设，灵石 -${fmt(cost)}` };
    }
    // seclude
    const gain = CONFIG.breakCost(kNow()) * CONFIG.DACHENG_QI;
    S.qi += gain;
    addEventLog(`【众生愿力·闭关】你闭关自守，不问世事：灵气 +${fmt(gain)}`);
    return {
      ok: true, tone: "win",
      title: "众生愿力 · 闭关",
      summary: `你闭关自守：灵气 +${fmt(gain)}`,
    };
  }
  if (ev.stage === 2) {
    if (choice === "gather") {
      S.reputation += CONFIG.DACHENG_REP;
      S.factions.qingyun.relation = clampRel(S.factions.qingyun.relation + CONFIG.DACHENG_REL);
      gainItem("material", CONFIG.DACHENG_MAT);
      addEventLog(`【众生愿力·法会】你广纳愿力：声望 +${CONFIG.DACHENG_REP}、青云门关系 +${CONFIG.DACHENG_REL}、灵材 +${CONFIG.DACHENG_MAT}`);
      return {
        ok: true, tone: "win",
        title: "众生愿力 · 法会",
        summary: `你广纳愿力：声望 +${CONFIG.DACHENG_REP}、青云门关系 +${CONFIG.DACHENG_REL}、灵材 +${CONFIG.DACHENG_MAT}`,
      };
    }
    // quiet
    const gain = CONFIG.breakCost(kNow()) * CONFIG.DACHENG_QI_GATHER;
    S.qi += gain;
    addEventLog(`【众生愿力·一缕】你只取一缕愿力，不扰众生：灵气 +${fmt(gain)}`);
    return {
      ok: true, tone: "win",
      title: "众生愿力 · 一缕",
      summary: `你只取一缕愿力：灵气 +${fmt(gain)}`,
    };
  }
  return { ok: true, summary: "愿力已散" };
}

// ---------- 「渡劫·九霄雷劫」境界专属事件（v0.6.4） ----------
// 飞升前的最后一劫：硬抗（高风险高回报）/ 献宝（稳但损失资产）/ 静待（保守）
function resolveDujie(ev, choice) {
  if (choice === "resist") {
    const c = eventCombat(CONFIG.DUJIE_RATIO);
    if (c.win) {
      const gain = CONFIG.breakCost(kNow()) * CONFIG.DUJIE_WIN_QI;
      S.qi += gain;
      S.reputation += CONFIG.DUJIE_WIN_REP;
      const types = CONFIG.ARTIFACT_TYPES;
      const type = types[Math.floor(Math.random() * types.length)].key;
      const art = makeArtifact(CONFIG.DUJIE_WIN_TIER, type);
      S.artifacts.push(art);
      addEventLog(`【九霄雷劫·破】你以道躯硬抗九霄雷劫，雷光洗体：灵气 +${fmt(gain)}、声望 +${CONFIG.DUJIE_WIN_REP}，并得「${art.name}」`);
      return {
        ok: true, win: true, rate: c.rate, tone: "win",
        title: "九霄雷劫 · 破",
        summary: `你硬抗雷劫成功（胜率 ${Math.round(c.rate * 100)}%）：灵气 +${fmt(gain)}、声望 +${CONFIG.DUJIE_WIN_REP}、法宝「${art.name}」`,
      };
    }
    const lost = Math.floor(S.qi * CONFIG.DUJIE_FAIL_QI);
    S.qi -= lost;
    S.stamina = 0;
    addEventLog(`【九霄雷劫·创】雷劫过重，你道躯受创：灵气 -${fmt(lost)}`);
    return {
      ok: true, win: false, rate: c.rate, tone: "lose",
      title: "九霄雷劫 · 创",
      summary: `你不敌雷劫（胜率 ${Math.round(c.rate * 100)}%）：灵气 -${fmt(lost)}，体力耗尽`,
    };
  }
  if (choice === "sacrifice") {
    const sac = takeSpareArtifact();
    if (!sac) return { ok: false, msg: "没有可牺牲的未装备法宝" };
    const gain = CONFIG.breakCost(kNow()) * CONFIG.DUJIE_SAC_QI;
    S.qi += gain;
    S.reputation += CONFIG.DUJIE_SAC_REP;
    addEventLog(`【九霄雷劫·代】你以「${sac.name}」代身引雷，法宝化灰：灵气 +${fmt(gain)}、声望 +${CONFIG.DUJIE_SAC_REP}`);
    return {
      ok: true, tone: "win",
      title: "九霄雷劫 · 代",
      summary: `「${sac.name}」代身引雷：灵气 +${fmt(gain)}、声望 +${CONFIG.DUJIE_SAC_REP}`,
    };
  }
  // wait（其余未知 choice 一律拒绝，避免传错参数白送收益）
  if (choice !== "wait" && choice !== "avoid") return { ok: false, msg: "无效选择" };
  const gain = CONFIG.breakCost(kNow()) * CONFIG.DUJIE_WAIT_QI;
  S.qi += gain;
  addEventLog(`【九霄雷劫·避】你退守洞府静待雷云散去：灵气 +${fmt(gain)}（雷劫未过，来日再战）`);
  return {
    ok: true, tone: "win",
    title: "九霄雷劫 · 避",
    summary: `你静待雷消：灵气 +${fmt(gain)}（雷劫未解，来日再战）`,
  };
}

// ---------- 古战场遗迹（v0.11.0） ----------
function resolveBattleground(ev, choice) {
  // 阶段 1
  if (ev.stage === 1) {
    if (choice === "search") {
      gainItem("material", CONFIG.BATTLEGROUND_SEARCH_MAT);
      addEventLog(`【古战场遗迹·外围】你只在残阵边缘翻找：灵材 +${CONFIG.BATTLEGROUND_SEARCH_MAT}`);
      return {
        ok: true, tone: "win",
        title: "古战场遗迹 · 外围",
        summary: `不涉险地，拾得灵材 +${CONFIG.BATTLEGROUND_SEARCH_MAT}`,
      };
    }
    // enter：消耗体力并一战
    if (S.stamina < 1) return { ok: false, msg: "体力不足，无法探入战阵" };
    S.stamina--;
    const r = eventCombat(CONFIG.BATTLEGROUND_RATIO);
    if (!r.win) {
      const loss = S.qi * 0.1;
      S.qi = Math.max(0, S.qi - loss);
      addEventLog(`【古战场遗迹·败退】阵中杀意太重，你负伤退出：灵气 -${fmt(loss)}`);
      return {
        ok: true, tone: "lose",
        title: "古战场遗迹 · 败退",
        summary: `残魂杀意未散，你负伤退出：灵气 -${fmt(loss)}`,
      };
    }
    ev.flags.entered = true;
    ev.stage = 2;
    addEventLog("【古战场遗迹·破阵】你压住残魂杀意，走入阵心。");
    return { ok: true, next: true, summary: "破阵而入，阵心尚有两样遗物" };
  }
  // 阶段 2
  if (choice === "bury") {
    S.reputation += CONFIG.BATTLEGROUND_BONE_REP;
    S.factions.qingyun.relation = clampRel(S.factions.qingyun.relation + CONFIG.BATTLEGROUND_BONE_REL);
    addEventLog(`【古战场遗迹·收骨】你收敛遗骨立碑：声望 +${CONFIG.BATTLEGROUND_BONE_REP}、青云门关系 +${CONFIG.BATTLEGROUND_BONE_REL}`);
    return {
      ok: true, tone: "win",
      title: "古战场遗迹 · 收骨",
      summary: `为前辈立碑：声望 +${CONFIG.BATTLEGROUND_BONE_REP}、青云门关系 +${CONFIG.BATTLEGROUND_BONE_REL}`,
    };
  }
  // loot
  gainItem("material", CONFIG.BATTLEGROUND_MAT);
  let art = null;
  if (typeof makeArtifact === "function") {
    art = makeArtifact(CONFIG.BATTLEGROUND_ART_TIER, ["attack", "defense", "support"][Math.floor(Math.random() * 3)]);
    art.fromRuins = true;              // 标记来源，便于后续扩展
    S.artifacts.push(art);
  }
  if (!S.stats) S.stats = {};
  S.stats.battlegroundWins = (S.stats.battlegroundWins || 0) + 1;
  addEventLog(`【古战场遗迹·拾遗】你掘出残兵：灵材 +${CONFIG.BATTLEGROUND_MAT}${art ? "、法宝「" + art.name + "」" : ""}`);
  return {
    ok: true, tone: "win",
    title: "古战场遗迹 · 拾遗",
    summary: `灵材 +${CONFIG.BATTLEGROUND_MAT}${art ? "，得法宝「" + art.name + "」（" + tierInfo(art.tier).name + "）" : ""}`,
  };
}

// ---------- 丹道大会（v0.11.0） ----------
function resolvePillMeet(ev, choice) {
  // 阶段 1
  if (ev.stage === 1) {
    if (choice === "skip") {
      addEventLog("【丹道大会】你未赴会，闭门自修。");
      return { ok: true, tone: "win", title: "丹道大会 · 未赴", summary: "你留在洞府，静心修炼" };
    }
    if (S.pills < CONFIG.PILLMEET_ENTRY_PILLS) {
      return { ok: false, msg: `丹药不足（需 ${CONFIG.PILLMEET_ENTRY_PILLS} 枚）` };
    }
    invRemove("pill", CONFIG.PILLMEET_ENTRY_PILLS);
    ev.stage = 2;
    addEventLog(`【丹道大会·入席】你备礼赴会（丹药 -${CONFIG.PILLMEET_ENTRY_PILLS}），席间有人邀你上台比丹。`);
    return { ok: true, next: true, summary: `赴会入席，丹药 -${CONFIG.PILLMEET_ENTRY_PILLS}` };
  }
  // 阶段 2：观摩
  if (choice === "watch") {
    S.reputation += CONFIG.PILLMEET_WATCH_REP;
    addEventLog(`【丹道大会·观摩】你细观诸家丹火：声望 +${CONFIG.PILLMEET_WATCH_REP}`);
    return {
      ok: true, tone: "win",
      title: "丹道大会 · 观摩",
      summary: `观他人丹火，有所得：声望 +${CONFIG.PILLMEET_WATCH_REP}`,
    };
  }
  // 阶段 2：斗丹
  if (S.pills < CONFIG.PILLMEET_CONTEST_PILLS) {
    return { ok: false, msg: `丹药不足（需 ${CONFIG.PILLMEET_CONTEST_PILLS} 枚）` };
  }
  invRemove("pill", CONFIG.PILLMEET_CONTEST_PILLS);
  // 斗丹胜率受炼丹房等级影响（经营投入有回报）
  const rate = Math.min(0.9, CONFIG.PILLMEET_CONTEST_RATE + (S.buildings.alchemy || 0) * 0.02);
  if (Math.random() < rate) {
    S.reputation += CONFIG.PILLMEET_WIN_REP;
    S.stone += CONFIG.PILLMEET_WIN_STONE;
    if (!S.stats) S.stats = {};
    S.stats.pillmeetWins = (S.stats.pillmeetWins || 0) + 1;
    addEventLog(`【丹道大会·夺魁】你的丹成色压过全场：声望 +${CONFIG.PILLMEET_WIN_REP}、灵石 +${fmt(CONFIG.PILLMEET_WIN_STONE)}`);
    return {
      ok: true, tone: "win",
      title: "丹道大会 · 夺魁",
      summary: `一举夺魁：声望 +${CONFIG.PILLMEET_WIN_REP}、灵石 +${fmt(CONFIG.PILLMEET_WIN_STONE)}（胜率 ${Math.round(rate * 100)}%）`,
    };
  }
  S.reputation += CONFIG.PILLMEET_LOSE_REP;
  addEventLog(`【丹道大会·落败】丹火不稳，未能入前三：声望 +${CONFIG.PILLMEET_LOSE_REP}（胜率 ${Math.round(rate * 100)}%）`);
  return {
    ok: true, tone: "lose",
    title: "丹道大会 · 落败",
    summary: `丹火不稳，未能入前三：声望 +${CONFIG.PILLMEET_LOSE_REP}（胜率 ${Math.round(rate * 100)}%）`,
  };
}
