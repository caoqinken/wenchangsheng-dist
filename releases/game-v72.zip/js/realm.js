// ============================================================
// 《问长生》秘境建设 / 养成 / 立宗（v0.31.0）
// 秘境资产化：矿场·药圃建设；法宝温养、神通参悟；驻守 3 处可立宗
// ============================================================

// ---------- 建设（矿场 / 药圃） ----------
function fieldMineLv(ch) { return (S.fieldMine && S.fieldMine[ch]) || 0; }
function fieldGardenLv(ch) { return (S.fieldGarden && S.fieldGarden[ch]) || 0; }

function fieldBuildCost(lv) {
  return Math.floor(CONFIG.FIELD_VEIN.COST_BASE * Math.pow(1.6, lv));
}

function upgradeFieldMine(ch) {
  if (!S.clearedMaps || !S.clearedMaps[ch]) return { ok: false, msg: "该秘境尚未探明" };
  const lv = fieldMineLv(ch);
  if (lv >= CONFIG.FIELD_VEIN.MAX) return { ok: false, msg: "矿场已至顶级" };
  const cost = fieldBuildCost(lv);
  if (S.stone < cost) return { ok: false, msg: "灵石不足" };
  // v0.32.0：升级需派驻矿工（凡人）
  const need = (typeof laborNeed === "function") ? laborNeed(lv + 1) : 0;
  if (need > 0 && (S.folk || 0) < need) return { ok: false, msg: `凡人不足（需 ${need} 名矿工）` };
  if (need > 0 && typeof consumeFolk === "function" && !consumeFolk(need, ch)) return { ok: false, msg: `本地聚落凡人不足（需 ${need} 名矿工）` };
  S.stone -= cost;
  if (need > 0) { if (typeof addFieldLabor === "function") addFieldLabor(ch, "mine", need); }
  if (!S.fieldMine) S.fieldMine = {};
  S.fieldMine[ch] = lv + 1;
  save();
  return { ok: true, lv: lv + 1, cost, need };
}

function upgradeFieldGarden(ch) {
  if (!S.clearedMaps || !S.clearedMaps[ch]) return { ok: false, msg: "该秘境尚未探明" };
  const lv = fieldGardenLv(ch);
  if (lv >= CONFIG.FIELD_VEIN.MAX) return { ok: false, msg: "药圃已至顶级" };
  const cost = fieldBuildCost(lv);
  if (S.stone < cost) return { ok: false, msg: "灵石不足" };
  // v0.32.0：升级需派驻药农（凡人）
  const need = (typeof laborNeed === "function") ? laborNeed(lv + 1) : 0;
  if (need > 0 && (S.folk || 0) < need) return { ok: false, msg: `凡人不足（需 ${need} 名药农）` };
  if (need > 0 && typeof consumeFolk === "function" && !consumeFolk(need, ch)) return { ok: false, msg: `本地聚落凡人不足（需 ${need} 名药农）` };
  S.stone -= cost;
  if (need > 0) { if (typeof addFieldLabor === "function") addFieldLabor(ch, "garden", need); }
  if (!S.fieldGarden) S.fieldGarden = {};
  S.fieldGarden[ch] = lv + 1;
  save();
  return { ok: true, lv: lv + 1, cost, need };
}

// ---------- 法宝温养 ----------
function artWarmLv(id) { return (S.artWarm && S.artWarm[id]) || 0; }
function artWarmMult(id) { return 1 + artWarmLv(id) * CONFIG.WARM.BONUS; }

function warmArtifact(id) {
  const a = (S.artifacts || []).find(x => x.id === id);
  if (!a) return { ok: false, msg: "法宝不存在" };
  const W = CONFIG.WARM;
  const lv = artWarmLv(id);
  if (lv >= W.MAX) return { ok: false, msg: "温养已满" };
  if ((S.materials || 0) < W.MAT) return { ok: false, msg: `灵材不足（需 ${W.MAT}）` };
  if (S.stone < W.STONE) return { ok: false, msg: `灵石不足（需 ${W.STONE}）` };
  invRemove("material", W.MAT);
  S.stone -= W.STONE;
  if (!S.artWarm) S.artWarm = {};
  S.artWarm[id] = lv + 1;
  save();
  return { ok: true, lv: lv + 1 };
}

// ---------- 神通参悟 ----------
function skillInsightLv(key) { return (S.skillInsight && S.skillInsight[key]) || 0; }
function skillInsightMult(key) { return 1 + skillInsightLv(key) * CONFIG.INSIGHT.BONUS; }

function insightSkill(key) {
  const sk = (typeof fldSkill === "function") ? fldSkill(key) : null;
  if (!sk) return { ok: false, msg: "无此神通" };
  const I = CONFIG.INSIGHT;
  const lv = skillInsightLv(key);
  if (lv >= I.MAX) return { ok: false, msg: "参悟已满" };
  if ((S.talisman || 0) < I.TALISMAN) return { ok: false, msg: `功法要诀不足（需 ${I.TALISMAN}）` };
  if (S.stone < I.STONE) return { ok: false, msg: `灵石不足（需 ${I.STONE}）` };
  invRemove("talisman", I.TALISMAN);
  S.stone -= I.STONE;
  if (!S.skillInsight) S.skillInsight = {};
  S.skillInsight[key] = lv + 1;
  save();
  return { ok: true, lv: lv + 1 };
}

// ---------- 立宗 ----------
function sectReady() {
  return (typeof playerTerritory === "function" ? playerTerritory() : 0) >= CONFIG.SECT.NEED_TERRITORY;
}

function sectUpgradeCost() {
  const C = CONFIG.SECT;
  const lv = (S.sect && S.sect.lv) || 0;
  return { stone: Math.floor(C.UP_STONE * Math.pow(1.5, lv)), spc: C.UP_SPC };
}

function highestClearedChapter() {
  const cleared = Object.keys(S.clearedMaps || {}).filter(k => S.clearedMaps[k]).map(Number);
  return cleared.length ? Math.max.apply(null, cleared) : -1;
}

function foundSect(name) {
  if (S.sect && S.sect.lv) return { ok: false, msg: "已立宗" };
  if (!sectReady()) {
    return { ok: false, msg: `需有 ${CONFIG.SECT.NEED_TERRITORY} 处驻守秘境作为根基（当前 ${playerTerritory()}）` };
  }
  const C = CONFIG.SECT;
  if (S.stone < C.BASE_STONE) return { ok: false, msg: `灵石不足（需 ${C.BASE_STONE}）` };
  const ch = highestClearedChapter();
  if (ch < 0) return { ok: false, msg: "需先探明至少一处秘境" };
  if (specialtyCount(ch) < C.BASE_SPC) {
    return { ok: false, msg: `${specialtyName(ch)}不足（需 ${C.BASE_SPC}）· 探索该章秘境可得` };
  }
  S.stone -= C.BASE_STONE;
  invRemove("sp:" + ch, C.BASE_SPC);
  S.sect = { name: (name || "长生宗").slice(0, 6), lv: 1 };
  save();
  return { ok: true, sect: S.sect };
}

function upgradeSect() {
  if (!S.sect || !S.sect.lv) return { ok: false, msg: "尚未立宗" };
  if (S.sect.lv >= CONFIG.SECT.MAX_LV) return { ok: false, msg: "宗门已至顶级" };
  const cost = sectUpgradeCost();
  if (S.stone < cost.stone) return { ok: false, msg: `灵石不足（需 ${cost.stone}）` };
  const ch = highestClearedChapter();
  if (ch < 0) return { ok: false, msg: "无可产出特产的秘境" };
  if (specialtyCount(ch) < cost.spc) return { ok: false, msg: `${specialtyName(ch)}不足（需 ${cost.spc}）` };
  S.stone -= cost.stone;
  invRemove("sp:" + ch, cost.spc);
  S.sect.lv += 1;
  save();
  return { ok: true, lv: S.sect.lv };
}

function sectSummary() {
  if (!S.sect || !S.sect.lv) return "尚未立宗";
  const C = CONFIG.SECT;
  return `${S.sect.name} Lv.${S.sect.lv} ｜ 全属性 +${(S.sect.lv * C.ATTR * 100).toFixed(1)}% ｜ 修炼 +${(S.sect.lv * C.CULT * 100).toFixed(0)}%`;
}
