// ============================================================
// 《问长生》法宝品阶系统（v0.6.0）
// 闭环：灵材+灵石 → 炼制（品阶/品质随机）→ 装备（三槽）→ 加成（百分比）
//       → 炼化升阶（祭品同阶）→ 分解回收灵材
// ============================================================

let artifactIdSeq = 1;

const ARTIFACT_TYPE_ICON = {
  attack: "assets/装备_本命.webp",
  defense: "assets/装备_护身.webp",
  support: "assets/装备_辅道.webp",
  relic: "assets/装备_古宝.webp",
  fabao: "assets/装备_法宝.webp",
};

function artifactIcon(type, cls) {
  const src = ARTIFACT_TYPE_ICON[type];
  if (!src) return "";
  return `<img class="art-ico ${cls || ""}" src="${src}" alt="">`;
}

// ---------- 基础查表 ----------
function tierInfo(tier) {
  return CONFIG.ARTIFACT_TIERS.find(t => t.tier === tier) || CONFIG.ARTIFACT_TIERS[0];
}
function typeInfo(key) {
  return CONFIG.ARTIFACT_TYPES.find(t => t.key === key) || CONFIG.ARTIFACT_TYPES[0];
}
function maxTier() {
  return CONFIG.ARTIFACT_TIERS.length;
}

// ---------- 炼制能力（由炼器坊等级决定） ----------
// 可炼最高品阶：Lv0-1→1品，Lv2-3→2品 …… Lv10+→6品
function forgeMaxTier() {
  const lv = S.buildings.forge || 0;
  return Math.min(maxTier(), 1 + Math.floor(lv / CONFIG.ARTIFACT_TIER_LV_STEP));
}

// 炼制成功率
function forgeRate(tier) {
  let r = CONFIG.ARTIFACT_FORGE_BASE_RATE - (tier - 1) * CONFIG.ARTIFACT_FORGE_TIER_DECAY;
  r += Math.min((S.buildings.forge || 0) * CONFIG.ARTIFACT_FORGE_LV_BONUS, CONFIG.ARTIFACT_FORGE_LV_CAP);
  return Math.max(CONFIG.ARTIFACT_RATE_MIN, Math.min(CONFIG.ARTIFACT_RATE_MAX, r));
}

// 炼制消耗
function forgeCost(tier) {
  const t = tierInfo(tier);
  return { material: t.material, stone: t.stone };
}

// ---------- 法宝生成 ----------
function round1(v) { return Math.round(v * 1000) / 1000; }

function rollArtifactName(type) {
  const pre = CONFIG.ARTIFACT_PREFIX[type] || CONFIG.ARTIFACT_PREFIX.attack;
  const suf = CONFIG.ARTIFACT_SUFFIX[type] || CONFIG.ARTIFACT_SUFFIX.attack;
  return pre[Math.floor(Math.random() * pre.length)] + suf[Math.floor(Math.random() * suf.length)];
}

// 按品阶生成法宝属性（百分比，含品质浮动）
function rollArtifactAttrs(tier) {
  const t = tierInfo(tier);
  const span = CONFIG.ARTIFACT_ROLL_MAX - CONFIG.ARTIFACT_ROLL_MIN;
  const roll = round1(CONFIG.ARTIFACT_ROLL_MIN + Math.random() * span);
  return {
    roll,
    main: round1(t.main * roll),
    sub: round1(t.sub * roll),
  };
}

// ---------- 词条（v0.6.2） ----------
// 掷一条指定种类的词条（洗练补位与正常生成共用同一口径）
function rollOneAffix(tier, typeKey) {
  const t = CONFIG.AFFIX_TYPES.find(x => x.key === typeKey);
  if (!t) return null;
  const baseArr = CONFIG.AFFIX_BASE[t.key];
  const base = baseArr[tier - 1] || 0;
  const roll = CONFIG.AFFIX_ROLL_MIN + Math.random() * (CONFIG.AFFIX_ROLL_MAX - CONFIG.AFFIX_ROLL_MIN);
  return { key: t.key, name: t.name, color: t.color, value: Math.round(base * roll * 1000) / 1000 };
}

// 品阶决定条数，随机决定种类；同类词条不重复生成（一件法宝内不叠同类）
function rollAffixes(tier) {
  const count = CONFIG.AFFIX_COUNT[tier - 1] || 0;
  if (count <= 0) return [];
  const pool = CONFIG.AFFIX_TYPES.slice();
  const out = [];
  for (let i = 0; i < count && pool.length > 0; i++) {
    const idx = Math.floor(Math.random() * pool.length);
    const t = pool.splice(idx, 1)[0];
    out.push(rollOneAffix(tier, t.key));
  }
  return out;
}

// 生成一件法宝实体
function makeArtifact(tier, type) {
  const a = rollArtifactAttrs(tier);
  const base = {
    id: artifactIdSeq++,
    name: rollArtifactName(type),
    tier, type,
    atk: 0, def: 0, hp: a.sub, cult: 0,
    roll: a.roll,
    affixes: rollAffixes(tier),
  };
  if (type === "attack") base.atk = a.main;
  else if (type === "defense") base.def = a.main;
  else if (type === "relic") { base.atk = round1(a.main * 0.5); base.def = round1(a.main * 0.5); base.hp = round1(a.sub * 2); }
  else if (type === "fabao") { base.cult = a.main; base.skill = rollFabaoSkill(tier); }
  else base.cult = a.main;
  // 套装器韵（v0.41.0）：同阶区间内按概率归入某套
  const _set = (CONFIG.ARTIFACT_SETS || []).find(st => tier >= st.from && tier <= st.to);
  if (_set && Math.random() < _set.rate) base.setKey = _set.key;
  // 图鉴收录（v0.6.5）：生成即记录，即便日后分解/被夺也不丢失
  if (typeof recordArtifactCodex === "function") recordArtifactCodex(base);
  return base;
}

// 按类型取主属性值
function artifactMain(a) {
  if (a.type === "attack") return a.atk;
  if (a.type === "defense") return a.def;
  if (a.type === "relic") return round1((a.atk || 0) + (a.def || 0));
  return a.cult;
}

// 法宝自带神通：按品阶从池中抽取（品阶越高可抽到的神通越好）
function rollFabaoSkill(tier) {
  const pool = CONFIG.FIELD_SKILLS.filter(s => s.fromFabao && s.tier <= tier);
  if (!pool.length) return null;
  return pool[Math.floor(Math.random() * pool.length)].key;
}

// ---------- 炼制 ----------
function forgeArtifact(tier) {
  const capTier = forgeMaxTier();
  if (tier > capTier) {
    return { ok: false, msg: `炼器坊 Lv.${S.buildings.forge || 0} 最多只能炼制「${tierInfo(capTier).name}」` };
  }
  const cost = forgeCost(tier);
  if ((S.materials || 0) < cost.material) return { ok: false, msg: `灵材不足（需 ${cost.material}）` };
  if (S.stone < cost.stone) return { ok: false, msg: `灵石不足（需 ${fmt(cost.stone)}）` };
  // v0.38.0：法宝入储物袋，袋满则先不炼（避免成品无处安放）
  if (typeof invFreeSlots === "function" && invFreeSlots() < 1) {
    return { ok: false, msg: `${invDef().name}已无空位，法宝无处安放（先换更高品级法器）` };
  }

  invRemove("material", cost.material);
  S.stone -= cost.stone;
  const rate = forgeRate(tier);

  if (Math.random() < rate) {
    const types = CONFIG.ARTIFACT_TYPES;
    const type = types[Math.floor(Math.random() * types.length)].key;
    const a = makeArtifact(tier, type);
    S.artifacts.push(a);
    invPutArtifact(a.id);
    save();
    return { ok: true, success: true, rate, cost, artifact: a };
  }
  // 失败：返还部分灵石，灵材损耗
  const back = Math.floor(cost.stone * CONFIG.ARTIFACT_FAIL_REFUND);
  S.stone += back;
  save();
  return { ok: true, success: false, rate, cost, back };
}

// ---------- 装备（v0.18.0：12 格栏位）----------
// 存档中 S.loadout 存 { 栏位key: 法宝id }；S.equipped 保留为三件本体的旧视图，
// 供 codex / event 等旧代码继续读取，二者由 syncEquippedView() 保持一致。
function loadout() {
  if (!S.loadout || typeof S.loadout !== "object") S.loadout = {};
  for (const s of CONFIG.LOADOUT_SLOTS) {
    if (S.loadout[s.key] === undefined) S.loadout[s.key] = null;
  }
  // 兜底：旧代码/旧存档直接写 S.equipped 时，补回对应栏位
  // （卸下会经 syncEquippedView 同步置 null，因此不会被误补）
  if (S.equipped) {
    if (S.loadout.weapon == null && S.equipped.attack != null) S.loadout.weapon = S.equipped.attack;
    if (S.loadout.armor == null && S.equipped.defense != null) S.loadout.armor = S.equipped.defense;
    if (S.loadout.trinket == null && S.equipped.support != null) S.loadout.trinket = S.equipped.support;
  }
  return S.loadout;
}

function slotDef(key) {
  return CONFIG.LOADOUT_SLOTS.find(s => s.key === key) || null;
}

function slotUnlocked(slot) {
  return (S.realm || 0) >= (slot.unlockRealm || 0);
}

function slotArtifact(key) {
  const id = loadout()[key];
  if (id == null) return null;
  return S.artifacts.find(a => a.id === id) || null;
}

// 已装备列表（按栏位顺序）
function equippedList() {
  const out = [];
  for (const s of CONFIG.LOADOUT_SLOTS) {
    const a = slotArtifact(s.key);
    if (a) out.push({ slot: s, artifact: a });
  }
  return out;
}

// 旧三槽视图同步
function syncEquippedView() {
  if (!S.equipped) S.equipped = { attack: null, defense: null, support: null };
  const lo = S.loadout || {};
  S.equipped.attack = lo.weapon == null ? null : lo.weapon;
  S.equipped.defense = lo.armor == null ? null : lo.armor;
  S.equipped.support = lo.trinket == null ? null : lo.trinket;
}

// 清理已不存在的法宝引用（分解 / 被夺 / 炼化祭品）
function pruneLoadout() {
  const lo = loadout();
  const ids = new Set((S.artifacts || []).map(a => a.id));
  for (const k in lo) {
    if (lo[k] != null && !ids.has(lo[k])) lo[k] = null;
  }
  syncEquippedView();
}

// 该法宝装备在哪个格
function slotOfArtifact(id) {
  const lo = loadout();
  for (const s of CONFIG.LOADOUT_SLOTS) if (lo[s.key] === id) return s.key;
  return null;
}

// 按类型取已装备的法宝（旧接口兼容）
function equippedArtifact(type) {
  for (const it of equippedList()) if (it.artifact.type === type) return it.artifact;
  return null;
}

function equipToSlot(slotKey, id) {
  const slot = slotDef(slotKey);
  if (!slot) return { ok: false, msg: "无此栏位" };
  if (!slotUnlocked(slot)) {
    return { ok: false, msg: `需 ${CONFIG.REALMS[slot.unlockRealm] || "更高"} 期方可开启` };
  }
  const a = S.artifacts.find(x => x.id === id);
  if (!a) return { ok: false, msg: "法宝不存在" };
  if (slot.accepts.indexOf(a.type) < 0) {
    return { ok: false, msg: `「${typeInfo(a.type).slot}」类法宝不能装入${slot.name}` };
  }
  const lo = loadout();
  // 同一件法宝不能同时占两格
  for (const k in lo) if (lo[k] === id) lo[k] = null;
  const replacedId = lo[slotKey];
  lo[slotKey] = id;
  syncEquippedView();
  invTakeArtifact(id);                       // 装备后移出储物袋
  if (replacedId != null) invPutArtifact(replacedId);   // 被换下的回到袋中
  save();
  const replaced = replacedId != null ? S.artifacts.find(x => x.id === replacedId) : null;
  return { ok: true, artifact: a, replaced };
}

function unequipSlot(slotKey) {
  const lo = loadout();
  if (lo[slotKey] == null) return { ok: false, msg: "该栏位没有法宝" };
  const a = S.artifacts.find(x => x.id === lo[slotKey]) || null;
  if (invFreeSlots() < 1) return { ok: false, msg: `${invDef().name}已无空位，卸下的法宝无处安放` };
  lo[slotKey] = null;
  syncEquippedView();
  if (a) invPutArtifact(a.id);
  save();
  return { ok: true, artifact: a };
}

// 旧接口：自动挑选可用栏位
function equipArtifact(id) {
  const a = S.artifacts.find(x => x.id === id);
  if (!a) return { ok: false, msg: "法宝不存在" };
  const cands = CONFIG.LOADOUT_SLOTS.filter(s => s.accepts.indexOf(a.type) >= 0 && slotUnlocked(s));
  if (!cands.length) return { ok: false, msg: "暂无可用栏位（境界不足）" };
  const lo = loadout();
  const empty = cands.find(s => lo[s.key] == null) || cands[0];
  return equipToSlot(empty.key, id);
}

function unequipArtifact(type) {
  for (const it of equippedList()) {
    if (it.artifact.type === type) return unequipSlot(it.slot.key);
  }
  return { ok: false, msg: "该槽位没有法宝" };
}

// 已装备法宝提供的主动术式（v0.53.3：独立第五格候选）
function equippedFabaoSkills() {
  const out = [];
  for (const it of equippedList()) {
    if (!it.artifact || it.artifact.type !== "fabao") continue;
    const key = it.artifact.skill;
    const skill = key && CONFIG.FIELD_SKILLS.find(s => s.key === key && s.fromFabao);
    if (!skill) continue;
    if (!out.some(x => x.key === key)) out.push({
      key, skill, artifactId: it.artifact.id, artifactName: it.artifact.name,
      tier: it.artifact.tier, slotKey: it.slot.key, slotName: it.slot.name,
    });
  }
  return out;
}

// 当前选中的独立法宝技；若对应法宝已卸下/分解则返回 null，不会带入战斗。
function selectedFabaoSkill() {
  const key = S.fabaoSkillSlot;
  if (!key) return null;
  return equippedFabaoSkills().find(x => x.key === key) || null;
}

// 兼容旧战场接口：保留「全部已装备法宝术式」列表，但新版气息战只使用独立第五格选中项。
function equippedSkills() {
  return equippedFabaoSkills().map(x => x.key);
}

// ---------- 法宝套装（v0.41.0）----------
function artifactSetDef(key) {
  return (CONFIG.ARTIFACT_SETS || []).find(s => s.key === key) || null;
}

// 当前已装备的各套件数
function artifactSetCounts() {
  const cnt = {};
  for (const it of equippedList()) {
    const k = it.artifact.setKey;
    if (!k) continue;
    cnt[k] = (cnt[k] || 0) + 1;
  }
  return cnt;
}

// 已激活套装（含档位与加成）
function activeArtifactSets() {
  const cnt = artifactSetCounts();
  const out = [];
  for (const st of (CONFIG.ARTIFACT_SETS || [])) {
    const c = cnt[st.key] || 0;
    if (c >= 2) out.push({ set: st, count: c, tier: c >= 3 ? 3 : 2, bonus: c >= 3 ? st.bonus3 : st.bonus2 });
  }
  return out;
}

function artifactSetBonus() {
  const acc = { atk: 0, def: 0, hp: 0, cult: 0 };
  for (const a of activeArtifactSets()) {
    for (const k in a.bonus) if (acc[k] !== undefined) acc[k] += a.bonus[k];
  }
  return acc;
}

// ---------- 加成汇总（供 playerCombat / cultivationRate 使用） ----------
function artifactBonus() {
  const b = { atk: 0, def: 0, hp: 0, cult: 0 };
  if (!Array.isArray(S.artifacts)) return b;
  for (const it of equippedList()) {
    const a = it.artifact;
    b.atk += a.atk || 0;
    b.def += a.def || 0;
    b.hp += a.hp || 0;
    b.cult += a.cult || 0;
  }
  // 套装词条（v0.41.0）：按件数直接叠加
  const setB = artifactSetBonus();
  b.atk += setB.atk || 0;
  b.def += setB.def || 0;
  b.hp += setB.hp || 0;
  b.cult += setB.cult || 0;
  // 器纹：直接叠加；共鸣：整体乘算
  const eng = engraveBonus();
  const res = resonanceBonus().bonus;
  const mul = 1 + res;
  b.atk = round1((b.atk + (eng.atk || 0)) * mul);
  b.def = round1((b.def + (eng.def || 0)) * mul);
  b.hp = round1((b.hp + (eng.hp || 0)) * mul);
  b.cult = round1((b.cult + (eng.cult || 0)) * mul);
  return b;
}

// ---------- 器纹（v0.18.0）----------
function engraveMax(a) {
  if (!a) return 0;
  return CONFIG.ENGRAVE.MAX_BY_TIER[(a.tier || 1) - 1] || 0;
}

function engraveCost(a) {
  const t = a ? (a.tier || 1) : 1;
  return { mat: CONFIG.ENGRAVE.COST_MAT * t, stone: CONFIG.ENGRAVE.COST_STONE * t };
}

function engraveArtifact(id) {
  const a = S.artifacts.find(x => x.id === id);
  if (!a) return { ok: false, msg: "法宝不存在" };
  if (!Array.isArray(a.engrave)) a.engrave = [];
  const max = engraveMax(a);
  if (!max) return { ok: false, msg: "凡品之器无法承载器纹" };
  if (a.engrave.length >= max) return { ok: false, msg: `器纹已满（${max} 条）` };
  const c = engraveCost(a);
  if ((S.materials || 0) < c.mat) return { ok: false, msg: `灵材不足（需 ${c.mat}）` };
  if (S.stone < c.stone) return { ok: false, msg: `灵石不足（需 ${fmt(c.stone)}）` };
  invRemove("material", c.mat);
  S.stone -= c.stone;
  const t = CONFIG.ENGRAVE.TYPES[Math.floor(Math.random() * CONFIG.ENGRAVE.TYPES.length)];
  const span = CONFIG.ENGRAVE.ROLL_MAX - CONFIG.ENGRAVE.ROLL_MIN;
  const line = {
    key: t.key, name: t.name, color: t.color,
    value: round1(t.value * (CONFIG.ENGRAVE.ROLL_MIN + Math.random() * span)),
  };
  a.engrave.push(line);
  save();
  return { ok: true, line, artifact: a };
}

function engraveBonus() {
  const acc = { atk: 0, def: 0, hp: 0, cult: 0 };
  for (const it of equippedList()) {
    for (const e of (it.artifact.engrave || [])) {
      if (acc[e.key] != null) acc[e.key] += e.value || 0;
    }
  }
  return acc;
}

// ---------- 共鸣（v0.18.0）：同品阶法宝达件数 → 全属性加成 ----------
function resonanceBonus() {
  const cnt = {};
  const minTier = CONFIG.RESONANCE_MIN_TIER || 3;
  for (const it of equippedList()) {
    const t = it.artifact.tier || 1;
    if (t < minTier) continue;
    cnt[t] = (cnt[t] || 0) + 1;
  }
  let best = 0, tier = 0;
  for (const t in cnt) {
    for (const r of CONFIG.RESONANCE) {
      if (cnt[t] >= r.count && r.bonus > best) { best = r.bonus; tier = parseInt(t, 10); }
    }
  }
  return { bonus: best, tier, count: cnt[tier] || 0 };
}

// 已装备法宝的词条汇总（战斗使用，含上限钳制）
function artifactAffix() {
  const acc = { crit: 0, lifesteal: 0, thorns: 0 };
  if (!Array.isArray(S.artifacts)) return acc;
  for (const it of equippedList()) {
    const a = it.artifact;
    if (!Array.isArray(a.affixes)) continue;
    for (const af of a.affixes) {
      if (acc[af.key] != null) acc[af.key] += af.value || 0;
    }
  }
  for (const k in acc) acc[k] = Math.min(acc[k], CONFIG.AFFIX_CAP[k]);
  return acc;
}

// 词条展示文本（单件）
function affixText(a) {
  if (!a || !Array.isArray(a.affixes) || !a.affixes.length) return "";
  return a.affixes.map(af => `${af.name} ${(af.value * 100).toFixed(1)}%`).join(" ｜ ");
}

// 已装备词条汇总文本
function affixSummaryText() {
  const af = artifactAffix();
  const parts = [];
  if (af.crit) parts.push(`暴击 ${(af.crit * 100).toFixed(1)}%`);
  if (af.lifesteal) parts.push(`吸血 ${(af.lifesteal * 100).toFixed(1)}%`);
  if (af.thorns) parts.push(`反伤 ${(af.thorns * 100).toFixed(1)}%`);
  return parts.join(" ｜ ");
}

// ---------- 炼化升阶 ----------
// 消耗 1 件同类型、同品阶的祭品法宝 + 灵材，成功则主法宝升一阶并重 roll 属性
function refineRate() {
  return Math.min(CONFIG.REFINE_RATE_CAP, CONFIG.REFINE_BASE_RATE + (S.buildings.forge || 0) * CONFIG.REFINE_LV_BONUS);
}

function refineCost(tier) {
  return Math.max(1, Math.floor(tierInfo(tier).material / 2));
}

function refineArtifact(id, sacId) {
  const a = S.artifacts.find(x => x.id === id);
  const sac = S.artifacts.find(x => x.id === sacId);
  if (!a) return { ok: false, msg: "主法宝不存在" };
  if (!sac || sac.id === a.id) return { ok: false, msg: "请选择祭品法宝" };
  if (a.tier >= maxTier()) return { ok: false, msg: "已是仙器，无法再炼化" };
  if (sac.type !== a.type) return { ok: false, msg: "祭品须与主法宝同类型" };
  if (sac.tier !== a.tier) return { ok: false, msg: "祭品须与主法宝同品阶" };
  const matCost = refineCost(a.tier);
  if ((S.materials || 0) < matCost) return { ok: false, msg: `灵材不足（需 ${matCost}）` };

  invRemove("material", matCost);
  // 祭品消散（12 格中若有引用一并清理）
  invTakeArtifact(sac.id);
  S.artifacts = S.artifacts.filter(x => x.id !== sac.id);
  pruneLoadout();

  const rate = refineRate();
  if (Math.random() < rate) {
    a.tier++;
    const attrs = rollArtifactAttrs(a.tier);
    a.roll = attrs.roll;
    a.atk = 0; a.def = 0; a.cult = 0;
    a.hp = attrs.sub;
    if (a.type === "attack") a.atk = attrs.main;
    else if (a.type === "defense") a.def = attrs.main;
    else if (a.type === "relic") { a.atk = round1(attrs.main * 0.5); a.def = round1(attrs.main * 0.5); }
    else if (a.type === "fabao") { a.cult = attrs.main; if (!a.skill) a.skill = rollFabaoSkill(a.tier); }
    else a.cult = attrs.main;
    a.affixes = rollAffixes(a.tier);   // 升阶后重铸词条
    save();
    return { ok: true, success: true, rate, matCost, artifact: a, sacName: sac.name };
  }
  save();
  return { ok: true, success: false, rate, matCost, artifact: a, sacName: sac.name };
}

// ---------- 分解 ----------
function dismantleArtifact(id) {
  // 分解前先确保不会留下指向已消失法宝的装备引用
  const _wasEquipped = slotOfArtifact(id);
  const a = S.artifacts.find(x => x.id === id);
  if (!a) return { ok: false, msg: "法宝不存在" };
  const gain = Math.max(1, Math.floor(tierInfo(a.tier).material * CONFIG.ARTIFACT_DISMANTLE_RATIO));
  if (S.equipped && S.equipped[a.type] === a.id) S.equipped[a.type] = null;
  invTakeArtifact(id);
  S.artifacts = S.artifacts.filter(x => x.id !== id);
  gainItem("material", gain);
  save();
  return { ok: true, gain, name: a.name };
}

// ---------- 词条洗练（v0.6.3，v0.6.4 支持锁定） ----------
// 消耗灵材 + 灵石重掷该法宝全部词条；无失败风险，结果即时生效
// locked=true 时消耗翻倍，但指定的那一条词条保持不变
function rerollCost(tier, locked) {
  const t = tierInfo(tier);
  const mult = locked ? CONFIG.REROLL_LOCK_MULT : 1;
  return {
    material: Math.max(1, Math.floor(t.material * CONFIG.REROLL_MAT_RATIO * mult)),
    stone: Math.floor(t.stone * CONFIG.REROLL_STONE_RATIO * mult),
  };
}

// 该法宝是否可洗练（宝器及以上才有词条）
function canReroll(a) {
  return !!a && a.tier >= CONFIG.REROLL_MIN_TIER;
}

// 该法宝是否可锁定洗练（词条数需达到下限）
function canLockReroll(a) {
  return canReroll(a) && (a.affixes || []).length >= CONFIG.REROLL_LOCK_MIN_COUNT;
}

function rerollAffixes(id, lockIndex) {
  const a = S.artifacts.find(x => x.id === id);
  if (!a) return { ok: false, msg: "法宝不存在" };
  if (!canReroll(a)) {
    return { ok: false, msg: `${tierInfo(CONFIG.REROLL_MIN_TIER).name}及以上才有词条，无需洗练` };
  }

  const old = (a.affixes || []).map(x => Object.assign({}, x));
  const useLock = canLockReroll(a) && typeof lockIndex === "number"
    && lockIndex >= 0 && lockIndex < old.length;
  const locked = useLock ? Object.assign({}, old[lockIndex]) : null;

  const cost = rerollCost(a.tier, !!locked);
  if ((S.materials || 0) < cost.material) return { ok: false, msg: `灵材不足（需 ${cost.material}）` };
  // 洗髓丹：免灵石 1 次（v0.38.0）
  const freeRoll = (S.rerollFree || 0) > 0;
  if (!freeRoll && S.stone < cost.stone) return { ok: false, msg: `灵石不足（需 ${fmt(cost.stone)}）` };

  invRemove("material", cost.material);
  if (freeRoll) S.rerollFree -= 1;
  else S.stone -= cost.stone;

  let next;
  if (locked) {
    // 锁定词条保留，其余按品阶补足且不与其同类重复
    const count = CONFIG.AFFIX_COUNT[a.tier - 1] || 0;
    next = [locked];
    const pool = CONFIG.AFFIX_TYPES.filter(t => t.key !== locked.key);
    while (next.length < count && pool.length > 0) {
      const idx = Math.floor(Math.random() * pool.length);
      const t = pool.splice(idx, 1)[0];
      next.push(rollOneAffix(a.tier, t.key));
    }
  } else {
    next = rollAffixes(a.tier);
  }

  a.affixes = next;
  save();
  return {
    ok: true, artifact: a, oldAffixes: old, newAffixes: next,
    cost, locked: locked ? locked.name : null,
  };
}

// ---------- 查询辅助（UI 用） ----------// 可作为某法宝祭品的候选（同类型、同品阶、非自身）
function refineCandidates(a) {
  if (!a || a.tier >= maxTier()) return [];
  return S.artifacts.filter(x => x.id !== a.id && x.type === a.type && x.tier === a.tier);
}

// 法宝属性展示文本
function artifactAttrText(a) {
  const parts = [];
  if (a.atk) parts.push(`攻 +${(a.atk * 100).toFixed(1)}%`);
  if (a.def) parts.push(`防 +${(a.def * 100).toFixed(1)}%`);
  if (a.cult) parts.push(`修炼 +${(a.cult * 100).toFixed(1)}%`);
  if (a.hp) parts.push(`血 +${(a.hp * 100).toFixed(1)}%`);
  return parts.join(" ｜ ");
}

// 战力评分（用于列表排序，粗略）
function artifactScore(a) {
  let affixScore = 0;
  if (Array.isArray(a.affixes)) {
    for (const af of a.affixes) {
      // 反伤权重高（纯防御收益），暴击/吸血次之
      affixScore += af.value * (af.key === "thorns" ? 120 : 100);
    }
  }
  // 温养（v0.31.0）：每级 +2% 评分
  const warm = (typeof artWarmMult === "function") ? artWarmMult(a.id) : 1;
  return (artifactMain(a) * 100 + (a.hp || 0) * 50 + a.tier * 10 + affixScore) * warm;
}

// 同步自增 id 序列到存档内最大 id 之后
// 修复：刷新页面 / 导入存档后 id 从 1 重新计数，会与已有法宝 id 冲突，
// 导致装备槽指向错误法宝（v0.6.2 修复）
function refreshArtifactSeq() {
  let maxId = 0;
  for (const a of (S.artifacts || [])) {
    if (a && typeof a.id === "number" && a.id > maxId) maxId = a.id;
  }
  artifactIdSeq = maxId + 1;
}

// 模块加载即同步（此时 state.js 已执行，S 已就绪）
refreshArtifactSeq();
