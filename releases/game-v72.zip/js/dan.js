// ============================================================
// 《问长生》丹方配伍（v0.39.0）：主动炼丹
// 灵田/炼丹房自动产出基础培元丹；此处按古方开炉，可炼高阶丹
// 火候按真实时间推进（离线亦算），成败由丹道修为（炼丹房等级）与古方难度决定
// ============================================================

function danRecipes() { return CONFIG.DAN.RECIPES; }

function danRecipe(key) { return CONFIG.DAN.RECIPES.find(r => r.key === key) || null; }

function danState() {
  if (!S.dan || typeof S.dan !== "object") S.dan = { slots: [null, null, null] };
  if (!Array.isArray(S.dan.slots)) S.dan.slots = [null, null, null];
  while (S.dan.slots.length < 3) S.dan.slots.push(null);
  return S.dan;
}

// 炉位数：炼丹房每 3 级多开一炉（上限 3）
function danSlotCount() {
  const lv = S.buildings.alchemy || 0;
  if (lv < 1) return 0;
  return Math.max(1, Math.min(3, 1 + Math.floor(lv / CONFIG.DAN.SLOT_PER_LEVEL)));
}

function danSlotState(i) {
  const d = danState();
  return d.slots[i] || null;
}

function danSlotRemainMs(i) {
  const sl = danSlotState(i);
  if (!sl) return 0;
  return Math.max(0, sl.startAt + sl.dur - Date.now());
}

function danSlotReady(i) {
  const sl = danSlotState(i);
  return !!sl && danSlotRemainMs(i) <= 0;
}

function danMultDef(mult) {
  return (CONFIG.DAN.MULTS || []).find(m => m.mult === mult) || CONFIG.DAN.MULTS[0];
}

// 成功率：古方基础 + 炼丹房等级 × 5%，天妒上限 95%
function danRate(r, mult) {
  if (!r) return 0;
  const lv = S.buildings.alchemy || 0;
  const m = danMultDef(mult || 1);
  const rate = r.base + Math.max(0, lv - r.alchemy) * CONFIG.DAN.LV_BONUS + (m.rate || 0);
  return Math.max(0.05, Math.min(CONFIG.DAN.MAX_RATE, rate));
}

function danBusy() {
  const d = danState();
  return d.slots.some(x => !!x);
}

function danAnyReady() {
  const d = danState();
  for (let i = 0; i < d.slots.length; i++) if (danSlotReady(i)) return true;
  return false;
}

// 兼容旧接口：返回第一炉的剩余时间 / 是否到期
function danRemainMs() {
  for (let i = 0; i < danState().slots.length; i++) if (danSlotState(i)) return danSlotRemainMs(i);
  return 0;
}

function danReady() { return danAnyReady(); }

function danFreeSlot() {
  const d = danState();
  for (let i = 0; i < danSlotCount(); i++) if (!d.slots[i]) return i;
  return -1;
}

function danUnlocked(r) {
  return (S.realm || 0) >= (r.realm || 0) && (S.buildings.alchemy || 0) >= (r.alchemy || 1);
}

// 开炉：校验境界 / 炉火等级 / 材料 / 炉位 / 袋位
function danStart(key, mult) {
  const r = danRecipe(key);
  if (!r) return { ok: false, msg: "无此丹方" };
  if ((S.buildings.alchemy || 0) < 1) return { ok: false, msg: "需先建造炼丹房" };
  if ((S.realm || 0) < (r.realm || 0)) return { ok: false, msg: `需 ${CONFIG.REALMS[r.realm]}期方可开此炉` };
  if ((S.buildings.alchemy || 0) < (r.alchemy || 1)) {
    return { ok: false, msg: `炉火不足：需炼丹房 Lv.${r.alchemy}（当前 Lv.${S.buildings.alchemy || 0}）` };
  }
  const slotIdx = danFreeSlot();
  if (slotIdx < 0) {
    return { ok: false, msg: `${danSlotCount()} 个炉位皆在炼丹（炉位数随炼丹房每 ${CONFIG.DAN.SLOT_PER_LEVEL} 级 +1）` };
  }
  const mDef = danMultDef(mult || 1);
  const multN = mDef.mult;
  const herbNeed = Math.floor((r.herb || 0) * multN);
  const matNeed = Math.floor((r.material || 0) * multN);
  if (Math.floor(S.herbs || 0) < herbNeed) return { ok: false, msg: `灵草不足（需 ${herbNeed}，持有 ${Math.floor(S.herbs || 0)}）` };
  if (Math.floor(S.materials || 0) < matNeed) return { ok: false, msg: `灵材不足（需 ${matNeed}，持有 ${Math.floor(S.materials || 0)}）` };
  if (r.spc) {
    const needSpc = Math.floor(r.spc.n * multN);
    const haveSpc = (typeof specialtyCount === "function") ? specialtyCount(r.spc.ch) : 0;
    if (haveSpc < needSpc) {
      return { ok: false, msg: `${CONFIG.FIELD_SPECIALTIES[r.spc.ch]}不足（需 ${needSpc}，持有 ${haveSpc}）· 该章秘境产出/坊市有售` };
    }
  }
  if (typeof invRoomCheck === "function") {
    const rc = invRoomCheck(r.out, r.n * CONFIG.DAN.CRIT_MULT);
    if (!rc.ok) return rc;
  }
  invRemove("herb", herbNeed);
  if (matNeed > 0) invRemove("material", matNeed);
  if (r.spc) invRemove("sp:" + r.spc.ch, r.spc.n);
  const d = danState();
  d.slots[slotIdx] = { recipe: key, startAt: Date.now(), dur: r.sec * 1000, mult: multN };
  save();
  if (typeof dailyProgress === "function") dailyProgress("dan1", 1);
  return { ok: true, recipe: r, rate: danRate(r, multN), dur: r.sec, slot: slotIdx, mult: multN };
}

// 收丹：成则得丹（上品双倍），败则返还半数材料
function danClaim(slotIdx) {
  const d = danState();
  const i = (typeof slotIdx === "number") ? slotIdx : d.slots.findIndex(x => !!x);
  if (i < 0 || !d.slots[i]) return { ok: false, msg: "炉中无丹" };
  const sl = d.slots[i];
  const r = danRecipe(sl.recipe);
  if (!r) { d.slots[i] = null; return { ok: false, msg: "丹方已失传" }; }
  const remain = danSlotRemainMs(i);
  if (remain > 0) return { ok: false, msg: `火候未足（尚需 ${Math.ceil(remain / 1000)} 秒）` };
  const mDef = danMultDef(sl.mult || 1);
  const rate = danRate(r, sl.mult || 1);
  const success = Math.random() < rate;
  d.slots[i] = null;
  if (success) {
    const crit = Math.random() < (CONFIG.DAN.CRIT_RATE + (mDef.crit || 0));
    const n = Math.max(1, Math.floor(r.n * (crit ? CONFIG.DAN.CRIT_MULT : 1) * (sl.mult > 1 ? 1 : 1)));
    gainItem(r.out, n);
    save();
    const def = (typeof invItemDef === "function") ? invItemDef(r.out) : null;
    if (!S.guideFlags) S.guideFlags = {};
    S.guideFlags.danClaimed = true;   // 引路判定：开炉收丹（v0.47.0）
    return { ok: true, success: true, crit, out: r.out, n, name: def ? def.name : r.name, rate };
  }
  const mN = sl.mult || 1;
  const backHerb = Math.floor((r.herb || 0) * mN * CONFIG.DAN.FAIL_REFUND);
  const backMat = Math.floor((r.material || 0) * mN * CONFIG.DAN.FAIL_REFUND);
  const backSpc = r.spc ? Math.floor(r.spc.n * mN * CONFIG.DAN.FAIL_REFUND) : 0;
  if (backHerb > 0) gainItem("herb", backHerb);
  if (backMat > 0) gainItem("material", backMat);
  if (backSpc > 0) gainItem("sp:" + r.spc.ch, backSpc);
  save();
  return { ok: true, success: false, backHerb, backMat, rate, name: r.name };
}

// 撤炉：主动放弃，返还三成材料（免得卡死）
function danAbort(slotIdx) {
  const d = danState();
  const i = (typeof slotIdx === "number") ? slotIdx : d.slots.findIndex(x => !!x);
  if (i < 0 || !d.slots[i]) return { ok: false, msg: "炉中无丹" };
  const sl = d.slots[i];
  const r = danRecipe(sl.recipe);
  const mN = sl.mult || 1;
  const backHerb = Math.floor((r.herb || 0) * mN * 0.3);
  const backMat = Math.floor((r.material || 0) * mN * 0.3);
  const backSpc = r.spc ? Math.floor(r.spc.n * mN * 0.3) : 0;
  if (backHerb > 0) gainItem("herb", backHerb);
  if (backMat > 0) gainItem("material", backMat);
  if (backSpc > 0) gainItem("sp:" + r.spc.ch, backSpc);
  d.slots[i] = null;
  save();
  return { ok: true, backHerb, backMat };
}

// ---------- 界面 ----------
function danSlotCardHtml(i) {
  const sl = danSlotState(i);
  const total = danSlotCount();
  if (i >= total) {
    return `<div class="dan-furnace locked"><span class="muted">第 ${i + 1} 炉 · 未开（炼丹房每 ${CONFIG.DAN.SLOT_PER_LEVEL} 级 +1 炉位）</span></div>`;
  }
  if (!sl) {
    return `<div class="dan-furnace idle"><span class="dan-furnace-name">第 ${i + 1} 炉空闲</span><span class="muted">选一方古法开炉</span></div>`;
  }
  const r = danRecipe(sl.recipe);
  const remain = danSlotRemainMs(i);
  const pct = Math.min(100, Math.max(0, ((sl.dur - remain) / (sl.dur || 1)) * 100));
  const ready = remain <= 0;
  const name = (typeof invItemDef === "function") ? (invItemDef(r.out) || {}).name : "";
  const mDef = danMultDef(sl.mult || 1);
  return `<div class="dan-furnace ${ready ? "ready" : "burning"}">
    <div class="dan-furnace-head">
      <span class="dan-furnace-name">${esc(r.name)}<span class="dan-mult">${esc(mDef.name)}</span></span>
      <span class="dan-rate">成功率 ${Math.round(danRate(r, sl.mult) * 100)}%</span>
    </div>
    <div class="dan-bar"><i style="width:${pct.toFixed(1)}%"></i></div>
    <div class="dan-furnace-foot">
      <span class="muted">${ready ? "丹成出炉，可收取" : "火候 " + Math.ceil(remain / 1000) + " 秒 · 产出 " + esc(name || r.out) + " ×" + r.n}</span>
      ${ready
        ? `<button class="btn-sm" data-action="danclaim" data-slot="${i}">收丹</button>`
        : `<button class="btn-xs" data-action="danabort" data-slot="${i}">撤炉（返三成）</button>`}
    </div>
  </div>`;
}

function danRecipeRow(r) {
  const unlocked = danUnlocked(r);
  const herbOk = Math.floor(S.herbs || 0) >= (r.herb || 0);
  const matOk = Math.floor(S.materials || 0) >= (r.material || 0);
  const spcOk = !r.spc || ((typeof specialtyCount === "function" ? specialtyCount(r.spc.ch) : 0) >= r.spc.n);
  const hasSlot = danFreeSlot() >= 0;
  const can = unlocked && herbOk && matOk && spcOk && hasSlot;
  const def = (typeof invItemDef === "function") ? (invItemDef(r.out) || {}) : {};
  const mats = [
    r.herb ? `灵草 ${r.herb}` : "",
    r.material ? `灵材 ${r.material}` : "",
    r.spc ? `${CONFIG.FIELD_SPECIALTIES[r.spc.ch]} ${r.spc.n}` : "",
  ].filter(Boolean).join(" ｜ ");
  return `<div class="dan-row ${can ? "" : "off"}">
    <div class="dan-row-main">
      <div class="dan-row-name">${esc(r.name)} <span class="dan-row-out">→ ${esc(def.name || r.out)} ×${r.n}</span></div>
      <div class="dan-row-desc">${esc(r.desc)}</div>
      <div class="dan-row-meta">
        <span>${mats}</span>
        <span>火候 ${Math.round(r.sec)} 秒 ｜ 成功率 ${Math.round(danRate(r, 1) * 100)}%</span>
      </div>
      ${unlocked ? "" : `<div class="dan-row-lock">需 ${CONFIG.REALMS[r.realm]}期 ／ 炼丹房 Lv.${r.alchemy}</div>`}
    </div>
    <button class="btn-sm" data-action="danpick" data-key="${r.key}" ${can ? "" : "disabled"}>开炉</button>
  </div>`;
}

// 选料档位弹窗
function showDanPick(key) {
  const r = danRecipe(key);
  if (!r) return;
  const rows = CONFIG.DAN.MULTS.map(m => {
    const herb = Math.floor((r.herb || 0) * m.mult);
    const mat = Math.floor((r.material || 0) * m.mult);
    const spc = r.spc ? Math.floor(r.spc.n * m.mult) : 0;
    const afford = Math.floor(S.herbs || 0) >= herb && Math.floor(S.materials || 0) >= mat
      && (!r.spc || specialtyCount(r.spc.ch) >= spc);
    return `<div class="dan-pick-row">
      <div class="dan-pick-main">
        <div class="dan-row-name">${esc(m.name)} <span class="dan-row-out">成功率 ${Math.round(danRate(r, m.mult) * 100)}% ｜ 上品率 ${Math.round((CONFIG.DAN.CRIT_RATE + m.crit) * 100)}%</span></div>
        <div class="dan-row-meta"><span>灵草 ${herb}${mat ? " ｜ 灵材 " + mat : ""}${spc ? " ｜ " + CONFIG.FIELD_SPECIALTIES[r.spc.ch] + " " + spc : ""}</span><span>${esc(m.desc)}</span></div>
      </div>
      <button class="btn-sm" data-action="danstartgo" data-key="${key}" data-mult="${m.mult}" ${afford ? "" : "disabled"}>开炉</button>
    </div>`;
  }).join("");
  showModal(`<div class="result">
    <div class="result-title">${esc(r.name)} · 选料</div>
    <div class="result-line muted-line">多下料可提纯增稳，但材料按倍数消耗。</div>
    <div class="dan-pick-list">${rows}</div>
    <button class="btn-primary" data-action="dan">返回丹房</button>
  </div>`);
}

function showDanPanel() {
  const alch = S.buildings.alchemy || 0;
  if (alch < 1) {
    showModal(`<div class="result">
      <div class="result-title">丹房</div>
      <div class="result-line">尚无炼丹房。先去洞府建造炼丹房，方可开炉炼丹。</div>
      <button class="btn-primary" data-action="closemodal">关闭</button>
    </div>`);
    return;
  }
  const slotsHtml = [0, 1, 2].map(danSlotCardHtml).join("");
  const rows = danRecipes().map(danRecipeRow).join("");
  showModal(`<div class="result inv-modal">
    <div class="result-title">丹房 · 炉火 Lv.${alch}</div>
    <div class="build-desc">古法开炉：投入灵草灵材，以火候换丹。炉位数 ${danSlotCount()}/3（每 ${CONFIG.DAN.SLOT_PER_LEVEL} 级 +1），成功率随炉火提升，火候按真实时间推进，离线亦算。</div>
    <div class="dan-slots">${slotsHtml}</div>
    <div class="sec-title small">古方</div>
    <div class="dan-list">${rows}</div>
    <div class="build-row">
      <button class="btn-sm" data-action="tab" data-tab="build">回洞府</button>
      <button class="btn-primary" data-action="closemodal">关闭</button>
    </div>
  </div>`);
}
