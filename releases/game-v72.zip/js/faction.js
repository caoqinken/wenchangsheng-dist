// ============================================================
// 《问长生》势力系统：势力独立演化 + 玩家关系 + 势力庇护
// ============================================================

// 势力关系（无该势力则 0）
function factionRel(key) {
  return S.factions[key] ? S.factions[key].relation : 0;
}

// 是否已获得某势力庇护
function blessed(key) {
  return factionRel(key) >= CONFIG.BLESSING_THRESHOLD;
}

function clampRel(v) {
  return Math.max(-CONFIG.RELATION_RANGE, Math.min(CONFIG.RELATION_RANGE, v));
}

// 势力每日演化：资源生产/消耗 → 实力增长 → 势力争斗
function factionTick() {
  const keys = Object.keys(S.factions);
  // 1. 资源与实力演化
  for (const k of keys) {
    const f = S.factions[k];
    f.resource += f.territory * CONFIG.FACTION_RESOURCE_RATE - f.power * CONFIG.FACTION_UPKEEP;
    if (f.resource < 0) f.resource = 0;
    f.power += f.resource * CONFIG.FACTION_POWER_GROWTH;
    if (f.power < 5) f.power = 5;
  }
  // 2. 势力争斗：最强吞并最弱（领土易主，因果可追溯）
  const strongest = keys.reduce((a, b) => S.factions[a].power >= S.factions[b].power ? a : b);
  const weakest = keys.reduce((a, b) => S.factions[a].power <= S.factions[b].power ? a : b);
  if (strongest !== weakest) {
    const s = S.factions[strongest], w = S.factions[weakest];
    if (s.power - w.power >= CONFIG.FACTION_WAR_POWER_GAP && w.territory > 1) {
      w.territory--;
      s.territory++;
      addEventLog(`${factionName(strongest)} 吞并 ${factionName(weakest)} 一处领地（实力悬殊）`);
    }
  }
}

function factionName(key) {
  const f = CONFIG.FACTIONS.find(x => x.key === key);
  return f ? f.name : key;
}
