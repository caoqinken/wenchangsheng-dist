// ============================================================
// 《问长生》秘境战场引擎（v0.16.0）
// 复刻《一念逍遥》：圆形图标角色、2.5D 地图、自由走位、方向性技能
// 本文件只管逻辑（世界坐标），不碰渲染
// ============================================================

// ---------- 查表 ----------
// 秘境章节解锁判定（v0.24.0 单一来源）：通关上一章末关 BOSS 后解锁下一章。
// ch=0 恒可进（bestStage 初始为 0）；ch=n 需 bestStage ≥ n×6（5 小关 + 1 BOSS）。
// UI 列表与 startFieldBattle 入口校验共用此函数，避免两处规则漂移。
function fldChapterUnlocked(ch) {
  return (S.bestStage || 0) >= ch * (CONFIG.STAGES_PER_CHAPTER + 1);
}

function fldSkill(key) {
  return CONFIG.FIELD_SKILLS.find(s => s.key === key) || null;
}

function fldUnlockedSkills(realm) {
  // 普通术式盘只收功法/境界术式；法宝技独立占用第五格，不挤占境界槽位。
  return CONFIG.FIELD_SKILLS.filter(s => {
    if (s.fromFabao) return false;
    if (s.gongfaKey) {
      if (typeof gongfaLearned !== "function" || !gongfaLearned(s.gongfaKey)) return false;
      const cat = (typeof gongfaCategory === "function") ? gongfaCategory(s.gongfaKey) : null;
      const eq = (typeof gongfaEquipState === "function") ? gongfaEquipState() : {};
      return !!cat && eq[cat] === s.gongfaKey;
    }
    return s.unlockRealm <= realm;
  });
}

// 默认技能盘：高阶优先，最多按境界开放的普通术式槽数量。
function fldDefaultSlots(realm) {
  const un = fldUnlockedSkills(realm);
  return un.slice().sort((a, b) => b.unlockRealm - a.unlockRealm)
    .slice(0, CONFIG.FIELD.SKILL_SLOTS).map(s => s.key);
}

// 只清洗玩家显式保存的普通术式：去无效/重复项，保留首次出现顺序，不自动写入默认补位。
function fldCleanSlots(raw, realm) {
  const keys = new Set(fldUnlockedSkills(realm).map(x => x.key));
  return [...new Set((Array.isArray(raw) ? raw : []).filter(k => keys.has(k)))];
}

// 战斗/技能盘归一化：在清洗后的显式顺序后补足默认技能，遵守境界容量。
function fldNormalizeSlots(raw, realm) {
  const capList = (CONFIG.BATTLE2 && CONFIG.BATTLE2.SLOT_BY_REALM) || [];
  const cap = capList.length ? (capList[Math.min(capList.length - 1, Math.max(0, realm || 0))] || 2) : CONFIG.FIELD.SKILL_SLOTS;
  const unlocked = fldUnlockedSkills(realm);
  let slots = fldCleanSlots(raw, realm);
  if (!slots.length) slots = fldDefaultSlots(realm);
  for (const sk of unlocked) {
    if (slots.length >= cap) break;
    if (!slots.includes(sk.key)) slots.push(sk.key);
  }
  return slots.slice(0, cap);
}

// 槽位换位统一入口，供 UI 与自动化回归共用。
function fldMoveSlot(index, delta, realm) {
  const slots = fldNormalizeSlots(S.fieldSlots, realm);
  const target = index + delta;
  if (!Number.isInteger(index) || !Number.isInteger(delta) || index < 0 || index >= slots.length || target < 0 || target >= slots.length) {
    return { ok: false, slots };
  }
  const t = slots[index]; slots[index] = slots[target]; slots[target] = t;
  S.fieldSlots = slots.slice();
  if (typeof save === "function") save();
  return { ok: true, slots };
}

// ---------- 玩家真元 ----------
function fldManaMax() {
  // 真元上限（v0.29.0）：随修炼方向变化（法修 1.25 倍）；v0.50.0 起计入丹田
  const dao = (typeof daoDef === "function") ? daoDef(S.dao) : { mana: 1 };
  const dan = (typeof meridianSum === "function") ? meridianSum().mana : 0;
  return Math.round((120 + S.realm * 26) * dao.mana + dan);
}

// ---------- 创建战场 ----------
function fldCreate(chapter) {
  const F = CONFIG.FIELD;
  const map = CONFIG.fieldMap(chapter);
  const p = playerCombat();
  // 难度跟随玩家真实进度（已通关的最高关），而不是章节序号
  const stage = Math.max(1, Math.min(41, (S.bestStage || 1) - 1));

  const player = {
    x: map.w * 0.5,
    y: map.w * 0.82,
    r: F.PLAYER_R,
    hp: p.hp, hpMax: p.hp,
    atk: p.attack, def: p.defense,
    speed: F.PLAYER_SPEED,
    facing: -Math.PI / 2,     // 朝上
    mana: fldManaMax(), manaMax: fldManaMax(),
    shield: (function () {
      const g = (typeof petInnerBonus === "function") ? petInnerBonus("guard") : 0;
      const heal = S.healShield || 0;      // 回春丹护盾（v0.38.0）
      return Math.floor(p.hp * g) + Math.floor(p.hp * heal);
    })(), shieldSec: 0,
  };

  const f = {
    chapter,
    map,
    stage,
    t: 0,
    size: map.w,
    player,
    monsters: [],
    projectiles: [],
    warnings: [],      // 红圈预警
    events: [],        // 视觉事件（渲染层消费）
    cds: {},
    atkCd: 0,
    dashCd: 0,
    dashT: 0,
    auto: true,
    over: false,
    win: false,
    killCount: 0,
    bossKilled: false,
    dmgDealt: 0,
    // 探索（v0.17.0）
    nodes: [],
    explore: 0,
    portal: null,
    gatherTarget: null,
    gathered: 0,
  };

  // 跟宠（v0.21.0）：出战的灵兽作为独立实体跟随
  if (typeof petCombat === "function" && typeof activePet === "function") {
    const pc = petCombat(activePet());
    if (pc) {
      // v0.24.0：灵兽技能带入战场（主动技独立计时、被动技常驻乘算、战嚎标记下次普攻）
      f.pet = {
        x: player.x - 40, y: player.y + 40,
        r: 15,
        atk: pc.atk, speed: pc.speed, cd: pc.cd, atkCd: 0,
        color: pc.color, name: pc.name, lv: pc.lv,
        star: pc.star, bond: pc.bond,
        skills: pc.skills || [],
        skillCds: {},             // 主动技能独立冷却
        facing: -Math.PI / 2, pulse: 0,
      };
    }
  }
  // 技能盘初始化
  const slots = fldNormalizeSlots(S.fieldSlots, S.realm);
  const fabaoSkill = typeof selectedFabaoSkill === "function" ? selectedFabaoSkill() : null;
  if (fabaoSkill && !slots.includes(fabaoSkill.key)) slots.push(fabaoSkill.key);
  f.slots = slots;

  // 生成怪物（环形分布，越靠外越多）
  const mHp = CONFIG.enemyHp(stage);
  const mAtk = CONFIG.enemyAttack(stage);
  const mDef = CONFIG.enemyDefense(stage);
  let uid = 1;
  const put = (kind, tier) => {
    // 在玩家周围环形撒点，但不贴脸
    let x, y, tries = 0;
    do {
      const ang = Math.random() * Math.PI * 2;
      const dist = 170 + Math.random() * (map.w * 0.30);
      x = player.x + Math.cos(ang) * dist;
      y = player.y + Math.sin(ang) * dist;
      x = Math.max(60, Math.min(map.w - 60, x));
      y = Math.max(60, Math.min(map.w - 60, y));
      tries++;
    } while (Math.hypot(x - player.x, y - player.y) < 200 && tries < 20);

    const conf = kind === "boss"
      ? { hpM: 0.30, atkM: 0.95, defM: 0.60, r: 30, speedM: 0.8, name: "守阵妖兽", aoe: true }
      : kind === "elite"
        ? { hpM: 0.12, atkM: 0.85, defM: 0.50, r: 23, speedM: 0.95, name: "精英妖兽", aoe: true }
        : { hpM: 0.05, atkM: 0.75, defM: 0.45, r: 18, speedM: 1.0, name: "妖兽", aoe: false };

    f.monsters.push({
      id: uid++,
      kind,
      name: conf.name,
      element: (CONFIG.CHAPTER_ELEMENTS[chapter] || "wood"),
      x, y,
      homeX: x, homeY: y,
      r: conf.r,
      hp: mHp * conf.hpM,
      hpMax: mHp * conf.hpM,
      atk: mAtk * conf.atkM,
      def: mDef * conf.defM,
      speed: CONFIG.FIELD.MON_SPEED * conf.speedM,
      atkCd: Math.random() * CONFIG.FIELD.MON_ATTACK_CD,
      facing: 0,
      slowT: 0,
      aoe: conf.aoe,
      aoeCd: 4 + Math.random() * 3,
      channel: 0,       // 蓄力剩余时间
      channelTarget: null,
      alive: true,
      hurtT: 0,
    });
  };

  // 野生灵兽（可收服）
  if (typeof petDef === "function" && Math.random() < CONFIG.PET_WILD_RATE) {
    const pool = CONFIG.PETS.filter(pt => pt.realm <= (S.realm || 0) + 1);
    if (pool.length) {
      const wdef = pool[Math.floor(Math.random() * pool.length)];
      const ang = Math.random() * Math.PI * 2;
      const dist = 260 + Math.random() * 220;
      const wx = Math.max(60, Math.min(map.w - 60, player.x + Math.cos(ang) * dist));
      const wy = Math.max(60, Math.min(map.w - 60, player.y + Math.sin(ang) * dist));
      f.monsters.push({
        id: uid++,
        kind: "wild",
        petKey: wdef.key,
        element: (CONFIG.CHAPTER_ELEMENTS[chapter] || "wood"),
        name: wdef.name + "（野生）",
        x: wx, y: wy, homeX: wx, homeY: wy,
        r: 20,
        hp: mHp * 0.10, hpMax: mHp * 0.10,
        atk: mAtk * 0.45,
        def: mDef * 0.35,
        speed: CONFIG.FIELD.MON_SPEED * 0.9,
        atkCd: 1.5,
        facing: 0, slowT: 0, aoe: false, aoeCd: 9,
      });
    }
  }

  for (let i = 0; i < map.spawn; i++) put("normal");
  for (let i = 0; i < map.elite; i++) put("elite");
  if (map.boss) {
    // 守阵 BOSS 固定在地图北端传送阵，玩家一路清过去
    put("boss");
    const b = f.monsters[f.monsters.length - 1];
    b.x = map.w * 0.5;
    b.y = 150;
    b.homeX = b.x;
    b.homeY = b.y;
  }

  // 交互节点：矿脉 / 灵脉 / 灵植 / 遗迹
  const nodeKinds = CONFIG.FIELD_NODES;
  const nodeCount = CONFIG.FIELD_MAP_NODES[chapter] || 5;
  for (let i = 0; i < nodeCount; i++) {
    const def = nodeKinds[i % nodeKinds.length];
    let nx, ny, tries = 0;
    do {
      const ang = Math.random() * Math.PI * 2;
      const dist = 150 + Math.random() * (map.w * 0.34);
      nx = player.x + Math.cos(ang) * dist;
      ny = player.y + Math.sin(ang) * dist;
      nx = Math.max(70, Math.min(map.w - 70, nx));
      ny = Math.max(70, Math.min(map.w - 70, ny));
      tries++;
    } while (
      (Math.hypot(nx - player.x, ny - player.y) < 130
        || f.nodes.some(nd => Math.hypot(nd.x - nx, nd.y - ny) < 120))
      && tries < 30
    );

    f.nodes.push({
      id: 5000 + i,
      kind: def.key,
      name: def.name,
      color: def.color,
      glow: def.glow,
      x: nx, y: ny,
      r: def.r,
      gatherTime: def.gatherTime,
      explore: def.explore,
      done: false,
      progress: 0,
    });
  }

  // 本章探索总量 = 全部妖兽 + 全部采集节点（按实际生成量算，保证任何一章都能满）
  f.exploreMax =
    f.monsters.reduce((sum, m) => sum + (CONFIG.FIELD_KILL_EXPLORE[m.kind] || 6), 0) +
    f.nodes.reduce((sum, n) => sum + n.explore, 0);

  return f;
}

// ---------- 事件 ----------
function fldPush(f, ev) {
  f.events.push(ev);
  // 缓冲上限：即使消费方漏取，也不会无限增长
  if (f.events.length > 300) f.events.splice(0, 100);
}

// ---------- 伤害结算 ----------
function fldHit(f, attacker, target, mult, color, isPlayer) {
  const raw = Math.max(attacker.atk - target.def, attacker.atk * 0.05);
  let dmg = raw * (mult || 1);
  // 古宝特效（v0.35.0）：玩家伤害加成 / 受伤减免
  if (isPlayer && typeof ancientEffectSum === "function") {
    dmg *= (1 + ancientEffectSum("atk"));
  } else if (!isPlayer && target === f.player && typeof ancientEffectSum === "function") {
    dmg *= (1 - Math.min(0.5, ancientEffectSum("reduce")));
  }
  // 五行克制与流派专精（v0.36.0）
  if (isPlayer && typeof elementCombatMult === "function" && target.element) {
    dmg *= elementCombatMult(target.element) * (1 + elementMasteryBonus());
  }

  // 法宝词条暴击（仅玩家）
  let crit = false;
  if (isPlayer) {
    const af = (typeof artifactAffix === "function") ? artifactAffix() : { crit: 0 };
    const ancCrit = (typeof ancientEffectSum === "function") ? ancientEffectSum("crit") : 0;
    if (Math.random() < (af.crit || 0) + ancCrit) { dmg *= CONFIG.AFFIX_CRIT_MULT; crit = true; }
  }
  dmg = Math.max(1, Math.round(dmg));

  // 护盾（仅玩家有）
  let absorbed = 0;
  if (target.shield > 0) {
    absorbed = Math.min(target.shield, dmg);
    target.shield -= absorbed;
    dmg -= absorbed;
    if (target.shield <= 0) { target.shield = 0; target.shieldSec = 0; }
  }

  target.hp -= dmg;
  if (isPlayer) {
    f.dmgDealt += dmg + absorbed;
    // 古宝吸血（v0.35.0）
    const ls = (typeof ancientEffectSum === "function") ? ancientEffectSum("lifesteal") : 0;
    if (ls > 0) f.player.hp = Math.min(f.player.hpMax, f.player.hp + dmg * ls);
  } else if (target === f.player && attacker && attacker.hp !== undefined) {
    // 古宝反伤（v0.35.0）
    const th = (typeof ancientEffectSum === "function") ? ancientEffectSum("thorns") : 0;
    if (th > 0) attacker.hp -= Math.max(1, Math.round(dmg * th));
  }
  if (target.hurtT !== undefined) target.hurtT = 0.18;

  fldPush(f, {
    type: "hit",
    x: target.x, y: target.y,
    dmg, crit, absorbed,
    color: color || "#3A3A3A",
    toPlayer: !isPlayer,
  });

  if (target.hp <= 0 && target !== f.player) {
    target.alive = false;
    f.killCount++;
    if (target.kind === "boss") f.bossKilled = true;
    if (target.kind === "wild" && typeof fldTryCapture === "function") fldTryCapture(f, target);
    // v0.24.0：嗜血——灵兽击杀 → 主人回真元
    if (attacker === f.pet && f.pet && f.pet.skills && f.pet.skills.indexOf("devour") >= 0) {
      const dv = CONFIG.petSkillDef("devour");
      if (dv) p.mana = Math.min(p.manaMax, p.mana + dv.mana);
    }
    fldPush(f, { type: "death", x: target.x, y: target.y, kind: target.kind, r: target.r });
    fldAddExplore(f, CONFIG.FIELD_KILL_EXPLORE[target.kind] || 6, target.x, target.y);
  }
  return dmg;
}

// ---------- 野生灵兽收服（v0.21.0）----------
// 击败野生灵兽后按概率收服：基础概率由灵兽稀有度决定，
// 玩家境界高于灵兽需求境界时每层 +5%，上限 85%
function fldTryCapture(f, m) {
  if (typeof petDef !== "function" || typeof capturePet !== "function") return null;
  const def = petDef(m.petKey);
  if (!def) return null;
  let rate = def.capture + ((S.realm || 0) - def.realm) * 0.05;
  rate = Math.max(0.05, Math.min(0.85, rate));
  const ok = Math.random() < rate;
  if (ok) {
    const r = capturePet(def.key);
    if (r.ok) {
      if (typeof recordPetCodex === "function") recordPetCodex(def.key);
      fldPush(f, { type: "capture", x: m.x, y: m.y, ok: true, color: def.color, name: def.name, rate });
      return { ok: true, def, rate };
    }
    fldPush(f, { type: "capture", x: m.x, y: m.y, ok: false, color: def.color, name: def.name, rate, reason: r.msg });
    return { ok: false, def, rate, reason: r.msg };
  }
  fldPush(f, { type: "capture", x: m.x, y: m.y, ok: false, color: def.color, name: def.name, rate });
  return { ok: false, def, rate };
}

// ---------- 方向工具 ----------
function fldNorm(x, y) {
  const d = Math.hypot(x, y);
  if (d < 1e-6) return { x: 0, y: -1 };
  return { x: x / d, y: y / d };
}

// 屏幕方向 → 世界方向（等轴测逆变换），供方向轮盘与测试共用
function fsScreenDirToWorld(sx, sy) {
  const F = CONFIG.FIELD;
  const wx = sx / (2 * F.ISO_X) + sy / (2 * F.ISO_Y);
  const wy = -sx / (2 * F.ISO_X) + sy / (2 * F.ISO_Y);
  return fldNorm(wx, wy);
}

// 点是否在扇形内
function fldInCone(px, py, ox, oy, dx, dy, range, halfAngle, targetR) {
  const vx = px - ox, vy = py - oy;
  const dist = Math.hypot(vx, vy);
  if (dist > range + (targetR || 0)) return false;
  if (dist < 1e-6) return true;
  const dot = (vx / dist) * dx + (vy / dist) * dy;
  const ang = Math.acos(Math.max(-1, Math.min(1, dot)));
  // 目标半径带来的角度补偿
  const pad = targetR ? Math.atan2(targetR, Math.max(dist, 1)) : 0;
  return ang <= halfAngle + pad;
}

// 线段（起点+方向+长度）与圆的距离
function fldSegCircle(sx, sy, dx, dy, len, cx, cy, cr) {
  const vx = cx - sx, vy = cy - sy;
  const proj = Math.max(0, Math.min(len, vx * dx + vy * dy));
  const px = sx + dx * proj, py = sy + dy * proj;
  return Math.hypot(cx - px, cy - py) <= cr;
}

// ---------- 释放技能 ----------
function fldCast(f, key, dirX, dirY) {
  if (f.over) return { ok: false, msg: "战斗已结束" };
  const sk = fldSkill(key);
  if (!sk) return { ok: false, msg: "无此神通" };
  if ((f.cds[key] || 0) > 0) return { ok: false, msg: "冷却中" };
  if (f.player.hp <= 0) return { ok: false, msg: "已力竭" };
  if (f.player.mana < sk.mana) return { ok: false, msg: "真元不足" };

  // 神通参悟（v0.31.0）：每级 +3% 倍率
  const _insight = (typeof skillInsightMult === "function") ? skillInsightMult(key) : 1;
  const _ancSkill = (typeof ancientEffectSum === "function") ? ancientEffectSum("skill") : 0;
  const _mult = (sk.mult || 0) * _insight * (1 + _ancSkill);
  // 强锁（v0.26.0）：目标优先，无目标拒绝释放（不扣真元/CD）
  let lockTarget = null;
  let d;
  if (sk.lock === "target") {
    const near = fldNearest(f, f.player.x, f.player.y, CONFIG.FIELD.SKILL_LOCK_MAX_RANGE);
    if (!near) return { ok: false, msg: "无目标可锁定" };
    lockTarget = near;
    d = fldNorm(near.x - f.player.x, near.y - f.player.y);
  } else {
    d = fldNorm(dirX === undefined ? Math.cos(f.player.facing) : dirX,
                dirY === undefined ? Math.sin(f.player.facing) : dirY);
  }
  f.player.facing = Math.atan2(d.y, d.x);
  f.player.mana -= sk.mana;
  const _ancCd = (typeof ancientEffectSum === "function") ? Math.min(0.4, ancientEffectSum("cd")) : 0;
  f.cds[key] = sk.cd * (1 - _ancCd);

  // 五行相生连携（v0.46.0）：上一式所生之元素，下一式伤害提升
  let genBonus = 0;
  if (sk.element && sk.mult > 0 && typeof elementGenerates === "function"
      && f.lastElem && Date.now() - (f.lastElemAt || 0) <= CONFIG.ELEMENT_GEN_WINDOW * 1000
      && elementGenerates(f.lastElem, sk.element)) {
    genBonus = CONFIG.ELEMENT_GEN_BONUS;
    fldPush(f, { type: "elem_gen", from: f.lastElem, to: sk.element, mult: genBonus });
  }
  if (sk.element) { f.lastElem = sk.element; f.lastElemAt = Date.now(); }
  const _multGen = _mult * (1 + genBonus);

  if (sk.shape === "line") {
    f.projectiles.push({
      x: f.player.x, y: f.player.y,
      dx: d.x, dy: d.y,
      speed: lockTarget ? 980 : 660,
      r: (sk.width || 40) / 2,
      width: sk.width || 40,
      life: (sk.range || 300) / (lockTarget ? 980 : 660),
      dmgMult: _multGen,
      color: sk.color,
      pierce: sk.pierce || 1,
      hitIds: [],
      isPlayer: true,
      skillKey: key,
      homing: lockTarget || null,
    });
    fldPush(f, { type: "cast", shape: "line", lock: sk.lock, x: f.player.x, y: f.player.y, dx: d.x, dy: d.y, color: sk.color, tier: sk.tier, tx: lockTarget ? lockTarget.x : null, ty: lockTarget ? lockTarget.y : null });
  } else if (sk.shape === "cone") {
    const half = (sk.angle || 1) / 2;
    for (const m of f.monsters) {
      if (!m.alive) continue;
      if (fldInCone(m.x, m.y, f.player.x, f.player.y, d.x, d.y, sk.range, half, m.r)) {
        if (sk.slow) { m.slowT = sk.slowSec; }
        fldHit(f, { atk: f.player.atk }, m, _multGen, sk.color, true);
      }
    }
    fldPush(f, { type: "cast", shape: "cone", x: f.player.x, y: f.player.y, dx: d.x, dy: d.y, range: sk.range, angle: sk.angle, color: sk.color, tier: sk.tier });
  } else if (sk.shape === "nova") {
    for (const m of f.monsters) {
      if (!m.alive) continue;
      if (Math.hypot(m.x - f.player.x, m.y - f.player.y) <= (sk.range || 160) + m.r) {
        if (sk.slow) m.slowT = sk.slowSec;
        fldHit(f, { atk: f.player.atk }, m, _multGen, sk.color, true);
      }
    }
    fldPush(f, { type: "cast", shape: "nova", x: f.player.x, y: f.player.y, range: sk.range || 160, color: sk.color, tier: sk.tier });
  } else if (sk.shape === "self") {
    if (sk.healPct) {
      const amt = Math.floor(f.player.hpMax * sk.healPct);
      f.player.hp = Math.min(f.player.hpMax, f.player.hp + amt);
      fldPush(f, { type: "heal", x: f.player.x, y: f.player.y, amount: amt, color: sk.color });
    }
    if (sk.shieldPct) {
      f.player.shield = Math.floor(f.player.hpMax * sk.shieldPct);
      f.player.shieldSec = sk.shieldSec || 8;
      fldPush(f, { type: "shield", x: f.player.x, y: f.player.y, amount: f.player.shield, color: sk.color });
    }
  }
  fldPush(f, { type: "casted", key, name: sk.name, elem: sk.element || null, gen: genBonus > 0 });
  return { ok: true, element: sk.element || null, gen: genBonus > 0 };
}

// ---------- 探索度与传送阵（v0.17.0）----------
function fldAddExplore(f, amount, x, y) {
  if (f.explore >= f.exploreMax) return;
  f.explore = Math.min(f.exploreMax, f.explore + amount);
  fldPush(f, { type: "explore", amount, total: f.explore, max: f.exploreMax, x, y });
  if (!f.portal && f.explore >= f.exploreMax * 0.75) {
    const boss = f.monsters.find(m => m.kind === "boss");
    const px = boss ? boss.x : f.size / 2;
    const py = boss ? boss.y : 150;
    f.portal = { x: px, y: py };
    fldPush(f, { type: "portal", x: px, y: py });
  }
}

// ---------- 采集完成 ----------
function fldFinishGather(f, node) {
  node.done = true;
  node.progress = 0;
  f.gathered++;
  const def = CONFIG.FIELD_NODES.find(d => d.key === node.kind);
  const _gfField = (typeof gongfaBonus === "function") ? (gongfaBonus().field || 0) : 0;
  const realmMul = (1 + S.realm * 0.35) * (1 + _gfField);   // 功法「秘境收获」
  const amt = Math.max(1, Math.floor((def.base || 1) * realmMul * (0.8 + Math.random() * 0.4)));

  let text = "";
  if (node.kind === "ore") { S.stone += amt; text = "灵石 +" + fmt(amt); }
  else if (node.kind === "vein") { S.qi += amt; text = "灵气 +" + fmt(amt); }
  else if (node.kind === "herb") { gainItem("herb", amt); text = "灵草 +" + amt; }
  else {
    const m = amt * 2;
    gainItem("material", m);
    text = "灵材 +" + m;
  }
  save();

  // 章节特产（v0.29.0）：采集有概率带出本章特产
  if (typeof specialtyDrop === "function" && Math.random() < 0.5) {
    const sp = specialtyDrop(f.chapter, "gather");
    text += "、 特产 " + (CONFIG.FIELD_SPECIALTIES[f.chapter] || "") + " +" + sp;
  }
  fldPush(f, {
    type: "gathered",
    x: node.x, y: node.y,
    kind: node.kind,
    text, color: def.glow || "#E4D9C4",
  });
  fldAddExplore(f, node.explore, node.x, node.y);
}

// ---------- 主推进 ----------
// input: { mx, my, dash }   mx/my ∈ [-1,1]
function fldStep(f, dt, input) {
  if (f.over) return [];
  const _evStart = f.events.length;   // 本帧事件起点
  const F = CONFIG.FIELD;
  const inp = input || { mx: 0, my: 0, dash: false };
  f.t += dt;
  if (f.t >= F.MAX_SECONDS) {
    fldEnd(f, f.explore >= f.exploreMax * 0.75);
    return f.events.slice(_evStart);
  }

  const p = f.player;

  // ===== 玩家移动 =====
  f.dashCd = Math.max(0, f.dashCd - dt);
  if (inp.dash && f.dashCd <= 0 && (inp.mx || inp.my)) {
    f.dashT = F.DASH_TIME;
    f.dashCd = F.DASH_CD;
    fldPush(f, { type: "dash", x: p.x, y: p.y });
  }
  const mv = fldNorm(inp.mx, inp.my);
  const moving = (inp.mx !== 0 || inp.my !== 0);
  if (moving) p.facing = Math.atan2(mv.y, mv.x);

  if (f.dashT > 0) {
    f.dashT -= dt;
    const sp = F.DASH_SPEED * dt;
    p.x += mv.x * sp;
    p.y += mv.y * sp;
    if (Math.random() < 0.5) fldPush(f, { type: "trail", x: p.x, y: p.y });
  } else if (moving) {
    p.x += mv.x * p.speed * dt;
    p.y += mv.y * p.speed * dt;
  }
  // 地图边界
  p.x = Math.max(p.r, Math.min(f.size - p.r, p.x));
  p.y = Math.max(p.r, Math.min(f.size - p.r, p.y));

  // ===== 跟宠（v0.21.0）=====
  if (f.pet) {
    const pt = f.pet;
    // 跟随：站在主人身后 PET_FOLLOW_DIST 处
    const tx = p.x - Math.cos(p.facing) * CONFIG.PET_FOLLOW_DIST;
    const ty = p.y - Math.sin(p.facing) * CONFIG.PET_FOLLOW_DIST;
    const fdx = tx - pt.x, fdy = ty - pt.y;
    const fdist = Math.hypot(fdx, fdy);
    if (fdist > 6) {
      // 距离越远追得越快，避免掉队也避免抖动
      const sp = Math.min(fdist, pt.speed * dt * (fdist > 160 ? 1.8 : 1));
      pt.x += (fdx / fdist) * sp;
      pt.y += (fdy / fdist) * sp;
    }
    pt.x = Math.max(pt.r, Math.min(f.size - pt.r, pt.x));
    pt.y = Math.max(pt.r, Math.min(f.size - pt.r, pt.y));
    // v0.24.0：主动技能冷却每帧递减
    for (const k in pt.skillCds) pt.skillCds[k] = Math.max(0, pt.skillCds[k] - dt);
    // 索敌出手
    pt.atkCd = Math.max(0, pt.atkCd - dt);
    pt.pulse = Math.max(0, pt.pulse - dt * 3);
    let target = null, best = 1e9;
    for (const m of f.monsters) {
      if (!m.alive) continue;
      const d = Math.hypot(m.x - pt.x, m.y - pt.y);
      if (d < best && d <= CONFIG.PET_SEEK_RANGE) { best = d; target = m; }
    }
    if (target) {
      pt.facing = Math.atan2(target.y - pt.y, target.x - pt.x);
      if (pt.atkCd <= 0) {
        pt.atkCd = pt.cd;
        pt.pulse = 1;
        // v0.24.0：獠牙（被动）普攻乘算
        const hasFang = pt.skills && pt.skills.indexOf("fang") >= 0;
        const fangDef = hasFang ? CONFIG.petSkillDef("fang") : null;
        fldHit(f, pt, target, fangDef ? fangDef.mult : 1, pt.color, false);
        fldPush(f, { type: "petcast", x: pt.x, y: pt.y, tx: target.x, ty: target.y, color: pt.color });
      }
      // v0.24.0：主动技能（独立冷却，各自因果闭环）
      for (const sk of (pt.skills || [])) {
        const sd = CONFIG.petSkillDef(sk);
        if (!sd || sd.type !== "active") continue;
        if ((pt.skillCds[sk] || 0) > 0) continue;
        pt.skillCds[sk] = sd.cd;
        if (sk === "smash") {
          // 猛扑：220% 一击
          fldHit(f, pt, target, sd.mult, pt.color, true);
          fldPush(f, { type: "petcast", x: pt.x, y: pt.y, tx: target.x, ty: target.y, color: pt.color, big: true });
        } else if (sk === "guard") {
          // 护主：给玩家护盾（吸收伤害走 fldHit 通用护盾结算）
          p.shield = Math.floor(pt.atk * sd.mult);
          p.shieldSec = 12;
          fldPush(f, { type: "shield", x: p.x, y: p.y, amount: p.shield, color: pt.color });
        } else if (sk === "roar") {
          // 战嚎：标记玩家下次普攻 ×1.6
          f.petRoarNext = true;
          fldPush(f, { type: "petcast", x: pt.x, y: pt.y, tx: p.x, ty: p.y, color: pt.color, big: true });
        }
      }
    }
  }

  // 护盾计时
  if (p.shieldSec > 0) {
    p.shieldSec -= dt;
    if (p.shieldSec <= 0) p.shield = 0;
  }
  // 真元回复
  const _manaBoost = (typeof petInnerBonus === "function") ? petInnerBonus("mana") : 0;
  p.mana = Math.min(p.manaMax, p.mana + 8 * dt * (1 + _manaBoost));

  // 技能冷却
  for (const k in f.cds) if (f.cds[k] > 0) f.cds[k] = Math.max(0, f.cds[k] - dt);

  // ===== 普攻（自动锁最近敌人，1.4 秒一次）=====
  f.atkCd = Math.max(0, f.atkCd - dt);
  if (f.auto && f.atkCd <= 0) {
    const near = fldNearest(f, p.x, p.y);
    if (near && Math.hypot(near.x - p.x, near.y - p.y) <= 260) {
      const d = fldNorm(near.x - p.x, near.y - p.y);
      p.facing = Math.atan2(d.y, d.x);
      f.atkCd = F.AUTO_CD;
      // v0.24.0：战嚎标记 → 本次普攻 ×1.6 后清除
      let basicMult = 1.0;
      if (f.petRoarNext) { basicMult = 1.6; f.petRoarNext = false; }
      f.projectiles.push({
        x: p.x, y: p.y, dx: d.x, dy: d.y,
        speed: 720, r: 10, width: 20, life: 0.42,
        dmgMult: basicMult, color: "#6E675D", pierce: 1, hitIds: [], isPlayer: true, basic: true,
      });
      fldPush(f, { type: "basic", x: p.x, y: p.y, dx: d.x, dy: d.y });
    }
  }

  // ===== 人兽合击（v0.35.0）：亲密度 ≥80，每 60 秒一次 ===='
  if (f.pet) {
    f.comboT = (f.comboT || 0) + dt;
    const _ap = (typeof activePet === "function") ? activePet() : null;
    const bond = _ap ? (_ap.bond || 0) : 0;
    if (bond >= CONFIG.PET_COMBO.BOND && f.comboT >= CONFIG.PET_COMBO.CD_SEC) {
      const near = fldNearest(f, p.x, p.y, 420);
      if (near) {
        f.comboT = 0;
        fldHit(f, { atk: p.atk * CONFIG.PET_COMBO.MULT }, near, 1, "#C1543A", true);
        fldPush(f, { type: "combo", x: near.x, y: near.y, tx: p.x, ty: p.y });
      }
    }
  }

  // ===== 投射物 =====
  for (let i = f.projectiles.length - 1; i >= 0; i--) {
    const pr = f.projectiles[i];
    // 强锁追踪（v0.26.0）：弹道每帧微调朝向目标，目标死亡即直行
    if (pr.homing && pr.homing.alive) {
      const hd = fldNorm(pr.homing.x - pr.x, pr.homing.y - pr.y);
      const blend = Math.min(1, dt * 10);
      const nd = fldNorm(pr.dx + (hd.x - pr.dx) * blend, pr.dy + (hd.y - pr.dy) * blend);
      pr.dx = nd.x; pr.dy = nd.y;
      if (pr.life < 0.25) pr.life = 0.25;
    }
    pr.x += pr.dx * pr.speed * dt;
    pr.y += pr.dy * pr.speed * dt;
    pr.life -= dt;

    if (pr.isPlayer) {
      for (const m of f.monsters) {
        if (!m.alive) continue;
        if (pr.hitIds.indexOf(m.id) >= 0) continue;
        if (Math.hypot(m.x - pr.x, m.y - pr.y) <= m.r + pr.r) {
          pr.hitIds.push(m.id);
          fldHit(f, { atk: f.player.atk }, m, pr.dmgMult, pr.color, true);
          pr.pierce--;
          if (pr.pierce <= 0) { pr.life = 0; break; }
        }
      }
    }

    if (pr.life <= 0 || pr.x < 0 || pr.y < 0 || pr.x > f.size || pr.y > f.size) {
      if (pr.isPlayer) fldPush(f, { type: "projEnd", x: pr.x, y: pr.y, color: pr.color });
      f.projectiles.splice(i, 1);
    }
  }

  // ===== 敌人 =====
  for (const m of f.monsters) {
    if (!m.alive) continue;
    if (m.hurtT > 0) m.hurtT -= dt;
    if (m.slowT > 0) m.slowT -= dt;
    m.atkCd = Math.max(0, m.atkCd - dt);
    m.aoeCd = Math.max(0, m.aoeCd - dt);

    const distToPlayer = Math.hypot(p.x - m.x, p.y - m.y);
    const distHome = Math.hypot(m.homeX - m.x, m.homeY - m.y);

    // 脱战回巢（BOSS 不脱战，否则玩家清到一半会被迫重打）
    if (distHome > F.LEASH && m.kind !== "boss") {
      m.channel = 0;
      m.channelTarget = null;
      fldMoveToward(m, m.homeX, m.homeY, dt, m.slowT > 0 ? 0.55 : 1);
      m.hp = Math.min(m.hpMax, m.hp + m.hpMax * F.MON_HP_RESET * dt);
      continue;
    }

    // 蓄力中
    if (m.channel > 0) {
      m.channel -= dt;
      if (m.channel <= 0 && m.channelTarget) {
        // AOE 落下
        const tx = m.channelTarget.x, ty = m.channelTarget.y;
        const rr = m.channelTarget.r;
        fldPush(f, { type: "aoeBurst", x: tx, y: ty, r: rr, color: "#A93F2E" });
        if (Math.hypot(p.x - tx, p.y - ty) <= rr + p.r) {
          fldHit(f, m, p, 1.3, "#A93F2E", false);
        }
        m.channelTarget = null;
        m.aoeCd = 7 + Math.random() * 3;
      }
      continue;
    }

    // 是否仇恨
    const aggro = distToPlayer <= F.AGGRO || m.hp < m.hpMax;

    if (aggro) {
      const d = fldNorm(p.x - m.x, p.y - m.y);
      m.facing = Math.atan2(d.y, d.x);

      // 精英/BOSS：远程红圈预警
      if (m.aoe && m.aoeCd <= 0 && distToPlayer < 420 && distToPlayer > 70) {
        m.channel = 1.0;
        m.channelTarget = { x: p.x, y: p.y, r: m.kind === "boss" ? 120 : 92 };
        fldPush(f, { type: "aoeWarn", x: p.x, y: p.y, r: m.channelTarget.r, dur: 1.0, boss: m.kind === "boss", kind: m.kind, srcX: m.x, srcY: m.y });
        continue;
      }

      if (distToPlayer > F.MON_ATTACK_RANGE + m.r) {
        fldMoveToward(m, p.x, p.y, dt, m.slowT > 0 ? 0.55 : 1);
      } else if (m.atkCd <= 0) {
        m.atkCd = F.MON_ATTACK_CD;
        fldHit(f, m, p, 1.0, "#8B2E4A", false);
        fldPush(f, { type: "monAttack", x: m.x, y: m.y, tx: p.x, ty: p.y });
      }
    } else {
      // 回巢游荡
      if (distHome > 30) fldMoveToward(m, m.homeX, m.homeY, dt, 0.6);
    }

    // 边界
    m.x = Math.max(m.r, Math.min(f.size - m.r, m.x));
    m.y = Math.max(m.r, Math.min(f.size - m.r, m.y));
  }

  // ===== 单位互相推开（避免叠在一起）=====
  for (let i = 0; i < f.monsters.length; i++) {
    const a = f.monsters[i];
    if (!a.alive) continue;
    for (let j = i + 1; j < f.monsters.length; j++) {
      const b = f.monsters[j];
      if (!b.alive) continue;
      const dx = b.x - a.x, dy = b.y - a.y;
      const d = Math.hypot(dx, dy);
      const min = a.r + b.r;
      if (d > 0 && d < min) {
        const push = (min - d) / 2;
        const nx = dx / d, ny = dy / d;
        a.x -= nx * push; a.y -= ny * push;
        b.x += nx * push; b.y += ny * push;
      }
    }
  }

  // ===== 采集（贴近节点自动采集；走开则进度归零）=====
  let gatherTarget = null;
  for (const n of f.nodes) {
    if (n.done) continue;
    if (Math.hypot(n.x - p.x, n.y - p.y) <= n.r + 46) { gatherTarget = n; break; }
  }
  if (gatherTarget) {
    gatherTarget.progress += dt;
    f.gatherTarget = gatherTarget;
    if (gatherTarget.progress >= gatherTarget.gatherTime) fldFinishGather(f, gatherTarget);
  } else {
    for (const n of f.nodes) if (!n.done) n.progress = 0;
    f.gatherTarget = null;
  }

  // ===== 传送阵：探索度 ≥80 开启，走进去即通关 =====
  if (f.portal && Math.hypot(f.portal.x - p.x, f.portal.y - p.y) <= CONFIG.FIELD_PORTAL_R) {
    fldEnd(f, true);
    return f.events.slice(_evStart);
  }

  // ===== 胜负 =====
  if (p.hp <= 0) { fldEnd(f, false); }
  else if (f.explore >= f.exploreMax) { fldEnd(f, true); }
  else if (f.monsters.every(m => !m.alive) && f.nodes.every(n => n.done)) { fldEnd(f, true); }

  return f.events.slice(_evStart);
}

function fldMoveToward(m, tx, ty, dt, speedMul) {
  const d = fldNorm(tx - m.x, ty - m.y);
  m.x += d.x * m.speed * (speedMul || 1) * dt;
  m.y += d.y * m.speed * (speedMul || 1) * dt;
}

function fldNearest(f, x, y, maxDist) {
  let best = null, bd = 1e9;
  for (const m of f.monsters) {
    if (!m.alive) continue;
    const d = Math.hypot(m.x - x, m.y - y);
    if (d < bd && (maxDist === undefined || d <= maxDist)) { bd = d; best = m; }
  }
  return best;
}

function fldEnd(f, win) {
  f.over = true;
  f.win = win;
  if (win) {
    // 功法要诀：秘境通关是主要产出来源（v0.20.0）
    const gain = 1 + Math.floor((f.map.chapter || 0) / 3);
    gainItem("talisman", gain);
    fldPush(f, { type: "reward", text: "功法残卷 +" + gain });
    // 章节特产（v0.29.0）：首通 BOSS 多给
    if (typeof specialtyDrop === "function") {
      const sp = specialtyDrop(f.map.chapter, f.bossKilled ? "boss" : "clear");
      fldPush(f, { type: "reward", text: (CONFIG.FIELD_SPECIALTIES[f.map.chapter] || "特产") + " +" + sp });
    }
    save();
  }
  fldPush(f, { type: "end", win });
}

// 消耗事件（渲染层每帧取走）
function fldDrainEvents(f) {
  const e = f.events;
  f.events = [];
  return e;
}
