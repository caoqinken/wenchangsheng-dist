// ============================================================
// 《问长生》战斗 v2 视觉层：Canvas 2D 骨骼小人（v0.15.0）
// 设计依据：docs/04 §6 + §10.2「动画重叠规则」
// 原则：全部程序化绘制，0 美术资源、0 包体增长
// ============================================================

const B2V = {
  canvas: null, ctx: null, w: 0, h: 0, dpr: 1,
  raf: 0, running: false,
  battle: null,
  actors: { ally: null, enemy: null },
  effects: [],        // 特效层（含残影）
  floaters: [],       // 伤害飘字
  shake: 0,           // 屏震
  onEnd: null,
};

// ---------- 墨色配置（与水墨国风一致）----------
const B2V_COLORS = {
  ally: "#2B2B2B",
  enemy: "#5A2E2E",
  ink: "#1F1F1F",
  allyAura: "#4A6B5A",
  enemyAura: "#8B3A3A",
  crit: "#A93F2E",
  heal: "#3E7A5E",
  shield: "#3E6E9E",
  ctrl: "#7A5AA8",
  hp: "#8B2E4A",
  hpEnemy: "#7A2A2A",
  qi: "#C9A227",
  mana: "#3E7EB8",
};

// ---------- 姿态 ----------
function b2vPose() {
  return {
    bob: 0,        // 躯干起伏
    lean: 0,       // 前倾角度
    head: 0,
    armLs: -0.5, armLf: -0.3,   // 左 大臂/小臂 角度（弧度）
    armRs: -0.5, armRf: -0.3,
    legLs: 0.15, legLf: 0.05,
    legRs: -0.15, legRf: 0.05,
  };
}

function b2vLerpPose(a, b, t) {
  const o = {};
  for (const k in a) o[k] = a[k] + (b[k] - a[k]) * t;
  return o;
}

function b2vEase(t) {
  // easeOutQuad
  return 1 - (1 - t) * (1 - t);
}

// ---------- 动作库：关键帧 {t:0~1, pose} ----------
const B2V_ACTIONS = {
  idle: {
    dur: 1.6, loop: true,
    frames: [
      { t: 0, p: { bob: 0, lean: 0, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 0.5, p: { bob: -2, lean: 0.02, head: 0.02, armLs: -0.56, armLf: -0.34, armRs: -0.44, armRf: -0.26, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 1, p: { bob: 0, lean: 0, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
    ],
  },
  punch: {
    dur: 0.34,
    frames: [
      { t: 0, p: { bob: 0, lean: -0.06, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 0.35, p: { bob: -1, lean: 0.12, head: 0.1, armLs: -0.9, armLf: -1.2, armRs: -0.2, armRf: -0.1, legLs: 0.3, legLf: 0.1, legRs: -0.35, legRf: 0.08 } },
      { t: 0.6, p: { bob: 0, lean: 0.18, head: 0.12, armLs: -1.35, armLf: -0.05, armRs: -0.15, armRf: -0.1, legLs: 0.35, legLf: 0.12, legRs: -0.4, legRf: 0.1 } },
      { t: 1, p: { bob: 0, lean: 0.04, head: 0.02, armLs: -0.55, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.18, legLf: 0.06, legRs: -0.18, legRf: 0.06 } },
    ],
  },
  swipe: {
    dur: 0.4,
    frames: [
      { t: 0, p: { bob: 0, lean: -0.05, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 0.3, p: { bob: -1, lean: -0.12, head: -0.08, armLs: -0.4, armLf: -2.0, armRs: -0.5, armRf: -0.3, legLs: 0.2, legLf: 0.06, legRs: -0.2, legRf: 0.06 } },
      { t: 0.62, p: { bob: 0, lean: 0.16, head: 0.1, armLs: -1.9, armLf: -0.15, armRs: -0.4, armRf: -0.25, legLs: 0.3, legLf: 0.1, legRs: -0.3, legRf: 0.08 } },
      { t: 1, p: { bob: 0, lean: 0.03, head: 0.01, armLs: -0.55, armLf: -0.32, armRs: -0.5, armRf: -0.3, legLs: 0.16, legLf: 0.05, legRs: -0.16, legRf: 0.05 } },
    ],
  },
  slam: {
    dur: 0.52,
    frames: [
      { t: 0, p: { bob: 0, lean: 0, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 0.34, p: { bob: -6, lean: -0.18, head: -0.14, armLs: -2.4, armLf: -0.2, armRs: -2.4, armRf: -0.2, legLs: 0.1, legLf: 0.05, legRs: -0.1, legRf: 0.05 } },
      { t: 0.58, p: { bob: 3, lean: 0.3, head: 0.22, armLs: -0.2, armLf: 0.35, armRs: -0.2, armRf: 0.35, legLs: 0.42, legLf: 0.14, legRs: -0.42, legRf: 0.14 } },
      { t: 1, p: { bob: 0, lean: 0.04, head: 0.02, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.17, legLf: 0.06, legRs: -0.17, legRf: 0.06 } },
    ],
  },
  triple: {
    dur: 0.55,
    frames: [
      { t: 0, p: { bob: 0, lean: -0.04, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 0.22, p: { bob: -2, lean: 0.1, head: 0.06, armLs: -1.4, armLf: -0.2, armRs: -0.3, armRf: -0.2, legLs: 0.26, legLf: 0.08, legRs: -0.28, legRf: 0.08 } },
      { t: 0.42, p: { bob: 0, lean: 0.02, head: 0, armLs: -0.7, armLf: -0.5, armRs: -1.3, armRf: -0.25, legLs: 0.2, legLf: 0.06, legRs: -0.22, legRf: 0.06 } },
      { t: 0.62, p: { bob: -1, lean: 0.14, head: 0.08, armLs: -1.5, armLf: -0.15, armRs: -0.4, armRf: -0.25, legLs: 0.3, legLf: 0.1, legRs: -0.32, legRf: 0.09 } },
      { t: 1, p: { bob: 0, lean: 0.03, head: 0.01, armLs: -0.55, armLf: -0.32, armRs: -0.5, armRf: -0.3, legLs: 0.16, legLf: 0.05, legRs: -0.16, legRf: 0.05 } },
    ],
  },
  slash: {
    dur: 0.62,
    frames: [
      { t: 0, p: { bob: 0, lean: -0.05, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 0.32, p: { bob: -4, lean: -0.22, head: -0.16, armLs: -2.7, armLf: -0.15, armRs: -2.6, armRf: -0.15, legLs: 0.08, legLf: 0.04, legRs: -0.08, legRf: 0.04 } },
      { t: 0.55, p: { bob: 2, lean: 0.34, head: 0.26, armLs: 0.35, armLf: 0.4, armRs: 0.3, armRf: 0.4, legLs: 0.46, legLf: 0.16, legRs: -0.46, legRf: 0.16 } },
      { t: 1, p: { bob: 0, lean: 0.04, head: 0.02, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.17, legLf: 0.06, legRs: -0.17, legRf: 0.06 } },
    ],
  },
  glow: {
    dur: 0.6,
    frames: [
      { t: 0, p: { bob: 0, lean: 0, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 0.4, p: { bob: -3, lean: -0.06, head: -0.1, armLs: -1.1, armLf: -0.9, armRs: -1.1, armRf: -0.9, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 1, p: { bob: 0, lean: 0, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
    ],
  },
  ring: {
    dur: 0.55,
    frames: [
      { t: 0, p: { bob: 0, lean: 0, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 0.35, p: { bob: 2, lean: -0.02, head: -0.06, armLs: -1.2, armLf: -0.2, armRs: -1.2, armRf: -0.2, legLs: 0.22, legLf: 0.08, legRs: -0.22, legRf: 0.08 } },
      { t: 1, p: { bob: 0, lean: 0, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
    ],
  },
  flame: {
    dur: 0.65,
    frames: [
      { t: 0, p: { bob: 0, lean: 0, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 0.4, p: { bob: -4, lean: -0.1, head: -0.18, armLs: -1.5, armLf: 0.2, armRs: -1.5, armRf: 0.2, legLs: 0.3, legLf: 0.12, legRs: -0.3, legRf: 0.12 } },
      { t: 1, p: { bob: 0, lean: 0, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
    ],
  },
  bind: {
    dur: 0.5,
    frames: [
      { t: 0, p: { bob: 0, lean: 0, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 0.3, p: { bob: -1, lean: 0.08, head: 0.06, armLs: -1.7, armLf: -1.4, armRs: -0.4, armRf: -0.2, legLs: 0.24, legLf: 0.08, legRs: -0.26, legRf: 0.08 } },
      { t: 0.6, p: { bob: 0, lean: 0.12, head: 0.08, armLs: -1.9, armLf: -1.5, armRs: -0.5, armRf: -0.25, legLs: 0.28, legLf: 0.1, legRs: -0.3, legRf: 0.1 } },
      { t: 1, p: { bob: 0, lean: 0.03, head: 0.01, armLs: -0.55, armLf: -0.32, armRs: -0.5, armRf: -0.3, legLs: 0.16, legLf: 0.05, legRs: -0.16, legRf: 0.05 } },
    ],
  },
  hurt: {
    dur: 0.28,
    frames: [
      { t: 0, p: { bob: 0, lean: 0, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 0.35, p: { bob: 1, lean: -0.2, head: -0.26, armLs: -0.1, armLf: -0.1, armRs: -0.1, armRf: -0.1, legLs: 0.05, legLf: 0.02, legRs: -0.25, legRf: 0.1 } },
      { t: 1, p: { bob: 0, lean: 0, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
    ],
  },
  dead: {
    dur: 0.9,
    frames: [
      { t: 0, p: { bob: 0, lean: 0, head: 0, armLs: -0.5, armLf: -0.3, armRs: -0.5, armRf: -0.3, legLs: 0.15, legLf: 0.05, legRs: -0.15, legRf: 0.05 } },
      { t: 1, p: { bob: 14, lean: -0.9, head: -0.5, armLs: -0.2, armLf: -0.1, armRs: -0.2, armRf: -0.1, legLs: 0.6, legLf: 0.3, legRs: -0.6, legRf: 0.3 } },
    ],
  },
};

// ---------- 制作角色 ----------
function b2vMakeActor(side) {
  return {
    side,
    action: "idle",
    actionT: 0,
    actionDur: B2V_ACTIONS.idle.dur,
    loop: true,
    ghosts: [],     // 残影（上一招特效层，扩散淡出）
    dead: false,
    hurtT: 0,
  };
}

// ---------- 播放动作（含"旧动作立即停止 + 特效降级为残影"规则）----------
function b2vPlay(actor, name) {
  if (!B2V_ACTIONS[name]) name = "punch";
  // 用户规则：新招出手的同一帧，旧招骨骼立即停止，特效层降级为残影
  if (actor.action !== "idle" && actor.action !== "dead") {
    actor.ghosts.push({
      action: actor.action,
      t: actor.actionT,
      dur: actor.actionDur,
      fade: 0,          // 0 → 1 的扩散淡出进度
      life: 0.25,
    });
    if (actor.ghosts.length > 2) actor.ghosts.shift();   // 最多 2 层
  }
  actor.action = name;
  actor.actionT = 0;
  actor.actionDur = B2V_ACTIONS[name].dur;
  actor.loop = !!B2V_ACTIONS[name].loop;
}

// ---------- 姿态采样 ----------
function b2vSample(actionName, t01) {
  const act = B2V_ACTIONS[actionName];
  if (!act) return b2vPose();
  const fr = act.frames;
  let a = fr[0], b = fr[fr.length - 1];
  for (let i = 0; i < fr.length - 1; i++) {
    if (t01 >= fr[i].t && t01 <= fr[i + 1].t) { a = fr[i]; b = fr[i + 1]; break; }
  }
  const span = (b.t - a.t) || 1;
  const lt = Math.max(0, Math.min(1, (t01 - a.t) / span));
  return b2vLerpPose(a.p, b.p, b2vEase(lt));
}

// ---------- 初始化 ----------
function b2vInit(canvas) {
  B2V.canvas = canvas;
  B2V.ctx = canvas.getContext("2d");
  b2vResize();
}

function b2vResize() {
  const c = B2V.canvas;
  if (!c) return;
  const rect = c.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  B2V.dpr = dpr;
  B2V.w = rect.width || c.clientWidth || 320;
  B2V.h = rect.height || c.clientHeight || 220;
  c.width = Math.round(B2V.w * dpr);
  c.height = Math.round(B2V.h * dpr);
  B2V.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

// ---------- 绘制单个小人 ----------
function b2vDrawActor(ctx, actor, pose, x, baseY, scale, facing, color, auraColor) {
  const S1 = scale;             // 上身长度
  ctx.save();
  ctx.translate(x, baseY);
  ctx.scale(facing * S1, S1);

  const hipY = -18;
  const shoulderY = -46;
  const headR = 7;

  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = color;
  ctx.fillStyle = color;

  const drawLimb = (x0, y0, a1, l1, a2, l2, w) => {
    const x1 = x0 + Math.sin(a1) * l1;
    const y1 = y0 + Math.cos(a1) * l1;
    const a2abs = a1 + a2;
    const x2 = x1 + Math.sin(a2abs) * l2;
    const y2 = y1 + Math.cos(a2abs) * l2;
    ctx.lineWidth = w;
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    return { x: x2, y: y2 };
  };

  const lean = pose.lean || 0;
  const bob = pose.bob || 0;

  // 腿
  drawLimb(-3, hipY, pose.legLs, 16, pose.legLf, 14, 4.2);
  drawLimb(3, hipY, pose.legRs, 16, pose.legRf, 14, 4.2);

  // 躯干（微倾）
  const sx = Math.sin(lean) * (shoulderY - hipY) * -1;
  const sy = hipY + (shoulderY - hipY) * Math.cos(lean);
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(0, hipY + bob * 0.3);
  ctx.quadraticCurveTo(sx * 0.5, (hipY + sy) / 2, sx, sy);
  ctx.stroke();

  // 头
  const hx = sx + Math.sin(lean + (pose.head || 0)) * 9;
  const hy = sy + Math.cos(lean + (pose.head || 0)) * 9;
  ctx.beginPath(); ctx.arc(hx, hy, headR, 0, Math.PI * 2); ctx.fill();

  // 手臂
  drawLimb(sx - 2, sy + 2, pose.armLs, 14, pose.armLf, 12, 3.6);
  drawLimb(sx + 2, sy + 2, pose.armRs, 14, pose.armRf, 12, 3.6);

  // 脚下阴影
  ctx.globalAlpha = 0.16;
  ctx.beginPath();
  ctx.ellipse(0, 6, 16, 4.5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;

  ctx.restore();
}

// ---------- 特效 ----------
function b2vSpawnEffect(kind, side, tier) {
  const col = side === "ally" ? B2V_COLORS.allyAura : B2V_COLORS.enemyAura;
  B2V.effects.push({ kind, side, tier: tier || 1, t: 0, life: b2vEffectLife(kind), color: col });
  if (B2V.effects.length > 24) B2V.effects.shift();
}

function b2vEffectLife(kind) {
  switch (kind) {
    case "slash": case "triple": return 0.38;
    case "slam": return 0.45;
    case "punch": return 0.22;
    case "glow": case "ring": case "flame": case "bind": return 0.55;
    default: return 0.3;
  }
}

function b2vDrawEffects(ctx, dt) {
  const W = B2V.w, H = B2V.h;
  const midX = W / 2;
  const allyX = W * 0.72;
  const enemyX = W * 0.28;

  for (let i = B2V.effects.length - 1; i >= 0; i--) {
    const e = B2V.effects[i];
    e.t += dt;
    const p = e.t / e.life;
    if (p >= 1) { B2V.effects.splice(i, 1); continue; }
    const alpha = 1 - p;
    const fromX = e.side === "ally" ? allyX : enemyX;
    const toX = e.side === "ally" ? enemyX : allyX;
    const dir = e.side === "ally" ? -1 : 1;

    ctx.save();
    ctx.globalAlpha = alpha;

    if (e.kind === "slash") {
      // 剑气：从己方扫向对面的弧线
      const sweep = 1 - Math.pow(1 - p, 2);
      const cx = fromX + (toX - fromX) * sweep * 0.9;
      ctx.strokeStyle = e.color;
      ctx.lineWidth = 3.2 * alpha + 1;
      ctx.beginPath();
      ctx.arc(cx, H * 0.52, 34, -Math.PI * 0.35, Math.PI * 0.35);
      ctx.stroke();
    } else if (e.kind === "triple") {
      for (let k = 0; k < 3; k++) {
        const off = (k - 1) * 9;
        const sweep = 1 - Math.pow(1 - Math.min(1, p + k * 0.12), 2);
        const cx = fromX + (toX - fromX) * sweep * 0.9;
        ctx.globalAlpha = alpha * (1 - k * 0.2);
        ctx.strokeStyle = e.color;
        ctx.lineWidth = 2.6;
        ctx.beginPath();
        ctx.arc(cx, H * 0.52 + off, 26, -Math.PI * 0.3, Math.PI * 0.3);
        ctx.stroke();
      }
    } else if (e.kind === "slam") {
      // 地面冲击波
      const r = 12 + p * 52;
      ctx.strokeStyle = e.color;
      ctx.lineWidth = 4 * alpha;
      ctx.beginPath(); ctx.ellipse(toX, H * 0.72, r, r * 0.36, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.globalAlpha = alpha * 0.4;
      ctx.beginPath(); ctx.ellipse(toX, H * 0.72, r * 0.7, r * 0.25, 0, 0, Math.PI * 2); ctx.stroke();
    } else if (e.kind === "punch") {
      const r = 6 + p * 16;
      ctx.fillStyle = e.color;
      ctx.globalAlpha = alpha * 0.5;
      ctx.beginPath(); ctx.arc(toX, H * 0.52, r, 0, Math.PI * 2); ctx.fill();
    } else if (e.kind === "glow") {
      // 回春：绿色光点上升
      for (let k = 0; k < 7; k++) {
        const px = fromX + Math.sin(k * 2.1 + p * 4) * 18;
        const py = H * 0.62 - p * 40 - k * 5;
        ctx.globalAlpha = alpha * 0.85;
        ctx.fillStyle = B2V_COLORS.heal;
        ctx.beginPath(); ctx.arc(px, py, 2.4, 0, Math.PI * 2); ctx.fill();
      }
    } else if (e.kind === "ring") {
      // 护盾：同心圆扩散
      for (let k = 0; k < 2; k++) {
        const r = 20 + p * 34 + k * 8;
        ctx.globalAlpha = alpha * (0.7 - k * 0.25);
        ctx.strokeStyle = B2V_COLORS.shield;
        ctx.lineWidth = 2.4;
        ctx.beginPath(); ctx.arc(fromX, H * 0.5, r, 0, Math.PI * 2); ctx.stroke();
      }
    } else if (e.kind === "flame") {
      for (let k = 0; k < 9; k++) {
        const px = fromX + Math.cos(k * 1.7) * (10 + p * 20);
        const py = H * 0.58 - p * 48 - k * 3;
        ctx.globalAlpha = alpha * 0.8;
        ctx.fillStyle = k % 2 ? "#C1543A" : "#E08A5A";
        ctx.beginPath(); ctx.arc(px, py, 2.8, 0, Math.PI * 2); ctx.fill();
      }
    } else if (e.kind === "bind") {
      // 定身：符文光圈
      const r = 16 + p * 10;
      ctx.globalAlpha = alpha * 0.9;
      ctx.strokeStyle = B2V_COLORS.ctrl;
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(toX, H * 0.68, r, r * 0.4, 0, 0, Math.PI * 2); ctx.stroke();
      for (let k = 0; k < 4; k++) {
        const ang = k * Math.PI / 2 + p * 2;
        ctx.beginPath();
        ctx.moveTo(toX + Math.cos(ang) * r, H * 0.68 + Math.sin(ang) * r * 0.4);
        ctx.lineTo(toX + Math.cos(ang) * (r + 7), H * 0.68 + Math.sin(ang) * (r + 7) * 0.4);
        ctx.stroke();
      }
    }
    ctx.restore();
  }
}

// ---------- 绘制残影（旧招特效扩散淡出）----------
function b2vDrawGhosts(ctx, actor, x, baseY, scale, facing, color, dt) {
  for (let i = actor.ghosts.length - 1; i >= 0; i--) {
    const g = actor.ghosts[i];
    g.life -= dt;
    g.fade = 1 - g.life / 0.25;
    if (g.life <= 0) { actor.ghosts.splice(i, 1); continue; }
    const pose = b2vSample(g.action, g.t);
    // 残影：整体放大扩散 + 透明度衰减，且不与新动作混合
    ctx.save();
    ctx.globalAlpha = 0.32 * (1 - g.fade);
    const grow = 1 + g.fade * 0.18;
    ctx.translate(x, baseY);
    ctx.scale(grow, grow);
    ctx.translate(-x, -baseY);
    b2vDrawActor(ctx, actor, pose, x, baseY, scale, facing, color, null);
    ctx.restore();
  }
}

// ---------- 飘字 ----------
function b2vFloater(text, x, y, color, big) {
  B2V.floaters.push({ text, x, y, color, big: !!big, t: 0, life: 0.9 });
}

function b2vDrawFloaters(ctx, dt) {
  for (let i = B2V.floaters.length - 1; i >= 0; i--) {
    const f = B2V.floaters[i];
    f.t += dt;
    const p = f.t / f.life;
    if (p >= 1) { B2V.floaters.splice(i, 1); continue; }
    ctx.save();
    ctx.globalAlpha = 1 - p * p;
    ctx.fillStyle = f.color;
    ctx.font = (f.big ? "bold 18px" : "15px") + " system-ui, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(f.text, f.x, f.y - p * 38);
    ctx.restore();
  }
}

// ---------- 主绘制 ----------
function b2vDrawFrame(dt) {
  const ctx = B2V.ctx;
  if (!ctx) return;
  const W = B2V.w, H = B2V.h;
  ctx.clearRect(0, 0, W, H);

  const b = B2V.battle;
  const allyX = W * 0.72;
  const enemyX = W * 0.28;
  const groundY = H * 0.78;
  const scale = Math.min(W / 340, H / 220) * 1.15;

  // 屏震
  if (B2V.shake > 0) {
    const s = B2V.shake;
    ctx.save();
    ctx.translate((Math.random() - 0.5) * s * 6, (Math.random() - 0.5) * s * 6);
    B2V.shake = Math.max(0, s - dt * 4);
  }

  // 地面墨线
  ctx.save();
  ctx.strokeStyle = "rgba(60,50,40,0.22)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(W * 0.12, groundY + 4);
  ctx.lineTo(W * 0.88, groundY + 4);
  ctx.stroke();
  ctx.restore();

  const A = B2V.actors.ally, E = B2V.actors.enemy;
  if (A) {
    if (!A.dead) b2vDrawGhosts(ctx, A, allyX, groundY, scale, 1, B2V_COLORS.ally, dt);
    const pose = b2vSample(A.action, A.actionT / A.actionDur);
    b2vDrawActor(ctx, A, pose, allyX, groundY, scale, 1, B2V_COLORS.ally, null);
  }
  if (E) {
    if (!E.dead) b2vDrawGhosts(ctx, E, enemyX, groundY, scale, -1, B2V_COLORS.enemy, dt);
    const pose = b2vSample(E.action, E.actionT / E.actionDur);
    b2vDrawActor(ctx, E, pose, enemyX, groundY, scale, -1, B2V_COLORS.enemy, null);
  }

  b2vDrawEffects(ctx, dt);
  b2vDrawFloaters(ctx, dt);

  if (B2V.shake > 0) ctx.restore();
}

// ---------- 更新动作时间 ----------
function b2vUpdateActors(dt) {
  for (const key of ["ally", "enemy"]) {
    const a = B2V.actors[key];
    if (!a) continue;
    a.actionT += dt;
    if (a.loop) {
      if (a.actionT >= a.actionDur) a.actionT = 0;
    } else if (a.actionT >= a.actionDur) {
      if (a.action === "dead") { a.actionT = a.actionDur; }
      else { b2vPlay(a, "idle"); }
    }
  }
}

// ---------- 循环 ----------
function b2vStart() {
  if (B2V.running) return;
  B2V.running = true;
  let last = performance.now();
  const loop = now => {
    if (!B2V.running) return;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    b2vUpdateActors(dt);
    b2vDrawFrame(dt);
    B2V.raf = requestAnimationFrame(loop);
  };
  B2V.raf = requestAnimationFrame(loop);
}

function b2vStop() {
  B2V.running = false;
  if (B2V.raf) cancelAnimationFrame(B2V.raf);
  B2V.raf = 0;
}

// ---------- 把战斗事件映射为动画 ----------
function b2vApplyEvent(ev) {
  const A = B2V.actors.ally, E = B2V.actors.enemy;
  if (!A || !E) return;
  const W = B2V.w, H = B2V.h;
  const allyX = W * 0.72, enemyX = W * 0.28;

  if (ev.type === "hit") {
    const isAlly = ev.from === "ally";
    const attacker = isAlly ? A : E;
    const victim = isAlly ? E : A;
    b2vPlay(attacker, ev.anim || "punch");
    b2vSpawnEffect(ev.anim === "punch" ? "punch" : ev.anim, ev.from, ev.tier);
    // 受击
    setTimeout(() => {
      if (!victim.dead) b2vPlay(victim, "hurt");
    }, 120);
    // 飘字
    const vx = isAlly ? enemyX : allyX;
    b2vFloater("-" + fmt(ev.dmg), vx + (Math.random() - 0.5) * 24, H * 0.42, ev.crit ? B2V_COLORS.crit : "#3A3A3A", ev.crit);
    if (ev.crit) B2V.shake = 1;
    if (ev.absorbed > 0) {
      b2vFloater("盾 " + fmt(ev.absorbed), vx, H * 0.36, B2V_COLORS.shield, false);
    }
  } else if (ev.type === "heal") {
    b2vPlay(A, "glow");
    b2vSpawnEffect("glow", "ally", ev.tier);
    b2vFloater("+" + fmt(ev.amount), allyX, H * 0.4, B2V_COLORS.heal, false);
  } else if (ev.type === "shield") {
    b2vPlay(A, "ring");
    b2vSpawnEffect("ring", "ally", ev.tier);
    b2vFloater("护盾 " + fmt(ev.amount), allyX, H * 0.34, B2V_COLORS.shield, false);
  } else if (ev.type === "buff") {
    b2vPlay(A, "flame");
    b2vSpawnEffect("flame", "ally", ev.tier);
    b2vFloater("攻+" + Math.round(ev.atkUp * 100) + "%", allyX, H * 0.34, "#C1543A", false);
  } else if (ev.type === "ctrl") {
    b2vPlay(A, "bind");
    b2vSpawnEffect("bind", "ally", ev.tier);
    b2vFloater("定身", enemyX, H * 0.34, B2V_COLORS.ctrl, true);
  } else if (ev.type === "end") {
    if (ev.win) {
      if (E) { E.dead = true; b2vPlay(E, "dead"); }
    } else {
      if (A) { A.dead = true; b2vPlay(A, "dead"); }
    }
  }
}
