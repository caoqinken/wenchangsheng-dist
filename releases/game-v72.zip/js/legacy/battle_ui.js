// ============================================================
// 《问长生》战斗界面（v0.15.0）
// 职责：全屏战斗 DOM、HUD、术式按钮、运功滑块、战报、结果结算
// 战斗逻辑在 battle2.js，渲染在 battle_view.js
// ============================================================

const BS = {
  el: null,
  battle: null,
  stage: 0,
  acc: 0,
  last: 0,
  speed: 1,
  raf: 0,
  logLines: [],
  ended: false,
};

// ---------- 打开战斗界面 ----------
function openBattleScreen(stage) {
  if (BS.el) return;
  const r = startBattleManual(stage);
  if (!r.ok) { toast(r.msg); return; }

  BS.stage = stage;
  BS.battle = b2Create(stage);
  BS.acc = 0;
  BS.speed = 1;
  BS.logLines = [];
  BS.ended = false;

  const stageNm = stageName(stage);
  const el = document.createElement("div");
  el.id = "battle-screen";
  el.innerHTML = `
    <div class="bs-enemyhud">
      <div class="bs-hudrow">
        <span class="bs-uname">${esc(BS.battle.enemy.name)}</span>
        <span class="bs-tag">${stageNm}</span>
        <button class="bs-exit" data-bs="exit">✕</button>
      </div>
      <div class="bs-bar hp"><i class="bs-hpfill"></i><b class="bs-hptext"></b></div>
    </div>

    <canvas id="bs-canvas"></canvas>

    <div class="bs-allyhud">
      <div class="bs-bar hp"><i class="bs-ahpfill"></i><b class="bs-ahptext"></b></div>
      <div class="bs-bar qi"><i class="bs-qifill"></i></div>
      <div class="bs-bar mana"><i class="bs-manafill"></i><b class="bs-manatext"></b></div>
    </div>

    <div class="bs-log"></div>

    <div class="bs-panel">
      <div class="bs-arts"></div>
      <div class="bs-tools">
        <div class="bs-yungong">
          <span>运功</span>
          <input type="range" class="bs-range" min="0" max="60" step="1" value="${Math.round((S.yungongRatio || 0) * 100)}">
          <b class="bs-ygval">${Math.round((S.yungongRatio || 0) * 100)}%</b>
        </div>
        <div class="bs-speed">
          <button class="bs-sp on" data-bs="speed" data-v="1">1x</button>
          <button class="bs-sp" data-bs="speed" data-v="2">2x</button>
          <button class="bs-sp" data-bs="speed" data-v="4">4x</button>
          <button class="bs-sp" data-bs="skip">跳过</button>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(el);
  BS.el = el;

  // 初始化 Canvas
  const canvas = el.querySelector("#bs-canvas");
  b2vInit(canvas);
  // 刚插入 DOM 时布局可能尚未完成，下一帧再校正一次尺寸
  requestAnimationFrame(() => { b2vResize(); });
  B2V.battle = BS.battle;
  B2V.actors.ally = b2vMakeActor("ally");
  B2V.actors.enemy = b2vMakeActor("enemy");
  B2V.effects = [];
  B2V.floaters = [];
  b2vStart();

  bsRenderArts();
  bsBindEvents();
  bsUpdateHud();
  bsPushLogText(`【起】${stageNm} —— 气息流转，战起`);

  window.addEventListener("resize", b2vResize);
  BS.last = performance.now();
  BS.raf = requestAnimationFrame(bsLoop);
}

// ---------- 主循环 ----------
function bsLoop(now) {
  if (!BS.el) return;
  const dt = Math.min(0.1, (now - BS.last) / 1000);
  BS.last = now;

  if (!BS.ended) {
    BS.acc += dt * BS.speed;
    const STEP = CONFIG.BATTLE2.TICK;
    let guard = 0;
    while (BS.acc >= STEP && !BS.ended && guard < 80) {
      BS.acc -= STEP;
      guard++;
      const evs = b2Tick(BS.battle, STEP);
      for (const e of evs) {
        b2vApplyEvent(e);
        const txt = b2LogText(e);
        if (txt) bsPushLogText(txt);
      }
      if (BS.battle.over) { BS.ended = true; bsFinish(); break; }
    }
  }

  bsUpdateHud();
  BS.raf = requestAnimationFrame(bsLoop);
}

// ---------- HUD ----------
function bsUpdateHud() {
  if (!BS.el) return;
  const b = BS.battle;
  const q = s => BS.el.querySelector(s);
  const pct = (v, m) => Math.max(0, Math.min(100, (v / m) * 100));

  const ehp = q(".bs-hpfill"), eht = q(".bs-hptext");
  if (ehp) ehp.style.width = pct(b.enemy.hp, b.enemy.hpMax) + "%";
  if (eht) eht.textContent = fmt(Math.max(0, b.enemy.hp)) + " / " + fmt(b.enemy.hpMax);

  const ahp = q(".bs-ahpfill"), aht = q(".bs-ahptext");
  if (ahp) ahp.style.width = pct(b.ally.hp, b.ally.hpMax) + "%";
  if (aht) aht.textContent = fmt(Math.max(0, b.ally.hp)) + " / " + fmt(b.ally.hpMax);

  const qf = q(".bs-qifill");
  if (qf) qf.style.width = pct(b.ally.qi, b.ally.qiMax) + "%";

  const avail = b.ally.mana - b.ally.manaMax * b.ally.yungong;
  const mf = q(".bs-manafill"), mt = q(".bs-manatext");
  if (mf) mf.style.width = pct(Math.max(0, avail), b.ally.manaMax) + "%";
  if (mt) mt.textContent = "真元 " + fmt(Math.max(0, avail));

  // 术式冷却
  const btns = BS.el.querySelectorAll(".bs-art");
  for (const btn of btns) {
    const key = btn.dataset.art;
    const cd = b.ally.cds[key] || 0;
    const art = b2Art(key);
    const enoughMana = avail >= (art ? art.mana : 0);
    const cdEl = btn.querySelector(".bs-art-cd");
    if (cd > 0) {
      btn.classList.add("cooling");
      if (cdEl) cdEl.textContent = cd.toFixed(1) + "s";
    } else {
      btn.classList.remove("cooling");
      if (cdEl) cdEl.textContent = "";
    }
    if (!enoughMana) btn.classList.add("nomana");
    else btn.classList.remove("nomana");
  }
}

// ---------- 术式按钮 ----------
function bsRenderArts() {
  const b = BS.battle;
  const box = BS.el.querySelector(".bs-arts");
  const arts = b.ally.slots.map(k => b2Art(k)).filter(Boolean);
  if (!arts.length) {
    box.innerHTML = `<div class="bs-noart">尚无术式，仅以普攻应敌</div>`;
    return;
  }
  box.innerHTML = arts.map(a => `
    <button class="bs-art tier-${a.tier}" data-art="${a.key}">
      <span class="bs-art-name">${esc(a.name)}</span>
      <span class="bs-art-cost">${a.cost}</span>
      <span class="bs-art-cd"></span>
    </button>
  `).join("");
}

// ---------- 事件 ----------
function bsBindEvents() {
  BS.el.addEventListener("click", ev => {
    const artBtn = ev.target.closest("[data-art]");
    if (artBtn) {
      const key = artBtn.dataset.art;
      const r = b2Cast(BS.battle, key);
      if (!r.ok) { toast(r.msg); return; }
      for (const e of r.events) {
        b2vApplyEvent(e);
        const txt = b2LogText(e);
        if (txt) bsPushLogText(txt);
      }
      bsUpdateHud();
      return;
    }
    const t = ev.target.closest("[data-bs]");
    if (!t) return;
    const a = t.dataset.bs;
    if (a === "exit") {
      bsClose(true);
    } else if (a === "speed") {
      BS.speed = parseFloat(t.dataset.v) || 1;
      BS.el.querySelectorAll(".bs-sp").forEach(x => x.classList.remove("on"));
      t.classList.add("on");
    } else if (a === "skip") {
      bsSkip();
    }
  });

  const range = BS.el.querySelector(".bs-range");
  if (range) {
    range.addEventListener("input", () => {
      const v = parseInt(range.value, 10) / 100;
      S.yungongRatio = Math.max(0, Math.min(CONFIG.BATTLE2.YUNGONG_MAX, v));
      BS.battle.ally.yungong = S.yungongRatio;
      const lab = BS.el.querySelector(".bs-ygval");
      if (lab) lab.textContent = Math.round(S.yungongRatio * 100) + "%";
      save();
    });
  }
}

// ---------- 战报 ----------
function bsPushLogText(txt) {
  BS.logLines.push(txt);
  if (BS.logLines.length > 40) BS.logLines.shift();
  const box = BS.el && BS.el.querySelector(".bs-log");
  if (!box) return;
  box.innerHTML = BS.logLines.slice(-4)
    .map(t => `<div class="bs-logline">${esc(t)}</div>`).join("");
}

// ---------- 跳过：按结果直接结算 ----------
function bsSkip() {
  if (BS.ended) return;
  b2RunToEnd(BS.battle);
  BS.ended = true;
  bsFinish();
}

// ---------- 结束 ----------
function bsFinish() {
  const b = BS.battle;
  const win = b.win;
  const stage = BS.stage;
  if (BS.raf) cancelAnimationFrame(BS.raf);
  BS.raf = 0;

  bsUpdateHud();
  bsPushLogText(win ? "【终】对手气息断绝 —— 你胜了" : "【终】你力竭不支 —— 败");

  setTimeout(() => {
    bsClose(false);
    if (win) {
      const st = settleStageWin(stage);
      showStageReward(stage, st, "亲征");
    } else {
      showModal(`
        <div class="result lose">
          <div class="result-title">✘ 落败</div>
          <div class="result-line">与 ${esc(stageName(stage))} 鏖战不敌</div>
          <div class="result-line">提示：可调高「运功」提升平A伤害，或带上治疗/护盾类术式</div>
          <button class="btn-primary" data-action="closemodal">继续</button>
        </div>`);
    }
    showView(currentTab);
  }, 750);
}

// ---------- 关闭 ----------
function bsClose(silent) {
  if (BS.raf) cancelAnimationFrame(BS.raf);
  BS.raf = 0;
  b2vStop();
  window.removeEventListener("resize", b2vResize);
  if (BS.el && BS.el.parentNode) BS.el.parentNode.removeChild(BS.el);
  BS.el = null;
  BS.battle = null;
  B2V.battle = null;
  B2V.actors.ally = null;
  B2V.actors.enemy = null;
  if (silent) {
    // 主动退出：不结算（体力已扣，视为放弃）
    toast("你退出了战斗");
    showView(currentTab);
  }
}
