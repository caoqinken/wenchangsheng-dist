// ============================================================
// 《问长生》战斗 v2：气息制半即时战斗（v0.15.0）
// 设计依据：docs/04_战斗与功法系统设计.md
// 铁律：普攻（倍率 1.0、气息 100/秒充能）必须与旧公式「每秒一回合」严格等价
//       否则 v0.13.0 调出的 12.7 天飞升曲线会被打乱
// ============================================================

// ---------- 查表 ----------
function b2Art(key) {
  return CONFIG.ARTS.find(a => a.key === key) || null;
}

// 术式槽数量：随境界自适应（2 → 8，架构支持任意 N）
function b2SlotCount(realmIdx) {
  const arr = CONFIG.BATTLE2.SLOT_BY_REALM;
  const i = Math.max(0, Math.min(arr.length - 1, realmIdx | 0));
  return Math.min(CONFIG.BATTLE2.SLOT_MAX, arr[i] || 2);
}

// 当前境界已解锁的术式
function b2UnlockedArts(realmIdx) {
  return CONFIG.ARTS.filter(a => a.unlockRealm <= realmIdx);
}

// 默认槽位：优先高阶术式，不足按低阶补
function b2DefaultSlots(realmIdx) {
  const un = b2UnlockedArts(realmIdx);
  const n = b2SlotCount(realmIdx);
  return un.slice()
    .sort((a, b) => b.unlockRealm - a.unlockRealm)
    .slice(0, n)
    .map(a => a.key);
}

// ---------- 单位构建 ----------
function b2PlayerUnit() {
  const p = playerCombat();
  const af = (typeof artifactAffix === "function")
    ? artifactAffix() : { crit: 0, lifesteal: 0, thorns: 0 };
  const manaMax = CONFIG.BATTLE2.MANA_MAX + S.realm * 30;
  const ratio = Math.max(0, Math.min(CONFIG.BATTLE2.YUNGONG_MAX, S.yungongRatio || 0));
  let slots = b2DefaultSlots(S.realm);
  if (Array.isArray(S.artSlots) && S.artSlots.length) {
    slots = S.artSlots.filter(k => b2Art(k)).slice(0, b2SlotCount(S.realm));
  }
  return {
    side: "ally", name: "你",
    hp: p.hp, hpMax: p.hp,
    attack: p.attack, defense: p.defense,
    mana: manaMax, manaMax, manaRegen: CONFIG.BATTLE2.MANA_REGEN,
    qi: CONFIG.BATTLE2.PUNCH_COST, qiMax: CONFIG.BATTLE2.QI_MAX, qiRegen: CONFIG.BATTLE2.QI_REGEN,
    yungong: ratio,
    slots, cds: {},
    shield: 0, shieldSec: 0,
    atkUp: 0, atkUpSec: 0,
    stunSec: 0,
    crit: af.crit || 0, lifesteal: af.lifesteal || 0, thorns: af.thorns || 0,
    lastAct: -99, ai: null,
  };
}

function b2EnemyUnit(stage) {
  const isBoss = CONFIG.isBoss(stage);
  const hp = CONFIG.enemyHp(stage);
  // 三类行为模板（v0.15.0 §3.7）
  const ai = isBoss ? "cunning" : (Math.random() < 0.45 ? "caster" : "brute");
  const slots = [];
  if (ai !== "brute") {
    const pool = CONFIG.ARTS.filter(a => a.kind === "dmg" && a.tier <= 2);
    if (pool.length) slots.push(pool[Math.floor(Math.random() * pool.length)].key);
    if (ai === "cunning" && b2Art("hui_chun")) slots.push("hui_chun");
  }
  const manaMax = CONFIG.BATTLE2.MANA_MAX;
  return {
    side: "enemy", name: isBoss ? "守关妖兽" : "妖兽",
    hp, hpMax: hp,
    attack: CONFIG.enemyAttack(stage), defense: CONFIG.enemyDefense(stage),
    mana: manaMax, manaMax, manaRegen: CONFIG.BATTLE2.MANA_REGEN * 0.8,
    qi: CONFIG.BATTLE2.PUNCH_COST, qiMax: CONFIG.BATTLE2.QI_MAX, qiRegen: CONFIG.BATTLE2.QI_REGEN,
    yungong: 0,
    slots, cds: {},
    shield: 0, shieldSec: 0,
    atkUp: 0, atkUpSec: 0,
    stunSec: 0,
    crit: 0, lifesteal: 0, thorns: 0,
    lastAct: -99, ai,
  };
}

// ---------- 创建战斗 ----------
function b2Create(stage) {
  return {
    stage,
    t: 0,
    ally: b2PlayerUnit(),
    enemy: b2EnemyUnit(stage),
    logs: [],
    over: false,
    win: false,
    rounds: 0,
  };
}

// ---------- 伤害结算 ----------
function b2ResolveHit(b, u, other, mult, art, evs) {
  const C = CONFIG.BATTLE2;
  const raw = Math.max(u.attack - other.defense, u.attack * 0.05);
  let dmg = raw * mult;
  dmg *= (1 + u.atkUp);
  dmg *= (1 + u.yungong * C.YUNGONG_RATE);

  let crit = false;
  if (u.crit > 0 && Math.random() < u.crit) {
    dmg *= CONFIG.AFFIX_CRIT_MULT;
    crit = true;
  }

  dmg = Math.max(1, Math.round(dmg));

  // 护盾吸收
  let absorbed = 0;
  if (other.shield > 0) {
    absorbed = Math.min(other.shield, dmg);
    other.shield -= absorbed;
    if (other.shield <= 0) { other.shield = 0; other.shieldSec = 0; }
    dmg -= absorbed;
  }

  other.hp -= dmg;

  // 吸血（按实际造成的伤害）
  if (u.lifesteal > 0 && dmg > 0) {
    u.hp = Math.min(u.hpMax, u.hp + dmg * u.lifesteal);
  }
  // 反伤
  if (other.thorns > 0) {
    u.hp -= raw * mult * other.thorns;
  }

  evs.push({
    type: "hit",
    from: u.side, to: other.side,
    fromName: u.name, toName: other.name,
    art: art ? art.name : null,
    anim: art ? art.anim : "punch",
    tier: art ? art.tier : 1,
    dmg, crit, absorbed,
    hpLeft: Math.max(0, Math.round(other.hp)),
    hpMax: other.hpMax,
  });
}

// ---------- 术式结算 ----------
function b2ResolveArt(b, u, other, art, evs) {
  if (art.kind === "dmg") {
    const n = art.hits || 1;
    for (let i = 0; i < n; i++) {
      if (other.hp <= 0 || u.hp <= 0) break;
      b2ResolveHit(b, u, other, art.mult, art, evs);
    }
  } else if (art.kind === "heal") {
    const amt = Math.max(1, Math.floor(u.hpMax * (art.healPct || 0.1)));
    u.hp = Math.min(u.hpMax, u.hp + amt);
    evs.push({ type: "heal", from: u.side, name: u.name, art: art.name, anim: art.anim, tier: art.tier, amount: amt, hpLeft: Math.round(u.hp) });
  } else if (art.kind === "buff") {
    if (art.shieldPct) {
      u.shield = Math.max(1, Math.floor(u.hpMax * art.shieldPct));
      u.shieldSec = art.shieldSec || 6;
      evs.push({ type: "shield", from: u.side, name: u.name, art: art.name, anim: art.anim, tier: art.tier, amount: u.shield, sec: u.shieldSec });
    }
    if (art.atkUp) {
      u.atkUp = art.atkUp;
      u.atkUpSec = art.dur || 6;
      evs.push({ type: "buff", from: u.side, name: u.name, art: art.name, anim: art.anim, tier: art.tier, atkUp: art.atkUp, sec: u.atkUpSec });
    }
  } else if (art.kind === "ctrl") {
    b2ResolveHit(b, u, other, art.mult, art, evs);
    if (other.hp > 0) {
      other.stunSec = art.ctrlSec || 2;
      other.qi = 0;   // 打断：清空对方气息
      evs.push({ type: "ctrl", from: u.side, to: other.side, name: u.name, art: art.name, anim: art.anim, tier: art.tier, sec: other.stunSec });
    }
  }
}

// ---------- 单单位尝试出手 ----------
function b2TryAct(b, u, other, evs) {
  const C = CONFIG.BATTLE2;
  if (b.over || u.hp <= 0 || other.hp <= 0) return;
  if (u.stunSec > 0) return;
  if (b.t - u.lastAct < C.PUNCH_INTERVAL_GUARD) return;

  // 运功锁定的真元不参与术式消耗
  const availMana = u.mana - u.manaMax * u.yungong;

  // 槽位从左到右，找第一个「CD 好 且 真元够」的术式
  let target = null;
  for (let i = 0; i < u.slots.length; i++) {
    const key = u.slots[i];
    const a = b2Art(key);
    if (!a) continue;
    if ((u.cds[key] || 0) > 0) continue;
    if (availMana < a.mana) continue;
    target = a;
    break;
  }

  if (target) {
    if (u.qi + 1e-6 < target.cost) return;   // 气息不足 → 等待攒条（不降级为普攻）
    u.qi -= target.cost;
    u.mana -= target.mana;
    u.cds[target.key] = target.cd;
    u.lastAct = b.t;
    b2ResolveArt(b, u, other, target, evs);
    return;
  }

  // 兜底普攻
  if (u.qi + 1e-6 < C.PUNCH_COST) return;
  u.qi -= C.PUNCH_COST;
  u.lastAct = b.t;
  b2ResolveHit(b, u, other, C.PUNCH_MULT, null, evs);
}

// ---------- 推进一个时间步 ----------
function b2Tick(b, dt) {
  const evs = [];
  if (b.over) return evs;
  b.t += dt;

  const units = [b.ally, b.enemy];
  for (const u of units) {
    if (u.hp <= 0) continue;
    if (u.shieldSec > 0) {
      u.shieldSec -= dt;
      if (u.shieldSec <= 0) { u.shield = 0; u.shieldSec = 0; }
    }
    if (u.atkUpSec > 0) {
      u.atkUpSec -= dt;
      if (u.atkUpSec <= 0) { u.atkUp = 0; u.atkUpSec = 0; }
    }
    if (u.stunSec > 0) {
      u.stunSec -= dt;
      if (u.stunSec < 0) u.stunSec = 0;
    }
    for (const k in u.cds) {
      if (u.cds[k] > 0) { u.cds[k] -= dt; if (u.cds[k] < 0) u.cds[k] = 0; }
    }
    u.qi = Math.min(u.qiMax, u.qi + u.qiRegen * dt);
    u.mana = Math.min(u.manaMax, u.mana + u.manaRegen * dt);
  }

  // 双方各自尝试出手（己方优先，避免同帧判定顺序导致的一方吃亏）
  b2TryAct(b, b.ally, b.enemy, evs);
  b2TryAct(b, b.enemy, b.ally, evs);

  b.rounds = Math.floor(b.t);

  // 死亡判定
  if (b.enemy.hp <= 0 && b.ally.hp <= 0) {
    b.over = true; b.win = false;
    evs.push({ type: "end", win: false, reason: "同归于尽" });
  } else if (b.enemy.hp <= 0) {
    b.over = true; b.win = true;
    evs.push({ type: "end", win: true });
  } else if (b.ally.hp <= 0) {
    b.over = true; b.win = false;
    evs.push({ type: "end", win: false });
  } else if (b.t >= CONFIG.BATTLE2.MAX_SECONDS) {
    // 超时：按剩余气血比例判负（防御方优势）
    b.over = true;
    b.win = (b.enemy.hp / b.enemy.hpMax) < (b.ally.hp / b.ally.hpMax);
    evs.push({ type: "end", win: b.win, reason: "鏖战超时" });
  }

  if (evs.length) {
    for (const e of evs) {
      b.logs.push(Object.assign({ t: b.t, sec: Math.floor(b.t) }, e));
    }
  }
  return evs;
}

// ---------- 手动催动（玩家点击术式）----------
// 规则：立即施放，但自身气息归零（用一息的气息换提前出招）
function b2Cast(b, key) {
  if (b.over) return { ok: false, msg: "战斗已结束" };
  const u = b.ally;
  const art = b2Art(key);
  if (!art) return { ok: false, msg: "术式不存在" };
  if (u.hp <= 0) return { ok: false, msg: "已然力竭" };
  if (u.stunSec > 0) return { ok: false, msg: "被定身，无法施法" };
  if ((u.cds[key] || 0) > 0) return { ok: false, msg: `冷却中（${u.cds[key].toFixed(1)} 息）` };
  const availMana = u.mana - u.manaMax * u.yungong;
  if (availMana < art.mana) return { ok: false, msg: "真元不足（运功占用了部分真元）" };

  const evs = [];
  u.mana -= art.mana;
  u.cds[key] = art.cd;
  u.qi = 0;                    // 代价：气息归零
  u.lastAct = b.t;
  b2ResolveArt(b, u, b.enemy, art, evs);
  for (const e of evs) {
    b.logs.push(Object.assign({ t: b.t, sec: Math.floor(b.t), manual: true }, e));
  }
  if (b.enemy.hp <= 0) {
    b.over = true; b.win = true;
    b.logs.push({ t: b.t, sec: Math.floor(b.t), type: "end", win: true });
  }
  return { ok: true, events: evs };
}

// ---------- 战报文本 ----------
function b2LogText(ev) {
  const pre = `【${ev.sec}息】`;
  switch (ev.type) {
    case "hit": {
      const who = ev.from === "ally" ? "你" : ev.fromName;
      const act = ev.art ? `施展「${ev.art}」` : "挥出一击";
      const tgt = ev.to === "ally" ? "你" : ev.toName;
      let s = `${pre}${who}${act}，${tgt} 气血 -${fmt(ev.dmg)}`;
      if (ev.crit) s += "（会心）";
      if (ev.absorbed > 0) s += `（护盾挡下 ${fmt(ev.absorbed)}）`;
      return s;
    }
    case "heal":
      return `${pre}${ev.name === "你" ? "你" : ev.name}催动「${ev.art}」，气血 +${fmt(ev.amount)}`;
    case "shield":
      return `${pre}${ev.name === "你" ? "你" : ev.name}结成「${ev.art}」，获得 ${fmt(ev.amount)} 护盾（${ev.sec} 息）`;
    case "buff":
      return `${pre}${ev.name === "你" ? "你" : ev.name}运转「${ev.art}」，攻击提升 ${Math.round(ev.atkUp * 100)}%（${ev.sec} 息）`;
    case "ctrl":
      return `${pre}${ev.name === "你" ? "你" : ev.name}敕令「${ev.art}」，${ev.to === "ally" ? "你" : "妖兽"}被定身 ${ev.sec} 息`;
    case "end":
      return ev.win ? `${pre}对手气息断绝 —— 你胜了` : `${pre}你力竭不支 —— 败`;
    default:
      return null;
  }
}

// ---------- 跑完（测试 / 跳过用）----------
function b2RunToEnd(b) {
  const dt = CONFIG.BATTLE2.TICK;
  let guard = 0;
  while (!b.over && guard < CONFIG.BATTLE2.MAX_SECONDS / dt + 10) {
    b2Tick(b, dt);
    guard++;
  }
  if (!b.over) { b.over = true; b.win = false; }
  return { win: b.win, seconds: b.t, allyHp: Math.max(0, b.ally.hp), enemyHp: Math.max(0, b.enemy.hp) };
}

// ---------- 自动模式单场结算（不渲染，供数值验证）----------
function b2AutoFight(stage) {
  const b = b2Create(stage);
  return b2RunToEnd(b);
}
