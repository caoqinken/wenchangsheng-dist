// ============================================================
// 《问长生》游戏状态管理 + 工具函数 + 存档
// ============================================================

// ---------- 数字格式化（万/亿/兆/京） ----------
const UNIT_STEPS = [
  [1e16, "京"], [1e12, "兆"], [1e8, "亿"], [1e4, "万"],
];
function fmt(n) {
  if (n == null || isNaN(n)) return "0";
  if (!isFinite(n)) return "∞";
  if (n < 0) return "-" + fmt(-n);
  if (n < 1000) return n < 10 && n % 1 !== 0 ? n.toFixed(1) : Math.floor(n).toString();
  for (const [th, unit] of UNIT_STEPS) {
    if (n >= th) {
      const v = n / th;
      return (v >= 100 ? Math.floor(v) : v.toFixed(2).replace(/\.?0+$/, "")) + unit;
    }
  }
  return Math.floor(n).toString();
}

// 存档版本（唯一来源：defaultState / migrateState / 导入校验共用）
const SAVE_VERSION = 18;

// ---------- 默认初始状态 ----------
function defaultState() {
  return {
    realm: 0,
    layer: 0,
    qi: 0,
    stone: 50,          // 初始灵石，让玩家能先升一级灵田
    stamina: CONFIG.MAX_STAMINA,
    lastOnline: Date.now(),
    // 经营
    buildings: { farm: 0, alchemy: 0, forge: 0, practice: 0, recruit: 0 },
    disciples: [],      // 弟子数组（v0.4.1：个体 NPC）
    starterDiscipleGranted: false, // 开局赠礼发放标记（v0.52.0）
    starterDiscipleCount: 0,   // 开局赠礼累计发放人数（v0.54.2）
    settings: { combatSpeed: 1, reducedMotion: false, textScale: "normal" }, // 玩家设置（v0.52.0）
    herbs: 0,
    // 储物法器（v0.37.0）：tier 为 CONFIG.INV.CONTAINERS 索引，slots 长度 = 当前空间格数
    // pending=true 表示首次需把旧字段（herbs/materials/pills/talisman/tribPills/碎片）装袋
    bag: { tier: 0, slots: [], stash: {}, pending: true },
    folk: 0,            // 凡人总数镜像（v0.28.0；v0.54.2 由各秘境聚落人口汇总）
    fieldSettlements: {}, // 秘境凡人聚落：章节 → {population,foundedAt,name}；_reserve 为旧档待分配人口
    fieldSociety: {}, // 凡人家庭、婚育、生活消费与聚落公库账本
    fieldResidents: {}, // 私有秘境本地修士人口、迁徙与洞府租赁账本
    dao: "fa",          // 修炼方向（v0.29.0：fa/ti/jian/dual）
    tunaLeft: CONFIG.TUNA.DAILY,   // 今日剩余吐纳次数
    tunaDate: "",       // 吐纳计数所属日期（gameTime 日）
    tunaCount: 0,       // 今日已吐纳次数（任务判定用）
    soulHurtUntil: 0,   // 元神受损截止时间戳（渡劫失败后 30 分钟）
    fate: 0,            // 机缘（硬通货，v0.29.0）
    huntingIncense: 0,  // 引魔香：待下一次有效离线结算消耗（v0.54.0）
    daily: {},          // 每日任务进度 { date, tasks:{} }
    weekly: {},         // 周常任务进度 { week, tasks:{} }
    specialty: {},      // 章节特产（v0.29.0：章节序号 → 数量）
    marketRefresh: {},  // 坊市刷新次数（v0.29.0：{date,left}）
    marketDeals: {},    // 坊市今日特价（v0.30.0：{date, items[]}）
    marketShelf: null,  // 坊市境界货架（v0.54.3：每2小时自动刷新）
    ancient: {},        // 古宝（v0.30.0：key → {star, infuse}）
    ancientFrag: {},    // 古宝碎片（v0.30.0：套装 key → 数量）
    pills: 0,
    // 丹药效果状态（v0.38.0）
    healShield: 0,      // 回春丹：下次入秘境气血护盾比例
    rerollFree: 0,      // 洗髓丹：剩余免费洗练次数
    gongfaCut: 0,       // 悟道丹：剩余悟道消耗折扣次数
    breakPillBuff: 0,   // 破境丹：已服层数（下次渡劫 +10%/枚）
    // 丹炉（v0.39.0 单炉 → v0.42.0 多炉位）：按真实时间推进，离线也算
    dan: { slots: [null, null, null] },
    pillBuff: 0,        // 药力层数（v0.8.0：每服 1 枚丹药 +1 层，+2% 修炼/层，上限 CONFIG.PILL_BONUS_CAP）
    gongfaCatalogVersion: CONFIG.GONGFA_CATALOG_VERSION || 1,
    gongfaBooks: (function () {           // 功法层数与领悟（v0.20.0；旧的单线 gongfa 已废弃）
      const o = {};
      for (const b of CONFIG.GONGFA_BOOKS) o[b.key] = { lv: 0, learned: b.key === "changsheng" };
      return o;
    })(),
    talisman: 1,        // 功法要诀（领悟功法消耗，秘境/事件产出）
    avatar: "qingshan", // 角色形象（v0.22.0）
    pets: [],           // 灵兽（v0.21.0）
    petActive: null,    // 出战灵兽 id
    // 渡劫（v0.5.0）
    tribPills: 0,       // 渡劫丹库存
    tribPillBuff: 0,    // 已服用渡劫丹层数（下次渡劫消耗）
    tribFails: 0,       // 渡劫连续失败计数（保底用）
    // 法宝（v0.6.0）
    materials: 0,       // 灵材（炼制法宝原料）
    artifacts: [],      // 法宝背包
    equipped: { attack: null, defense: null, support: null },  // 三件本体的旧视图（v0.18.0 起由 loadout 同步）
    loadout: {},        // 12 格装备栏（v0.18.0，键见 CONFIG.LOADOUT_SLOTS，存法宝 id）
    // 战斗
    bestStage: 0,       // 已通关最高关卡（0 表示尚未通关第 0 关）
    lastStage: 0,       // 当前选择挑战的关卡
    // 动态世界（v0.4.0）+ 经济（v0.4.2）
    version: SAVE_VERSION,
    // 内视（v0.50.0）：经脉已通穴数 / 丹田丹阶
    meridian: { ren: 0, du: 0, chong: 0 },
    dantian: 0,
    playerName: null,   // 道号（v0.25.0：建角时写入，同时作为存档键）
    gameTime: { year: 1, month: 1, day: 1, dayTick: 0 },
    factions: {
      qingyun: { power: 50, resource: 100, territory: 3, relation: 0 },
      moyuan:  { power: 45, resource: 90,  territory: 2, relation: 0 },
      sanxiu:  { power: 30, resource: 70,  territory: 1, relation: 20 },
    },
    market: { herb: 10, pill: 50, tribPill: 500, material: 80 },   // 坊市现价（随行情波动）
    reputation: 0,
    activeEvent: null,
    eventCooldown: {},   // 各事件链上次触发的累计天数（v0.6.1）
    milestones: {},      // 境界专属事件完成记录（v0.6.2）
    achievements: {},    // 已达成成就（key → 达成时累计天数，v0.6.5）
    stats: { battleWins: 0, bossWins: 0 },   // 累计统计（v0.6.5；v0.11.0 增 battlegroundWins / pillmeetWins）
    codex: { artifacts: {}, events: {} },   // 图鉴收录（v0.6.5；v0.8.0 增 beasts / regions）
    storySeen: {},      // 已读章节叙事（v0.11.0）
    storyChoices: {},   // 章节分支选择（v0.12.0）：{ 章节序号: "war" | "dao" }
    towerBest: 0,       // 试炼塔最高通关层（v0.8.0）
    towerCoin: 0,       // 塔币（v0.9.0，塔专属货币）
    // 秘境战场（v0.16.0）：技能盘配置（空数组 = 按境界取默认）
    fieldSlots: [],
    fabaoSkillSlot: null, // v0.53.3：法宝主动术式独立第五格
    yungongRatio: 0,       // 运功比例 0~60%（v0.52.0）
    gongfaEquip: { xin: "changsheng", shu: null, shen: null, dao: null }, // 四类功法装备位（v0.52.0）
    shuSlots: [],          // 术式槽，空数组按境界默认（v0.52.0）
    wudao: 0,              // 悟道资源（v0.52.0，后续功法层数升级使用）
    // 秘境探索与派遣（v0.17.0）
    clearedMaps: {},    // 已探明的秘境（章节序号 → true）
    mapTeam: {},        // 秘境驻守（章节序号 → [弟子id]）
    fieldEducation: {}, // 秘境独立教化：章节 → {progress,private,totalGuardSec}
    fieldCommerce: {}, // v0.56.2：私有秘境经营设施与NPC每日需求、有限采购预算
    realms: {}, // v0.58.0：秘境统一身份注册表；旧业务账本暂不搬迁、不复制
    fieldVein: {},      // 灵脉等级（v0.26.0：章节序号 → lv，建设经营秘境）
    fieldMine: {},      // 矿场等级（v0.31.0：章节序号 → lv）
    fieldGarden: {},    // 药圃等级（v0.31.0：章节序号 → lv）
    artWarm: {},        // 法宝温养（v0.31.0：法宝 id → lv）
    skillInsight: {},   // 神通参悟（v0.31.0：技能 key → lv）
    sect: {},           // 宗门（v0.31.0：{name, lv}）
    fieldStable: {},    // 秘境安定度（v0.32.0：章节 → 0~100）
    fieldTemple: {},    // 神庙等级（v0.32.0：章节 → 0~3）
    fieldLabor: {},     // 已派驻凡人（v0.32.0：章节 → {vein,mine,garden}）
    recruitPool: {},    // 招徒候选（v0.32.0：{ch, date, list}）
    dynasty: {},        // 凡间王朝（v0.32.0：{name}）
    staff: {},          // 秘境职务（v0.33.0：章节 → {discipleId, office}）
    missions: [],       // 弟子任务（v0.33.0：[{id,type,ch,discipleId,endAt,status}]）
    missionSeq: 0,      // 任务自增 id
    dynastyOffice: {},  // 王朝官职（v0.33.0：官职 key → 弟子 id）
    lostFields: {},     // 失守秘境（v0.33.0：章节 → true）
    contribution: 0,    // 宗门贡献（v0.34.0）
    petInner: {},       // 灵兽内丹（v0.35.0：灵兽 id → 内丹 key）
    conquered: 0,       // 已攻占据点数（v0.35.0）
    garden: {},         // 药园（v0.36.0：{size, plots:[{crop,plantedAt,watered}]}）
    avatarBody: {},     // 化身（v0.36.0：{unlocked,lv,map,lastClaim}）
    friends: [],        // 仙友/道侣（v0.36.0）
    friendSeq: 0,       // 仙友 id 自增
    sectDaily: {},      // 宗门任务进度（v0.34.0：{date, prog{}, claimed{}}）
    sectTrial: {},      // 护法试炼记录（v0.34.0：{day, best}）
    mapNodeT: {},       // 资源点刷新计时（v0.28.0：章节序号 → 秒）
    // 驻守结算单（v0.51.0）：章节序号 → { sec, stone, qi, herb, material, folk }
    // 只做账目汇总，产出已实时入账，结算时不清资源
    settle: {},
    eventLog: [],
  };
}

// ---------- 全局状态 ----------
let S = load();

// 存档迁移：各旧版本 → v6（disciples 数组化、补 market/渡劫/法宝字段）
function migrateState(d) {
  // v0.52.0：设置字段逐项补齐，兼容旧档与不完整导入档
  if (!d.settings || typeof d.settings !== "object") d.settings = {};
  d.settings = Object.assign({ combatSpeed: 1, reducedMotion: false, textScale: "normal" }, d.settings);
  if (![1, 1.5, 2].includes(Number(d.settings.combatSpeed))) d.settings.combatSpeed = 1;
  d.settings.combatSpeed = Number(d.settings.combatSpeed);
  d.settings.reducedMotion = !!d.settings.reducedMotion;
  if (!["normal", "large"].includes(d.settings.textScale)) d.settings.textScale = "normal";
  // v0.52.0：战斗/功法 v2 新字段，旧档安全补齐。
  if (typeof d.yungongRatio !== "number" || !isFinite(d.yungongRatio)) d.yungongRatio = 0;
  d.yungongRatio = Math.max(0, Math.min(0.6, d.yungongRatio));
  if (!d.gongfaEquip || typeof d.gongfaEquip !== "object") d.gongfaEquip = {};
  d.gongfaEquip = Object.assign({ xin: "changsheng", shu: null, shen: null, dao: null }, d.gongfaEquip);
  if (!Array.isArray(d.shuSlots)) d.shuSlots = [];
  if (typeof d.wudao !== "number" || !isFinite(d.wudao) || d.wudao < 0) {
    const legacyGongfa = Number(d.gongfa) || 0;
    d.wudao = Math.max(0, legacyGongfa * 100);
  }
  if (typeof d.disciples === "number") {
    const arr = [];
    for (let i = 0; i < d.disciples; i++) {
      arr.push({
        id: i + 1,
        name: CONFIG.DISCIPLE_NAMES[i % CONFIG.DISCIPLE_NAMES.length],
        aptitude: 1, realm: 0, layer: 0,
        loyalty: 60, mood: 80, assignedTo: null, cultivation: 0,
      });
    }
    d.disciples = arr;
  }
  if (!Array.isArray(d.disciples)) d.disciples = [];
  // 弟子专精 / 师徒情谊（v0.10.0）：旧档补默认值，专精按委派建筑对齐以免"一上线就不匹配"
  for (const dcp of d.disciples) {
    if (dcp.specialty == null) {
      dcp.specialty = dcp.assignedTo || (CONFIG.SPECIALTIES[0] && CONFIG.SPECIALTIES[0].key) || "farm";
    }
    if (typeof dcp.bond !== "number") dcp.bond = 0;
    // v0.17.4：补齐数值字段，否则 0.7+0.006*undefined = NaN 会污染灵田产出
    if (typeof dcp.loyalty !== "number") dcp.loyalty = 60;
    if (typeof dcp.mood !== "number") dcp.mood = 80;
    if (typeof dcp.cultivation !== "number") dcp.cultivation = 0;
    if (typeof dcp.aptitude !== "number") dcp.aptitude = 1;
    if (typeof dcp.realm !== "number") dcp.realm = 0;
    if (typeof dcp.layer !== "number") dcp.layer = 0;
    if (typeof dcp.trainingDate !== "string") dcp.trainingDate = "";
    if (typeof dcp.trainingExp !== "number" || !isFinite(dcp.trainingExp)) dcp.trainingExp = 0;
  }
  // v0.54.2：开局赠礼从 1 名扩为 5 名。旧档只补足「开山赠礼」人数，不覆盖玩家已招募弟子。
  let _starterCount = d.disciples.filter(_x => _x && _x.origin === "开山赠礼").length;
  const _hasStarterGrantCount = Number.isFinite(Number(d.starterDiscipleCount)) && Number(d.starterDiscipleCount) > 0;
  let _targetStarterCount = 0;
  // 只有旧档没有「已发放人数」字段时才补齐；新档中弟子离山后不重复补发。
  if (!_hasStarterGrantCount && d.starterDiscipleGranted) _targetStarterCount = 5; // v0.52~0.54.1 旧档
  if (!_hasStarterGrantCount && !_targetStarterCount && d.playerName && d.disciples.length === 0 && (Number(d.version) || 0) < 16) _targetStarterCount = 5;
  if (_targetStarterCount > 0 && _targetStarterCount < 5) _targetStarterCount = 5;
  const _existingStarterIds = d.disciples.map(_x => Number(_x.id) || 0);
  let _nextStarterId = Math.max(0, ..._existingStarterIds) + 1;
  while (_starterCount < _targetStarterCount) {
    const _idx = _starterCount;
    const _name = _idx === 0 ? "守山童子" : CONFIG.DISCIPLE_NAMES[(_idx - 1) % CONFIG.DISCIPLE_NAMES.length];
    d.disciples.push({
      id: _nextStarterId++, name: _name, aptitude: 1, realm: 0, layer: 0,
      loyalty: 100, mood: 90, assignedTo: null, cultivation: 0,
      specialty: (CONFIG.SPECIALTIES[_idx % CONFIG.SPECIALTIES.length] && CONFIG.SPECIALTIES[_idx % CONFIG.SPECIALTIES.length].key) || "farm",
      bond: 0, origin: "开山赠礼", trainingDate: "", trainingExp: 0,
    });
    _starterCount++;
  }
  if (_targetStarterCount > 0) {
    d.starterDiscipleGranted = true;
    d.starterDiscipleCount = _targetStarterCount;
  } else {
    d.starterDiscipleCount = _hasStarterGrantCount ? Math.floor(Number(d.starterDiscipleCount)) : _starterCount;
  }
  delete d.assigned;
  // market 兼容：逐字段补全（浅合并会整体覆盖，缺子字段会丢失 herb/pill）
  if (!d.market || typeof d.market !== "object") d.market = {};
  if (d.market.herb == null) d.market.herb = CONFIG.MARKET_BASE.herb;
  if (d.market.pill == null) d.market.pill = CONFIG.MARKET_BASE.pill;
  if (d.market.tribPill == null) d.market.tribPill = CONFIG.MARKET_BASE.tribPill;
  if (d.market.material == null) d.market.material = CONFIG.MARKET_BASE.material;
  // 法宝兼容（v0.6.0）
  if (d.materials == null) d.materials = 0;
  if (!Array.isArray(d.artifacts)) d.artifacts = [];
  if (!d.equipped || typeof d.equipped !== "object") d.equipped = {};
  if (d.equipped.attack === undefined) d.equipped.attack = null;
  if (d.equipped.defense === undefined) d.equipped.defense = null;
  if (d.equipped.support === undefined) d.equipped.support = null;
  // 清理悬空装备引用（法宝已不存在）
  const ids = d.artifacts.map(a => a.id);
  for (const k of ["attack", "defense", "support"]) {
    if (d.equipped[k] != null && ids.indexOf(d.equipped[k]) < 0) d.equipped[k] = null;
  }
  // 12 格装备栏（v0.18.0，纯新增字段）：旧三槽自动迁移到对应栏位
  if (!d.loadout || typeof d.loadout !== "object") d.loadout = {};
  for (const sl of CONFIG.LOADOUT_SLOTS) {
    if (d.loadout[sl.key] === undefined) d.loadout[sl.key] = null;
    if (d.loadout[sl.key] != null && ids.indexOf(d.loadout[sl.key]) < 0) d.loadout[sl.key] = null;
  }
  if (d.loadout.weapon == null && d.equipped.attack != null) d.loadout.weapon = d.equipped.attack;
  if (d.loadout.armor == null && d.equipped.defense != null) d.loadout.armor = d.equipped.defense;
  if (d.loadout.trinket == null && d.equipped.support != null) d.loadout.trinket = d.equipped.support;
  // 法宝新字段（v0.18.0）：器纹、自带神通
  for (const a of d.artifacts) {
    if (!Array.isArray(a.engrave)) a.engrave = [];
    if (a.skill === undefined) a.skill = null;
  }
  // 事件链冷却（v0.6.1，纯新增字段，缺失时补空对象即可，无需升级 version）
  if (!d.eventCooldown || typeof d.eventCooldown !== "object") d.eventCooldown = {};
  // 法宝词条（v0.6.2）：旧档法宝补空词条数组，不追发，需重新炼制/炼化获得
  for (const a of d.artifacts) {
    if (!Array.isArray(a.affixes)) a.affixes = [];
  }
  // 境界专属事件里程碑（v0.6.2）
  if (!d.milestones || typeof d.milestones !== "object") d.milestones = {};
  // 道途录（v0.6.5）：成就 / 统计 / 图鉴
  if (!d.achievements || typeof d.achievements !== "object") d.achievements = {};
  if (!d.stats || typeof d.stats !== "object") d.stats = {};
  if (typeof d.stats.battleWins !== "number") d.stats.battleWins = 0;
  if (typeof d.stats.bossWins !== "number") d.stats.bossWins = 0;
  if (!d.codex || typeof d.codex !== "object") d.codex = {};
  if (!d.codex.artifacts || typeof d.codex.artifacts !== "object") d.codex.artifacts = {};
  if (!d.codex.events || typeof d.codex.events !== "object") d.codex.events = {};
  // 妖兽 / 秘境图鉴（v0.8.0）
  if (!d.codex.beasts || typeof d.codex.beasts !== "object") d.codex.beasts = {};
  if (!d.codex.regions || typeof d.codex.regions !== "object") d.codex.regions = {};
  if (!d.codex.pets || typeof d.codex.pets !== "object") d.codex.pets = {};
  // 药力（v0.8.0，纯新增字段）
  if (typeof d.pillBuff !== "number") d.pillBuff = 0;
  // 试炼塔最高层（v0.8.0）
  if (typeof d.towerBest !== "number") d.towerBest = 0;
  // 塔币（v0.9.0，纯新增字段）
  if (typeof d.towerCoin !== "number") d.towerCoin = 0;
  // 秘境战场技能盘（v0.16.0，纯新增字段，不升级 version）
  if (!Array.isArray(d.fieldSlots)) d.fieldSlots = [];
  // 秘境探索与派遣（v0.17.0，纯新增字段）
  if (!d.clearedMaps || typeof d.clearedMaps !== "object") d.clearedMaps = {};
  if (!d.mapTeam || typeof d.mapTeam !== "object") d.mapTeam = {};
  // v0.26.0：灵脉等级表（旧档补空对象；非法值钳制到 0~MAX）
  if (!d.fieldVein || typeof d.fieldVein !== "object") d.fieldVein = {};
  // v0.29.0：修炼方向/吐纳/机缘/任务/特产
  if (!d.dao || !CONFIG.DAO_PATHS.some(x => x.key === d.dao)) d.dao = "fa";
  if (typeof d.tunaLeft !== "number") d.tunaLeft = CONFIG.TUNA.DAILY;
  if (typeof d.tunaDate !== "string") d.tunaDate = "";
  if (typeof d.tunaCount !== "number") d.tunaCount = 0;
  if (typeof d.soulHurtUntil !== "number") d.soulHurtUntil = 0;
  if (typeof d.fate !== "number") d.fate = 0;
  d.huntingIncense = (d.huntingIncense === true || d.huntingIncense === 1) ? 1 : 0;
  if (!d.daily || typeof d.daily !== "object") d.daily = {};
  if (!d.weekly || typeof d.weekly !== "object") d.weekly = {};
  if (!d.specialty || typeof d.specialty !== "object") d.specialty = {};
  if (!d.marketRefresh || typeof d.marketRefresh !== "object") d.marketRefresh = {};
  if (!d.marketDeals || typeof d.marketDeals !== "object") d.marketDeals = {};
  if (!d.marketShelf || typeof d.marketShelf !== "object") d.marketShelf = null;
  if (d.marketShelf && (!Array.isArray(d.marketShelf.items) || !Number.isFinite(Number(d.marketShelf.refreshedAt)))) d.marketShelf = null;
  if (!d.ancient || typeof d.ancient !== "object") d.ancient = {};
  if (!d.fieldMine || typeof d.fieldMine !== "object") d.fieldMine = {};
  if (!d.fieldGarden || typeof d.fieldGarden !== "object") d.fieldGarden = {};
  if (!d.artWarm || typeof d.artWarm !== "object") d.artWarm = {};
  if (!d.skillInsight || typeof d.skillInsight !== "object") d.skillInsight = {};
  if (!d.sect || typeof d.sect !== "object") d.sect = {};
  if (!d.fieldStable || typeof d.fieldStable !== "object") d.fieldStable = {};
  if (!d.fieldTemple || typeof d.fieldTemple !== "object") d.fieldTemple = {};
  if (!d.fieldLabor || typeof d.fieldLabor !== "object") d.fieldLabor = {};
  if (!d.fieldResidents || typeof d.fieldResidents !== "object" || Array.isArray(d.fieldResidents)) d.fieldResidents = {};
  for (const _ch in d.fieldResidents) {
    const _r = d.fieldResidents[_ch] || {};
    d.fieldResidents[_ch] = { cultivators: Math.max(0, Math.floor(Number(_r.cultivators) || 0)), progress: Math.max(0, Math.min(0.999999, Number(_r.progress) || 0)), totalArrived: Math.max(0, Math.floor(Number(_r.totalArrived) || 0)), totalDeparted: Math.max(0, Math.floor(Number(_r.totalDeparted) || 0)), converted: Math.max(0, Math.floor(Number(_r.converted) || 0)), departureProgress: Math.max(0, Math.min(0.999999, Number(_r.departureProgress) || 0)), totalRentPaid: Math.max(0, Math.floor(Number(_r.totalRentPaid) || 0)), lastRentPaid: Math.max(0, Math.floor(Number(_r.lastRentPaid) || 0)), lastRentDay: typeof _r.lastRentDay === "string" ? _r.lastRentDay : "", lastDay: typeof _r.lastDay === "string" ? _r.lastDay : "", wallets: Array.isArray(_r.wallets) ? _r.wallets.filter(w => w && typeof w === "object").map(w => ({ id: Math.max(1, Math.floor(Number(w.id) || 1)), balance: Math.max(0, Math.floor(Number(w.balance) || 0)), lastIncomeDay: typeof w.lastIncomeDay === "string" ? w.lastIncomeDay : "", purchasesDay: typeof w.purchasesDay === "string" ? w.purchasesDay : "", purchasesCount: Math.max(0, Math.floor(Number(w.purchasesCount) || 0)), occupation: typeof w.occupation === "string" ? w.occupation : "" })) : [], nextWalletId: Math.max(1, Math.floor(Number(_r.nextWalletId) || 1)), totalWalletIncome: Math.max(0, Math.floor(Number(_r.totalWalletIncome) || 0)), totalWalletSpent: Math.max(0, Math.floor(Number(_r.totalWalletSpent) || 0)), totalResidentPurchases: Math.max(0, Math.floor(Number(_r.totalResidentPurchases) || 0)), departedWalletBalance: Math.max(0, Math.floor(Number(_r.departedWalletBalance) || 0)) };
    while (d.fieldResidents[_ch].wallets.length < d.fieldResidents[_ch].cultivators) { const id = d.fieldResidents[_ch].nextWalletId++; d.fieldResidents[_ch].wallets.push({ id, balance: 0, lastIncomeDay: "", purchasesDay: "", purchasesCount: 0, occupation: "" }); }
    if (d.fieldResidents[_ch].wallets.length > d.fieldResidents[_ch].cultivators) d.fieldResidents[_ch].wallets = d.fieldResidents[_ch].wallets.slice(0, d.fieldResidents[_ch].cultivators);
  }
  // v0.57.0：凡人社会账本独立于人口主账本，旧档不追发公库余额或历史婚育。
  if (!d.fieldSociety || typeof d.fieldSociety !== "object" || Array.isArray(d.fieldSociety)) d.fieldSociety = {};
  for (const _ch in d.fieldSociety) {
    const _v = d.fieldSociety[_ch] || {};
    d.fieldSociety[_ch] = { marriedCouples: Math.max(0, Math.floor(Number(_v.marriedCouples) || 0)), marriageProgress: Math.max(0, Math.min(0.999999, Number(_v.marriageProgress) || 0)), birthProgress: Math.max(0, Math.min(0.999999, Number(_v.birthProgress) || 0)), births: Math.max(0, Math.floor(Number(_v.births) || 0)), children: Math.max(0, Math.floor(Number(_v.children) || 0)), maturationProgress: Math.max(0, Math.min(0.999999, Number(_v.maturationProgress) || 0)), treasury: Math.max(0, Number(_v.treasury) || 0), levyIncome: Math.max(0, Number(_v.levyIncome) || 0), consumptionPaid: Math.max(0, Number(_v.consumptionPaid) || 0), consumptionShortfall: Math.max(0, Number(_v.consumptionShortfall) || 0), lastConsumption: Math.max(0, Number(_v.lastConsumption) || 0), lastLevyDay: typeof _v.lastLevyDay === "string" ? _v.lastLevyDay : "", lastLifeDay: typeof _v.lastLifeDay === "string" ? _v.lastLifeDay : "" };
  }
  if (!d.recruitPool || typeof d.recruitPool !== "object") d.recruitPool = {};
  if (!d.dynasty || typeof d.dynasty !== "object") d.dynasty = {};
  if (!d.staff || typeof d.staff !== "object") d.staff = {};
  if (!Array.isArray(d.missions)) d.missions = [];
  if (typeof d.missionSeq !== "number") d.missionSeq = 0;
  if (!d.dynastyOffice || typeof d.dynastyOffice !== "object") d.dynastyOffice = {};
  if (!d.lostFields || typeof d.lostFields !== "object") d.lostFields = {};
  if (typeof d.contribution !== "number") d.contribution = 0;
  if (!d.petInner || typeof d.petInner !== "object") d.petInner = {};
  if (typeof d.conquered !== "number") d.conquered = 0;
  if (!d.garden || typeof d.garden !== "object") d.garden = {};
  if (!d.avatarBody || typeof d.avatarBody !== "object") d.avatarBody = {};
  if (!Array.isArray(d.friends)) d.friends = [];
  if (typeof d.friendSeq !== "number") d.friendSeq = 0;
  if (!d.sectDaily || typeof d.sectDaily !== "object") d.sectDaily = {};
  if (!d.sectTrial || typeof d.sectTrial !== "object") d.sectTrial = {};
  for (const k in d.fieldStable) d.fieldStable[k] = Math.max(0, Math.min(100, Math.floor(Number(d.fieldStable[k]) || 0)));
  for (const k in d.fieldTemple) d.fieldTemple[k] = Math.max(0, Math.min(CONFIG.STABLE.TEMPLE_MAX, Math.floor(Number(d.fieldTemple[k]) || 0)));
  for (const k in d.fieldMine) d.fieldMine[k] = Math.max(0, Math.min(CONFIG.FIELD_VEIN.MAX, Math.floor(Number(d.fieldMine[k]) || 0)));
  for (const k in d.fieldGarden) d.fieldGarden[k] = Math.max(0, Math.min(CONFIG.FIELD_VEIN.MAX, Math.floor(Number(d.fieldGarden[k]) || 0)));
  for (const k in d.artWarm) d.artWarm[k] = Math.max(0, Math.min(CONFIG.WARM.MAX, Math.floor(Number(d.artWarm[k]) || 0)));
  for (const k in d.skillInsight) d.skillInsight[k] = Math.max(0, Math.min(CONFIG.INSIGHT.MAX, Math.floor(Number(d.skillInsight[k]) || 0)));
  if (!d.ancientFrag || typeof d.ancientFrag !== "object") d.ancientFrag = {};
  // 古宝数值钳制
  for (const k in d.ancient) {
    const v = d.ancient[k] || {};
    v.star = Math.max(1, Math.min(CONFIG.ANCIENT.MAX_STAR, Math.floor(Number(v.star) || 1)));
    v.infuse = Math.max(0, Math.min(CONFIG.ANCIENT.INFUSE_MAX, Math.floor(Number(v.infuse) || 0)));
    d.ancient[k] = v;
  }
  // v0.28.0：凡人（旧档补 0；非法值钳制为非负整数）
  const _folk = Math.floor(Number(d.folk));
  d.folk = isFinite(_folk) && _folk > 0 ? _folk : 0;
  // v0.54.2：凡人从全局数字升级为「各秘境聚落人口」账本。
  // 旧档人口全部保留：优先分配给已有驻守秘境，没有驻守时放入迁移储备，首次经营时再迁入聚落。
  if (!d.fieldSettlements || typeof d.fieldSettlements !== "object" || Array.isArray(d.fieldSettlements)) d.fieldSettlements = {};
  for (const _ch in d.fieldSettlements) {
    if (_ch === "_reserve") continue;
    const _v = d.fieldSettlements[_ch] || {};
    d.fieldSettlements[_ch] = {
      population: Math.max(0, Number(_v.population) || 0),
      foundedAt: typeof _v.foundedAt === "string" ? _v.foundedAt : "",
      name: typeof _v.name === "string" ? _v.name : "",
    };
  }
  let _settled = Math.max(0, Number(d.fieldSettlements._reserve) || 0);
  for (const _ch in d.fieldSettlements) if (_ch !== "_reserve") _settled += d.fieldSettlements[_ch].population;
  if (_folk > _settled) {
    const _activeMaps = Object.keys(d.mapTeam || {}).filter(_ch => Array.isArray(d.mapTeam[_ch]) && d.mapTeam[_ch].length && d.clearedMaps && d.clearedMaps[_ch]);
    let _left = _folk - _settled;
    if (_activeMaps.length) {
      const _each = _left / _activeMaps.length;
      for (const _ch of _activeMaps) {
        if (!d.fieldSettlements[_ch]) d.fieldSettlements[_ch] = { population: 0, foundedAt: "", name: "" };
        d.fieldSettlements[_ch].population += _each;
      }
    } else _settled += _left;
  }
  d.fieldSettlements._reserve = Math.max(0, _settled > _folk ? Number(d.fieldSettlements._reserve) || 0 : _folk - Object.keys(d.fieldSettlements).filter(_k => _k !== "_reserve").reduce((_n, _k) => _n + d.fieldSettlements[_k].population, 0));
  // 以账本为准，保留小数繁衍进度。
  d.folk = Object.keys(d.fieldSettlements).reduce((_n, _k) => _n + (_k === "_reserve" ? Math.max(0, Number(d.fieldSettlements._reserve) || 0) : d.fieldSettlements[_k].population), 0);
  for (const k in d.fieldVein) {
    const v = Math.floor(Number(d.fieldVein[k]));
    d.fieldVein[k] = isFinite(v) ? Math.max(0, Math.min(CONFIG.FIELD_VEIN.MAX, v)) : 0;
  }
  // 章节叙事与新增统计（v0.11.0，纯新增字段）
  if (!d.storySeen || typeof d.storySeen !== "object") d.storySeen = {};
  if (!d.storyChoices || typeof d.storyChoices !== "object") d.storyChoices = {};
  if (typeof d.stats.battlegroundWins !== "number") d.stats.battlegroundWins = 0;
  if (typeof d.stats.pillmeetWins !== "number") d.stats.pillmeetWins = 0;
  // 建筑 / 世界时钟 / 势力（v0.17.4 修复）
  // load() 用 Object.assign(defaultState(), migrated) 是浅合并：
  // 旧档只要缺 buildings.forge 这类子字段，就会被整体替换成不完整对象，
  // 之后 1+0.07*undefined 与 0*undefined 直接产出 NaN，一路污染 S.qi / 战斗数值并落盘。
  const _def = defaultState();
  if (!d.buildings || typeof d.buildings !== "object") d.buildings = {};
  for (const _k of Object.keys(_def.buildings)) {
    if (typeof d.buildings[_k] !== "number" || !isFinite(d.buildings[_k])) d.buildings[_k] = _def.buildings[_k];
  }
  if (!d.gameTime || typeof d.gameTime !== "object") d.gameTime = {};
  for (const _k of Object.keys(_def.gameTime)) {
    if (typeof d.gameTime[_k] !== "number" || !isFinite(d.gameTime[_k])) d.gameTime[_k] = _def.gameTime[_k];
  }
  if (!d.factions || typeof d.factions !== "object") d.factions = {};
  for (const _k of Object.keys(_def.factions)) {
    if (!d.factions[_k] || typeof d.factions[_k] !== "object") {
      d.factions[_k] = JSON.parse(JSON.stringify(_def.factions[_k]));
      continue;
    }
    for (const _kk of Object.keys(_def.factions[_k])) {
      if (typeof d.factions[_k][_kk] !== "number" || !isFinite(d.factions[_k][_kk])) {
        d.factions[_k][_kk] = _def.factions[_k][_kk];
      }
    }
  }
  // 顶层数值兜底：NaN 一经写入存档就不可逆，这里统一清洗
  for (const _k of ["qi", "stone", "stamina", "herbs", "pills", "materials", "reputation",
    "bestStage", "lastStage", "pillBuff", "tribPills", "tribPillBuff", "tribFails",
    "towerBest", "towerCoin", "talisman",
    "healShield", "rerollFree", "gongfaCut", "breakPillBuff"]) {
    if (typeof d[_k] !== "number" || !isFinite(d[_k])) d[_k] = _def[_k];
  }
  // 功法目录 v1（v0.53.1）：旧十阶 → 正式六阶，一次性按层数进度比例迁移。
  // 保留 legacyLv 供审计；不删除已领悟状态、不回收秘籍、不清空悟道或装备。
  if (!d.gongfaBooks || typeof d.gongfaBooks !== "object") d.gongfaBooks = {};
  const _needsGongfaCatalogMigration = Number(d.gongfaCatalogVersion || 0) < (CONFIG.GONGFA_CATALOG_VERSION || 1);
  for (const _gb of CONFIG.GONGFA_BOOKS) {
    let _cur = d.gongfaBooks[_gb.key];
    if (!_cur || typeof _cur !== "object") _cur = d.gongfaBooks[_gb.key] = { lv: 0 };
    if (typeof _cur.lv !== "number" || !isFinite(_cur.lv)) _cur.lv = 0;
    _cur.lv = Math.max(0, _cur.lv);
    if (_needsGongfaCatalogMigration) {
      const _oldMax = Math.max(1, Number(_gb.legacyLayers) || _gb.layers);
      const _oldLv = Math.min(_oldMax, _cur.lv);
      _cur.legacyLv = _oldLv;
      const _ratioLv = Math.round((_oldLv / _oldMax) * _gb.layers);
      // 旧节点位于 3/6/9/12 层；优先保留已达成的三层关窍里程碑。
      const _milestoneLv = _oldLv > 0 && _oldLv % 3 === 0 ? _oldLv : _ratioLv;
      _cur.lv = Math.min(_gb.layers, Math.max(0, _milestoneLv));
    }
    if (_cur.lv > _gb.layers) _cur.lv = _gb.layers;
    if (typeof _cur.learned !== "boolean") _cur.learned = _cur.lv > 0 || _gb.key === "changsheng";
  }
  d.gongfaCatalogVersion = CONFIG.GONGFA_CATALOG_VERSION || 1;
  if (typeof d.talisman !== "number" || !isFinite(d.talisman) || d.talisman < 0) d.talisman = 0;
  // 角色形象（v0.22.0，纯新增字段）
  if (!d.avatar || !CONFIG.AVATARS.some(a => a.key === d.avatar)) d.avatar = CONFIG.AVATARS[0].key;
  // 灵兽（v0.21.0，纯新增字段；v0.24.0 补深度养成子字段）
  if (!Array.isArray(d.pets)) d.pets = [];
  for (const _pt of d.pets) {
    if (typeof _pt.lv !== "number" || !isFinite(_pt.lv) || _pt.lv < 1) _pt.lv = 1;
    if (typeof _pt.exp !== "number" || !isFinite(_pt.exp) || _pt.exp < 0) _pt.exp = 0;
    if (typeof _pt.star !== "number" || !isFinite(_pt.star) || _pt.star < 1) _pt.star = 1;
    if (_pt.star > CONFIG.PET_STAR_MAX) _pt.star = CONFIG.PET_STAR_MAX;
    if (typeof _pt.bond !== "number" || !isFinite(_pt.bond) || _pt.bond < 0) _pt.bond = 0;
    if (_pt.bond > CONFIG.PET_BOND_MAX) _pt.bond = CONFIG.PET_BOND_MAX;
    if (!Array.isArray(_pt.skills)) {
      // 旧档灵兽无技能：按稀有度补掷一次（与捕捉规则一致）
      const _pd = CONFIG.PETS.find(x => x.key === _pt.key);
      _pt.skills = (_pd && CONFIG.petSkillRoll) ? CONFIG.petSkillRoll(_pd.tier) : [];
    } else {
      // 过滤非法技能 key
      _pt.skills = _pt.skills.filter(k => CONFIG.petSkillDef && CONFIG.petSkillDef(k));
    }
  }
  if (d.petActive === undefined) d.petActive = d.pets.length ? d.pets[0].id : null;
  if (d.petActive != null && !d.pets.some(x => x.id === d.petActive)) d.petActive = null;
  let _legacyGongfa = (typeof d.gongfa === "number" && isFinite(d.gongfa)) ? d.gongfa : 0;
  if (_legacyGongfa > 0) {
    for (const _gb of CONFIG.GONGFA_BOOKS) {
      while (_legacyGongfa > 0 && d.gongfaBooks[_gb.key].lv < _gb.layers) {
        d.gongfaBooks[_gb.key].lv++;
        d.gongfaBooks[_gb.key].learned = true;   // 有层数即视为已领悟
        _legacyGongfa--;
      }
    }
  }
  d.gongfa = 0;

  // ---------- 新手引路（v0.47.0）----------
  if (!d.guide || typeof d.guide !== "object") d.guide = { step: 0, done: [] };
  if (!Array.isArray(d.guide.done)) d.guide.done = [];
  if (!isFinite(d.guide.step) || d.guide.step < 0) d.guide.step = d.guide.done.length;
  if (!d.guideFlags || typeof d.guideFlags !== "object") d.guideFlags = {};

  // ---------- 仙友事件（v0.45.0）----------
  if (!d.friendHelp || typeof d.friendHelp !== "object") d.friendHelp = { date: "", used: 0 };
  if (!isFinite(d.friendHelp.used)) d.friendHelp.used = 0;
  if (!isFinite(d.helpBuffUntil)) d.helpBuffUntil = 0;
  if (!isFinite(d.loverGiftAt)) d.loverGiftAt = 0;
  if (Array.isArray(d.friends)) {
    for (const f of d.friends) {
      if (!Array.isArray(f.events)) f.events = [];
      if (!isFinite(f.rel)) f.rel = 0;
    }
  }

  // ---------- 丹炉（v0.39.0 单炉 → v0.42.0 三炉位）----------
  if (!d.dan || typeof d.dan !== "object") d.dan = { slots: [null, null, null] };
  // 旧档单炉结构迁移
  if (typeof d.dan.recipe !== "undefined" && !Array.isArray(d.dan.slots)) {
    const legacy = d.dan.recipe && CONFIG.DAN.RECIPES.some(r => r.key === d.dan.recipe)
      ? { recipe: d.dan.recipe, startAt: d.dan.startAt || 0, dur: d.dan.dur || 0, mult: 1 }
      : null;
    d.dan = { slots: [legacy, null, null] };
  }
  if (!Array.isArray(d.dan.slots)) d.dan.slots = [null, null, null];
  while (d.dan.slots.length < 3) d.dan.slots.push(null);
  if (d.dan.slots.length > 3) d.dan.slots.length = 3;
  for (let i = 0; i < 3; i++) {
    const sl = d.dan.slots[i];
    if (!sl || typeof sl !== "object") { d.dan.slots[i] = null; continue; }
    if (!sl.recipe || !CONFIG.DAN.RECIPES.some(r => r.key === sl.recipe)) { d.dan.slots[i] = null; continue; }
    if (!isFinite(sl.startAt)) sl.startAt = 0;
    if (!isFinite(sl.dur) || sl.dur < 0) sl.dur = 0;
    if (!isFinite(sl.mult) || sl.mult < 1 || sl.mult > 3) sl.mult = 1;
  }

  // ---------- 储物法器（v0.37.0）----------
  // 结构校正在此完成；把旧资源字段装进袋子在 inventory.js 的 invEnsure() 里做（依赖堆叠算法）
  const _cts = CONFIG.INV.CONTAINERS;
  if (!d.bag || typeof d.bag !== "object") {
    d.bag = { tier: 0, slots: [], pending: true };
  }
  let _tier = parseInt(d.bag.tier, 10);
  if (!isFinite(_tier) || _tier < 0 || _tier >= _cts.length) _tier = 0;
  d.bag.tier = _tier;
  const _cap = _cts[_tier].slots;
  const _slots = Array.isArray(d.bag.slots) ? d.bag.slots : [];
  const _clean = [];
  for (let i = 0; i < _cap; i++) {
    const st = _slots[i];
    if (st && typeof st === "object" && typeof st.key === "string" && isFinite(st.n) && st.n > 0) {
      _clean.push({ key: st.key, n: st.n });
    } else _clean.push(null);
  }
  d.bag.slots = _clean;
  if (!d.bag.stash || typeof d.bag.stash !== "object") d.bag.stash = {};
  for (const _sk in d.bag.stash) {
    const _sn = Number(d.bag.stash[_sk]);
    if (!isFinite(_sn) || _sn <= 0) delete d.bag.stash[_sk]; else d.bag.stash[_sk] = _sn;
  }
  if (d.bag.pending !== false) d.bag.pending = true;

  // ---------- 内视：经脉与丹田（v0.50.0）----------
  // 纯新增整数：缺字段补 0，非法值钳制。旧档零丢失、无版本分支。
  if (!d.meridian || typeof d.meridian !== "object") d.meridian = {};
  for (const _md of CONFIG.MERIDIANS) {
    let _hv = parseInt(d.meridian[_md.key], 10);
    if (!isFinite(_hv) || _hv < 0) _hv = 0;
    if (_hv > CONFIG.MERIDIAN.MAX_PER) _hv = CONFIG.MERIDIAN.MAX_PER;
    d.meridian[_md.key] = _hv;
  }
  let _dt = parseInt(d.dantian, 10);
  if (!isFinite(_dt) || _dt < 0) _dt = 0;
  if (_dt > CONFIG.DANTIAN.MAX) _dt = CONFIG.DANTIAN.MAX;
  d.dantian = _dt;

  // ---------- 驻守结算单（v0.51.0）----------
  // 纯新增结构：缺字段补空对象；单条记录逐项校验，非法值归零，不影响旧档任何数据。
  if (!d.settle || typeof d.settle !== "object" || Array.isArray(d.settle)) d.settle = {};
  for (const _ch in d.settle) {
    const _r = d.settle[_ch];
    if (!_r || typeof _r !== "object") { delete d.settle[_ch]; continue; }
    const _clean = { sec: 0, stone: 0, qi: 0, herb: 0, material: 0, folk: 0 };
    for (const _k in _clean) {
      const _v = Number(_r[_k]);
      _clean[_k] = isFinite(_v) && _v > 0 ? _v : 0;
    }
    if (_clean.sec > CONFIG.DISPATCH.SETTLE_KEEP_SEC) _clean.sec = CONFIG.DISPATCH.SETTLE_KEEP_SEC;
    if (_clean.sec <= 0) delete d.settle[_ch]; else d.settle[_ch] = _clean;
  }

  if (!d.fieldEducation || typeof d.fieldEducation !== "object") d.fieldEducation = {};
  if (!d.fieldCommerce || typeof d.fieldCommerce !== "object") d.fieldCommerce = {};
  for (const ch in d.fieldCommerce) {
    const c = d.fieldCommerce[ch] || {};
    c.buildings = c.buildings && typeof c.buildings === "object" ? c.buildings : {};
    c.market = c.market && typeof c.market === "object" ? c.market : {};
    if (c.budget && typeof c.budget === "object") {
      const issued = Math.max(0, Number(c.budget.issued) || 0);
      c.budget = { day: typeof c.budget.day === "string" ? c.budget.day : "", issued,
        remaining: Math.max(0, Math.min(issued, Number(c.budget.remaining) || 0)),
        spent: Math.max(0, Math.min(issued, Number(c.budget.spent) || 0)),
        rentReserved: Math.max(0, Math.min(Number(c.budget.remaining) || 0, Number(c.budget.rentReserved) || 0)) };
    } else c.budget = null;
    d.fieldCommerce[ch] = c;
  }
  for (const ch in d.fieldEducation) {
    const e = d.fieldEducation[ch] || {};
    e.progress = Math.max(0, Math.min(1, Number(e.progress) || 0));
    e.private = !!e.private || e.progress >= 1;
    if (e.private) e.progress = 1;
    e.totalGuardSec = Math.max(0, Number(e.totalGuardSec) || 0);
    d.fieldEducation[ch] = e;
  }
  // v0.58.0：建立秘境统一身份注册表。这里只登记身份与旧账本绑定关系，
  // 不复制人口、库存、建筑、产出或资金，避免双真源与旧档资源膨胀。
  if (!d.realms || typeof d.realms !== "object" || Array.isArray(d.realms)) d.realms = {};
  const _realmKeys = new Set();
  const _realmSources = [d.clearedMaps, d.mapTeam, d.fieldEducation, d.fieldCommerce,
    d.fieldVein, d.fieldMine, d.fieldGarden, d.fieldStable, d.fieldTemple,
    d.fieldLabor, d.fieldSettlements, d.fieldSociety, d.fieldResidents,
    d.staff, d.settle, d.mapNodeT, d.lostFields];
  for (const _src of _realmSources) {
    if (!_src || typeof _src !== "object") continue;
    for (const _key of Object.keys(_src)) {
      if (_key !== "_reserve" && Number.isInteger(Number(_key)) && Number(_key) >= 0) _realmKeys.add(String(Number(_key)));
    }
  }
  for (const _ch of _realmKeys) {
    const _id = "field_" + _ch;
    const _old = d.realms[_id] && typeof d.realms[_id] === "object" ? d.realms[_id] : {};
    const _settlement = d.fieldSettlements && d.fieldSettlements[_ch] || {};
    const _education = d.fieldEducation && d.fieldEducation[_ch] || {};
    const _private = !!_education.private || Number(_education.progress) >= 1;
    const _cleared = !!(d.clearedMaps && d.clearedMaps[_ch]);
    const _lost = !!(d.lostFields && d.lostFields[_ch]);
    d.realms[_id] = {
      id: _id,
      sourceChapter: _ch,
      name: typeof _old.name === "string" && _old.name.trim() ? _old.name : (typeof _settlement.name === "string" && _settlement.name.trim() ? _settlement.name : `第${Number(_ch) + 1}处秘境`),
      schemaVersion: 1,
      status: _lost ? "lost" : (_private ? "private" : (_cleared ? "discovered" : "dormant")),
      ownership: _private ? "player" : "unclaimed",
      createdAt: typeof _old.createdAt === "string" ? _old.createdAt : (typeof _settlement.foundedAt === "string" ? _settlement.foundedAt : ""),
      // 这些绑定是数据来源索引，不是副本；后续迁移按模块逐项切换真源。
      legacyBindings: {
        exploration: "clearedMaps",
        dispatch: "mapTeam",
        education: "fieldEducation",
        commerce: "fieldCommerce",
        vein: "fieldVein",
        mine: "fieldMine",
        fieldGarden: "fieldGarden",
        stability: "fieldStable",
        temple: "fieldTemple",
        labor: "fieldLabor",
        settlement: "fieldSettlements",
        society: "fieldSociety",
        cultivators: "fieldResidents",
        staff: "staff",
        settlementLedger: "settle",
        resourceNodes: "mapNodeT",
        lossState: "lostFields"
      },
      futureSystems: _old.futureSystems && typeof _old.futureSystems === "object" ? _old.futureSystems : {}
    };
  }
  // 不删除无法从旧章节反推的未来注册项，且不静默改写其 ID。
  d.version = SAVE_VERSION;
  return d;
}

// ---------- 角色档案（v0.25.0：按道号分档）----------
function profileBook() {
  try {
    const raw = localStorage.getItem(CONFIG.PROFILE_KEY);
    const d = raw ? JSON.parse(raw) : null;
    if (d && d.names) return d;
  } catch (e) { console.warn("档案读取失败", e); }
  return { last: "", names: {} };
}
function writeProfileBook(book) {
  try { localStorage.setItem(CONFIG.PROFILE_KEY, JSON.stringify(book)); }
  catch (e) { console.warn("档案写入失败", e); }
}
function saveKeyOf(name) { return CONFIG.SAVE_KEY_PREFIX + encodeURIComponent(name); }
// 已存在的道号列表（换角色/读档用）
function listProfiles() {
  const b = profileBook();
  return Object.keys(b.names).map(n => ({ name: n, avatar: b.names[n].avatar, createdAt: b.names[n].createdAt }));
}
// 建角：写入档案并清掉旧版单档（用户 v0.25.0 决定：旧档不继承）
function createCharacter(name, avatarKey, daoKey) {
  const nm = String(name || "").trim();
  if (nm.length < CONFIG.NAME_MIN || nm.length > CONFIG.NAME_MAX) {
    return { ok: false, msg: `道号需 ${CONFIG.NAME_MIN}~${CONFIG.NAME_MAX} 个字` };
  }
  const b = profileBook();
  if (b.names[nm]) return { ok: false, msg: "该道号已有存档，可直接继续" };
  S = defaultState();
  S.playerName = nm;
  S.avatar = avatarKey || S.avatar;
  // v0.54.2：开局赠送五名凡俗弟子，保证秘境驻守、洞府委派与弟子任务能并行起步。
  // 仅创建新道号时发放；读档、导入和切换角色不重复赠送。
  if (typeof createDisciple === "function") {
    for (let i = 0; i < 5; i++) {
      const starter = createDisciple();
      starter.name = i === 0 ? "守山童子" : CONFIG.DISCIPLE_NAMES[(i - 1) % CONFIG.DISCIPLE_NAMES.length];
      starter.aptitude = 1;
      starter.realm = 0;
      starter.layer = 0;
      starter.loyalty = 100;
      starter.mood = 90;
      starter.origin = "开山赠礼";
      S.disciples.push(starter);
    }
    S.starterDiscipleGranted = true;
    S.starterDiscipleCount = 5;
  }
  if (daoKey && (CONFIG.DAO_PATHS || []).some(d => d.key === daoKey)) S.dao = daoKey;
  b.names[nm] = { avatar: S.avatar, createdAt: Date.now() };
  b.last = nm;
  writeProfileBook(b);
  for (const k of CONFIG.LEGACY_KEYS) { try { localStorage.removeItem(k); } catch (e) {} }
  save();
  return { ok: true, name: nm };
}
// 切换道号（读该道号的档）
function switchCharacter(name) {
  const b = profileBook();
  if (!b.names[name]) return { ok: false, msg: "没有该道号的存档" };
  let d = null;
  try {
    const raw = localStorage.getItem(saveKeyOf(name));
    if (raw) d = JSON.parse(raw);
  } catch (e) { return { ok: false, msg: "存档读取失败" }; }
  S = d ? Object.assign(defaultState(), migrateState(d)) : defaultState();
  S.playerName = name;
  b.last = name;
  writeProfileBook(b);
  return { ok: true, name };
}

function load() {
  try {
    const b = profileBook();
    if (b.last && b.names[b.last]) {
      const raw = localStorage.getItem(saveKeyOf(b.last));
      if (raw) {
        const d = JSON.parse(raw);
        const st = Object.assign(defaultState(), migrateState(d));
        st.playerName = b.last;   // 档案为道号的唯一来源
        return st;
      }
    }
  } catch (e) { console.warn("读档失败", e); }
  // 无档：返回未建角的空档（不读取 v1/v2 旧单档，v0.25.0 起旧档清空）
  return defaultState();
}

function save() {
  S.lastOnline = Date.now();
  if (!S.playerName) return;   // 未建角不落盘
  try {
    localStorage.setItem(saveKeyOf(S.playerName), JSON.stringify(S));
    const b = profileBook();
    if (!b.names[S.playerName]) b.names[S.playerName] = { avatar: S.avatar, createdAt: Date.now() };
    b.names[S.playerName].avatar = S.avatar;
    b.last = S.playerName;
    writeProfileBook(b);
  } catch (e) { console.warn("存档失败", e); }
}

function resetSave() {
  if (confirm("确定要重置当前道号的所有进度吗？此操作不可撤销。")) {
    try { if (S.playerName) localStorage.removeItem(saveKeyOf(S.playerName)); } catch (e) {}
    const b = profileBook();
    if (S.playerName && b.names[S.playerName]) {
      delete b.names[S.playerName];
      if (b.last === S.playerName) b.last = Object.keys(b.names)[0] || "";
      writeProfileBook(b);
    }
    S = defaultState();
    location.reload();
  }
}

// ---------- 存档导出 / 导入（v0.6.2） ----------
// 换设备带走进度：导出为 JSON 文本（可下载或复制），导入时校验 + 迁移
const SAVE_MAGIC = "wenchangsheng-save";

// 导出存档文本（含标识、版本、导出时间）
function exportSaveText() {
  save();   // 先落盘，保证导出的是最新状态
  return JSON.stringify({
    magic: SAVE_MAGIC,
    game: "问长生",
    version: S.version,
    exportedAt: Date.now(),
    data: S,
  });
}

// 下载为 .json 文件（桌面端优先）
function downloadSaveFile() {
  const text = exportSaveText();
  const d = new Date();
  const pad = x => String(x).padStart(2, "0");
  const name = `问长生存档_${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}.json`;
  try {
    const blob = new Blob([text], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    return { ok: true, name };
  } catch (e) {
    return { ok: false, msg: "当前环境不支持文件下载，请改用「复制存档码」" };
  }
}

// 解析并校验存档文本（不做写入）
function parseSaveText(text) {
  if (!text || !String(text).trim()) return { ok: false, msg: "存档内容为空" };
  let obj;
  try { obj = JSON.parse(text); }
  catch (e) { return { ok: false, msg: "格式错误：不是有效的存档 JSON" }; }
  let raw = null;
  if (obj && obj.magic === SAVE_MAGIC && obj.data) raw = obj.data;
  else if (obj && obj.realm != null && obj.buildings) raw = obj;   // 兼容裸存档
  if (!raw) return { ok: false, msg: "校验失败：这不是《问长生》的存档" };
  if (raw.version != null && raw.version > SAVE_VERSION) {
    return { ok: false, msg: `存档版本（v${raw.version}）高于当前游戏，请更新游戏后再导入` };
  }
  return { ok: true, data: raw };
}

// 执行导入（覆盖当前进度，不可撤销）
function importSaveText(text) {
  const r = parseSaveText(text);
  if (!r.ok) return r;
  try {
    const migrated = migrateState(r.data);
    const keepName = S.playerName;          // 导入只覆盖进度，不夺走当前道号归属
    S = Object.assign(defaultState(), migrated);
    // 道号归属：当前道号 > 档内道号 > 默认散修（保证导入后必有归属，可正常落盘）
    S.playerName = keepName || migrated.playerName || "无名散修";
    const book = profileBook();
    if (!book.names[S.playerName]) {
      book.names[S.playerName] = { avatar: S.avatar, createdAt: Date.now() };
    }
    book.last = S.playerName;
    writeProfileBook(book);
    // 重置法宝 id 序列，避免新炼法宝与导入存档内的法宝 id 冲突
    if (typeof refreshArtifactSeq === "function") refreshArtifactSeq();
    save();
    return {
      ok: true,
      summary: `导入成功：${CONFIG.REALMS[S.realm] || "?"}${(S.layer || 0) + 1}层 ｜ 法宝 ${(S.artifacts || []).length} 件 ｜ 灵石 ${fmt(S.stone)}`,
    };
  } catch (e) {
    return { ok: false, msg: "导入失败：" + e.message };
  }
}

// ---------- 派生属性 ----------
function kNow() { return globalLayer(S.realm, S.layer); }

function realmName() { return CONFIG.REALMS[S.realm]; }

// 法宝加成汇总（artifact.js 未加载时安全降级为 0）
function _ab() {
  if (typeof artifactBonus === "function") return artifactBonus();
  return { atk: 0, def: 0, hp: 0, cult: 0 };
}

// 剧本分支加成汇总（v0.12.0）
// 战之选择 → 攻击；道之选择 → 修炼速率。幅度刻意压小（满配 +10% 攻 / +7.5% 修炼）。
function storyBonus() {
  const c = S.storyChoices || {};
  let war = 0, dao = 0;
  for (const k of Object.keys(c)) {
    if (c[k] === "war") war++;
    else if (c[k] === "dao") dao++;
  }
  return {
    war, dao, chosen: war + dao,
    atk: war * CONFIG.STORY_WAR_ATK,
    cult: dao * CONFIG.STORY_DAO_CULT,
  };
}

// 道心结论：五章全部选完才结算
function storyEnding() {
  const b = storyBonus();
  if (b.chosen < CONFIG.CHAPTERS.length) return null;
  const warRatio = b.war / b.chosen;
  if (warRatio >= CONFIG.STORY_ENDING_RATIO) {
    return { key: "war", title: "剑心通明", desc: "你一路拔剑，一路未悔。长生路上，你信的是自己手中这柄剑。" };
  }
  if (1 - warRatio >= CONFIG.STORY_ENDING_RATIO) {
    return { key: "dao", title: "道心澄澈", desc: "你一路守住本心，不为外物所动。长生路上，你信的是不动的那颗心。" };
  }
  return { key: "balance", title: "心剑双修", desc: "你既拔剑，也守心。长生路上，你走的是一条自己的路。" };
}

// 选择章节分支（v0.12.0）：一次性、不可更改。
// 注意 storySeen 在此处才写入——玩家若在弹窗中途离开，下次仍会重新弹出。
function chooseStory(ch, pick) {
  const def = CONFIG.CHAPTERS[ch];
  if (!def || !def.story) return { ok: false, msg: "该章没有剧情" };
  if (!S.storyChoices) S.storyChoices = {};
  if (S.storyChoices[ch]) return { ok: false, msg: "该章道心已定，不可更改" };
  const opt = (def.story.choices || []).find(c => c.key === pick);
  if (!opt) return { ok: false, msg: "无效选项" };
  S.storyChoices[ch] = pick;
  if (!S.storySeen) S.storySeen = {};
  S.storySeen[ch] = (typeof totalDays === "function") ? totalDays() : 0;
  const b = storyBonus();
  save();
  return {
    ok: true, label: opt.label, desc: opt.desc,
    war: b.war, dao: b.dao, chosen: b.chosen,
    ending: storyEnding(),
  };
}

// 已探明秘境章数（v0.25.0：clearedMaps 为唯一来源）
function fieldClearCount() {
  if (!S.clearedMaps) return 0;
  return Object.keys(S.clearedMaps).filter(k => S.clearedMaps[k]).length;
}

// 练功房弟子加成（v0.27.0 修复：此前弟子入驻练功房对修炼速率完全无效）
function practiceDiscipleMult() {
  let m = 1;
  for (const d of S.disciples) {
    if (d.assignedTo === "practice") m += discipleOutputBonus(d);
  }
  return m;
}

// 修炼加成明细（v0.25.0：唯一来源，速率与 UI 明细共用同一组乘区）
// 修炼速率 = 基础 × 练功房(等级×弟子) × 功法/道体 × 药力 × 势力庇护 × 辅道法宝 × 剧本 × 秘境探明
function cultivationBreakdown() {
  const base = CONFIG.baseRate(S.realm, S.layer);
  const gf = gongfaBonus();                   // v0.20.0：十阶功法汇总
  const _avCult = (typeof avatarTint === "function") ? avatarTint().cult : 0;
  const practiceBase = 1 + CONFIG.PRACTICE_RATE_BONUS * (S.buildings.practice || 0);
  const practiceDisc = practiceDiscipleMult();
  const practice = practiceBase * practiceDisc;
  const gongfa = 1 + gf.cult + _avCult;
  // 药力（v0.8.0 接入：此前 PILL_RATE_BONUS / PILL_BONUS_CAP 为未使用的死配置）
  // 丹效功法（「五气朝元」「九转金丹功」等）放大药力收益
  const pill = 1 + Math.min((S.pillBuff || 0) * CONFIG.PILL_RATE_BONUS * (1 + gf.pill), CONFIG.PILL_BONUS_CAP);
  // 势力庇护：与青云门关系达标，修炼速率 +10%
  const bless = blessed("qingyun") ? 1.1 : 1;
  // 辅道法宝：修炼速率百分比加成
  const art = 1 + _ab().cult;
  // 剧本「道」之选择（v0.12.0）
  const story = 1 + storyBonus().cult;
  // 秘境探明（v0.25.0）：每章 +1%，随探明章数常驻
  const fldCh = fieldClearCount();
  const field = 1 + fldCh * CONFIG.FIELD_CLEAR_CULT_BONUS;
  // 修炼方向（v0.29.0）：法修 +8% / 体修 -8% / 剑修 -2% / 双修 -25%
  const daoK = (typeof daoDef === "function") ? daoDef(S.dao).cult : 1;
  // 古宝（v0.30.0）：收藏加成
  const anci = 1 + ((typeof ancientBonus === "function") ? ancientBonus().cult : 0);
  // 宗门（v0.31.0）：每级修炼 +1%
  let sectK = 1 + (S.sect && S.sect.lv ? S.sect.lv * CONFIG.SECT.CULT : 0);
  // 王朝国师（v0.33.0）：修炼 +3%
  if (typeof dynastyOfficeMult === "function") sectK *= (1 + dynastyOfficeMult("cult"));
  // 道侣（v0.36.0）：+5% 修炼
  if (typeof loverBonus === "function") sectK *= (1 + loverBonus());
  // 仙友请援（v0.45.0）：2 小时内修炼 +10%
  if (typeof helpBuffActive === "function" && helpBuffActive()) sectK *= (1 + CONFIG.FRIEND.HELP_CULT);
  // 内视（v0.50.0）：经脉小周天 + 丹田丹阶
  const mer = 1 + ((typeof meridianSum === "function") ? meridianSum().cult : 0);
  const total = base * practice * gongfa * pill * bless * art * story * field * daoK * anci * sectK * mer;
  return {
    base, practice, practiceBase, practiceDisc, gongfa, pill, bless, art, story, field, dao: daoK, anci, sect: sectK, meridian: mer,
    fieldChapters: fldCh, pillLayers: S.pillBuff || 0,
    practiceLv: S.buildings.practice || 0, total,
  };
}

// 修炼速率（灵气/秒）——保留旧接口，内部走明细唯一来源
function cultivationRate() {
  return cultivationBreakdown().total;
}

// 离线修炼速率展示：与 computeOffline() 使用同一闭关功法乘区，避免 UI 口径不一致。
function offlineCultivationRate() {
  const off = (typeof gongfaBonus === "function") ? (gongfaBonus().offline || 0) : 0;
  return cultivationRate() * CONFIG.OFFLINE_RATE * (1 + off);
}

// 玩家战斗属性（含炼器坊基础加成 + 法宝百分比加成）
function playerCombat() {
  const a = CONFIG.playerAttr(S.realm, S.layer);
  const forgeBonus = S.buildings.forge * 10;  // 每级炼器坊 +10 攻防
  const b = _ab();
  const sb = storyBonus();   // 剧本「战」之选择（v0.12.0）
  const gf = gongfaBonus();  // 功法（v0.20.0 十阶体系）
  const av = (typeof avatarTint === "function") ? avatarTint() : { atk: 0, def: 0, hp: 0, cult: 0 };
  // 修炼方向（v0.29.0）：体修厚血、剑修高攻、法修脆皮
  const dao = (typeof daoDef === "function") ? daoDef(S.dao) : { atk: 1, def: 1, hp: 1 };
  // 古宝（v0.30.0）
  const anc = (typeof ancientBonus === "function") ? ancientBonus() : { atk: 0, def: 0, hp: 0, cult: 0 };
  // 宗门（v0.31.0）：每级全属性 +1.5%
  const sectA = (S.sect && S.sect.lv ? S.sect.lv * CONFIG.SECT.ATTR : 0)
    + ((S.dynasty && S.dynasty.name) ? CONFIG.DYNASTY.ATTR : 0);
  // 灵兽内丹（v0.35.0）：锐金丹 → 主人攻击 +8%
  const pin = (typeof petInnerBonus === "function") ? petInnerBonus("atk") : 0;
  // 内视（v0.50.0）：经脉主属性 + 周天 + 丹田（唯一来源 meridianSum）
  const mdz = (typeof meridianSum === "function") ? meridianSum() : { atk: 0, def: 0, hp: 0, cult: 0 };
  return {
    attack: (a.attack + forgeBonus) * (1 + b.atk + sb.atk + gf.atk + av.atk + anc.atk + sectA + mdz.atk) * dao.atk * (1 + pin),
    defense: (a.defense + forgeBonus) * (1 + b.def + gf.def + av.def + anc.def + sectA + mdz.def) * dao.def,
    hp: a.hp * (1 + b.hp + gf.hp + av.hp + anc.hp + sectA + mdz.hp) * dao.hp,
  };
}

function playerPower() {
  const p = playerCombat();
  return p.attack * 10 + p.defense * 8 + p.hp * 0.5;
}

// 建筑产出（每秒）：基础产出 × 弟子加成
function buildingOutput(key) {
  const lv = S.buildings[key];
  // 弟子加成：遍历委派到该建筑的弟子
  let discipleMult = 1;
  for (const d of S.disciples) {
    if (d.assignedTo === key) discipleMult += discipleOutputBonus(d);
  }
  switch (key) {
    case "farm":     return 0.5 * lv * discipleMult;   // 灵草/秒
    case "alchemy":  return lv * discipleMult;          // 每 tick 炼丹数量
    case "forge":    return lv;                         // 法宝等级（攻防由 playerCombat 计算）
    case "practice": return lv;                         // 已折算进速率
    case "recruit":  return lv;                         // 弟子槽上限
    default: return 0;
  }
}

// 弟子槽位上限：招募堂等级 + 1
// 弟子名额（v0.54.2）：基础 5（与开局五名弟子对齐）+ 招募堂 + 境界 + 建筑总级/5 + 宗门×2 + 立朝 3
function discipleSlots() {
  const SL = CONFIG.SLOTS;
  let buildSum = 0;
  for (const k in (S.buildings || {})) buildSum += S.buildings[k] || 0;
  const sect = (S.sect && S.sect.lv) ? S.sect.lv * SL.PER_SECT : 0;
  const dyn = (S.dynasty && S.dynasty.name) ? SL.DYNASTY : 0;
  return SL.BASE + (S.buildings.recruit || 0) + (S.realm || 0) * CONFIG.DISCIPLE_SLOT_PER_REALM
    + Math.floor(buildSum / SL.BUILD_DIV) + sect + dyn;
}
