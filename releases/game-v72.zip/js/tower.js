// ============================================================
// 《问长生》无尽试炼塔（v0.8.0）
// 设计要点：
// 1) 绝对难度曲线，不用「玩家战力自适应」——否则玩家越强敌人越强，永远差一层
// 2) 锚点 = 炼气1层裸装战力（≈190），第 1 层 ×0.55，每层 ×1.33
// 3) 失败无惩罚，只消耗体力，鼓励反复试（放置游戏不该惩罚探索）
// ============================================================

// 该层是否为守关妖兽（每 10 层）
function towerIsBoss(floor) {
  return floor % CONFIG.TOWER_BOSS_EVERY === 0;
}

// 该层敌人战力（绝对数值）
function towerFloorPower(floor) {
  return CONFIG.TOWER_ANCHOR * CONFIG.TOWER_BASE * Math.pow(CONFIG.TOWER_GROWTH, floor - 1);
}

// 由战力反推三围：沿用玩家 atk:def:hp = 1 : 0.5 : 10 的比例
// 玩家战力 = atk*10 + def*8 + hp*0.5 = unit*10 + unit*0.5*8 + unit*10*0.5 = 19*unit
function towerEnemy(floor) {
  const pw = towerFloorPower(floor);
  const mult = towerIsBoss(floor) ? 1.25 : 1;   // 守关层额外强化 25%
  const unit = (pw / 19) * mult;
  return { attack: unit, defense: unit * 0.5, hp: unit * 10, power: pw * mult };
}

// 该层奖励
function towerReward(floor) {
  const boss = towerIsBoss(floor);
  const stone = Math.floor(CONFIG.TOWER_STONE_BASE * Math.pow(CONFIG.TOWER_STONE_GROWTH, floor - 1));
  const mat = floor % CONFIG.TOWER_MAT_EVERY === 0 ? Math.ceil(floor / CONFIG.TOWER_MAT_EVERY) : 0;
  const rep = floor % CONFIG.TOWER_REP_EVERY === 0 ? 5 + Math.floor(floor / CONFIG.TOWER_REP_EVERY) * 5 : 0;
  return {
    stone: boss ? stone * 2 : stone,
    mat: mat + (boss ? 3 : 0),
    rep: rep + (boss ? 20 : 0),
    boss,
  };
}

// 下一待挑战层
function towerNextFloor() {
  return (S.towerBest || 0) + 1;
}

// ---------- 塔币与塔阁（v0.9.0） ----------
// 塔币只由通关层数产出，只能换塔阁物品，不流入主线经济，避免"第二套货币"污染主线平衡。
function towerCoinFor(floor) {
  return CONFIG.TOWER_COIN_BASE + Math.floor(floor / 10) * CONFIG.TOWER_COIN_PER_10;
}

function towerShopItem(key) {
  return CONFIG.TOWER_SHOP.find(x => x.key === key) || null;
}

function exchangeTower(key) {
  const item = towerShopItem(key);
  if (!item) return { ok: false, msg: "没有该物品" };
  if ((S.towerCoin || 0) < item.cost) return { ok: false, msg: `塔币不足（需 ${item.cost}，现有 ${S.towerCoin || 0}）` };
  if (item.kind === "artifact") {
    if (typeof makeArtifact !== "function") return { ok: false, msg: "法宝系统未就绪" };
    S.towerCoin -= item.cost;
    const a = makeArtifact(item.tier, item.type);
    a.name = item.name;        // 塔专属命名，与炼制法宝区分
    a.fromTower = true;
    S.artifacts.push(a);
    save();
    return { ok: true, item, artifact: a };
  }
  S.towerCoin -= item.cost;
  if (item.res === "mat") gainItem("material", item.amount);
  else if (item.res === "stone") S.stone = (S.stone || 0) + item.amount;
  save();
  return { ok: true, item };
}

// 挑战下一层
function challengeTower() {
  const floor = towerNextFloor();
  if (S.stamina < 1) return { ok: false, msg: "体力不足，请稍候恢复" };
  S.stamina--;
  const e = towerEnemy(floor);
  const r = simulateBattleWith(e.attack, e.defense, e.hp);
  if (!r.win) {
    save();
    return { ok: true, win: false, floor, rounds: r.rounds, enemyPower: e.power, myPower: playerPower() };
  }
  // ---- 胜利结算 ----
  const rw = towerReward(floor);
  S.stone = (S.stone || 0) + rw.stone;
  if (rw.mat) gainItem("material", rw.mat);
  if (rw.rep) S.reputation = (S.reputation || 0) + rw.rep;
  const coin = towerCoinFor(floor);
  S.towerCoin = (S.towerCoin || 0) + coin;
  S.towerBest = floor;
  if (typeof weeklyProgress === "function") weeklyProgress("tower5", 1);
  if (!S.stats) S.stats = { battleWins: 0, bossWins: 0 };
  S.stats.battleWins = (S.stats.battleWins || 0) + 1;
  let beast = null;
  if (rw.boss) {
    S.stats.bossWins = (S.stats.bossWins || 0) + 1;
    const def = CONFIG.CODEX_BEASTS.find(b => b.tower === floor);
    if (def) {
      beast = def;
      if (typeof recordBeastCodex === "function") recordBeastCodex(def.key);
    }
  }
  save();
  return { ok: true, win: true, floor, rounds: r.rounds, reward: rw, coin, enemyPower: e.power, myPower: playerPower(), beast };
}
