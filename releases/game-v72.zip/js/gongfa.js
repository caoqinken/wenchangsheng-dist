// ============================================================
// 《问长生》功法体系（v0.53.1：六阶目录与旧档迁移）
// 旧 tier 保留为掉落兼容字段；grade/layers/unlockRealm/category 是当前正式目录。
// v0.52.0 起升级消耗悟道，心法/术法/身法/道法四类战斗装备位由 config 显式归类。
// ============================================================

function gongfaBook(key) {
  return CONFIG.GONGFA_BOOKS.find(b => b.key === key) || null;
}

function gongfaTierBooks(tier) {
  // 旧接口保留：tier 参数仍指旧掉落阶位（1~10），避免兼容调用改变语义。
  return CONFIG.GONGFA_BOOKS.filter(b => b.tier === tier);
}

// v0.53.1：正式目录直接读取 grade，不再用旧十阶 tier 做数学映射。
// tier 保留为旧掉落兼容字段；目录阶位以 grade 为唯一真源。
function gongfaGrade(book) {
  if (!book) return 1;
  return Math.max(1, Math.min(6, Number(book.grade) || 1));
}
function gongfaGradeBooks(grade) {
  return CONFIG.GONGFA_BOOKS.filter(b => gongfaGrade(b) === grade);
}
function gongfaGradeName(grade) {
  const g = Math.max(1, Math.min(6, grade | 0));
  const def = CONFIG.GONGFA_GRADES && CONFIG.GONGFA_GRADES[g];
  return `${["", "一阶", "二阶", "三阶", "四阶", "五阶", "六阶"][g]}·${def ? def.name : ""}`;
}

const GONGFA_ATTR_KEYS = ["cult", "atk", "def", "hp", "trib", "crit", "pill", "field", "offline", "lifesteal"];

// 四类战斗功法装备位。旧功法保留原有修炼加成，装备位额外决定战斗构筑。
const GONGFA_V2_CATEGORIES = {
  xin: { name: "心法", desc: "真元上限与回复" },
  shu: { name: "术法", desc: "攻击与运功系数" },
  shen: { name: "身法", desc: "疾速与闪避" },
  dao: { name: "道法", desc: "防御与会心" },
};
const GONGFA_V2_CATEGORY_MAP = Object.fromEntries(
  CONFIG.GONGFA_BOOKS.map(b => [b.key, b.category || "dao"])
);
function gongfaCategory(key) { return GONGFA_V2_CATEGORY_MAP[key] || "dao"; }
function gongfaGradePrerequisite(grade) {
  if (grade <= 1) return true;
  return gongfaGradeBooks(grade - 1).some(b => gongfaMaxed(b.key));
}
function gongfaUnlockReason(book) {
  if (!book) return "无此功法";
  if ((S.realm || 0) < (book.unlockRealm || 0)) return `需${CONFIG.REALMS[book.unlockRealm] || "更高境界"}`;
  const grade = gongfaGrade(book);
  if (!gongfaGradePrerequisite(grade)) return `需先将任意一部${gongfaGradeName(grade - 1)}功法修至圆满`;
  return "已满足解锁条件";
}
function gongfaEquipState() {
  if (!S.gongfaEquip || typeof S.gongfaEquip !== "object") S.gongfaEquip = { xin:"changsheng", shu:null, shen:null, dao:null };
  for (const k of Object.keys(GONGFA_V2_CATEGORIES)) if (S.gongfaEquip[k] === undefined) S.gongfaEquip[k] = null;
  return S.gongfaEquip;
}
function equipGongfaV2(key) {
  const b = gongfaBook(key);
  if (!b) return { ok:false, msg:"无此功法" };
  if (!gongfaLearned(key)) return { ok:false, msg:"尚未领悟，不能装备" };
  const cat = gongfaCategory(key), old = gongfaEquipState()[cat];
  gongfaEquipState()[cat] = key;
  save();
  return { ok:true, category:cat, old, book:b };
}
function gongfaNodeCount(book, lv) {
  return new Set((book && book.nodes || []).filter(n => lv >= n.at).map(n => n.at)).size;
}
function gongfaV2Profile() {
  const eq = gongfaEquipState();
  const out = { mana:0, manaRegen:0, atk:0, yungong:0, speed:0, dodge:0, def:0, hp:0, crit:0, lifesteal:0 };
  for (const cat of Object.keys(GONGFA_V2_CATEGORIES)) {
    const key = eq[cat]; if (!key || !gongfaLearned(key)) continue;
    const book = gongfaBook(key), lv = gongfaLv(key), nodes = gongfaNodeCount(book, lv);
    // 战斗属性直接读取该功法逐层属性与已点亮关窍，避免节点只显示不生效。
    const actual = gongfaLayerBonus(book, lv);
    out.atk += actual.atk || 0;
    out.def += actual.def || 0;
    out.hp += actual.hp || 0;
    out.crit += actual.crit || 0;
    out.lifesteal += actual.lifesteal || 0;
    // 类别专属的战斗成长；具体攻防/气血/会心仍以每部功法自身配置为准。
    if (cat === "xin") { out.mana += lv * 0.04 + nodes * 0.01; out.manaRegen += lv * 0.012 + nodes * 0.003; }
    else if (cat === "shu") out.yungong += lv * 0.008 + nodes * 0.002;
    else if (cat === "shen") { out.speed += lv * 0.02 + nodes * 0.005; out.dodge += lv * 0.006 + nodes * 0.002; }
  }
  for (const k of Object.keys(out)) out[k] = Math.round(out[k] * 10000) / 10000;
  return out;
}

function gongfaState() {
  if (!S.gongfaBooks || typeof S.gongfaBooks !== "object") S.gongfaBooks = {};
  for (const b of CONFIG.GONGFA_BOOKS) {
    const cur = S.gongfaBooks[b.key];
    if (!cur || typeof cur !== "object") {
      S.gongfaBooks[b.key] = { lv: 0, learned: b.key === "changsheng" };
      continue;
    }
    if (typeof cur.lv !== "number" || !isFinite(cur.lv)) cur.lv = 0;
    if (cur.lv < 0) cur.lv = 0;
    if (cur.lv > b.layers) cur.lv = b.layers;
    if (typeof cur.learned !== "boolean") cur.learned = cur.lv > 0 || b.key === "changsheng";
  }
  return S.gongfaBooks;
}

function gongfaLv(key) {
  const st = gongfaState();
  return st[key] ? st[key].lv : 0;
}

function gongfaLearned(key) {
  const st = gongfaState();
  return !!(st[key] && st[key].learned);
}

function gongfaUnlocked(book) {
  if (!book || (S.realm || 0) < (book.unlockRealm || 0)) return false;
  return gongfaGradePrerequisite(gongfaGrade(book));
}

function gongfaMaxed(key) {
  const b = gongfaBook(key);
  return !!b && gongfaLv(key) >= b.layers;
}

// ---------- 领悟 ----------
function gongfaLearnReq(key) {
  const b = gongfaBook(key);
  if (!b) return { ok: false, msg: "无此功法" };
  if (gongfaLearned(key)) return { ok: false, msg: "已领悟" };
  if ((S.realm || 0) < (b.unlockRealm || 0)) {
    return { ok: false, msg: `需${CONFIG.REALMS[b.unlockRealm] || "更高境界"}方可领悟` };
  }
  if (!gongfaGradePrerequisite(gongfaGrade(b))) {
    return { ok: false, msg: `需先将任意一部${gongfaGradeName(gongfaGrade(b) - 1)}功法修至圆满` };
  }
  const need = b.cost || 1;
  // v0.38.0：秘籍物品化——领悟需持有对应秘籍（高阶功法分上下卷，需 2 本同名）
  const have = (typeof invCount === "function") ? Math.floor(invCount("book:" + key)) : 0;
  if (have < need) {
    return { ok: false, msg: `缺少《${b.name}》秘籍（需 ${need} 本，持有 ${have}）· 秘境 BOSS 可得，或花灵石寻访` };
  }
  return { ok: true, need, have };
}

function learnGongfa(key) {
  const r = gongfaLearnReq(key);
  if (!r.ok) return r;
  invRemove("book:" + key, r.need);
  gongfaState()[key].learned = true;
  save();
  return { ok: true, book: gongfaBook(key) };
}

// ---------- 秘籍获取（v0.38.0）----------
// 残卷参悟：3 卷换 1 本随机未习秘籍（受境界解锁限制）
function refineTalisman() {
  const need = CONFIG.PILLS.REFINE_TALISMAN;
  if ((S.talisman || 0) < need) return { ok: false, msg: `残卷不足（需 ${need} 卷，持有 ${Math.floor(S.talisman || 0)}）` };
  const pool = CONFIG.GONGFA_BOOKS.filter(b => !gongfaLearned(b.key) && gongfaUnlocked(b));
  if (!pool.length) return { ok: false, msg: "已无可参悟的秘籍（或境界不足），残卷可留待日后" };
  invRemove("talisman", need);
  const b = pool[Math.floor(Math.random() * pool.length)];
  gainItem("book:" + b.key, 1);
  save();
  return { ok: true, book: b };
}

// 寻访秘籍：花灵石购得一本随机未习秘籍（价格随境界上涨）
function searchGongfaBook() {
  const pool = CONFIG.GONGFA_BOOKS.filter(b => !gongfaLearned(b.key) && gongfaUnlocked(b));
  if (!pool.length) return { ok: false, msg: "已学尽可学的秘籍，待境界提升后再寻" };
  const price = Math.floor(CONFIG.TALISMAN_PRICE * 6 * (1 + (S.realm || 0) * 0.5));
  if ((S.stone || 0) < price) return { ok: false, msg: `灵石不足（寻访需 ${fmt(price)}）` };
  const b = pool[Math.floor(Math.random() * pool.length)];
  const room = (typeof invRoomCheck === "function") ? invRoomCheck("book:" + b.key, 1) : { ok: true };
  if (!room.ok) return room;
  S.stone -= price;
  gainItem("book:" + b.key, 1);
  save();
  return { ok: true, book: b, price };
}

// 某部功法的秘籍持有数（UI 用）
function bookHeldCount(key) {
  return (typeof invCount === "function") ? Math.floor(invCount("book:" + key)) : 0;
}

// ---------- 修炼 ----------
function gongfaCost(book, targetLv) {
  const n = Math.max(1, targetLv || (gongfaLv(book.key) + 1));
  const grade = gongfaGrade(book);
  return { wudao: Math.floor(CONFIG.GONGFA_WUDAO_COST * n * (1 + (grade - 1) * 0.25)) };
}

function upgradeGongfa(key) {
  const b = gongfaBook(key);
  if (!b) return { ok: false, msg: "无此功法" };
  if (!gongfaLearned(key)) return { ok: false, msg: "尚未领悟此功法" };
  gongfaState();
  const lv = S.gongfaBooks[key].lv;
  if (lv >= b.layers) return { ok: false, msg: "此功法已圆满" };
  const cost = gongfaCost(b, lv + 1);
  // 悟道丹：悟道消耗 -30%（1 次）；功法升级不再挤占突破灵气与灵石。
  const useCut = (S.gongfaCut || 0) > 0;
  const wudaoNeed = useCut ? Math.floor(cost.wudao * (1 - (CONFIG.PILLS.DAO_WUDAO_CUT || CONFIG.PILLS.DAO_STONE_CUT))) : cost.wudao;
  if ((S.wudao || 0) < wudaoNeed) return { ok: false, msg: `悟道不足（需 ${fmt(wudaoNeed)}，当前 ${fmt(S.wudao || 0)}）` };
  if (useCut) S.gongfaCut -= 1;
  cost.wudao = wudaoNeed;
  S.wudao -= wudaoNeed;
  S.gongfaBooks[key].lv++;
  save();
  const newLv = S.gongfaBooks[key].lv;
  const full = newLv >= b.layers;
  const node = b.nodes.find(n => n.at === newLv);
  return { ok: true, book: b, lv: newLv, full, node: node || null, cost };
}

// ---------- 收益计算 ----------
function gongfaLayerBonus(book, lv) {
  const out = {};
  for (const k of GONGFA_ATTR_KEYS) out[k] = 0;
  if (!lv || !book) return out;
  // 新旧层数按进度比例迁移；用旧/新层数比例缩放每层底值，保持圆满时的原有总基础收益。
  const statScale = (book.legacyLayers && book.layers) ? book.legacyLayers / book.layers : 1;
  for (const k in book.stats) {
    if (out[k] === undefined) continue;
    out[k] += book.stats[k] * lv * statScale;
  }
  for (const n of (book.nodes || [])) {
    if (lv >= n.at && out[n.key] !== undefined) out[n.key] += n.value;
  }
  if (lv >= book.layers) {
    for (const k in out) out[k] *= CONFIG.GONGFA_FULL_MULT;
  }
  for (const k in out) out[k] = Math.round(out[k] * 10000) / 10000;
  return out;
}

function gongfaBonus() {
  const total = {};
  for (const k of GONGFA_ATTR_KEYS) total[k] = 0;
  const st = gongfaState();
  for (const b of CONFIG.GONGFA_BOOKS) {
    const one = gongfaLayerBonus(b, st[b.key].lv);
    for (const k of GONGFA_ATTR_KEYS) total[k] += one[k];
  }
  for (const k of GONGFA_ATTR_KEYS) total[k] = Math.round(total[k] * 10000) / 10000;
  return total;
}

// ---------- 展示 ----------
function gongfaPips(lv, max) {
  let out = "";
  for (let i = 0; i < max; i++) out += i < lv ? "●" : "○";
  return out;
}

const GONGFA_ATTR_ICON = {
  cult: "assets/属性_洞府灵气.webp", atk: "assets/属性_攻伐.webp",
  def: "assets/属性_护体.webp", hp: "assets/属性_气血.webp",
  trib: "assets/属性_渡劫.webp", crit: "assets/属性_会心.webp",
  pill: "assets/属性_丹效.webp", field: "assets/属性_秘境收获.webp",
  offline: "assets/属性_闭关收益.webp", lifesteal: "assets/属性_噬血.webp",
};

function attrIcon(key, cls) {
  const src = GONGFA_ATTR_ICON[key];
  if (!src) return "";
  return `<img class="attr-ico ${cls || ""}" src="${src}" alt="">`;
}

const GONGFA_ATTR_NAME = {
  cult: "洞府灵气", atk: "攻伐", def: "护体", hp: "气血", trib: "渡劫",
  crit: "会心", pill: "丹效", field: "秘境收获", offline: "闭关收益", lifesteal: "噬血",
};

function gongfaBonusText(book, lv) {
  const b = gongfaLayerBonus(book, lv);
  const parts = [];
  for (const k of GONGFA_ATTR_KEYS) {
    if (b[k]) parts.push(`${GONGFA_ATTR_NAME[k]} +${(b[k] * 100).toFixed(1)}%`);
  }
  return parts.length ? parts.join(" ｜ ") : "尚未参悟";
}

// 已圆满的功法数（成就/统计用）
function gongfaFullCount() {
  const st = gongfaState();
  return CONFIG.GONGFA_BOOKS.filter(b => st[b.key].lv >= b.layers).length;
}
