// ============================================================
// 秘境章节触发逻辑专项测试（v0.24.0）
// 覆盖：章节解锁边界 / 入口校验 / 结算幂等 / 图鉴收录触发 / 派遣联动
// 运行：node test_field_trigger.js
// ============================================================
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const store = {};
global.localStorage = {
  getItem: k => (k in store ? store[k] : null),
  setItem: (k, v) => { store[k] = String(v); },
  removeItem: k => { delete store[k]; },
};
global.window = { addEventListener() {}, removeEventListener() {}, devicePixelRatio: 1 };
global.confirm = () => true;
global.location = { reload() {} };
global.Image = function () { this.onload = null; this.src = ""; };
global.performance = { now: () => Date.now() };
let _raf = 1;
global.requestAnimationFrame = (fn) => ++_raf;
global.cancelAnimationFrame = () => {};

// 固定随机数（可复现）
let _seed = 20261116;
Math.random = () => { _seed = (_seed * 1103515245 + 12345) % 2147483648; return _seed / 2147483648; };

function load(f) {
  vm.runInThisContext(fs.readFileSync(path.join(__dirname, f), "utf8"), { filename: f });
}
load("js/config.js");
load("js/state.js");
load("js/inventory.js");
load("js/gongfa.js");
load("js/avatar.js");
load("js/pet.js");
load("js/artifact.js");
load("js/idle.js");
load("js/combat.js");
load("js/tower.js");
load("js/build.js");
load("js/time.js");
load("js/faction.js");
load("js/event.js");
load("js/npc.js");
load("js/economy.js");
load("js/codex.js");
load("js/field.js");
load("js/dispatch.js");
load("js/field_view.js");
load("js/meridians.js");
load("js/ui.js");
load("js/field_ui.js");

// 万能 DOM stub：创建的元素带 innerHTML / querySelector / addEventListener / classList
function mkEl() {
  const el = {
    children: [],
    style: {},
    dataset: {},
    classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
    set innerHTML(v) { this._html = String(v); },
    get innerHTML() { return this._html || ""; },
    querySelector: () => mkEl(),
    querySelectorAll: () => [],
    addEventListener() {},
    removeEventListener() {},
    appendChild(c) { this.children.push(c); return c; },
    removeChild() {},
    getBoundingClientRect: () => ({ width: 400, height: 300, left: 0, top: 0 }),
    getContext: null,
    parentNode: { removeChild() {} },
    width: 400, height: 300, clientWidth: 400, clientHeight: 300,
  };
  el.querySelector = (sel) => {
    if (sel === "#fs-canvas") return mkCanvasEl();
    return mkEl();
  };
  return el;
}
function mkCanvasEl() {
  const el = mkEl();
  const calls = [];
  const ctx = new Proxy({}, {
    get(t, k) {
      if (k === "canvas") return el;
      return (...args) => {
        calls.push([k].concat(args));
        if (k === "createRadialGradient" || k === "createLinearGradient") return { addColorStop() {} };
        if (k === "measureText") return { width: 10 };
        return undefined;
      };
    },
    set(t, k, v) { calls.push(["#" + k, v]); return true; },
  });
  el.getContext = () => ctx;
  el._calls = calls;
  return el;
}
global.document = {
  hidden: false,
  body: { appendChild() {}, removeChild() {} },
  createElement: () => mkEl(),
  querySelectorAll: () => [],
  querySelector: () => null,
  getElementById: () => mkEl(),
  addEventListener() {},
  removeEventListener() {},
};

// toast 捕获
let toastMsg = "";
const _origToast = (typeof toast === "function") ? toast : null;
toast = function (msg) { toastMsg = msg; };

// ---------- 断言工具 ----------
let pass = 0, fail = 0;
function eq(actual, expect, name) {
  if (JSON.stringify(actual) === JSON.stringify(expect)) { pass++; console.log("  [PASS] " + name); }
  else { fail++; console.log(`  [FAIL] ${name}  期望=${JSON.stringify(expect)} 实际=${JSON.stringify(actual)}`); }
}
function ok(cond, name) { eq(!!cond, true, name); }
function section(t) { console.log("\n--- " + t + " ---"); }

function freshState() {
  // 重置存档到全新状态（v0.25.0：存档按道号分档，测试统一用固定道号）
  localStorage.removeItem("wendao_save");
  S = defaultState();
  S.playerName = "测试者";
  S.stamina = 20;
  save();
  toastMsg = "";
}

// ============================================================
section("A. 章节解锁边界（fldChapterUnlocked 单一来源）");
freshState();
eq(S.bestStage, 0, "初始 bestStage=0");
ok(fldChapterUnlocked(0), "ch0 初始可进");
eq(fldChapterUnlocked(1), false, "ch1 初始锁定");
eq(fldChapterUnlocked(2), false, "ch2 初始锁定");
S.bestStage = 5;   // 通关 n=4（第 0 章第 5 小关），尚未过末 BOSS
eq(fldChapterUnlocked(1), false, "bestStage=5（未过 ch0 末关）→ ch1 仍锁");
S.bestStage = 6;   // 通关 n=5（第 0 章末 BOSS）
ok(fldChapterUnlocked(1), "bestStage=6（过 ch0 末关）→ ch1 解锁");
eq(fldChapterUnlocked(2), false, "ch2 仍锁");
S.bestStage = 12;
ok(fldChapterUnlocked(2), "bestStage=12 → ch2 解锁");
S.bestStage = 41;
ok(fldChapterUnlocked(6), "bestStage=41 → ch6 解锁");
// 边界函数正确性
eq(CONFIG.isBoss(5), true, "isBoss(5)=true（第 0 章末关）");
eq(CONFIG.isBoss(6), false, "isBoss(6)=false");
eq(CONFIG.chapterOf(5), 0, "chapterOf(5)=0");
eq(CONFIG.chapterOf(6), 1, "chapterOf(6)=1");

// ============================================================
section("B. startFieldBattle 入口校验");
freshState();
const staminaBefore = S.stamina;
startFieldBattle(1);   // ch1 未解锁
eq(S.stamina, staminaBefore, "未解锁章节：体力不扣");
eq(toastMsg.indexOf("尚未解锁") >= 0, true, "未解锁章节：toast 提示");
eq(FS.field, null, "未解锁章节：不创建战场");

startFieldBattle(0);   // ch0 已解锁但体力 0
S.stamina = 0;
startFieldBattle(0);
eq(toastMsg.indexOf("体力不足") >= 0, true, "体力 0：拒绝进入");
eq(FS.field, null, "体力 0：不创建战场");

S.stamina = 20;
startFieldBattle(0);
eq(S.stamina, 19, "正常进入：扣 1 体力");
ok(FS.field != null, "正常进入：战场已创建");
eq(FS.field.chapter, 0, "战场章节 = 0");
fsClose(false);

// 未解锁章在解锁后可进（因果闭环）
S.bestStage = 6;
S.stamina = 20;
startFieldBattle(1);
eq(FS.field.chapter, 1, "bestStage=6 后 ch1 可正常进入");
fsClose(false);

// ============================================================
section("C. 结算幂等 + 探明标记（走 fsFinish 真实路径）");
freshState();
// mock setTimeout 立即执行（fsFinish 用 600ms 延迟关屏+结算）
const _origSetTimeout = setTimeout;
setTimeout = (fn, ms) => { fn(); return 0; };
S.bestStage = 0;
// 模拟通关第 0 章末关战场：创建战场 → 判胜 → fsFinish（内部含 settleStageWin + clearedMaps）
startFieldBattle(0);
FS.field.win = true;
fsFinish();
eq(S.bestStage, 6, "首通 ch0 末关 → bestStage=6");
eq(S.stats.bossWins, 1, "BOSS 战绩 +1");
eq(S.codex.beasts.wolf != null, true, "首通收录妖兽 wolf");
eq(S.codex.regions.region_ch0 != null, true, "首通收录秘境 region_ch0");
eq(S.clearedMaps && S.clearedMaps[0], true, "fsFinish → clearedMaps[0] 标记探明");
const wolfDay1 = S.codex.beasts.wolf;
const bossWins1 = S.stats.bossWins;
const stone1 = S.stone;

// 重复通关同一章末关（再次完整走战场流程）
S.stamina = 20;
startFieldBattle(0);
FS.field.win = true;
fsFinish();
eq(S.bestStage, 6, "重复通关：bestStage 不回退不重复+1");
eq(S.codex.beasts.wolf, wolfDay1, "重复通关：妖兽图鉴首录日不覆盖");
eq(S.clearedMaps[0], true, "重复通关：探明标记保持");
eq(S.stats.bossWins, bossWins1 + 1, "重复通关：BOSS 战绩正常累计（预期行为）");
ok(S.stone > stone1, "重复通关：仍有灵石收益（刷关收益预期行为）");

// ============================================================
section("D. 图鉴收录触发正确性");
freshState();
settleStageWin(3);   // 第 0 章非末关
eq((S.codex.beasts && Object.keys(S.codex.beasts).length) || 0, 0, "非末关通关：不收录妖兽图鉴");
eq((S.codex.regions && Object.keys(S.codex.regions).length) || 0, 0, "非末关通关：不收录秘境图鉴");
eq(CONFIG.isBoss(3), false, "n=3 非末关");

settleStageWin(11);  // 第 1 章末关
eq(S.codex.beasts.spider != null, true, "过 ch1 末关收录 spider");
eq(S.codex.regions.region_ch1 != null, true, "过 ch1 末关收录 region_ch1");
eq(S.codex.beasts.wolf == null, true, "未过 ch0 末关：wolf 未收录（跳关场景）");

// ============================================================
section("E. 派遣联动");
freshState();
// 造一名测试弟子（初始宗门无弟子）
S.disciples.push({ id: 1, name: "测试弟子", aptitude: 3, realm: 2, loyalty: 80, mood: 70, specialty: "farming", assignedTo: null });
eq(assignDispatch(0, 1).ok, false, "未探明秘境：派遣拒绝");
eq(assignDispatch(0, 1).msg.indexOf("尚未探明") >= 0, true, "拒绝原因正确");
// 探明后可派遣（走 fsFinish 真实路径）
startFieldBattle(0);
FS.field.win = true;
fsFinish();
eq(assignDispatch(0, 1).ok, true, "已探明秘境：派遣成功");
eq((S.mapTeam[0] || []).indexOf(1) >= 0, true, "弟子进入派遣队伍");
eq(assignDispatch(0, 1).ok, false, "重复派遣同一弟子：拒绝");

// ============================================================
section("F. 存档完整性");
freshState();
S.bestStage = 6;
S.clearedMaps[0] = true;
S.codex = { beasts: { wolf: 3 }, regions: { region_ch0: 3 } };
save();
const raw = JSON.parse(localStorage.getItem(CONFIG.SAVE_KEY_PREFIX + encodeURIComponent("测试者")));
eq(raw.bestStage, 6, "bestStage 持久化");
eq(raw.clearedMaps[0], true, "clearedMaps 持久化");
eq(raw.codex.beasts.wolf, 3, "图鉴收录持久化");

// ============================================================
console.log(`\n===== 结果：${pass} 通过，${fail} 失败 =====`);
process.exit(fail > 0 ? 1 : 0);
