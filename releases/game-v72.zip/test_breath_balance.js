const fs=require('fs'),path=require('path'),vm=require('vm');
const store={}; global.localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=String(v),removeItem:k=>delete store[k]};
global.window={addEventListener:()=>{},removeEventListener:()=>{}}; global.document={hidden:false}; global.confirm=()=>true; global.location={reload:()=>{}};
// 固定随机种子，确保敌人生成、会心与掉落模拟可复现。
let _seed=20261116; Math.random=()=>{_seed=(_seed*1664525+1013904223)>>>0;return _seed/4294967296;};
function load(f){vm.runInThisContext(fs.readFileSync(path.join(__dirname,f),'utf8'),{filename:f});}
[
'js/config.js','js/state.js','js/inventory.js','js/gongfa.js','js/avatar.js','js/pet.js','js/artifact.js','js/idle.js','js/combat.js','js/tower.js','js/build.js','js/dan.js','js/guide.js','js/time.js','js/faction.js','js/event.js','js/npc.js','js/economy.js','js/codex.js','js/field.js','js/dispatch.js','js/dao.js','js/tuna.js','js/daily.js','js/specialty.js','js/ancient.js','js/meridians.js','js/realm.js','js/recruit.js','js/staff.js','js/sect.js','js/element.js','js/life.js','js/field_view.js','js/field_ui.js','js/breath.js'
].forEach(load);
// stop delayed UI settlement in this deterministic harness
setTimeout=()=>0;
function sim(ch,realm,layer,runs){let rows=[];for(let n=0;n<runs;n++){
 S=defaultState(); S.realm=realm; S.layer=layer; S.bestStage=ch*6; S.stamina=30; S.playerName='sim';
 const f=fldCreate(ch); breathNormalizeEnemies(f); BREATH.field=f; BREATH.profile=gongfaV2Profile(); BREATH.active=true; BREATH.playerGas=0; BREATH.enemyGas=0; BREATH.enemyIndex=0; BREATH.slotCursor=0; BREATH.cooldowns={}; BREATH.tick=0; BREATH.resultShown=false;
 f.monsters.sort((a,b)=>({normal:0,elite:1,wild:2,boss:3}[a.kind]??0)-({normal:0,elite:1,wild:2,boss:3}[b.kind]??0));
 let ticks=0; while(BREATH.active && ticks<900){breathTick();ticks++;}
 rows.push({win:!!f.win,ticks,hp:Math.max(0,f.player.hp),hpPct:Math.max(0,f.player.hp/f.player.hpMax),monsters:f.monsters.length});
 }
 const wins=rows.filter(x=>x.win).length; const avg=rows.reduce((a,x)=>a+x.ticks,0)/rows.length; const hp=rows.filter(x=>x.win).reduce((a,x)=>a+x.hpPct,0)/Math.max(1,wins);
 return {chapter:ch,realm,wins,runs,avgTicks:+avg.toFixed(1),avgHpPct:+(hp*100).toFixed(1),rows};}
const results=[sim(0,0,0,20),sim(1,1,0,20),sim(2,2,0,20),sim(3,3,0,20),sim(4,4,0,20),sim(5,5,0,20),sim(6,6,0,20)];
let failed=false;
for(const r of results){
 const winRate=r.wins/r.runs;
 console.log(`[${winRate>=0.9?'PASS':'FAIL'}] 第${r.chapter+1}章（境界${r.realm}）胜率 ${r.wins}/${r.runs}，平均 ${r.avgTicks.toFixed(1)} 息，胜场剩余气血 ${r.avgHpPct.toFixed(1)}%`);
 if(winRate<0.9 || r.avgTicks>120) failed=true;
}
console.log(`数值抽样：${results.length*20} 场，${failed?'未通过':'全部通过'}`);
if(failed)process.exit(1);
