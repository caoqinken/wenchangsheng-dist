// 资源净流量公式专项测试（v0.54.3）
const fs=require('fs'), path=require('path'), vm=require('vm');
const store={}; global.localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=String(v),removeItem:k=>delete store[k]};
global.window={addEventListener:()=>{}}; global.document={hidden:false}; global.confirm=()=>true;
function load(f){vm.runInThisContext(fs.readFileSync(path.join(__dirname,f),'utf8'),{filename:f});}
let pass=0,fail=0; function a(n,v){if(v){pass++;console.log('[PASS] '+n);}else{fail++;console.log('[FAIL] '+n);}}
load('js/config.js');load('js/state.js');load('js/inventory.js');load('js/npc.js');load('js/dispatch.js');load('js/build.js');
global.blessed=()=>false;global.stableMult=()=>1;global.officeBonus=()=>0;global.dynastyFolkMult=()=>1;global.fieldTempleLv=()=>0;global.fieldMineLv=()=>0;global.fieldGardenLv=()=>0;
S=defaultState();
S.disciples=[{id:1,realm:0,loyalty:80,specialty:'farm',bond:90},{id:2,realm:0,loyalty:80,specialty:'farm',bond:90},{id:3,realm:0,loyalty:80,specialty:'farm',bond:90}];
S.mapTeam={0:[1]};S.clearedMaps={0:true};
const one=dispatchRate(0);S.mapTeam={0:[1,2,3]};const three=dispatchRate(0);
a('驻守资源产出随弟子人数线性增加',Math.abs(three.stone/one.stone-3)<1e-9&&Math.abs(three.herb/one.herb-3)<1e-9);
a('派遣产出包含灵石、灵气、灵草、灵材与凡人',one.stone>0&&one.qi>0&&one.herb>0&&one.material>0&&one.folk>0);
S.disciples=[];S.buildings={farm:1,alchemy:1,forge:0,practice:0,recruit:0};
const farm=buildingOutput('farm'), alch=buildingOutput('alchemy');
a('灵田Lv1每秒产0.5灵草',farm===0.5);
a('炼丹房Lv1每秒最多消耗2灵草并产1培元丹',2*S.buildings.alchemy===2&&alch===1);
S.buildings.farm=4;
a('灵田Lv4理论产草恰好覆盖炼丹房Lv1消耗',buildingOutput('farm')===2&&buildingOutput('farm')===2*S.buildings.alchemy);
S.buildings={farm:1,alchemy:1,forge:0,practice:0,recruit:0};
let flow=herbFlowSnapshot();
a('净流量诊断与经营tick同源：Lv1/Lv1每秒净缺1.5灵草',flow.farmIn===0.5&&flow.consume===2&&flow.net===-1.5);
S.buildings.farm=4; flow=herbFlowSnapshot();
a('灵田Lv4/Lv1基础配置净流量为0',flow.net===0);
S.disciples=[{id:9,assignedTo:'farm',aptitude:3,realm:0,loyalty:80,bond:0,specialty:'farm'}];
flow=herbFlowSnapshot();
a('灵田弟子委派加成进入净流量计算',flow.farmIn>2&&flow.net>0);
S.disciples=[]; S.buildings={farm:1,alchemy:2,forge:0,practice:0,recruit:0}; S.herbs=90; flow=herbFlowSnapshot();
a('灵草库存可覆盖时间按当前净消耗计算',Math.abs(flow.net+3.5)<1e-9&&Math.abs(flow.coverageSec-90/3.5)<1e-9);
console.log(`结果：${pass} 通过，${fail} 失败`);if(fail)process.exit(1);
