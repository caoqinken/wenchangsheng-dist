// v0.54.6：三类经营路线情景模拟。只读调用现有产出/成本函数，不修改游戏存档或平衡参数。
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=__dirname,store={};
global.localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=String(v),removeItem:k=>delete store[k]};
global.window={addEventListener:()=>{}};global.document={hidden:false};global.confirm=()=>true;
function load(f){vm.runInThisContext(fs.readFileSync(path.join(root,f),'utf8'),{filename:f});}
['js/config.js','js/state.js','js/inventory.js','js/npc.js','js/dispatch.js','js/build.js','js/realm.js','js/artifact.js','js/gongfa.js'].forEach(load);
global.stableMult=()=>1;global.officeBonus=()=>0;global.dynastyFolkMult=()=>1;global.fieldTempleLv=()=>0;global.fieldMineLv=ch=>(S.fieldMine&&S.fieldMine[ch])||0;global.fieldGardenLv=ch=>(S.fieldGarden&&S.fieldGarden[ch])||0;global.blessed=()=>false;
const H=3600, realms=CONFIG.REALMS, fmt=n=>Number(n).toFixed(1);
const scenarios=[
 {id:'idle',name:'挂机型',hours:72,desc:'每境界驻守72小时；不主动升级建筑/秘境、不招募、不炼器。'},
 {id:'normal',name:'常规经营型',hours:48,desc:'每境界驻守48小时；每阶段尝试升级矿场与药圃各1级，隔阶段招募1名弟子，每阶段炼制1件递进品阶法宝。'},
 {id:'deep',name:'深度经营型',hours:36,desc:'每境界驻守36小时；每阶段尝试灵脉/矿场/药圃各升1级、招募1名弟子、炼制2件递进品阶法宝，并刻印1条对应品阶器纹。'}
];
function simulate(sc){
 S=defaultState();S.disciples=Array.from({length:5},(_,i)=>({id:i+1,realm:0,layer:0,loyalty:80,specialty:'farm',bond:90}));
 S.mapTeam={};S.clearedMaps={};S.fieldVein={};S.fieldMine={};S.fieldGarden={};S.lostFields={};
 let ledger={stone:Number(S.stone)||0,qi:0,herb:Number(S.herbs)||0,material:0,folk:Number(S.folk)||0},spent={stone:0,material:0,folk:0},unmet=0;const out=[];
 for(let ri=0;ri<realms.length;ri++){
  const ch=Math.min(ri,CONFIG.CHAPTERS.length-1);S.realm=ri;
  S.disciples.slice(0,3).forEach(d=>d.realm=ri);S.mapTeam[ch]=[1,2,3];S.clearedMaps[ch]=true;
  const tier=Math.min(6,Math.max(1,Math.ceil((ri+1)/2)));
  const canPay=(key,n)=>ledger[key]+1e-9>=n;const pay=(key,n)=>{if(!canPay(key,n)){unmet++;return false;}ledger[key]-=n;spent[key]+=n;return true;};
  const upgrade=(kind)=>{
   const lv=(S[kind]&&S[kind][ch])||0;if(lv>=CONFIG.FIELD_VEIN.MAX)return;
   const cost=kind==='fieldVein'?fieldVeinCost(ch):fieldBuildCost(lv);
   const labor=(lv+1)*CONFIG.LABOR.PER_BUILD_LEVEL;
   if(!canPay('stone',cost)||!canPay('folk',labor)){unmet++;return;}
   pay('stone',cost);pay('folk',labor);S[kind][ch]=lv+1;
  };
  if(sc.id==='normal'){
   upgrade('fieldMine');upgrade('fieldGarden');
   if(ri%2===1){const cs=CONFIG.recruitCost(S.disciples.length),cf=CONFIG.DISCIPLE_FOLK_COST;if(canPay('stone',cs)&&canPay('folk',cf)){pay('stone',cs);pay('folk',cf);S.disciples.push({id:S.disciples.length+1,realm:ri,loyalty:80,specialty:'farm',bond:90});}else unmet++;}
   const c=forgeCost(tier);pay('stone',c.stone);pay('material',c.material);
  } else if(sc.id==='deep'){
   upgrade('fieldVein');upgrade('fieldMine');upgrade('fieldGarden');
   {const cs=CONFIG.recruitCost(S.disciples.length),cf=CONFIG.DISCIPLE_FOLK_COST;if(canPay('stone',cs)&&canPay('folk',cf)){pay('stone',cs);pay('folk',cf);S.disciples.push({id:S.disciples.length+1,realm:ri,loyalty:80,specialty:'farm',bond:90});}else unmet++;}
   const c=forgeCost(tier);for(let j=0;j<2;j++){pay('stone',c.stone);pay('material',c.material);}
   const ec=engraveCost({tier});pay('stone',ec.stone);pay('material',ec.mat);
  }
  const r=dispatchRate(ch),hours=sc.hours;
  for(const k of ['stone','qi','herb','material','folk'])ledger[k]+=r[k]*H*hours;
  out.push({realm:realms[ri],hours,stone:ledger.stone,material:ledger.material,herb:ledger.herb,folk:ledger.folk,spentStone:spent.stone,spentMaterial:spent.material,unmet});
 }
 return {out,spent,unmet,totalHours:sc.hours*realms.length,desc:sc.desc};
}
const results=scenarios.map(s=>({scenario:s,result:simulate(s)}));
const lines=['# v0.54.6 P1：三类经营路线情景模拟','','## 模拟边界','','- 这是可复现的情景模型，不是玩家行为统计；没有真实遥测数据，路线行为频次均为显式假设。','- 产出复用当前 `dispatchRate()`；建设/炼器/器纹/招募成本复用当前项目配置与函数。','- 每个境界使用3名同境界驻守弟子（忠诚80、灵植专精、情谊90）；同一章节映射规则与v0.54.5一致。','- 初始灵石沿用 `defaultState()` 的50枚，其他本模型资源按默认状态计；资源跨境界累计。只计入本模型明确列出的动作，不包含灵田炼丹tick、坊市交易、宗门/王朝收益、功法/经脉消耗、随机炼器返还/失败回收、离线封顶与资源背包上限。','- 建设升级只有在模型资源余额足够时才执行；不足时记录未满足次数。未满足次数不代表游戏内真实失败率。','- 同一章节在高境界映射到第7章，秘境建设等级沿用该章节；因此高境界阶段会继承同一块领地的设施等级。','','## 三条路线设定',''];
for(const {scenario:s,result:r} of results){lines.push(`### ${s.name}`,'',`- ${s.desc}`,`- 模拟总时长：${r.totalHours} 小时（${realms.length}个境界阶段）`,`- 未满足资源动作数：${r.unmet}`,`- 累计支出：灵石 ${fmt(r.spent.stone)}；灵材 ${fmt(r.spent.material)}；凡人 ${fmt(r.spent.folk)}`,'','| 境界阶段 | 累计灵石 | 累计灵材 | 累计灵草 | 累计凡人 | 累计灵石支出 | 累计灵材支出 | 未满足动作 |','|---|---:|---:|---:|---:|---:|---:|---:|');for(const x of r.out)lines.push(`| ${x.realm} | ${fmt(x.stone)} | ${fmt(x.material)} | ${fmt(x.herb)} | ${fmt(x.folk)} | ${fmt(x.spentStone)} | ${fmt(x.spentMaterial)} | ${x.unmet} |`);lines.push('');}
lines.push('## 结果解读','','1. 挂机路线提供资源累积基线，但没有主动经营消耗；不能将其理解为最优玩法。','2. 常规/深度路线的未满足动作会暴露资源瓶颈，但由于路线行为是人为设定，不应把次数直接当作真实玩家体验。','3. 若某路线在前期无法支付高阶炼器成本，首先应检查法宝品阶解锁条件、材料获取渠道和炼器失败返还规则，而不是直接提高所有驻守产出。','4. 本轮不修改任何游戏倍率、成本、存档字段或玩法规则；下一步应从真实玩家存档/匿名行为统计校准每阶段时长与动作频次。','','## 复现','','```bash','node audit_economy_routes.js','```','','## 验证','','- 16个 `test_*.js` 测试脚本全部退出码为0；自动化断言合计 **1642通过、0失败**（核心逻辑1104、UI冒烟316、UI去重53及其他专项169）。','- 固定种子战斗抽样 **140/140场通过**；项目内64个JavaScript文件全部通过 `node --check`。','- `test_economy_routes.js` 新增专项6项，全部通过；ZIP完整性检查通过。','- P0的10000场Monte Carlo/DPS、手动操作增益、手动/速战胜率差与飞升周期门禁仍按此前决定暂缓，未计入通过。','- 本报告由脚本直接生成，路线参数集中在 `scenarios` 数组，可复现、可调整。','');
const report=path.join(root,'..','docs','v0.54.6_P1_三类经营路线情景模拟.md');fs.writeFileSync(report,lines.join('\n'));console.log(lines.join('\n'));
