// P1 成长信息反馈回归：在线/离线修炼、驻守折算与练功房边际收益提示。
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const store = {};
global.localStorage = { getItem:k => (k in store ? store[k] : null), setItem:(k,v) => { store[k] = String(v); }, removeItem:k => { delete store[k]; } };
const els = {};
const stubEl = () => ({ textContent:"", innerHTML:"", style:{}, classList:{ add(){}, remove(){}, toggle(){} }, dataset:{} });
global.window = { addEventListener:() => {} };
global.document = { hidden:false, getElementById:id => (els[id] = els[id] || stubEl()), querySelectorAll:() => [], body:{ addEventListener:() => {} } };
global.confirm = () => true;
global.location = { reload:() => {} };
function load(f) { vm.runInThisContext(fs.readFileSync(path.join(__dirname, f), "utf8"), { filename:f }); }
const files = ["js/config.js", "js/state.js", "js/artifact.js", "js/idle.js", "js/combat.js", "js/tower.js", "js/build.js", "js/dan.js", "js/guide.js", "js/time.js", "js/faction.js", "js/event.js", "js/npc.js", "js/economy.js", "js/codex.js", "js/gongfa.js", "js/avatar.js", "js/pet.js", "js/field.js", "js/dispatch.js", "js/field_view.js", "js/dao.js", "js/tuna.js", "js/daily.js", "js/specialty.js", "js/ancient.js", "js/meridians.js", "js/realm.js", "js/recruit.js", "js/staff.js", "js/field_education.js", "js/sect.js", "js/element.js", "js/life.js", "js/ui.js"];
for (const f of files) load(f);
load("js/onboard.js"); load("js/inventory.js");
let pass = 0, fail = 0;
function assert(name, ok) { if (ok) { pass++; console.log("[PASS] " + name); } else { fail++; console.log("[FAIL] " + name); } }
S = defaultState(); S.lastOnline = Date.now();
assert("离线修炼速率与在线速率按 50% 折算", Math.abs(offlineCultivationRate() / cultivationRate() - CONFIG.OFFLINE_RATE) < 1e-9);
const home = viewHome();
assert("洞府主页显示在线与普通离线修炼速率", home.includes("在线修炼") && home.includes("普通离线"));
const cultDetail = (showCultDetail(), els.modal.innerHTML);
assert("修炼加成明细显示离线速率与上限口径", cultDetail.includes("普通离线") && cultDetail.includes("8 小时"));
S.buildings.practice = 2; S.stone = 999999;
const build = viewBuild();
assert("练功房显示下一级投资后的修炼速率变化", build.includes("升至 Lv.3") && build.includes("投资"));
S.clearedMaps = { 0:true }; S.mapTeam = { 0:[1] };
S.disciples = [{ id:1, name:"测试弟子", realm:0, layer:0, loyalty:80, aptitude:1, specialty:"farm", bond:0 }];
const on = dispatchRate(0), normal = dispatchOfflineRate(0, false), incense = dispatchOfflineRate(0, true);
assert("普通离线驻守为在线产出的 25%", Math.abs(normal.factor - 0.25) < 1e-9 && Math.abs(normal.stone / on.stone - 0.25) < 1e-9);
assert("引魔香离线驻守为在线产出的 37.5%", Math.abs(incense.factor - 0.375) < 1e-9 && Math.abs(incense.stone / on.stone - 0.375) < 1e-9);
showDispatchModal(0);
const dispatchHtml = els.modal.innerHTML;
assert("驻守弹窗同时展示在线、普通离线、引魔香离线产出", dispatchHtml.includes("在线每秒") && dispatchHtml.includes("普通离线") && dispatchHtml.includes("引魔香离线"));
assert("驻守弹窗明确提示 25%/37.5% 折算", dispatchHtml.includes("25.0%") && dispatchHtml.includes("37.5%"));
console.log(`\n成长反馈专项：${pass} 通过，${fail} 失败`);
if (fail) process.exit(1);
