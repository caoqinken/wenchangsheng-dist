// ============================================================
// 二次进入秘境的渲染差异探测器
// 目的：用可录制的 2D context 跑「进入→退帧→再进入」，逐帧比对绘制调用，
//      抓出 NaN 坐标、异常尺寸、绘制序列差异
// 运行：node test_repeat_enter.js
// ============================================================
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const store = {};
global.localStorage = {
  getItem: k => (k in store ? store[k] : null),
  setItem: (k, v) => { store[k] = String(v); },
  removeItem: k => { delete store[k]; },
};
global.window = { addEventListener() {}, removeEventListener() {}, devicePixelRatio: 2 };
global.document = { hidden: false, createElement: () => ({ style: {} }) };
global.confirm = () => true;
global.location = { reload() {} };
global.Image = function () { this.onload = null; this.src = ""; };
let mockRandom = 0.5;
let _seed = 20261115;
Math.random = () => { _seed = (_seed * 1103515245 + 12345) % 2147483648; return _seed / 2147483648; };

function load(f) {
  vm.runInThisContext(fs.readFileSync(path.join(__dirname, f), "utf8"), { filename: f });
}
load("js/config.js");
load("js/state.js");
load("js/gongfa.js");
load("js/avatar.js");
load("js/field.js");
load("js/field_view.js");

function mkCanvas(w, h) {
  const calls = [];
  const t = {};
  const ctx = new Proxy(t, {
    get(target, k) {
      if (k in target) return target[k];
      if (k === "canvas") return null;
      return (...args) => {
        calls.push([k].concat(args));
        if (k === "createRadialGradient" || k === "createLinearGradient") return { addColorStop() {} };
        if (k === "measureText") return { width: 10 };
        return undefined;
      };
    },
    set(target, k, v) { calls.push(["#" + k, v]); target[k] = v; return true; },
  });
  const c = {
    width: 300, height: 150, clientWidth: w, clientHeight: h,
    getBoundingClientRect: () => ({ width: w, height: h, left: 0, top: 0 }),
    getContext: () => ctx,
    addEventListener() {},
  };
  return { c, calls };
}

function runOnce(tag, w, h, frames) {
  _seed = 20261115;   // 两次进入使用同一随机序列，地图/妖兽完全一致，才可能严格比对
  const field = fldCreate(1);
  const rec = mkCanvas(w, h);
  flvInit(rec.c, field);
  for (let i = 0; i < frames; i++) {
    const evs = fldStep(field, 1 / 60);
    for (const e of evs) flvOnEvent(e);
    flvDraw(1 / 60);
  }
  return { field, canvas: rec.c, calls: rec.calls, tag };
}

function scanBad(calls) {
  const bad = [];
  for (const call of calls) {
    for (let i = 1; i < call.length; i++) {
      const v = call[i];
      if (typeof v === "number" && (!isFinite(v) || Math.abs(v) > 1e6)) {
        bad.push(call[0] + " 参数" + i + " = " + v);
        break;
      }
    }
  }
  return bad;
}

function topOps(calls) {
  const m = {};
  for (const call of calls) {
    if (String(call[0])[0] === "#") continue;
    m[call[0]] = (m[call[0]] || 0) + 1;
  }
  return m;
}

let pass = 0, fail = 0;
function assert(name, cond, extra) {
  if (cond) { pass++; console.log("  [PASS] " + name); }
  else { fail++; console.log("  [FAIL] " + name + (extra ? "  -> " + extra : "")); }
}

const W = 390, H = 700, FR = 90;

console.log("== 第一次进入 ==");
const a = runOnce("A", W, H, FR);
console.log("  画布: " + a.canvas.width + "x" + a.canvas.height + "  FLDV=" + FLDV.w + "x" + FLDV.h + " dpr=" + FLDV.dpr);
console.log("  节点数=" + a.field.nodes.length + " 妖兽=" + a.field.monsters.length + " 调用=" + a.calls.length);
const badA = scanBad(a.calls);
assert("第一次进入无非法绘制参数", badA.length === 0, badA.slice(0, 3).join(" | "));

console.log("\n== 第二次进入（不清 FLDV，模拟连续进出）==");
const b = runOnce("B", W, H, FR);
console.log("  画布: " + b.canvas.width + "x" + b.canvas.height + "  FLDV=" + FLDV.w + "x" + FLDV.h + " dpr=" + FLDV.dpr);
console.log("  节点数=" + b.field.nodes.length + " 妖兽=" + b.field.monsters.length + " 调用=" + b.calls.length);
const badB = scanBad(b.calls);
assert("第二次进入无非法绘制参数", badB.length === 0, badB.slice(0, 3).join(" | "));

assert("第二次画布尺寸与第一次一致", a.canvas.width === b.canvas.width && a.canvas.height === b.canvas.height,
  "A=" + a.canvas.width + "x" + a.canvas.height + " B=" + b.canvas.width + "x" + b.canvas.height);

const opA = topOps(a.calls), opB = topOps(b.calls);
const keys = new Set([].concat(Object.keys(opA), Object.keys(opB)));
const diffOps = [];
for (const k of keys) if ((opA[k] || 0) !== (opB[k] || 0)) diffOps.push(k + ": A=" + (opA[k] || 0) + " B=" + (opB[k] || 0));
// 固定随机序列后两次应完全一致；若不一致即说明存在跨局状态残留
const _totalA = Object.values(opA).reduce((a, b) => a + b, 0);
const _totalB = Object.values(opB).reduce((a, b) => a + b, 0);
assert("两次绘制调用完全一致", _totalA === _totalB,
  diffOps.slice(0, 6).join(" | "));

// 节点坐标范围
function nodeRange(f) {
  if (!f.nodes.length) return "空";
  let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
  for (const n of f.nodes) { x0 = Math.min(x0, n.x); x1 = Math.max(x1, n.x); y0 = Math.min(y0, n.y); y1 = Math.max(y1, n.y); }
  return "x[" + Math.round(x0) + "," + Math.round(x1) + "] y[" + Math.round(y0) + "," + Math.round(y1) + "]";
}
console.log("  节点范围 A: " + nodeRange(a.field));
console.log("  节点范围 B: " + nodeRange(b.field));
assert("两次节点均在合理范围内", (() => {
  const chk = f => f.nodes.every(n => isFinite(n.x) && isFinite(n.y) && Math.abs(n.x) < 5000 && Math.abs(n.y) < 5000);
  return chk(a.field) && chk(b.field);
})());

// 背景图加载
assert("第二次进入背景图状态已重置", FLDV.bgImg !== null && FLDV.bgReady === false || FLDV.bgReady === true);

console.log("\n== 极端场景：画布元素重建 + 首帧布局为 0 ==");
const _c3 = mkCanvas(0, 0);
_c3.c.getBoundingClientRect = () => ({ width: 0, height: 0, left: 0, top: 0 });
const _f3 = fldCreate(1);
flvInit(_c3.c, _f3);
assert("布局为 0 时退回视口尺寸，不停留在浏览器默认 300×150",
  _c3.c.width > 300 && _c3.c.height > 150, "实际 " + _c3.c.width + "x" + _c3.c.height);

// 布局随后恢复为正常尺寸 → 自愈必须在若干帧内修正
_c3.c.clientWidth = 411; _c3.c.clientHeight = 733;
_c3.c.getBoundingClientRect = () => ({ width: 411, height: 733, left: 0, top: 0 });
for (let i = 0; i < 20; i++) { fldStep(_f3, 1 / 60); flvDraw(1 / 60); }
assert("尺寸变化后渲染循环自愈重建画布",
  Math.abs(_c3.c.width - 411 * 2) <= 1 && Math.abs(_c3.c.height - 733 * 2) <= 1,
  "实际 " + _c3.c.width + "x" + _c3.c.height + "，应为 822x1466");

console.log("\n===== 结果：" + pass + " 通过，" + fail + " 失败 =====");
process.exitCode = fail ? 1 : 0;
