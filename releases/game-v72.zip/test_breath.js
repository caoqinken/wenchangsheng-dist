// 气息战斗 v2 单元回归（Node）
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const skills = {
  light: { key:'light', name:'轻式', mult:.6, mana:10, cd:0, color:'#aa8844' },
  heavy: { key:'heavy', name:'重式', mult:1.52, mana:20, cd:0, color:'#aa8844' },
  control: { key:'control', name:'冰封', mult:.6, mana:10, cd:2, slow:true, color:'#4488aa' },
};
const context = {
  console, Math, Date, isFinite, setTimeout:(fn)=>{fn();return 0;},
  performance:{now:()=>1000},
  S:{realm:0,yungongRatio:0,settings:{combatSpeed:1}},
  CONFIG:{BATTLE2:{QI_MAX:200,QI_REGEN:100,MANA_REGEN:12,YUNGONG_RATE:.15,SLOT_BY_REALM:[2,3,4,5,6,7,8,8,8,8,8]}},
  FS:{field:null},
  finishCalled:false,
  fsFinish:function(){context.finishCalled=true;},
  fldSkill:k=>skills[k]||null,
  fmt:n=>String(Math.floor(n)),
  esc:s=>String(s),
  document:{}, window:{},
  requestAnimationFrame:()=>1, cancelAnimationFrame:()=>{},
  toast:()=>{}, save:()=>{},
};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname,'js/breath.js'),'utf8'),context);
let pass=0,fail=0;
function a(n,v){if(v){pass++;console.log('[PASS] '+n)}else{fail++;console.log('[FAIL] '+n)}}
const B=vm.runInContext("BREATH",context);
a('气息消耗档：轻式60',context.breathGasCost(skills.light)===60);
a('气息消耗档：重式150',context.breathGasCost(skills.heavy)===150);
// 术式倍率与多段命中必须实际进入伤害结算；禁用随机会心以便精确断言。
context.Math = Object.create(Math); context.Math.random = () => 0.99;
B.field={player:{atk:100,def:10,hp:100,hpMax:100,mana:100,manaMax:100,shield:0},monsters:[{name:'倍率木桩',hp:1000,hpMax:1000,def:0,atk:10,alive:true,kind:'normal'}],slots:[],dmgDealt:0,killCount:0,bossKilled:false};
const lightDamage=context.breathDamage({atk:100},B.field.monsters[0],.6,'player','轻式');
a('轻式倍率0.60实际造成60%基础伤害',lightDamage===60 && B.field.monsters[0].hp===940);
B.field.monsters[0].hp=1000;
const heavyDamage=context.breathDamage({atk:100},B.field.monsters[0],1.52,'player','重式');
a('重式倍率1.52实际造成152%基础伤害',heavyDamage===152 && B.field.monsters[0].hp===848);
B.field.monsters[0].hp=1000;
const tripleDamage=context.breathDamage({atk:100,hits:3},B.field.monsters[0],.45,'player','三叠浪');
a('多段术式按命中次数累计倍率伤害',tripleDamage===135 && B.field.monsters[0].hp===865);
context.S.realm=0; a('炼气期术式槽上限为2',context.breathSlotCap()===2); context.S.realm=1; a('筑基期术式槽上限为3',context.breathSlotCap()===3); context.S.realm=7; a('高境界术式槽上限扩展到8',context.breathSlotCap()===8);
context.S.yungongRatio=.9; a('运功比例上限钳制到60%',context.breathYungongRatio()===.6);
B.field={player:{atk:100,manaMax:200},monsters:[]}; B.profile={yungong:0};
a('满运功附伤按攻击归一化为+9%',Math.abs(context.breathYungongDamage()-9)<1e-9);
B.field.player.manaMax=400;
a('运功附伤不随真元上限异常膨胀',Math.abs(context.breathYungongDamage()-9)<1e-9);
B.field.player.atk=200;
a('运功附伤随角色攻击同比例成长',Math.abs(context.breathYungongDamage()-18)<1e-9);
B.field.player.atk=100; B.field.player.manaMax=200; B.field.player.mana=200;
context.S.yungongRatio=.6;
a('运功预留真元不从真元总量扣除',Math.abs(context.breathAvailableMana()-80)<1e-9);
B.field.player.mana=119;
a('真元低于预留额度时可用真元归零',context.breathAvailableMana()===0);
context.S.yungongRatio=0; B.field.player.mana=100;
B.field={player:{atk:100,def:10,hp:100,hpMax:100,mana:100,manaMax:100,shield:0},monsters:[{name:'气息上限木桩',hp:1000,hpMax:1000,def:0,atk:10,alive:true,kind:'normal'}],slots:[],dmgDealt:0,killCount:0,bossKilled:false};
B.playerGas=199; B.enemyGas=0; B.cooldowns={}; B.tick=0; B.el=null;
context.breathTick();
a('气息上限按设计固定为200，不再溢出到300',B.playerGas<=200);
// 真元回复必须使用配置的绝对值 12/秒，而不是按真元上限的百分比估算。
B.field={player:{atk:100,def:10,hp:100,hpMax:100,mana:50,manaMax:200,shield:0},monsters:[{name:'真元回复木桩',hp:10000,hpMax:10000,def:0,atk:1,alive:true,kind:'normal'}],slots:[],dmgDealt:0,killCount:0,bossKilled:false};
B.playerGas=0; B.enemyGas=0; B.cooldowns={}; B.buffs={}; B.tick=0; B.el=null;
context.S.yungongRatio=0; B.profile={manaRegen:0,speed:0,dodge:0};
context.breathTick();
a('真元基础回复按配置固定为12点/秒',B.field.player.mana===62);
context.S.yungongRatio=0;
B.field={player:{atk:100,def:10,hp:100,hpMax:100,mana:100,manaMax:100,shield:0},monsters:[{name:'测试妖兽',hp:1000,hpMax:1000,def:0,atk:10,alive:true,kind:'normal'}],slots:['light','heavy'],dmgDealt:0,killCount:0,bossKilled:false};
B.playerGas=100; B.enemyGas=0; B.cooldowns={}; B.slotCursor=0; B.el=null;
context.breathPlayerAct();
a('自动循环优先按槽位释放轻式',B.field.monsters[0].hp<1000 && B.playerGas===40 && B.slotCursor===1);
// 冷却期间无可用术式时允许普攻；若重式可用但气息不足则不降级普攻。
B.cooldowns.light=3; B.cooldowns.heavy=0; B.playerGas=100; B.field.monsters[0].hp=1000;
context.breathPlayerAct();
a('重式未蓄满150气息时等待，不降级普攻',B.playerGas===100 && B.field.monsters[0].hp===1000);
B.playerGas=150; context.breathPlayerAct();
a('重式达到150气息后释放',B.playerGas===0 && B.field.monsters[0].hp<1000);
// 槽位顺序必须先选中第一个 CD/真元可用术式；气息不足时不能越过它释放后续轻式。
B.cooldowns={heavy:0,light:0}; B.field.slots=['heavy','light']; B.playerGas=100; B.slotCursor=0; B.field.player.mana=100; B.field.monsters[0].hp=1000;
context.breathPlayerAct();
a('前置重式气息不足时等待，不越过槽位释放后续轻式',B.playerGas===100 && B.field.monsters[0].hp===1000 && B.slotCursor===0);
B.playerGas=150; context.breathPlayerAct();
a('前置重式蓄满后按槽位顺序释放',B.playerGas===0 && B.field.monsters[0].hp<1000 && B.slotCursor===1);
B.cooldowns={control:0}; B.field.slots=['control']; B.playerGas=12; B.enemyGas=80; B.field.monsters[0].hp=1000;
context.breathUseSkill('control',true);
a('手动催动将自身气息归零',B.playerGas===0);
a('控制术式命中蓄力敌人时打断',B.enemyGas===0);
const _normalized={chapter:0,player:{atk:100,def:50},monsters:[{kind:'normal',hp:1000,hpMax:1000,atk:1000,def:500,alive:true}]};
context.breathNormalizeEnemies(_normalized);
a('气息战将自由走位怪物属性压缩到回合制量级',_normalized.monsters[0].hpMax>=120 && _normalized.monsters[0].def===15 && _normalized.monsters[0].atk>=52.5);
B.active=true;
B.field={chapter:0,monsters:[{alive:false}],player:{hp:1},killCount:1,exploreMax:50};
context.FS.field=B.field;
context.breathComplete(true);
a('胜利结束写入兼容结算字段',B.field.over===true && B.field.win===true && !!B.field.portal && B.field.explore===B.field.exploreMax);
a('胜利结束调用原有秘境结算入口',context.finishCalled===true);
console.log(`结果：${pass} 通过，${fail} 失败`);
if(fail)process.exit(1);
