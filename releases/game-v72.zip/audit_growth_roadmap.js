// v0.54.7：成长经济路线图。只读取正式 CONFIG，生成可复现的突破节奏与养成门槛审计。
const fs=require('fs'),path=require('path'),vm=require('vm');
vm.runInThisContext(fs.readFileSync(path.join(__dirname,'js/config.js'),'utf8'),{filename:'js/config.js'});
const C=CONFIG, realms=C.REALMS, layers=C.LAYERS_PER_REALM;
const fmt=n=>Number(n).toLocaleString('en-US',{maximumFractionDigits:2});
const rows=[];let totalSec=0,totalQi=0;
for(let r=0;r<realms.length;r++){
 let qi=0,sec=0,min=Infinity,max=0;
 for(let l=0;l<layers;l++){
  const k=r*layers+l,cost=C.breakCost(k),rate=C.baseRate(r,l),t=cost/rate;
  qi+=cost;sec+=t;min=Math.min(min,t);max=Math.max(max,t);
 }
 totalQi+=qi;totalSec+=sec;
 rows.push({realm:realms[r],qi,sec,min,max,avg:sec/layers});
}
const tiers=C.ARTIFACT_TIERS.map(t=>({tier:t.tier,name:t.name,forgeLv:(t.tier-1)*C.ARTIFACT_TIER_LV_STEP,stone:t.stone,material:t.material,rateAtMin:Math.max(C.ARTIFACT_RATE_MIN,Math.min(C.ARTIFACT_RATE_MAX,C.ARTIFACT_FORGE_BASE_RATE-(t.tier-1)*C.ARTIFACT_FORGE_TIER_DECAY+Math.min(((t.tier-1)*C.ARTIFACT_TIER_LV_STEP)*C.ARTIFACT_FORGE_LV_BONUS,C.ARTIFACT_FORGE_LV_CAP)))}));
const slotUnlock=C.LOADOUT_SLOTS.map(s=>`${s.name}：${realms[s.unlockRealm]||'未知'}（realm ${s.unlockRealm}）`);
const out=[];
out.push('# v0.54.7 P1：成长经济路线图与境界节奏审计','','## 本轮范围','','- 基线：v0.54.6；本轮先核对真实代码与设计稿，不修改游戏经济倍率、成本、战斗或存档字段。','- 突破成本与修炼基础速率直接读取 `CONFIG.breakCost()`、`CONFIG.baseRate()`；按99层逐层计算。','- 时间为**无任何额外加成、连续在线修炼、无离线封顶、无渡劫失败**的理论下限，不是实际通关承诺。真实 `cultivationBreakdown()` 还会乘练功房、功法、药力、法宝、秘境、势力、经脉等倍率。','',`- 突破层数：${realms.length}境 × ${layers}层 = ${realms.length*layers}层。`,`- 理论总灵气需求：${fmt(totalQi)}。`,`- 理论基础修炼总时长：${fmt(totalSec/3600)} 小时（${fmt(totalSec/86400)} 天）。`,'','## 炼气至金仙：逐境突破成本与基础时间','','| 境界 | 9层灵气总需求 | 基础时间（小时） | 单层最快（秒） | 单层最慢（秒） |','|---|---:|---:|---:|---:|');
for(const x of rows)out.push(`| ${x.realm} | ${fmt(x.qi)} | ${fmt(x.sec/3600)} | ${fmt(x.min)} | ${fmt(x.max)} |`);
out.push('','## 实际突破规则核实','','- 层内突破：灵气达标后100%成功。','- 每境第9层跨境：触发渡劫成功率判定；失败会损失当前剩余灵气的30%，累计失败达到保底阈值后第3次必成，并有元神受损冷却。','- 因此上表只统计一次成功所需的灵气，不含失败重修与冷却；实际总时长必然更长。','- 公式：`k = realm × 9 + layer`；`cost = 100 × 1.29^k`；基础速率 `5^realm × 1.03^layer`。','', '## 建筑路线：必需与可选','','| 建筑 | 解锁 | 成长作用 | 路线定位 |','|---|---|---|---|','| 练功房 | 炼气 | 每级基础修炼速率 +7%，是直接缩短突破时间的核心投资 | 推荐优先；非突破硬门槛 |','| 灵田 | 炼气 | 产出灵草，支撑炼丹原料 | 经营/丹药路线可选 |','| 炼丹房 | 筑基 | 消耗灵草生产丹药 | 丹药路线可选；不是境界突破硬门槛 |','| 招募堂 | 筑基 | 增加弟子名额 | 多弟子经营路线可选 |','| 炼器坊 | 金丹 | 解锁法宝品阶锻造上限，同时每级给固定攻防 | 战斗/法宝路线可选；高阶炼器的前置投资 |','- 代码中的突破按钮只检查灵气、境界/层数与渡劫规则；没有要求先升级某座建筑。建筑是效率与战斗路线，不是突破许可条件。','', '## 法宝成长路线与成本门槛','','| 品阶 | 名称 | 炼器坊最低等级 | 灵石/次 | 灵材/次 | 设计基础成功率（最低坊级） |','|---:|---|---:|---:|---:|---:|');
for(const t of tiers)out.push(`| ${t.tier} | ${t.name} | ${t.forgeLv} | ${fmt(t.stone)} | ${t.material} | ${(t.rateAtMin*100).toFixed(1)}% |`);
out.push('','- 三件本体装备栏位炼气即开放；古宝栏位从金丹、元婴、化神逐步开放；法宝栏位从化神起逐步开放，后续大乘全开。','- 法宝主属性按百分比随境界基础属性缩放；辅道法宝的修炼加成进入 `cultivationBreakdown()`。法宝不是突破硬门槛，但可同时影响战斗或修炼效率。','- 仙器单件基础成本为24,000灵石、96灵材；升阶另需同类型同品阶祭品，失败风险不可忽略。','', '## 三条成长路线建议（非强制）','','1. **稳健挂机**：先保持基础修炼，不强迫早期投入炼器坊；资源优先保留给实际开放的关键系统。适合低操作频次。','2. **修炼优先**：练功房优先升级；灵田/炼丹房仅在药力供给或丹药消费明确时扩张；辅道法宝与功法按边际修炼收益投资。','3. **战斗经营**：战斗推进卡关时再投资炼器坊与本命/护身法宝；按炼器坊每两级开放一档法宝的规则规划，不建议为了高阶品阶提前透支全部资源。','', '## 经济路线数据如何使用','','- v0.54.6三路线模拟的小时数是人为设定的驻守周期，且未纳入修炼灵气完整积累、炼丹tick、坊市净交易、功法/经脉消耗、随机炼器返还与离线封顶。它不能直接换算为“几小时升一境”。','- 资源积累时间应按当前存档真实 `dispatchRate()`、可用秘境数、弟子数量/专精、建设等级、人口劳役和离线结算上限重新计算。','- 下一步若要给出可信的“从炼气到金仙现实天数”，必须先统一：驻守秘境数量与弟子分配、在线/离线占比、战斗掉落频次、法宝目标槽位、炼丹/坊市消费频次。当前没有遥测，不应把某条假设路线伪装成标准答案。','', '## 结论与本轮变更','','- 已核实真实突破公式、跨境渡劫规则、建筑解锁、法宝品阶成本与炼器坊门槛。','- 暂无证据表明突破流程缺少某项强制建筑或资源前置，因此本轮不修改游戏规则。','- `SAVE_VERSION` 保持17；无新增存档字段；无数值平衡改动。','- P0未完成门禁（10000场Monte Carlo/DPS、手动操作增益、手动/速战胜率差、飞升周期）继续标记暂缓，不计入通过。','', '## 复现','','```bash','node audit_growth_roadmap.js','```','');
const file=path.join(__dirname,'..','docs','v0.54.7_P1_成长经济路线图.md');fs.writeFileSync(file,out.join('\n'));process.stdout.write(out.join('\n'));
