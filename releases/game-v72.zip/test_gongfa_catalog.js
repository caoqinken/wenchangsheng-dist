// v0.53.1 六阶功法目录与解锁规则专项回归
const fs=require("fs"),path=require("path"),vm=require("vm");
const ctx={console,Math,Date,isFinite,CONFIG:null,S:{realm:9,gongfaBooks:{},gongfaEquip:{xin:"changsheng",shu:null,shen:null,dao:null}},save:()=>{},invCount:()=>0,invRemove:()=>{},gainItem:()=>{},fmt:n=>String(n)};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname,"js/config.js"),"utf8"),ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname,"js/gongfa.js"),"utf8"),ctx);
let pass=0,fail=0;function a(n,v){if(v){pass++;console.log("[PASS] "+n)}else{fail++;console.log("[FAIL] "+n)}}
const CONFIG=vm.runInContext("CONFIG",ctx); const books=CONFIG.GONGFA_BOOKS;
a("完整保留25部功法且key唯一",books.length===25&&new Set(books.map(b=>b.key)).size===25);
a("六阶层数严格为3/6/9/9/12/12",books.every(b=>b.layers===[0,3,6,9,9,12,12][b.grade]));
a("六阶解锁境界严格为炼气/筑基/金丹/元婴/化神/真仙",books.every(b=>b.unlockRealm===[0,0,1,2,3,4,9][b.grade]));
a("25部功法都有四类归属",books.every(b=>["xin","shu","shen","dao"].includes(b.category)));
a("旧阶位与旧层数元数据完整保留",books.every(b=>b.tier>=1&&b.tier<=10&&b.legacyLayers>=b.layers&&Number.isInteger(b.legacyUnlockRealm)));
a("旧层节点已折叠至新阶层数上限",books.every(b=>b.nodes.every(n=>n.at<=b.layers)));
ctx.S.gongfaBooks.changsheng={lv:3,learned:true};
a("一阶圆满后满足二阶前置条件",ctx.gongfaGradePrerequisite(2));
a("二阶功法悟道成本按正式品阶计算",ctx.gongfaCost(books.find(b=>b.grade===2),2).wudao===50);
ctx.S.gongfaBooks.baihua={lv:12,learned:true}; ctx.S.realm=8;
a("六阶即使上一阶圆满也不能提前到渡劫期解锁",ctx.gongfaUnlocked(books.find(b=>b.grade===6))===false);
ctx.S.realm=9;
a("达到真仙且五阶有圆满功法后解锁六阶",ctx.gongfaUnlocked(books.find(b=>b.grade===6))===true);
console.log(`结果：${pass} 通过，${fail} 失败`);if(fail)process.exit(1);
