// 《问长生》31 部功法专属术式资源预算审计
// 仅读取 CONFIG，不模拟战斗、不修改游戏数据。
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const ctx = {};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, 'js/config.js'), 'utf8'), ctx);
const skills = vm.runInContext('CONFIG.FIELD_SKILLS', ctx).filter(x => x.gongfaKey);
const gasCost = sk => sk.mult >= 1.25 ? 150 : 60; // 与 breathGasCost() 当前实现保持一致
const lines = [
  '# 31 部功法专属术式资源预算审计',
  '',
  '> 自动读取 `CONFIG.FIELD_SKILLS`；只统计带 `gongfaKey` 的功法专属术式。气息档按当前 `breathGasCost()` 阈值复算，不代表已确认的最终设计分档。理论循环仅作单技能木桩上限估算，不含多槽竞争、目标数量、支持效果与手动催招。',
  '',
  `专属术式：${skills.length} 个。`,
  '',
  '| 术式 | 功法 | 解锁境界 | 倍率×段数 | CD(息) | 真元 | 当前气息成本 | 理论循环DPS倍率 | 真元净消耗/秒 | 定位 |',
  '|---|---|---:|---:|---:|---:|---:|---:|---:|---|'
];
for (const sk of skills) {
  const gas = gasCost(sk);
  const hits = Math.max(1, sk.hits || 1);
  const cycle = Math.max(Number(sk.cd) || 1, gas / 100);
  const dps = (Number(sk.mult) || 0) * hits / cycle;
  const manaNet = (Number(sk.mana) || 0) / cycle - 12;
  const role = sk.mult > 0 ? (sk.slow || sk.control ? '伤害/控制' : '伤害') : (sk.manaRestorePct ? '回复真元' : sk.healPct ? '治疗' : sk.shieldPct ? '护盾' : '增益/防御');
  lines.push(`| ${sk.name} | ${sk.gongfaKey} | ${sk.unlockRealm} | ${sk.mult || 0}×${hits} | ${sk.cd} | ${sk.mana} | ${gas} | ${dps.toFixed(3)} | ${manaNet >= 0 ? '+' : ''}${manaNet.toFixed(2)} | ${role} |`);
}
lines.push('', '## 审计观察', '');
const drain = skills.filter(sk => sk.mult > 0).map(sk => ({sk,cycle:Math.max(Number(sk.cd)||1,gasCost(sk)/100)})).filter(x => x.sk.mana/x.cycle > 12);
lines.push(`- 单技能持续循环时，理论真元净消耗超过 12/秒的伤害术式：${drain.length} 个。该值是单槽估算；多槽轮转会进一步改变实际占用。`);
lines.push('- 当前代码以 `mult >= 1.25` 判定 150 气息，否则 60 气息；设计稿只明确轻式 0.60、重式 1.52、绝式 2.05 三个锚点，未定义 0.85～1.80 等中间倍率的统一归档规则。');
lines.push('- 因此本轮不改术式气息成本、真元消耗或 CD，避免把代码阈值误当成已确认设计。');
const out = path.join(__dirname, '..', 'docs', 'v0.53.6_功法术式资源预算表.md');
fs.writeFileSync(out, lines.join('\n') + '\n');
console.log(`已生成 ${out}；功法专属术式 ${skills.length} 个。`);
