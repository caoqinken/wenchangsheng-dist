// v0.53.0 功法六阶映射、关窍战斗收益与功法术式归属回归
const fs=require('fs'),path=require('path'),vm=require('vm');
const ctx={console,Math,Date,isFinite,CONFIG:null,S:{realm:8,gongfaBooks:{},gongfaEquip:{xin:'changsheng',shu:null,shen:null,dao:null}},
  save:()=>{},invCount:()=>0,invRemove:()=>{},gainItem:()=>{},fmt:n=>String(n)};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname,'js/config.js'),'utf8'),ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname,'js/gongfa.js'),'utf8'),ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname,'js/field.js'),'utf8'),ctx);
let pass=0,fail=0;function a(n,v){if(v){pass++;console.log('[PASS] '+n)}else{fail++;console.log('[FAIL] '+n)}}
const books=vm.runInContext('CONFIG.GONGFA_BOOKS',ctx);
a('功法目录仍保留原有25部，未丢弃旧内容',books.length===25);
a('旧十阶映射到六阶且边界正确',
  ctx.gongfaGrade(books.find(x=>x.tier===1))===1 &&
  ctx.gongfaGrade(books.find(x=>x.tier===2))===2 &&
  ctx.gongfaGrade(books.find(x=>x.tier===6))===4 &&
  ctx.gongfaGrade(books.find(x=>x.tier===10))===6);
a('六阶展示分组覆盖全部功法',Array.from({length:6},(_,i)=>ctx.gongfaGradeBooks(i+1).length).reduce((x,y)=>x+y,0)===25);
ctx.S.gongfaBooks.changsheng={lv:3,learned:true};
let prof=ctx.gongfaV2Profile();
a('功法达到3层后关窍效果进入战斗属性',Math.abs(prof.mana-.13)<1e-9 && Math.abs(prof.manaRegen-.039)<1e-9);
const avail=ctx.fldUnlockedSkills(8).map(x=>x.key);
a('默认装备长生诀时可用其专属灵息掌',avail.includes('lingxi_zhang'));
ctx.S.gongfaEquip.xin=null;
const noXin=ctx.fldUnlockedSkills(8).map(x=>x.key);
a('卸下长生诀后专属灵息掌从技能盘候选移除',!noXin.includes('lingxi_zhang'));
ctx.S.gongfaBooks.chiyang={lv:0,learned:true};ctx.S.gongfaEquip.shu='chiyang';
const fire=ctx.fldUnlockedSkills(8).map(x=>x.key);
a('装备赤阳经后解锁其专属火海术',fire.includes('huo_hai'));
ctx.S.gongfaEquip.shu=null;
a('卸下赤阳经后火海术不再可选',!ctx.fldUnlockedSkills(8).some(x=>x.key==='huo_hai'));
console.log(`结果：${pass} 通过，${fail} 失败`);if(fail)process.exit(1);
