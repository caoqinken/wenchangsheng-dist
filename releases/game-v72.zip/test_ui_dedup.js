// ============================================================
// 界面去重专项（v0.49.0）
// 目的：一个功能只有一个入口，杜绝「修炼页宫格 + 洞府页 + 页底卡片」三处重复
// 校验对象：6 个页签视图的 HTML + 关键弹窗
// ============================================================
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const store = {};
global.localStorage = {
  getItem: k => (k in store ? store[k] : null),
  setItem: (k, v) => { store[k] = String(v); },
  removeItem: k => { delete store[k]; },
};
const stubEl = () => ({ textContent: "", innerHTML: "", style: {}, classList: { add() {}, remove() {}, toggle() {} }, dataset: {} });
const els = {};
global.window = { addEventListener: () => {}, scrollTo: () => {} };
global.document = {
  hidden: false,
  getElementById: id => (els[id] = els[id] || stubEl()),
  querySelectorAll: () => [],
  body: { addEventListener: () => {} },
};
global.confirm = () => true;
global.location = { reload: () => {} };

function load(f) {
  vm.runInThisContext(fs.readFileSync(path.join(__dirname, f), "utf8"), { filename: f });
}
const files = ["js/config.js", "js/state.js", "js/artifact.js", "js/idle.js", "js/combat.js",
  "js/tower.js", "js/build.js", "js/dan.js", "js/guide.js", "js/time.js", "js/faction.js", "js/event.js", "js/npc.js", "js/economy.js",
  "js/codex.js", "js/gongfa.js", "js/avatar.js", "js/pet.js", "js/field.js", "js/dispatch.js", "js/field_view.js", "js/dao.js", "js/tuna.js", "js/daily.js", "js/specialty.js", "js/ancient.js", "js/meridians.js", "js/realm.js", "js/recruit.js", "js/staff.js", "js/field_education.js", "js/sect.js", "js/element.js", "js/life.js", "js/ui.js", "js/field_ui.js"];
for (const f of files) load(f);
load("js/onboard.js");
load("js/inventory.js");

let fail = 0, pass = 0;
function ok(cond, name, detail) {
  if (cond) { pass++; console.log("  [PASS] " + name); }
  else { fail++; console.log("  [FAIL] " + name + (detail ? " → " + detail : "")); }
}
const count = (html, action) => (html.match(new RegExp('data-action="' + action + '"', "g")) || []).length;

// ---------- 场景：全新存档（第 1 章可探索，其余未解锁） ----------
S = defaultState();
S.lastOnline = Date.now();
S.playerName = "去重测试";
invEnsure();

const HOME = viewHome(), BUILD = viewBuild(), WORLD = viewWorld(),
      BATTLE = viewBattle(), CHAR = viewChar(), CODEX = viewCodex();
const ALL = { home: HOME, build: BUILD, world: WORLD, battle: BATTLE, char: CHAR, codex: CODEX };

console.log("\n== 一、修炼页：只放修炼行为 ==");
ok(HOME.indexOf("quick-grid") < 0, "修炼页无八宫格（已删除）");
ok(count(HOME, "tuna") === 1, "修炼页吐纳入口唯一", "出现 " + count(HOME, "tuna") + " 次");
["dan", "garden", "avatar", "bag", "openforge", "sect", "daily"].forEach(a => {
  ok(count(HOME, a) === 0, "修炼页不含 " + a + "（归洞府/世界）", "出现 " + count(HOME, a) + " 次");
});

console.log("\n== 二、洞府页：经营功能唯一入口 ==");
// 用「全解锁」存档验证：建筑已解锁、宗门已立
S.realm = 5;
S.buildings = { farm: 2, alchemy: 2, forge: 2, practice: 2, recruit: 2 };
S.sect = { name: "去重宗", lv: 1 };
S.stone = 1e6;
const BUILD2 = viewBuild();
["dan", "garden", "avatar", "bag", "craft", "sect"].forEach(a => {
  const n = count(BUILD2, a);
  ok(n === 1, "洞府页 " + a + " 入口唯一", "出现 " + n + " 次");
});
const ALL2 = { home: HOME, build: BUILD2, world: WORLD, battle: BATTLE, char: CHAR, codex: CODEX };
let crossDup = [];
["dan", "garden", "avatar", "craft", "sect"].forEach(a => {
  const total = Object.keys(ALL2).reduce((s, k) => s + count(ALL2[k], a), 0);
  if (total !== 1) crossDup.push(a + "×" + total);
});
ok(crossDup.length === 0, "经营功能全站各仅一处入口", crossDup.join(" "));
ok(count(ALL2.home, "bag") + count(ALL2.build, "bag") === 1, "储物袋入口唯一（洞府·储物法器）");

console.log("\n== 三、世界页：日常与机缘唯一入口 ==");
ok(count(WORLD, "daily") === 1, "世界页日常入口唯一", "出现 " + count(WORLD, "daily") + " 次");
ok(WORLD.indexOf("日常 · 机缘") >= 0, "世界页含「日常 · 机缘」分区");

console.log("\n== 四、历练页：一章一个入口组 ==");
ok(count(BATTLE, "battle") === 1, "速战按钮唯一（仅在当前章条目内）", "出现 " + count(BATTLE, "battle") + " 次");
ok(BATTLE.indexOf("battle-card") < 0, "页底重复的速战卡已移除");
ok(BATTLE.indexOf("速战本章") < 0, "「速战本章」旧文案已移除");
ok(BATTLE.indexOf("map-next") >= 0, "下一关敌情并入秘境条目");
// 第 1 章已探明后：该章速战应彻底消失，只留驻守；速战转到下一未探明章
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "去重测试";
S.clearedMaps = { 0: true };
S.bestStage = 6;
const BATTLE2 = viewBattle();
ok(BATTLE2.indexOf('data-action="battle" data-n="0"') < 0, "已探明章条目内不再出现速战");
ok(BATTLE2.indexOf('data-action="battle" data-n="6"') >= 0, "速战只落在当前未探明章");
ok(count(BATTLE2, "battle") === 1, "全页速战最多一个", "出现 " + count(BATTLE2, "battle") + " 次");
ok(count(BATTLE2, "dispatch") === 1, "已探明章只留驻守入口", "出现 " + count(BATTLE2, "dispatch") + " 次");
ok((BATTLE2.match(/第 0\/6 关/g) || []).length <= 1, "未解锁章不再显示假进度（仅当前章 0/6）");
// 全部通关：一个速战都不该剩
S.bestStage = CONFIG.CHAPTERS.length * (CONFIG.STAGES_PER_CHAPTER + 1);
S.clearedMaps = {};
for (let i = 0; i < CONFIG.CHAPTERS.length; i++) S.clearedMaps[i] = true;
const BATTLE3 = viewBattle();
ok(count(BATTLE3, "battle") === 0, "全通关后无速战入口（改为驻守经营）", "出现 " + count(BATTLE3, "battle") + " 次");
ok(BATTLE3.indexOf("已通关全部秘境") >= 0, "全通关给出收束提示");

console.log("\n== 五、古宝：归入道途图鉴，合成收进储物袋 ==");
ok(CODEX.indexOf("古宝图鉴") >= 0, "道途页含古宝图鉴");
ok(count(CODEX, "ancset") === CONFIG.ANCIENT_SETS.length, "每套一张简卡（点击看详情）", "出现 " + count(CODEX, "ancset") + " 次");
ok(CODEX.indexOf("ancforge") < 0, "图鉴页不再放碎片合成按钮");
ok(count(CHAR, "ancient") === 0, "人物页不再单开古宝面板入口");

S = defaultState(); S.lastOnline = Date.now(); S.playerName = "去重测试";
invEnsure(); invSet("frag:qingyun", 12);
showItemDetail("frag:qingyun");
const detail = el("modal").innerHTML;
ok(count(detail, "ancforge") === 1, "背包碎片详情含唯一合成入口", "出现 " + count(detail, "ancforge") + " 次");
ok(detail.indexOf("合成下一件古宝") >= 0, "合成按钮文案明确");

showAncientSetDetail("qingyun");
const setDetail = el("modal").innerHTML;
ok(setDetail.indexOf("青锋古剑") >= 0 || setDetail.indexOf("未获得") >= 0, "套装详情正常渲染");
ok(count(setDetail, "ancforge") === 0, "套装详情不做合成（避免第二个合成入口）");
ok(/undefined|NaN|\[object Object\]/.test(setDetail) === false, "套装详情无脏数据");

showAncientPanel();
const panel = el("modal").innerHTML;
ok(count(panel, "ancforge") === 0, "古宝总览不做合成", "出现 " + count(panel, "ancforge") + " 次");
ok(/undefined|NaN/.test(panel) === false, "古宝总览无脏数据");

console.log("\n== 六、内视与器物养成入口（v0.50.0） ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "去重测试";
S.realm = 2; S.stone = 1e6; S.materials = 500; invEnsure();
const HOME50 = viewHome(), BUILD50 = viewBuild(), CODEX50 = viewCodex();
ok(count(HOME50, "innerview") === 1, "内视入口唯一（人物简图）", "出现 " + count(HOME50, "innerview") + " 次");
ok(count(HOME50, "meridianopen") === 0, "点穴只在弹窗内，页面不铺按钮");
ok(count(BUILD50, "craft") === 1 && count(BUILD50, "openforge") === 0, "炼器坊唯一入口，炼制收进面板");
ok(count(CODEX50, "ancstar") === 0 && count(CODEX50, "ancinfuse") === 0, "图鉴不做升星/注灵");
ok(/undefined|NaN|\[object Object\]/.test(HOME50 + BUILD50 + CODEX50) === false, "新页面无脏数据");

console.log("\n== 七、全量 action 唯一性（列表型白名单） ==");
// 列表型动作按「条目各一个」属正常；其余功能动作一旦全站出现 >1 次即为重复入口
const LIST_DUP = ["ancset", "artdown", "artfilter", "artpick", "artup", "assign", "buydeal",
  "gflearn", "insightskill", "unassign", "upgrade", "tab", "battle", "dispatch", "entermap",
  "ransom", "claimtask", "gardenplot", "sellspecialty", "buyspecialty", "buymarketshelf"];
const tally = {};
Object.keys(ALL2).forEach(k => {
  const re = /data-action="([a-z]+)"/g;
  let m;
  while ((m = re.exec(ALL2[k]))) {
    tally[m[1]] = tally[m[1]] || { total: 0 };
    tally[m[1]].total++;
  }
});
const badDup = Object.keys(tally).filter(a => tally[a].total > 1 && LIST_DUP.indexOf(a) < 0)
  .map(a => a + "×" + tally[a].total);
ok(badDup.length === 0, "无功能型重复入口（列表型白名单除外）", badDup.join(" "));

console.log("\n== 八、全站视图无脏数据 ==");
Object.keys(ALL).forEach(k => {
  ok(!/undefined|NaN|\[object Object\]/.test(ALL[k]), k + " 视图无 undefined/NaN");
});

console.log("\n===== 去重专项：" + (fail === 0 ? "全部通过（" + pass + " 项）" : fail + " 项失败 / " + pass + " 项通过") + " =====");
process.exit(fail === 0 ? 0 : 1);
