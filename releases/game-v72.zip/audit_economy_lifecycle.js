// v0.54.5 生命周期资源经济诊断：复用当前源码成本/产出函数，不修改游戏状态或平衡参数。
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=__dirname,store={};
global.localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=String(v),removeItem:k=>delete store[k]};
global.window={addEventListener:()=>{}};global.document={hidden:false};global.confirm=()=>true;
function load(f){vm.runInThisContext(fs.readFileSync(path.join(root,f),'utf8'),{filename:f});}
load('js/config.js');load('js/state.js');load('js/inventory.js');load('js/npc.js');load('js/dispatch.js');load('js/build.js');load('js/realm.js');load('js/artifact.js');load('js/gongfa.js');
global.stableMult=()=>1;global.officeBonus=()=>0;global.dynastyFolkMult=()=>1;global.fieldTempleLv=()=>0;global.fieldMineLv=()=>0;global.fieldGardenLv=()=>0;global.blessed=()=>false;
S=defaultState();
const H=3600, DAY=86400;
const fmt=n=>Number(n).toFixed(2);
const rows=[];
for(let realm=0;realm<=10;realm++){
  const ch=Math.min(realm,CONFIG.CHAPTERS.length-1);
  S.realm=realm;S.disciples=Array.from({length:3},(_,i)=>({id:i+1,realm,layer:0,loyalty:80,specialty:'farm',bond:90}));
  S.mapTeam={[ch]:[1,2,3]};S.clearedMaps={[ch]:true};S.fieldVein={};S.fieldMine={};S.fieldGarden={};S.lostFields={};
  const r=dispatchRate(ch);
  rows.push({realm,chapter:ch+1,stone:r.stone*H,qi:r.qi*H,herb:r.herb*H,mat:r.material*H,folk:r.folk*H});
}
// 成本曲线均调用现有项目函数/配置；不模拟随机成功率为确定产出。
const build=[0,1,2,3,4,5].map(lv=>({from:lv,to:lv+1,stone:CONFIG.buildingCost(lv)}));
const field=[0,1,2,3,4].map(lv=>({from:lv,to:lv+1,stone:fieldBuildCost(lv)}));
const forge=CONFIG.ARTIFACT_TIERS.map(t=>({tier:t.tier,material:forgeCost(t.tier).material,stone:forgeCost(t.tier).stone,refineMaterial:refineCost(t.tier),engraveMaterial:engraveCost({tier:t.tier}).mat,engraveStone:engraveCost({tier:t.tier}).stone}));
const recruit=[0,1,2,3,4,5,6,7].map(n=>({disciple:n+1,stone:CONFIG.recruitCost(n),folk:CONFIG.DISCIPLE_FOLK_COST}));
const sectBase=CONFIG.SECT.BASE_STONE;
const sectUps=Array.from({length:CONFIG.SECT.MAX_LV-1},(_,i)=>Math.floor(CONFIG.SECT.UP_STONE*Math.pow(1.5,i+1)));
const realmLabels=CONFIG.REALMS;
const lines=[];
lines.push('# v0.54.5 P1：全生命周期资源经济诊断');lines.push('');
lines.push('## 口径与限制');lines.push('');
lines.push('- 产出调用当前源码 `dispatchRate()`；成本调用 `CONFIG.buildingCost()`、`fieldBuildCost()`、`forgeCost()`、`refineCost()`、`engraveCost()`、`CONFIG.recruitCost()`。');
lines.push('- 驻守样本：每个境界 3 名同境界弟子，忠诚 80、灵植专精、情谊 90；每处秘境单独计算。章节映射 `min(境界索引, 第7章)`。');
lines.push('- 不叠加宗门/王朝/官职/庇护/安定度/灵脉/矿场/药圃加成；因此是中性基准，不代表极限经营配置。');
lines.push('- 这是“资源流入 + 单次行为成本”的生命周期诊断，不把所有玩家必然会做的次数伪装成固定消耗，也不把灵气、悟道、特产等不同资源折算成灵石。随机炼器只列单次投入，不把成功率误当作确定产物。');
lines.push('');
lines.push('## 一、全境界驻守资源流入');lines.push('');
lines.push('| 境界 | 秘境 | 灵石/小时 | 灵气/小时 | 灵草/小时 | 灵材/小时 | 凡人/小时 |');lines.push('|---|---:|---:|---:|---:|---:|---:|');
for(const r of rows)lines.push(`| ${realmLabels[r.realm]} | ${r.chapter} | ${fmt(r.stone)} | ${fmt(r.qi)} | ${fmt(r.herb)} | ${fmt(r.mat)} | ${fmt(r.folk)} |`);
lines.push('');lines.push('## 二、可复核的单次消耗曲线');lines.push('');
lines.push('### 洞府建筑升级（灵石）');lines.push('');lines.push('| 当前等级 → 目标等级 | 灵石 |');lines.push('|---|---:|');for(const x of build)lines.push(`| ${x.from} → ${x.to} | ${x.stone} |`);
lines.push('');lines.push('### 秘境灵脉/矿场/药圃升级（共用成本函数，另需凡人劳役）');lines.push('');lines.push('| 当前等级 → 目标等级 | 灵石 |');lines.push('|---|---:|');for(const x of field)lines.push(`| ${x.from} → ${x.to} | ${x.stone} |`);
lines.push('');lines.push('### 弟子招募');lines.push('');lines.push('| 招募序号 | 灵石 | 凡人 |');lines.push('|---:|---:|---:|');for(const x of recruit)lines.push(`| 第 ${x.disciple} 名 | ${fmt(x.stone)} | ${x.folk} |`);
lines.push('');lines.push('### 法宝制造、升阶与器纹');lines.push('');lines.push('| 品阶 | 炼制灵材 | 炼制灵石 | 升阶灵材（另需同类型同品阶祭品） | 单条器纹灵材 | 单条器纹灵石 |');lines.push('|---|---:|---:|---:|---:|---:|');for(const x of forge)lines.push(`| ${CONFIG.ARTIFACT_TIERS[x.tier-1].name} | ${x.material} | ${x.stone} | ${x.refineMaterial} | ${x.engraveMaterial} | ${x.engraveStone} |`);
lines.push('');lines.push('### 宗门');lines.push('');lines.push(`- 立宗一次性成本：灵石 ${sectBase} + 当前最高已探明章节特产 ${CONFIG.SECT.BASE_SPC}。`);lines.push(`- 后续升级灵石成本（第2级起）：${sectUps.join('、')}；每次另需特产 ${CONFIG.SECT.UP_SPC}。`);
lines.push('');lines.push('## 三、资源回本时间示例');lines.push('');
lines.push('以下只用“单秘境 3 名弟子”的驻守灵石/灵材/灵草流入除成本，表示理论累计流入达到单次成本所需时间；并非净利润或玩家真实可支配时间，因未扣除其他消耗、上限、离线时长限制与资源竞争。');
lines.push('');lines.push('| 境界 | 炼制凡品灵宝的灵石成本回本 | 炼制仙器灵石成本回本 | 仙器灵材成本回本 |');lines.push('|---|---:|---:|---:|');
for(const r of rows){const t1=forge[0],t6=forge[5];lines.push(`| ${realmLabels[r.realm]} | ${fmt(t1.stone/(r.stone/H))} 小时 | ${fmt(t6.stone/(r.stone/H))} 小时 | ${fmt(t6.material/(r.mat/H))} 小时 |`);}
lines.push('');lines.push('## 四、诊断结论');lines.push('');
lines.push('1. **灵石是主要通用建设/制造成本，但单次炼器成本随品阶陡增**：仙器单次炼制需 24,000 灵石与 96 灵材；炼制失败仍损失灵材，灵石仅按配置返还部分。高品阶资源压力主要来自灵材与重复尝试，而不是只看灵石回本。');
lines.push('2. **法宝养成存在持续材料消耗口**：升阶还需同类型同品阶祭品与灵材；器纹按品阶线性增加灵材/灵石；温养固定每级 30 灵材+300 灵石（上限10级）。单件法宝完整养成成本会因玩家选择而异，不能指定成统一“必需消耗”。');
lines.push('3. **秘境建设同时占用灵石与凡人劳役**：灵脉、矿场、药圃共用指数成本曲线；矿工/药农/灵脉师还会被本地聚落人口约束。仅比较灵石成本会低估建设门槛。');
lines.push('4. **弟子扩编是递增灵石成本 + 凡人机会成本**：每招一人额外消耗 1 名凡人，后续招募灵石成本按 1.5 倍递增；因此凡人增长和本地劳役分配会成为中后期约束。');
lines.push('5. **丹药并非单一资源 sink**：炼丹房持续消耗灵草产出培元丹；玩家服用丹药会消耗成品，但手动丹方炼制、丹药使用频率依玩家选择变化。当前模型只把灵田—炼丹房连续流量作为已验证生产链，不臆测玩家每小时炼制次数。');
lines.push('6. **宗门消耗是阶段性门槛**：立宗需3处驻守领地、5000灵石与特产；升级持续消耗灵石和特产，但其属性收益与经营加成应放在下一阶段的收益侧一起评估。');
lines.push('');lines.push('## 五、下一轮应补齐的真实数据');lines.push('');
lines.push('- 玩家行为日志/可重复情景：每境界平均秘境驻守时长、建筑等级路径、法宝炼制尝试数、升阶/洗练/器纹/温养次数、弟子招募数、坊市买卖量。');
lines.push('- 完整产出侧：洞府灵田、炼丹房、秘境驻守、矿场/药圃/灵脉、离线结算上限、势力与官职加成统一按真实 tick 叠加。');
lines.push('- 完整消耗侧：丹方手动炼制、功法领悟/悟道、经脉与丹田、弟子培养、宗门/王朝、坊市净交易、法宝全养成链。');
lines.push('- 在上述数据齐备前，不建议改基础倍率。先做代表性“保守/常规/重经营”三条可复现路线，再比较每阶段库存变化。');
lines.push('');lines.push('## 复现');lines.push('');lines.push('```bash');lines.push('node audit_economy_lifecycle.js');lines.push('```');
const out=path.join(root,'..','docs','v0.54.5_P1_全生命周期资源经济诊断.md');fs.writeFileSync(out,lines.join('\n')+'\n');console.log(lines.join('\n'));
