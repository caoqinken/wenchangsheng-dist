// ============================================================
// 《问长生》核心逻辑测试（Node，mock 浏览器）
// 覆盖：存档迁移(→v5) + v0.3.0 回归 + v0.4.x 世界/弟子/经济/事件链
//      + v0.5.0 渡劫机制
// 运行：node test_logic.js
// ============================================================
const fs = require("fs");
const path = require("path");
const vm = require("vm");

// ---- mock 浏览器全局 ----
const store = {};
global.localStorage = {
  getItem: k => (k in store ? store[k] : null),
  setItem: (k, v) => { store[k] = String(v); },
  removeItem: k => { delete store[k]; },
};
global.window = { addEventListener: () => {} };
global.document = { hidden: false };
global.confirm = () => true;
global.location = { reload: () => {} };
global.console = console;

let mockRandom = 0.99; // 默认不触发随机事件
Math.random = () => mockRandom;

function load(f) {
  const code = fs.readFileSync(path.join(__dirname, f), "utf8");
  vm.runInThisContext(code, { filename: f });
}

let pass = 0, fail = 0;
function assert(name, cond) {
  if (cond) { pass++; console.log("  [PASS] " + name); }
  else { fail++; console.log("  [FAIL] " + name + "  -> realm=" + S.realm + " layer=" + S.layer + " qi=" + S.qi + " stone=" + S.stone + " rep=" + S.reputation + " tribFails=" + S.tribFails); }
}

// ===== 阶段 1：存档迁移（旧版本 → v5）=====
console.log("== 1. 存档迁移 ==");
store["wenchangsheng_save_v1"] = JSON.stringify({
  realm: 3, layer: 2, qi: 12345, stone: 500, bestStage: 7,
  disciples: 2, assigned: { farm: 1 },
});
load("js/config.js");
load("js/state.js");
load("js/inventory.js");   // v0.37.0 储物法器（容器/堆叠唯一真源）
load("js/gongfa.js");
load("js/avatar.js");
load("js/pet.js");
assert("旧单档不再自动继承（v0.25.0 清档决策，realm 归零）", S.realm === 0 && S.version === SAVE_VERSION);
assert("新档默认设置字段完整", S.settings && S.settings.combatSpeed === 1 && S.settings.reducedMotion === false && S.settings.textScale === "normal");
assert("未建角时 playerName 为空", S.playerName === null);
const _mig = migrateState(JSON.parse(store["wenchangsheng_save_v1"]));
assert("旧档迁移默认无待结算引魔香", _mig.huntingIncense === 0);
const _migIncBad = migrateState({ version: 15, huntingIncense: "0" });
assert("异常字符串引魔香状态不会被误判为已点燃", _migIncBad.huntingIncense === 0);
assert("迁移函数仍可处理 v1 档（导入路径）", _mig.realm === 3 && _mig.version === SAVE_VERSION);
assert("disciples 数字迁移为弟子数组", Array.isArray(_mig.disciples) && _mig.disciples.length === 2);
assert("弟子对象字段完整", _mig.disciples[0] && _mig.disciples[0].name && typeof _mig.disciples[0].loyalty === "number" && _mig.disciples[0].assignedTo === null);
assert("旧 assigned 字段已移除", _mig.assigned === undefined);
assert("迁移补充势力与时间字段", _mig.factions && _mig.factions.qingyun && _mig.gameTime.year === 1);
assert("迁移补充坊市与渡劫丹市价", _mig.market && _mig.market.pill === CONFIG.MARKET_BASE.pill && _mig.market.tribPill === CONFIG.MARKET_BASE.tribPill);
assert("迁移补充渡劫字段", _mig.tribPills === 0 && _mig.tribPillBuff === 0 && _mig.tribFails === 0);
assert("迁移补充法宝字段", _mig.materials === 0 && Array.isArray(_mig.artifacts) && _mig.equipped.attack === null);
assert("迁移补充灵材市价", _mig.market.material === CONFIG.MARKET_BASE.material);
assert("旧档迁移补齐设置默认值", _mig.settings && _mig.settings.combatSpeed === 1 && _mig.settings.textScale === "normal");
assert("旧档迁移补齐气息战斗/功法装备结构", _mig.yungongRatio === 0 && _mig.gongfaEquip.xin === "changsheng" && Array.isArray(_mig.shuSlots) && _mig.wudao === 0);
const _oldNoDisciple = migrateState({ version: 13, playerName: "旧档无弟子", disciples: [] });
assert("旧档无弟子时一次性补发五名开山弟子", _oldNoDisciple.disciples.length === 5 && _oldNoDisciple.disciples[0].name === "守山童子" && _oldNoDisciple.starterDiscipleGranted === true && _oldNoDisciple.starterDiscipleCount === 5);
const _oldOneStarter = migrateState({ version: 15, playerName: "v15旧档", starterDiscipleGranted: true, disciples: [{ id: 9, name: "守山童子", origin: "开山赠礼", aptitude: 1 }] });
assert("v0.54.1 已有一名赠礼弟子的旧档只补足到五名", _oldOneStarter.disciples.filter(x => x.origin === "开山赠礼").length === 5 && _oldOneStarter.disciples.some(x => x.id === 9));
const _starterLost = migrateState({ version: 16, starterDiscipleGranted: true, starterDiscipleCount: 5, disciples: [{ id: 1, name: "守山童子", origin: "开山赠礼" }] });
assert("已迁移的新档不会因弟子离山而重复补发开局赠礼", _starterLost.disciples.length === 1);
const _oldFolkSettlements = migrateState({ version: 15, folk: 12, clearedMaps: { 0: true, 1: true }, mapTeam: { 0: [1], 1: [2] }, disciples: [] });
assert("旧档凡人总数迁移为各驻守秘境聚落且不丢失", _oldFolkSettlements.folk === 12 && _oldFolkSettlements.fieldSettlements["0"].population + _oldFolkSettlements.fieldSettlements["1"].population === 12);
const _oldGongfa = migrateState({ version: 13, playerName: "旧功法档", gongfa: 3, disciples: [{id:1,name:"旧弟子"}] });
assert("旧功法总纲按 100 倍折算为悟道补偿", _oldGongfa.wudao === 300);

// 重置为干净状态，加载其余模块
S = defaultState();
S.lastOnline = Date.now();
load("js/artifact.js");
load("js/idle.js");
load("js/combat.js");
load("js/build.js");
load("js/dan.js");
load("js/guide.js");
load("js/time.js");
load("js/faction.js");
load("js/event.js");
load("js/npc.js");
load("js/economy.js");
load("js/codex.js");
load("js/tower.js");
load("js/field.js");
load("js/dispatch.js");
load("js/dao.js");
load("js/tuna.js");
load("js/daily.js");
load("js/specialty.js");
load("js/ancient.js");
load("js/meridians.js");
load("js/realm.js");
load("js/recruit.js");
load("js/staff.js");
load("js/field_education.js");
load("js/sect.js");
load("js/element.js");
load("js/life.js");

// ===== 开局弟子与设置回归 =====
console.log("== 开局弟子与设置 ==");
const _starterCreate = createCharacter("开局弟子测试", "qingshan", "fa");
assert("创建新道号成功", _starterCreate.ok === true);
assert("新道号开局赠送五名弟子且首名为守山童子", S.disciples.length === 5 && S.disciples[0].name === "守山童子" && S.disciples.every(d => d.origin === "开山赠礼"));
assert("开局弟子名额与五人赠礼匹配，不出现超额开局", S.disciples.length === 5 && discipleSlots() >= 5);
assert("五名赠送弟子均为凡俗初阶且可派遣", S.disciples.every(d => d.realm === 0 && d.layer === 0 && d.aptitude === 1 && d.assignedTo === null));
assert("开局赠礼标记来源且不额外赠送凡人", S.disciples.every(d => d.origin === "开山赠礼") && S.folk === 0);
S.clearedMaps = { 0: true };
assert("开局赠送弟子可用于首次秘境驻守", assignDispatch(0, S.disciples[0].id).ok === true);
// v0.54.2：师尊培养与工作历练成长
const _growDisciple = S.disciples[1];
S.qi = CONFIG.DISCIPLE_GROWTH.QI_COST;
const _qiTrain = trainDisciple(_growDisciple.id, "qi");
assert("消耗灵气可培养弟子并增加修为", _qiTrain.ok && S.qi === 0 && _growDisciple.cultivation === CONFIG.DISCIPLE_GROWTH.QI_EXP);
gainItem("pill", 1);
const _pillTrain = trainDisciple(_growDisciple.id, "pill");
assert("消耗培元丹可培养弟子并增加更多修为", _pillTrain.ok && _growDisciple.cultivation === CONFIG.DISCIPLE_GROWTH.QI_EXP + CONFIG.DISCIPLE_GROWTH.PILL_EXP && invCount("pill") === 0);
assert("弟子培养不设每日上限且灵气不足时不扣资源", trainDisciple(_growDisciple.id, "qi").ok === false && S.qi === 0);
S.qi = CONFIG.DISCIPLE_GROWTH.QI_COST * 5;
let _unlimitedQi = true;
for (let i = 0; i < 5; i++) _unlimitedQi = trainDisciple(_growDisciple.id, "qi").ok && _unlimitedQi;
assert("灵气充足时可连续培养超过每日30修为", _unlimitedQi && S.qi === 0 && (_growDisciple.layer * CONFIG.DISCIPLE_GROWTH_THRESHOLD + _growDisciple.cultivation) >= CONFIG.DISCIPLE_GROWTH.QI_EXP * 8);
gainItem("pill", 5);
let _unlimitedPill = true;
for (let i = 0; i < 5; i++) _unlimitedPill = trainDisciple(_growDisciple.id, "pill").ok && _unlimitedPill;
assert("培元丹充足时可连续培养超过每日30修为", _unlimitedPill && invCount("pill") === 0);
assert("连续培养按实际资源逐次扣除且无每日计数依赖", _growDisciple.trainingExp === undefined && _growDisciple.trainingDate === undefined);
assert("灵气培养成本与经验配置保持不变", CONFIG.DISCIPLE_GROWTH.QI_COST === 500 && CONFIG.DISCIPLE_GROWTH.QI_EXP === 10);
_growDisciple.realm = CONFIG.REALMS.length - 1; _growDisciple.layer = CONFIG.LAYERS_PER_REALM - 1; _growDisciple.cultivation = 0; S.qi = CONFIG.DISCIPLE_GROWTH.QI_COST;
const _maxTrain = trainDisciple(_growDisciple.id, "qi");
assert("弟子达到最高境界后拒绝培养且不扣资源", !_maxTrain.ok && S.qi === CONFIG.DISCIPLE_GROWTH.QI_COST);
// v0.55.3：弟子任务风险按任务类型进入真实成功率，并在派遣时锁定。
const _missionProbe = { aptitude: 1, realm: 0 };
const _clearRate = missionRate(_missionProbe, "clear");
const _escortRate = missionRate(_missionProbe, "escort");
const _preachRate = missionRate(_missionProbe, "preach");
assert("弟子任务成功率遵循清剿/护送/传道各自风险梯度", _clearRate < _escortRate && _escortRate < _preachRate);
assert("任务成功率在资质与境界提升后提高且不超过95%", missionRate({ aptitude: 5, realm: 10 }, "preach") === 0.95 && missionRate({ aptitude: 5, realm: 0 }, "clear") > _clearRate);
const _missionStateBeforeLockTest = S;
S = defaultState();
S.stamina = CONFIG.MAX_STAMINA;
const _missionLockD = createDisciple();
S.disciples.push(_missionLockD);
_missionLockD.aptitude = 1; _missionLockD.realm = 0;
const _lockedMission = missionStart("escort", null, _missionLockD.id);
const _lockedRate = _lockedMission.ok ? S.missions[0].successRate : -1;
_missionLockD.aptitude = 5; _missionLockD.realm = 10;
if (_lockedMission.ok) {
  S.missions[0].endAt = Date.now() - 1;
  const _oldRandomForLock = Math.random;
  Math.random = () => (_lockedRate + 0.01);
  missionsTick();
  Math.random = _oldRandomForLock;
}
assert("任务成功率在派遣时锁定，不因任务期间弟子属性变化而漂移", _lockedMission.ok && S.missions.some(m => m.success === false));
S = _missionStateBeforeLockTest;

// v0.55.2：最大培养按资源与境界剩余容量自动取最小值。
_growDisciple.realm = 0; _growDisciple.layer = 0; _growDisciple.cultivation = 0;
S.qi = CONFIG.DISCIPLE_GROWTH.QI_COST * 5;
const _batchQi = trainDisciple(_growDisciple.id, "qi", "max");
assert("最大灵气培养按可用资源批量扣除并统一结算", _batchQi.ok && _batchQi.count === 5 && _batchQi.gain === 50 && S.qi === 0 && _growDisciple.layer === 1);
gainItem("pill", 5);
_growDisciple.cultivation = 40;
const _batchPill = trainDisciple(_growDisciple.id, "pill", "max");
assert("最大丹药培养只消耗突破下一层所需数量，不浪费余丹", _batchPill.ok && _batchPill.count === 5 && _batchPill.gain === 100 && invCount("pill") === 0 && _growDisciple.layer === 3 && _growDisciple.cultivation === 40);
const _noBatchResource = trainDisciple(_growDisciple.id, "qi", "max");
assert("最大培养资源不足时不扣资源也不增加修为", !_noBatchResource.ok && _growDisciple.cultivation === 40);
// 闲修、洞府职守、秘境驻守、任务的日常历练速度不同。
const _workD = S.disciples[2];
_workD.mood = 100; _workD.loyalty = 100; _workD.cultivation = 0; _workD.assignedTo = null;
S.mapTeam = {}; S.missions = [];
npcTick();
assert("闲修弟子按资质基础速度成长", Math.abs(_workD.cultivation - 1) < 1e-9);
_workD.cultivation = 0; _workD.assignedTo = "farm"; npcTick();
assert("洞府职守比闲修获得更多历练", Math.abs(_workD.cultivation - CONFIG.DISCIPLE_GROWTH.BUILD_MULT) < 1e-9);
_workD.cultivation = 0; _workD.assignedTo = null; S.clearedMaps = { 0: true }; S.mapTeam = { 0: [_workD.id] }; npcTick();
assert("秘境驻守比洞府职守获得更多历练", Math.abs(_workD.cultivation - CONFIG.DISCIPLE_GROWTH.DISPATCH_MULT) < 1e-9);
_workD.cultivation = 0; S.mapTeam = {}; S.stamina = CONFIG.MAX_STAMINA; mockRandom = 0;
const _missionGrowthStart = missionStart("clear", 0, _workD.id);
S.missions[S.missions.length - 1].endAt = Date.now() - 1;
const _missionGrowthBefore = _workD.cultivation;
missionsTick();
assert("完成弟子任务按任务类型获得额外修为", _missionGrowthStart.ok && _workD.cultivation >= _missionGrowthBefore + CONFIG.MISSION.TYPES[0].growth && S.missions.some(m => m.success === true));
mockRandom = 0.99;
S = defaultState();
refreshDiscipleSeq();

// ===== 阶段 2：回归 v0.3.0 =====
console.log("== 2. 回归 v0.3.0 闭环 ==");
assert("初始为炼气1层", S.realm === 0 && S.layer === 0);
assert("初始修炼速率=1×道途系数（无庇护）", Math.abs(cultivationRate() - daoDef(S.dao).cult) < 1e-6);
S.qi = 0; idleTick(100);
assert("挂机100秒累积100灵气×道途", Math.abs(S.qi - 100 * daoDef(S.dao).cult) < 1);
const r1 = doBreak();
assert("境内升层必定成功（炼气1→2）", r1.ok === true && !r1.trib && S.realm === 0 && S.layer === 1);
S.realm = 1; S.layer = 0; S.qi = 0;
assert("筑基1层速率=5×道途系数", Math.abs(cultivationRate() - 5 * daoDef(S.dao).cult) < 1e-6);
S.realm = 0; S.layer = 0; S.stamina = 30; S.stone = 0; S.bestStage = 0;
const br = startBattle(0);
assert("挑战0关胜利且掉落灵石", br.ok && br.win && S.stone > 0);
assert("通关进度推进", S.bestStage === 1);
S.buildings.farm = 2; invSet("herb", 0); buildTick(10);
assert("灵田10秒产10灵草（无弟子加成）", Math.abs(S.herbs - 0.5 * 2 * 10) < 0.01);

// ===== 阶段 3：时间/势力/庇护 =====
console.log("== 3. 时间与势力 ==");
const day0 = S.gameTime.day;
timeTick(60);
assert("60秒推进1天", S.gameTime.day === day0 + 1);
const qBefore = S.factions.qingyun.power;
factionTick();
assert("势力实力随时间演化", S.factions.qingyun.power !== qBefore || S.factions.qingyun.resource !== 100);
S.factions.qingyun.relation = 50;
assert("青云门庇护生效", blessed("qingyun") === true);
S.factions.qingyun.relation = 0;

// ===== 阶段 4：弟子系统 =====
console.log("== 4. 弟子系统 ==");
S.stone = 1000; S.buildings.recruit = 2;
S.folk = 100;   // v0.28.0：收徒需凡人
const rRec = recruitDisciple();
assert("招募生成弟子个体", rRec.ok === true && S.disciples.length === 1);
while (S.disciples.length < discipleSlots()) { S.stone = 1e6; S.folk = 100; recruitDisciple(); }
assert("弟子槽上限生效（名额随经营成长）", S.disciples.length === discipleSlots() && recruitDisciple().ok === false);
const rAs = assignDisciple("farm");
assert("委派设置 assignedTo", rAs.ok === true && S.disciples[0].assignedTo === "farm");
S.buildings.farm = 2;
assert("弟子委派提升建筑产出", buildingOutput("farm") > 0.5 * 2);
unassignDisciple("farm");
const d0 = S.disciples[0];
d0.aptitude = 3; d0.mood = 100; d0.cultivation = 48; d0.layer = 0; d0.realm = 0;
npcTick();
assert("弟子自主修炼满自动升层", d0.layer === 1);
S.disciples = [{ id: 99, name: "测试", aptitude: 1, realm: 0, layer: 0, loyalty: 10, mood: 40, assignedTo: null, cultivation: 0 }];
mockRandom = 0.05;
npcTick();
assert("低忠诚弟子离山", S.disciples.length === 0);
mockRandom = 0.99;

// ===== 阶段 5：动态经济 =====
console.log("== 5. 动态经济 ==");
const baseHerb = CONFIG.MARKET_BASE.herb;
S.market.herb = baseHerb;
economyTick();
assert("价格波动保持在区间内", S.market.herb >= baseHerb * CONFIG.MARKET_RANGE[0] && S.market.herb <= baseHerb * CONFIG.MARKET_RANGE[1]);
marketShock("herb", 1.6);
assert("事件冲击推高灵草价", S.market.herb > baseHerb);
S.stone = 1000; invSet("herb", 0);
const rBuy = buyHerb();
assert("买入灵草扣灵石加库存", rBuy.ok && S.herbs === CONFIG.TRADE_HERB_BATCH);
invSet("pill", 5);
const pillPriceBefore = S.market.pill;
const stoneBeforeSell = S.stone;
const rSell = sellPill();
assert("卖出丹药得灵石且压低价", rSell.ok && S.pills === 4 && S.stone > stoneBeforeSell && S.market.pill < pillPriceBefore);

// ===== 阶段 6：魔渊入侵事件链 =====
console.log("== 6. 魔渊入侵事件链 ==");
S.factions.moyuan.power = 80; S.factions.qingyun.power = 50;
S.activeEvent = { chain: "invasion", stage: 1, flags: {} };
S.stone = 500; S.stamina = 30;
const qRel0 = S.factions.qingyun.relation;
const herbBeforeChain = S.market.herb;
const rWarn = resolveEvent("warn");
assert("阶段1传信扣灵石", rWarn.ok === true && S.stone === 480);
assert("事件进入阶段2且未关闭", S.activeEvent !== null && S.activeEvent.stage === 2);
const moyBefore = S.factions.moyuan.power;
const repBefore = S.reputation;
const rHelp = resolveEvent("help");
assert("阶段2援助并终局结算", rHelp.ok === true && S.activeEvent === null);
assert("两阶段叠加：关系+40、声望+15", S.factions.qingyun.relation === qRel0 + 40 && S.reputation === repBefore + 15);
assert("大胜结局削弱魔渊宗-10", S.factions.moyuan.power === moyBefore - 10);
assert("战乱冲击灵草涨价", S.market.herb > herbBeforeChain);

// ===== 阶段 7：渡劫机制 =====
console.log("== 7. 渡劫机制 ==");
// 7.1 成功率计算
S.realm = 0; S.layer = 0; S.tribPillBuff = 0; S.tribFails = 0; S.reputation = 0; S.gongfa = 0;
S.factions.qingyun.relation = 0;
assert("基础渡劫成功率=85%", Math.abs(tribulationRate() - CONFIG.TRIB_BASE_RATE) < 1e-9);
S.realm = 2;
assert("每深入一境成功率-3%", Math.abs(tribulationRate() - (CONFIG.TRIB_BASE_RATE - 2 * CONFIG.TRIB_REALM_DECAY)) < 1e-9);
S.realm = 0;
// 7.2 跨境渡劫成功路径
S.layer = 8; S.qi = 1e9;
mockRandom = 0.5;   // < 0.85 → 成功
const rTrib = doBreak();
assert("渡劫成功晋升筑基", rTrib.trib === true && rTrib.success === true && S.realm === 1 && S.layer === 0);
assert("渡劫成功声望+5且计数清零", S.reputation === CONFIG.TRIB_SUCCESS_REP && S.tribFails === 0);
// 7.3 失败路径：损灵气30%
S.realm = 1; S.layer = 8; S.qi = 1e7; S.tribFails = 0;
mockRandom = 0.99;   // > 0.82 → 失败
const costTrib = CONFIG.breakCost(globalLayer(1, 8));
const qiAfterCost = 1e7 - costTrib;
const rFail = doBreak();
assert("渡劫失败损失剩余灵气30%", rFail.trib === true && rFail.success === false && Math.abs(S.qi - qiAfterCost * (1 - CONFIG.TRIB_FAIL_QI_LOSS)) < 1);
assert("失败计数+1", S.tribFails === 1);
// 7.4 保底：连败2次后第3次必成（v0.29.0：先验证元神受损拦截，再模拟等待结束）
S.tribFails = CONFIG.TRIB_PITY - 1; S.layer = 8; S.realm = 1; S.qi = 1e9;
const _rHurt = doBreak();
assert("元神受损期间拒绝渡劫", _rHurt.ok === false && /元神受损/.test(_rHurt.msg) && S.realm === 1);
S.soulHurtUntil = 0;   // 模拟已过 30 分钟
mockRandom = 0.99;
const rPity = doBreak();
assert("心境圆融保底必成", rPity.trib === true && rPity.success === true && rPity.pity === true && S.realm === 2);
// 7.5 渡劫丹闭环：坊市购买→服用加成→渡劫消耗
S.stone = 5000;
const rBuyTrib = buyTribPill();
assert("坊市购入渡劫丹", rBuyTrib.ok === true && S.tribPills === 1);
const rateBefore = tribulationRate();
useTribPill();
assert("服用渡劫丹成功率+15%", Math.abs(tribulationRate() - rateBefore - CONFIG.TRIB_PILL_BONUS) < 1e-9);
assert("渡劫丹入库消耗/进入buff", S.tribPills === 0 && S.tribPillBuff === 1);
S.layer = 8; S.qi = 1e9; mockRandom = 0.5;
S.soulHurtUntil = 0;   // 清除元神受损（v0.29.0）
doBreak();
assert("渡劫后丹药buff消耗", S.tribPillBuff === 0);
// 7.6 庇护加成
S.tribPillBuff = 0; S.factions.qingyun.relation = 50;
const rateNoBless = CONFIG.TRIB_BASE_RATE - S.realm * CONFIG.TRIB_REALM_DECAY;
assert("青云门庇护渡劫+10%", Math.abs(tribulationRate() - rateNoBless - CONFIG.TRIB_BLESS_BONUS) < 1e-9);
S.factions.qingyun.relation = 0;

// ===== 阶段 8：法宝品阶系统（v0.6.0）=====
console.log("== 8. 法宝品阶系统 ==");
mockRandom = 0.99;

// 8.1 炼制品阶门槛（由炼器坊等级决定）
S = defaultState(); S.buildings.forge = 0;
assert("炼器坊Lv0仅可炼凡品", forgeMaxTier() === 1);
S.buildings.forge = 4;
assert("炼器坊Lv4可炼至宝器(3阶)", forgeMaxTier() === 3);
S.buildings.forge = 10;
assert("炼器坊Lv10可炼至仙器(6阶)", forgeMaxTier() === 6);

// 8.2 炼制成功率公式
S.buildings.forge = 0;
assert("凡品基础炼制成功率90%", Math.abs(forgeRate(1) - CONFIG.ARTIFACT_FORGE_BASE_RATE) < 1e-9);
assert("每高一阶成功率-12%", Math.abs(forgeRate(3) - (0.90 - 2 * 0.12)) < 1e-9);
S.buildings.forge = 20;
assert("炼器坊加成封顶且不超98%", Math.abs(forgeRate(1) - 0.98) < 1e-9);

// 8.3 前置拦截
S = defaultState(); S.buildings.forge = 2; invSet("material", 0); S.stone = 1e7;
assert("灵材不足禁止炼制", forgeArtifact(1).ok === false);
invSet("material", 100); S.stone = 0;
assert("灵石不足禁止炼制", forgeArtifact(1).ok === false);
S.stone = 1e7;
assert("超出炼器坊品阶上限禁止炼制", forgeArtifact(4).ok === false);

// 8.4 炼制成功：扣料 + 入库 + 属性区间
S = defaultState(); S.buildings.forge = 2; invSet("material", 100); S.stone = 1e6;
const c1 = forgeCost(1);
const matBefore = S.materials, stoneBefore = S.stone;
mockRandom = 0.1;   // < 0.90 → 成功
const rF = forgeArtifact(1);
assert("炼制成功入库法宝", rF.ok === true && rF.success === true && S.artifacts.length === 1);
assert("炼制扣除灵材与灵石", S.materials === matBefore - c1.material && S.stone === stoneBefore - c1.stone);
const newArt = S.artifacts[0];
assert("法宝品质浮动落在区间", newArt.roll >= CONFIG.ARTIFACT_ROLL_MIN && newArt.roll <= CONFIG.ARTIFACT_ROLL_MAX);
assert("法宝属性值=品阶基准×品质", Math.abs(artifactMain(newArt) - Math.round(tierInfo(1).main * newArt.roll * 1000) / 1000) < 1e-9);
assert("法宝具备血量副属性", newArt.hp > 0);
assert("法宝名称非空", typeof newArt.name === "string" && newArt.name.length > 0);

// 8.5 炼制失败：灵材损耗、返还50%灵石
S = defaultState(); S.buildings.forge = 2; invSet("material", 100); S.stone = 10000;
mockRandom = 0.999;  // > 0.90 → 失败
const matB2 = S.materials, stoneB2 = S.stone;
const rFf = forgeArtifact(1);
assert("炼制失败不入库", rFf.ok === true && rFf.success === false && S.artifacts.length === 0);
assert("炼制失败灵材损耗", S.materials === matB2 - CONFIG.ARTIFACT_TIERS[0].material);
assert("炼制失败返还50%灵石", S.stone === stoneB2 - CONFIG.ARTIFACT_TIERS[0].stone + Math.floor(CONFIG.ARTIFACT_TIERS[0].stone * 0.5));

// 8.6 装备与百分比加成（全周期有效性的核心验证）
S = defaultState();
S.artifacts = [{ id: 9001, name: "测试剑", tier: 1, type: "attack", atk: 0.20, def: 0, hp: 0.10, cult: 0, roll: 1 }];
const rEq = equipArtifact(9001);
assert("装备法宝写入对应槽位", rEq.ok === true && S.equipped.attack === 9001);
const pcA = playerCombat();
assert("攻击按百分比加成(10→12×道途)", Math.abs(pcA.attack - 12 * daoDef(S.dao).atk) < 1e-6);
assert("血量按百分比加成(100→110×道途)", Math.abs(pcA.hp - 110 * daoDef(S.dao).hp) < 1e-6);
S.realm = 3; S.layer = 0;
const baseAtkB = CONFIG.playerAttr(3, 0).attack;
assert("高境界法宝加成同样按比例生效", Math.abs(playerCombat().attack - baseAtkB * 1.2 * daoDef(S.dao).atk) < 1e-6);
S.realm = 0; S.layer = 0;

// 8.7 三槽独立 + 辅道法宝影响修炼
S.artifacts.push({ id: 9002, name: "测试珠", tier: 1, type: "support", atk: 0, def: 0, hp: 0, cult: 0.5, roll: 1 });
S.artifacts.push({ id: 9003, name: "测试甲", tier: 1, type: "defense", atk: 0, def: 0.30, hp: 0, cult: 0, roll: 1 });
equipArtifact(9002); equipArtifact(9003);
assert("三槽可同时装备互不覆盖", S.equipped.attack === 9001 && S.equipped.support === 9002 && S.equipped.defense === 9003);
assert("防御加成生效(5→6.5)", Math.abs(playerCombat().defense - 6.5) < 1e-6);
assert("辅道法宝提升修炼速率(+50%)", Math.abs(cultivationRate() - 1.5 * daoDef(S.dao).cult) < 1e-6);

// 8.8 同槽替换与卸下
S.artifacts.push({ id: 9004, name: "新剑", tier: 2, type: "attack", atk: 0.12, def: 0, hp: 0.06, cult: 0, roll: 1 });
const rEq2 = equipArtifact(9004);
assert("同槽替换并返回旧装备", rEq2.ok === true && rEq2.replaced && rEq2.replaced.id === 9001 && S.equipped.attack === 9004);
const rUnEq = unequipArtifact("attack");
assert("卸下法宝清空槽位", rUnEq.ok === true && S.equipped.attack === null);
assert("卸下后攻击加成消失", artifactBonus().atk === 0);

// 8.9 炼化升阶（成功）
S = defaultState(); invSet("material", 100);
S.artifacts = [
  { id: 11, name: "主剑", tier: 1, type: "attack", atk: 0.03, def: 0, hp: 0.015, cult: 0, roll: 1 },
  { id: 12, name: "祭剑", tier: 1, type: "attack", atk: 0.03, def: 0, hp: 0.015, cult: 0, roll: 1 },
];
assert("炼化候选=同型同阶祭品", refineCandidates(S.artifacts[0]).length === 1);
const matB3 = S.materials;
mockRandom = 0.1;   // < 0.60 → 成功
const rRf = refineArtifact(11, 12);
assert("炼化成功主法宝升一阶", rRf.ok === true && rRf.success === true && S.artifacts[0].tier === 2);
assert("炼化成功祭品消散", S.artifacts.length === 1 && S.artifacts[0].id === 11);
assert("炼化消耗灵材", S.materials === matB3 - refineCost(1));
assert("升阶后属性按新品阶重铸", Math.abs(artifactMain(S.artifacts[0]) - Math.round(tierInfo(2).main * S.artifacts[0].roll * 1000) / 1000) < 1e-9);

// 8.10 炼化失败：祭品仍消散、主法宝保留
S = defaultState(); invSet("material", 100);
S.artifacts = [
  { id: 21, name: "主", tier: 1, type: "attack", atk: 0.03, def: 0, hp: 0.015, cult: 0, roll: 1 },
  { id: 22, name: "祭", tier: 1, type: "attack", atk: 0.03, def: 0, hp: 0.015, cult: 0, roll: 1 },
];
mockRandom = 0.999; // > 0.60 → 失败
const rRfF = refineArtifact(21, 22);
assert("炼化失败主法宝保留原阶", rRfF.ok === true && rRfF.success === false && S.artifacts[0].tier === 1);
assert("炼化失败祭品仍消散", S.artifacts.length === 1);

// 8.11 炼化前置校验
S = defaultState(); invSet("material", 100);
S.artifacts = [
  { id: 31, name: "剑", tier: 1, type: "attack", atk: 0.03, def: 0, hp: 0.015, cult: 0, roll: 1 },
  { id: 32, name: "甲", tier: 1, type: "defense", atk: 0, def: 0.02, hp: 0.015, cult: 0, roll: 1 },
];
assert("异类型祭品被拒绝", refineArtifact(31, 32).ok === false);
S.artifacts[1] = { id: 33, name: "祭剑", tier: 2, type: "attack", atk: 0.06, def: 0, hp: 0.03, cult: 0, roll: 1 };
assert("异品阶祭品被拒绝", refineArtifact(31, 33).ok === false);
S.artifacts = [
  { id: 34, name: "仙剑", tier: 6, type: "attack", atk: 0.28, def: 0, hp: 0.14, cult: 0, roll: 1 },
  { id: 35, name: "仙剑2", tier: 6, type: "attack", atk: 0.28, def: 0, hp: 0.14, cult: 0, roll: 1 },
];
assert("仙器封顶不可再炼化", refineArtifact(34, 35).ok === false);

// 8.12 分解回收灵材
S = defaultState(); invSet("material", 0);
S.artifacts = [{ id: 41, name: "旧宝器", tier: 3, type: "attack", atk: 0.10, def: 0, hp: 0.05, cult: 0, roll: 1 }];
equipArtifact(41);
const rDis = dismantleArtifact(41);
const expectMat = Math.max(1, Math.floor(tierInfo(3).material * CONFIG.ARTIFACT_DISMANTLE_RATIO));
assert("分解返还灵材", rDis.ok === true && S.materials === expectMat);
assert("分解后法宝移除且自动卸下", S.artifacts.length === 0 && S.equipped.attack === null);

// 8.13 存档 v6 迁移：法宝与装备引用完整保留
const legacy = {
  version: 5, realm: 2, layer: 3, qi: 500, stone: 1000,
  artifacts: [
    { id: 7, name: "旧剑", tier: 2, type: "attack", atk: 0.06, def: 0, hp: 0.03, cult: 0, roll: 1 },
    { id: 8, name: "旧珠", tier: 1, type: "support", atk: 0, def: 0, hp: 0, cult: 0.03, roll: 1 },
  ],
  equipped: { attack: 7, support: 8 },
  materials: 5,
};
const mig = migrateState(JSON.parse(JSON.stringify(legacy)));
assert("v5→v12 保留法宝库", mig.artifacts.length === 2 && mig.version === SAVE_VERSION);
assert("v5→v7 保留装备引用", mig.equipped.attack === 7 && mig.equipped.support === 8);
assert("v5→v7 补齐缺失槽位与灵材市价", mig.equipped.defense === null && mig.market.material === CONFIG.MARKET_BASE.material);
assert("v5→v7 保留灵材存量", mig.materials === 5);
const mig2 = migrateState({ version: 6, artifacts: [], equipped: { attack: 999, defense: null, support: null } });
assert("迁移清理悬空装备引用", mig2.equipped.attack === null);

// 8.14 灵材经济与战斗掉落
S = defaultState(); S.stone = 10000; S.market.material = CONFIG.MARKET_BASE.material;
const rBM = buyMaterial();
assert("坊市买入灵材×10", rBM.ok === true && S.materials === CONFIG.MATERIAL_TRADE_BATCH);
assert("买入推高灵材价格", S.market.material > CONFIG.MARKET_BASE.material);
const stoneBeforeSellMat = S.stone;
const rSM = sellMaterial();
assert("坊市卖出灵材", rSM.ok === true && S.materials === 0 && S.stone > stoneBeforeSellMat);
economyTick();
assert("经济演化覆盖灵材且在区间内", S.market.material >= CONFIG.MARKET_BASE.material * CONFIG.MARKET_RANGE[0] && S.market.material <= CONFIG.MARKET_BASE.material * CONFIG.MARKET_RANGE[1]);
S = defaultState(); S.stamina = 30; invSet("material", 0);
mockRandom = 0.1;  // < 0.2 → 掉灵材
const rDrop = startBattle(0);
assert("战斗胜利可掉落灵材", rDrop.ok === true && rDrop.win === true && S.materials >= 1);
S = defaultState(); S.realm = 8; S.layer = 8; S.stamina = 30; invSet("material", 0);
mockRandom = 0.99;
const rBoss = startBattle(5);
assert("BOSS 必掉灵材×2", rBoss.ok === true && rBoss.win === true && S.materials === CONFIG.MATERIAL_BOSS_DROP);

// ===== 阶段 9：世界事件链扩展（v0.6.1）=====
console.log("== 9. 世界事件链扩展 ==");

// 9.1 冷却机制
S = defaultState();
assert("初始各事件链均无冷却", eventChainReady("beasttide") && eventChainReady("auction") && eventChainReady("demonraid"));
markChain("beasttide");
assert("标记后进入冷却", eventChainReady("beasttide") === false);
S.gameTime.day += CONFIG.EVENT_COOLDOWN_DAYS;
assert("冷却天数到达后恢复可触发", eventChainReady("beasttide") === true);

// 9.2 触发条件：拍卖会需散修关系达标
S = defaultState();
S.factions.sanxiu.relation = 0;
S.activeEvent = null;
mockRandom = 0.0;
eventTick();
assert("散修关系不足时不触发拍卖会", !S.activeEvent || S.activeEvent.chain !== "auction");
S = defaultState();
S.factions.sanxiu.relation = CONFIG.AUCTION_REL_MIN;
markChain("invasion"); markChain("beasttide"); markChain("demonraid");
S.activeEvent = null;
mockRandom = 0.0;
eventTick();
assert("关系达标可触发拍卖会", S.activeEvent !== null && S.activeEvent.chain === "auction");
assert("触发后写入冷却", S.eventCooldown.auction != null);

// 9.3 冷却期内不重复触发
S = defaultState();
S.factions.sanxiu.relation = 0;
S.activeEvent = null;
markChain("beasttide");
mockRandom = 0.0;
eventTick();
assert("冷却期内该链不再触发", S.activeEvent === null || S.activeEvent.chain !== "beasttide");

// 9.4 触发条件：魔道夺宝需持有法宝
S = defaultState();
S.artifacts = [];
markChain("invasion"); markChain("beasttide"); markChain("auction");
S.factions.sanxiu.relation = 0;
S.activeEvent = null;
mockRandom = 0.0;
eventTick();
assert("无法宝时不触发魔道夺宝", !S.activeEvent || S.activeEvent.chain !== "demonraid");
S = defaultState();
S.artifacts = [{ id: 1, name: "诱饵", tier: 1, type: "attack", atk: 0.03, def: 0, hp: 0.015, cult: 0, roll: 1 }];
S.factions.sanxiu.relation = 0;
markChain("invasion"); markChain("beasttide"); markChain("auction");
S.activeEvent = null;
mockRandom = 0.0;
eventTick();
assert("持有法宝可触发魔道夺宝", S.activeEvent !== null && S.activeEvent.chain === "demonraid");

// 9.5 拍卖会全流程（入场 → 竞价成功）
S = defaultState(); S.stone = 1000; invSet("material", 0);
S.factions.sanxiu.relation = 50;
S.activeEvent = { chain: "auction", stage: 1, flags: {} };
const stoneA = S.stone;
const rEnter = resolveEvent("enter");
assert("拍卖入场扣灵石并进入下一阶段", rEnter.ok === true && rEnter.next === true && S.stone === stoneA - CONFIG.AUCTION_ENTRY_COST);
assert("入场后事件仍挂起", S.activeEvent !== null && S.activeEvent.stage === 2);
const relBeforeAuc = S.factions.sanxiu.relation;
const matPriceBefore = S.market.material;
const matBid = S.materials;
mockRandom = 0.1;   // < 0.4+50*0.002=0.5 → 竞得
const rBid = resolveEvent("bid");
assert("拍卖竞得灵材", rBid.ok === true && rBid.win === true && S.materials === matBid + CONFIG.AUCTION_MATERIAL_REWARD);
assert("竞得后散修关系上升", S.factions.sanxiu.relation === relBeforeAuc + CONFIG.AUCTION_REL_WIN);
assert("灵材流入压低坊市价", S.market.material < matPriceBefore);
assert("拍卖终局后关闭事件", S.activeEvent === null);

// 9.6 拍卖会：竞价失手 / 不入场
S = defaultState(); S.stone = 1000; S.factions.sanxiu.relation = 20;
S.activeEvent = { chain: "auction", stage: 2, flags: { entered: true } };
mockRandom = 0.99;  // > 0.44 → 失手
const stoneBidF = S.stone;
const rBidF = resolveEvent("bid");
assert("竞价失手灵石照扣但不获灵材", rBidF.ok === true && rBidF.win === false && S.stone === stoneBidF - CONFIG.AUCTION_BID_COST);
S = defaultState(); S.factions.sanxiu.relation = 40;
S.activeEvent = { chain: "auction", stage: 1, flags: {} };
const rSkip = resolveEvent("skip");
assert("过门不入降低散修关系", rSkip.ok === true && S.factions.sanxiu.relation === 40 + CONFIG.AUCTION_REL_SKIP);

// 9.7 妖兽潮：探查 → 迎战胜利
S = defaultState(); S.stamina = 30; S.stone = 0; S.bestStage = 3;
invSet("material", 0); S.reputation = 0;
S.activeEvent = { chain: "beasttide", stage: 1, flags: {} };
const stScout = S.stamina;
const rScout = resolveEvent("scout");
assert("探查扣体力并进入下一阶段", rScout.ok === true && rScout.next === true && S.stamina === stScout - CONFIG.BEASTTIDE_SCOUT_STAMINA);
assert("探查标记写入事件", S.activeEvent.flags.scouted === true);
mockRandom = 0.1;   // 胜率判定通过
const matBeast = S.materials, repBeast = S.reputation;
const rFight = resolveEvent("fight");
assert("迎战胜利获得灵材与声望", rFight.ok === true && rFight.win === true && S.materials === matBeast + CONFIG.BEASTTIDE_REWARD_MAT && S.reputation === repBeast + CONFIG.BEASTTIDE_REP);
assert("妖兽潮胜利结算后关闭事件", S.activeEvent === null);

// 9.8 妖兽潮：未探查迎战失败 / 布阵避战 / 体力拦截
S = defaultState(); S.stamina = 30; invSet("herb", 100);
S.activeEvent = { chain: "beasttide", stage: 2, flags: { scouted: false } };
mockRandom = 0.99;
const rFightF = resolveEvent("fight");
assert("迎战失败损失四成灵草且体力清零", rFightF.ok === true && rFightF.win === false && S.herbs === 60 && S.stamina === 0);
S = defaultState(); S.stone = 500; invSet("herb", 100);
S.activeEvent = { chain: "beasttide", stage: 2, flags: {} };
const rAvoid = resolveEvent("avoid");
assert("布阵避战扣灵石且仅损一成灵草", rAvoid.ok === true && rAvoid.avoided === true && S.stone === 500 - CONFIG.BEASTTIDE_AVOID_STONE && S.herbs === 90);
S = defaultState(); S.stamina = 0;
S.activeEvent = { chain: "beasttide", stage: 1, flags: {} };
assert("体力不足无法探查", resolveEvent("scout").ok === false);

// 9.9 魔道夺宝：布阵 → 反杀
S = defaultState(); S.stone = 1000; invSet("material", 20); S.bestStage = 2;
S.artifacts = [{ id: 1, name: "护身剑", tier: 2, type: "attack", atk: 0.06, def: 0, hp: 0.03, cult: 0, roll: 1 }];
S.equipped = { attack: 1, defense: null, support: null };
S.activeEvent = { chain: "demonraid", stage: 1, flags: {} };
const rArray = resolveEvent("array");
assert("布迷阵扣灵石灵材并进入下一阶段", rArray.ok === true && rArray.next === true && S.stone === 1000 - CONFIG.DEMONRAID_ARRAY_STONE && S.materials === 20 - CONFIG.DEMONRAID_ARRAY_MATERIAL);
mockRandom = 0.1;
const moyRelBefore = S.factions.moyuan.relation;
const rRaidWin = resolveEvent("fight");
assert("反杀魔修并结仇魔渊", rRaidWin.ok === true && rRaidWin.win === true && S.factions.moyuan.relation === moyRelBefore - CONFIG.DEMONRAID_REL_PENALTY);
assert("胜利不会损失自己的法宝", S.artifacts.length === 1);

// 9.10 魔道夺宝：败北夺走未装备法宝（不夺已装备的）
S = defaultState(); S.stone = 1000;
S.artifacts = [
  { id: 1, name: "护身剑", tier: 3, type: "attack", atk: 0.10, def: 0, hp: 0.05, cult: 0, roll: 1 },
  { id: 2, name: "备用刀", tier: 1, type: "attack", atk: 0.03, def: 0, hp: 0.015, cult: 0, roll: 1 },
];
S.equipped = { attack: 1, defense: null, support: null };
S.activeEvent = { chain: "demonraid", stage: 2, flags: { array: false } };
mockRandom = 0.99;
const rRaidLose = resolveEvent("fight");
assert("败北只夺走未装备法宝", rRaidLose.ok === true && rRaidLose.win === false && S.artifacts.length === 1 && S.artifacts[0].id === 1);

// 9.11 魔道夺宝：无备用法宝则损失灵石 / 以宝换命
S = defaultState(); S.stone = 1000;
S.artifacts = [{ id: 5, name: "唯一", tier: 2, type: "attack", atk: 0.06, def: 0, hp: 0.03, cult: 0, roll: 1 }];
S.equipped = { attack: 5, defense: null, support: null };
S.activeEvent = { chain: "demonraid", stage: 2, flags: { array: false } };
mockRandom = 0.99;
const rLostStone = resolveEvent("fight");
assert("无备用法宝则损失三成灵石且法宝保留", rLostStone.ok === true && rLostStone.win === false && S.artifacts.length === 1 && S.stone === 700);
S = defaultState(); S.stone = 1000;
S.artifacts = [{ id: 9, name: "舍利", tier: 1, type: "support", atk: 0, def: 0, hp: 0.015, cult: 0.03, roll: 1 }];
S.equipped = { attack: null, defense: null, support: null };
S.factions.moyuan.relation = 0;
S.activeEvent = { chain: "demonraid", stage: 2, flags: {} };
const rYield = resolveEvent("yield");
assert("以宝换命交出法宝且魔渊关系回升", rYield.ok === true && S.artifacts.length === 0 && S.factions.moyuan.relation === 5);

// 9.12 灵矿现世（自动正面事件）
const oldSecret = CONFIG.EVENT_SECRET_REALM_CHANCE;
CONFIG.EVENT_SECRET_REALM_CHANCE = 0;   // 隔离秘境事件
S = defaultState(); invSet("material", 0);
markChain("invasion"); markChain("beasttide"); markChain("auction"); markChain("demonraid");
S.factions.sanxiu.relation = 0;
S.activeEvent = null;
mockRandom = 0.03;   // < 0.04 → 灵矿现世
eventTick();
assert("灵矿现世自动获得灵材", S.materials >= 5);
CONFIG.EVENT_SECRET_REALM_CHANCE = oldSecret;
mockRandom = 0.99;

// 9.13 事件战斗胜率钳制
const cOverwhelm = eventCombat(0);
assert("碾压时胜率不超过95%", cOverwhelm.rate <= CONFIG.EVENT_WIN_RATE_MAX);
const cHopeless = eventCombat(99);
assert("绝境时胜率不低于15%", cHopeless.rate >= CONFIG.EVENT_WIN_RATE_MIN);

// 9.14 事件卡描述完整性（数据驱动：UI 可直接渲染）
let metaOk = true;
for (const chain of ["invasion", "beasttide", "auction", "demonraid"]) {
  for (const st of [1, 2]) {
    const m = eventMeta({ chain, stage: st, flags: {} });
    if (!m.title || !m.desc || !Array.isArray(m.choices) || m.choices.length === 0) metaOk = false;
    if (m.choices.some(x => !x.key || !x.label)) metaOk = false;
  }
}
assert("四条事件链两阶段均有完整 UI 描述", metaOk === true);

// 9.15 存档迁移补齐事件冷却字段
const migEv = migrateState({ version: 6, artifacts: [] });
assert("迁移补齐事件链冷却字段", migEv.eventCooldown != null && typeof migEv.eventCooldown === "object");

// ===== 阶段 10：法宝词条（v0.6.2）=====
console.log("\n== 10. 法宝词条（暴击/吸血/反伤） ==");
S = defaultState();
S.lastOnline = Date.now();

// 10.1 品阶决定词条条数
for (const [tier, expect] of [[1, 0], [2, 0], [3, 1], [4, 1], [5, 2], [6, 2]]) {
  let okCount = true;
  for (let i = 0; i < 30; i++) {
    if (rollAffixes(tier).length !== expect) okCount = false;
  }
  assert(`tier${tier} 词条条数恒为 ${expect}`, okCount);
}

// 10.2 词条种类不重复 + 种类合法 + 数值正
let dupOk = true, kindOk = true;
const validKeys = CONFIG.AFFIX_TYPES.map(t => t.key);
for (let i = 0; i < 50; i++) {
  const affs = rollAffixes(6);
  const keys = affs.map(a => a.key);
  if (new Set(keys).size !== keys.length) dupOk = false;
  for (const af of affs) {
    if (!validKeys.includes(af.key)) kindOk = false;
    if (!(af.value > 0)) kindOk = false;
    if (!af.name) kindOk = false;
  }
}
assert("同一法宝内词条种类不重复", dupOk);
assert("词条种类与数值合法", kindOk);

// 10.3 词条基准随品阶递增
assert("暴击基准随品阶递增",
  CONFIG.AFFIX_BASE.crit[5] > CONFIG.AFFIX_BASE.crit[4] &&
  CONFIG.AFFIX_BASE.crit[4] > CONFIG.AFFIX_BASE.crit[2]);
assert("反伤基准高于暴击（纯防御收益更高）",
  CONFIG.AFFIX_BASE.thorns[5] > CONFIG.AFFIX_BASE.crit[5]);

// 10.4 makeArtifact 携带词条
const artT3 = makeArtifact(3, "attack");
assert("宝器法宝带 1 条词条", Array.isArray(artT3.affixes) && artT3.affixes.length === 1);
const artT1 = makeArtifact(1, "attack");
assert("凡品法宝无词条", Array.isArray(artT1.affixes) && artT1.affixes.length === 0);
const artT6 = makeArtifact(6, "support");
assert("仙器法宝带 2 条词条", artT6.affixes.length === 2);

// 10.5 词条汇总上限钳制
S.artifacts = [];
S.equipped = { attack: null, defense: null, support: null };
for (const type of ["attack", "defense", "support"]) {
  const a = {
    id: 900 + S.artifacts.length, name: "满暴" + type, tier: 6, type,
    atk: 0, def: 0, cult: 0, hp: 0.1, roll: 1,
    affixes: [{ key: "crit", name: "暴击", color: "#A93F2E", value: 0.30 }],
  };
  S.artifacts.push(a);
  S.equipped[type] = a.id;
}
assert("暴击汇总受 45% 上限钳制", Math.abs(artifactAffix().crit - CONFIG.AFFIX_CAP.crit) < 1e-9);

// 10.6 卸下后归零
S.equipped = { attack: null, defense: null, support: null };
S.loadout = {};
const afZero = artifactAffix();
assert("卸下后词条汇总归零", afZero.crit === 0 && afZero.lifesteal === 0 && afZero.thorns === 0);

// 10.7 评分：有词条更高
const lowArt = { tier: 5, type: "attack", atk: 0.21, def: 0, cult: 0, hp: 0.1, affixes: [] };
const highArt = { tier: 5, type: "attack", atk: 0.21, def: 0, cult: 0, hp: 0.1, affixes: [{ key: "crit", name: "暴击", value: 0.1 }] };
assert("有词条法宝评分更高", artifactScore(highArt) > artifactScore(lowArt));

// 10.8 战斗：暴击生效
S = defaultState();
S.realm = 2; S.layer = 5;
S.artifacts = []; S.equipped = { attack: null, defense: null, support: null };
mockRandom = 0;
const rNoCrit = simulateBattle(6);
const critArt = {
  id: 501, name: "暴击剑", tier: 5, type: "attack",
  atk: 0.2, def: 0, cult: 0, hp: 0.1, roll: 1,
  affixes: [{ key: "crit", name: "暴击", color: "", value: 0.45 }],
};
S.artifacts.push(critArt);
S.equipped.attack = 501;
const rCrit = simulateBattle(6);
assert("暴击词条在战斗中触发", rCrit.crits > 0);
assert("暴击缩短战斗回合", rCrit.rounds <= rNoCrit.rounds);

// 10.9 战斗：反伤生效
S.equipped.attack = null;
S.loadout.weapon = null;
const thornArt = {
  id: 502, name: "反伤甲", tier: 5, type: "defense",
  atk: 0, def: 0, cult: 0, hp: 0.1, roll: 1,
  affixes: [{ key: "thorns", name: "反伤", color: "", value: 0.6 }],
};
S.artifacts.push(thornArt);
S.equipped.defense = 502;
const rThorn = simulateBattle(6);
assert("反伤词条加速敌人倒下", rThorn.rounds <= rNoCrit.rounds);
assert("反伤不改变我方基础伤害", rThorn.pDmg === rNoCrit.pDmg);

// 10.10 吸血汇入汇总
S.equipped.defense = null;
const vampArt = {
  id: 503, name: "吸血印", tier: 5, type: "support",
  atk: 0, def: 0, cult: 0.21, hp: 0.1, roll: 1,
  affixes: [{ key: "lifesteal", name: "吸血", color: "", value: 0.11 }],
};
S.artifacts.push(vampArt);
S.equipped.support = 503;
assert("吸血词条汇入汇总", Math.abs(artifactAffix().lifesteal - 0.11) < 1e-9);

// 10.11 炼化升阶重铸词条
S = defaultState();
S.realm = 2; S.stone = 99999; invSet("material", 999);
S.buildings.forge = 12;
const mainA = makeArtifact(1, "attack");
mainA.tier = 1; mainA.affixes = [];
const sacA = makeArtifact(1, "attack");
S.artifacts = [mainA, sacA];
S.equipped.attack = mainA.id;
mockRandom = 0;   // refineRate 必成
const rRef = refineArtifact(mainA.id, sacA.id);
const mainAfter = S.artifacts.find(x => x.id === mainA.id);
assert("炼化升阶成功", rRef.ok === true && rRef.success === true);
assert("升到宝器后获得 1 条词条", mainAfter.tier === 2 ? true : Array.isArray(mainAfter.affixes));

// 10.12 旧存档法宝补空词条
const migAffix = migrateState({
  version: 6,
  artifacts: [{ id: 1, name: "旧剑", tier: 3, type: "attack", atk: 0.1, def: 0, cult: 0, hp: 0.05, roll: 1 }],
});
assert("旧法宝迁移补齐空词条数组",
  Array.isArray(migAffix.artifacts[0].affixes) && migAffix.artifacts[0].affixes.length === 0);

// ===== 阶段 11：存档导出 / 导入（v0.6.2）=====
console.log("\n== 11. 存档导出 / 导入 ==");
S = defaultState();
S.lastOnline = Date.now();
S.realm = 4; S.layer = 3; S.stone = 12345; invSet("material", 66);
S.artifacts = [makeArtifact(4, "defense")];

const expText = exportSaveText();
let expParsed = null;
try { expParsed = JSON.parse(expText); } catch (e) { expParsed = null; }
assert("导出文本是合法 JSON 且带 magic",
  expParsed && expParsed.magic === "wenchangsheng-save");
assert("导出内容包含完整状态",
  expParsed.data.realm === 4 && expParsed.data.stone === 12345 && expParsed.data.artifacts.length === 1);

const pOk = parseSaveText(expText);
assert("合法存档通过校验", pOk.ok === true && pOk.data.realm === 4);

const pBad = parseSaveText("this is not json");
assert("非法 JSON 被拒绝", pBad.ok === false && /格式/.test(pBad.msg));

const pEmpty = parseSaveText("");
assert("空存档被拒绝", pEmpty.ok === false);

const pForeign = parseSaveText(JSON.stringify({ foo: 1, bar: 2 }));
assert("非本游戏存档被拒绝", pForeign.ok === false);

const pHigh = parseSaveText(JSON.stringify({
  magic: "wenchangsheng-save",
  data: { version: 99, realm: 1, buildings: {} },
}));
assert("高版本存档被拒绝", pHigh.ok === false && /版本/.test(pHigh.msg));

// 导入覆盖
S.realm = 0; S.stone = 0; S.artifacts = [];
const rImp = importSaveText(expText);
assert("导入成功并覆盖当前进度",
  rImp.ok === true && S.realm === 4 && S.stone === 12345);
assert("导入后法宝保留", S.artifacts.length === 1);
assert("导入后里程碑字段就绪", S.milestones != null && typeof S.milestones === "object");

// 裸存档兼容（无 magic 包裹）
const pBare = parseSaveText(JSON.stringify({ realm: 1, layer: 2, stone: 500, buildings: { farm: 1 } }));
assert("裸存档（无 magic）兼容", pBare.ok === true && pBare.data.stone === 500);

// 导入旧档自动迁移补全
S = defaultState();
const rOld = importSaveText(JSON.stringify({ realm: 1, layer: 0, stone: 10, buildings: { farm: 1 } }));
assert("导入旧档自动补全缺失字段",
  rOld.ok === true && S.market != null && Array.isArray(S.artifacts) && S.equipped.attack === null);

// 导出 → 导入 往返一致
S = defaultState();
S.realm = 2; S.layer = 7; S.stone = 888; invSet("material", 33); S.reputation = 12;
const roundTrip = exportSaveText();
S = defaultState();
importSaveText(roundTrip);
assert("导出导入往返数据一致",
  S.realm === 2 && S.layer === 7 && S.stone === 888 && S.materials === 33 && S.reputation === 12);

// 导入后法宝 id 序列不冲突（防装备槽指向错误法宝）
S = defaultState();
const bigIdArt = makeArtifact(3, "attack");
bigIdArt.id = 77;
S.artifacts = [bigIdArt];
S.equipped.attack = 77;
const impText2 = exportSaveText();
S = defaultState();
importSaveText(impText2);
const newArtAfterImport = makeArtifact(3, "defense");
assert("导入后新法宝 id 不与存档冲突", newArtAfterImport.id > 77);
assert("导入后装备指向仍有效", equippedArtifact("attack") && equippedArtifact("attack").id === 77);

// ===== 阶段 12：境界专属剧情事件（v0.6.2）=====
console.log("\n== 12. 境界专属剧情事件 ==");
S = defaultState();
S.lastOnline = Date.now();
S.realm = 2; S.layer = 0;

// 12.1 识别待触发
const peJd = pendingRealmEvent();
assert("金丹期识别出待触发的心魔劫", peJd && peJd.key === "heartdemon");

// 12.2 eventTick 最高优先级触发
mockRandom = 0.99;
eventTick();
assert("金丹境界事件优先触发",
  S.activeEvent && S.activeEvent.chain === "heartdemon");
assert("触发后写入里程碑", S.milestones.heartdemon != null);

// 12.3 事件卡完整性
const mHd = eventMeta({ chain: "heartdemon", stage: 1, flags: {} });
assert("心魔劫事件卡描述完整",
  mHd.title && mHd.desc && mHd.choices.length === 2 &&
  mHd.choices.every(c => c.key && c.label));

// 12.4 灵石不足无法静心守一
S.stone = 0;
const rCalmNo = resolveEvent("calm");
assert("灵石不足无法静心守一", rCalmNo.ok === false && S.activeEvent !== null);

// 12.5 静心守一结算
S.stone = 1000;
const rCalm = resolveEvent("calm");
assert("静心守一扣除灵石", rCalm.ok === true && S.stone === 1000 - CONFIG.HEARTDEMON_STONE);
assert("守一后心魔劫关闭", S.activeEvent === null);

// 12.6 直面心魔失败分支
S = defaultState();
S.realm = 2; S.stone = 0; S.qi = 1000;
S.activeEvent = { chain: "heartdemon", stage: 1, flags: {} };
mockRandom = 0.999;   // eventCombat 必败
const rFaceFail = resolveEvent("face");
assert("直面心魔失败扣灵气",
  rFaceFail.ok === true && rFaceFail.win === false && S.qi < 1000);
assert("失败后体力清零", S.stamina === 0);
assert("失败后事件关闭", S.activeEvent === null);

// 12.7 直面心魔成功分支
S = defaultState();
S.realm = 2; S.stone = 0; S.qi = 0; invSet("material", 0);
S.activeEvent = { chain: "heartdemon", stage: 1, flags: {} };
mockRandom = 0;       // eventCombat 必胜
const rFaceWin = resolveEvent("face");
assert("直面心魔成功获得灵气与灵材",
  rFaceWin.ok === true && rFaceWin.win === true &&
  S.qi > 0 && S.materials === CONFIG.HEARTDEMON_REWARD_MAT);

// 12.8 元婴紫府洞天：破禁
S = defaultState();
S.realm = 3; S.stone = 1000;
S.milestones = { heartdemon: 1 };
S.activeEvent = { chain: "zifu", stage: 1, flags: {} };
const rEnterZf = resolveEvent("enter");
assert("破禁而入扣灵石并进入二阶段",
  rEnterZf.ok === true && rEnterZf.next === true &&
  S.stone === 1000 - CONFIG.ZIFU_ENTER_STONE && S.activeEvent.stage === 2);

// 12.9 洞天夺宝失败
mockRandom = 0.999;
S.artifacts = [];
const rZfFail = resolveEvent("treasure");
assert("洞天夺宝失败损失灵石且无所得",
  rZfFail.ok === true && rZfFail.win === false && S.artifacts.length === 0);
assert("洞天事件终局后关闭", S.activeEvent === null);

// 12.10 洞天夺宝成功获得法宝
S = defaultState();
S.realm = 3; S.stone = 1000;
S.activeEvent = { chain: "zifu", stage: 2, flags: {} };
S.artifacts = [];
mockRandom = 0;
const rZfWin = resolveEvent("treasure");
assert("洞天夺宝成功获得法宝",
  rZfWin.ok === true && rZfWin.win === true && S.artifacts.length === 1);
assert("洞天法宝品阶符合配置",
  S.artifacts[0].tier === CONFIG.ZIFU_ARTIFACT_TIER);

// 12.11 采灵材即退
S = defaultState();
S.realm = 3; invSet("material", 0);
S.activeEvent = { chain: "zifu", stage: 2, flags: {} };
const rZfMat = resolveEvent("material");
assert("采灵材即退获得灵材",
  rZfMat.ok === true && S.materials === CONFIG.ZIFU_REWARD_MAT);
assert("采撷后事件关闭", S.activeEvent === null);

// 12.12 外围吐纳（不入洞天）
S = defaultState();
S.realm = 3; S.qi = 0; S.stone = 0;
S.activeEvent = { chain: "zifu", stage: 1, flags: {} };
const rZfMed = resolveEvent("meditate");
assert("外围吐纳获得灵气且不消耗灵石",
  rZfMed.ok === true && S.qi > 0 && S.stone === 0 && S.activeEvent === null);

// 12.13 已完成后不再触发
S = defaultState();
S.realm = 3;
S.milestones = { heartdemon: 1, zifu: 1 };
assert("已完成的境界事件不再触发", pendingRealmEvent() === null);

// 12.14 境界不足不触发
S = defaultState();
S.realm = 1;
assert("境界不足时不触发境界事件", pendingRealmEvent() === null);

// 12.15 迁移补齐里程碑
const migMile = migrateState({ version: 6, artifacts: [] });
assert("迁移补齐里程碑字段",
  migMile.milestones && typeof migMile.milestones === "object");

// ===== 阶段 13：化神 / 炼虚境界事件（v0.6.3）=====
console.log("\n== 13. 化神 / 炼虚境界事件 ==");

// 13.1 识别待触发
S = defaultState();
S.realm = 4; S.milestones = { heartdemon: 1, zifu: 1 };
const peHs = pendingRealmEvent();
assert("化神期识别出神识化虚", peHs && peHs.key === "huashen");

// 13.2 三选一事件卡
const mHs = eventMeta({ chain: "huashen", stage: 1, flags: {} });
assert("神识化虚为三选一",
  mHs.title && mHs.choices.length === 3 && mHs.choices.every(c => c.key && c.label));

// 13.3 稳守本心
S = defaultState();
S.realm = 4; S.qi = 0;
S.activeEvent = { chain: "huashen", stage: 1, flags: {} };
const rHold = resolveEvent("hold");
assert("稳守本心获得灵气并关闭事件", rHold.ok === true && S.qi > 0 && S.activeEvent === null);

// 13.4 凝练神识
S = defaultState();
S.realm = 4; S.qi = 10000; invSet("material", 0); S.reputation = 0;
S.activeEvent = { chain: "huashen", stage: 1, flags: {} };
const rCond = resolveEvent("condense");
assert("凝练神识以灵气换灵材声望",
  rCond.ok === true &&
  S.qi === 10000 - Math.floor(10000 * CONFIG.HUASHEN_QI_LOSS) &&
  S.materials === 10 && S.reputation === 8);

// 13.5 灵气不足无法凝练
S.qi = 0;
S.activeEvent = { chain: "huashen", stage: 1, flags: {} };
assert("灵气不足无法凝练神识", resolveEvent("condense").ok === false);

// 13.6 参悟虚空失败
S = defaultState();
S.realm = 4; S.qi = 10000; S.stamina = 20;
S.activeEvent = { chain: "huashen", stage: 1, flags: {} };
mockRandom = 0.999;
const rGazeFail = resolveEvent("gaze");
assert("参悟虚空失败损失灵气并力竭",
  rGazeFail.ok === true && rGazeFail.win === false && S.qi < 10000 && S.stamina === 0);
assert("参悟失败后事件关闭", S.activeEvent === null);

// 13.7 参悟虚空成功
S = defaultState();
S.realm = 4; S.qi = 0; invSet("material", 0);
S.activeEvent = { chain: "huashen", stage: 1, flags: {} };
mockRandom = 0;
const rGazeWin = resolveEvent("gaze");
assert("参悟虚空成功获得灵气灵材声望",
  rGazeWin.win === true && S.qi > 0 &&
  S.materials === CONFIG.HUASHEN_REWARD_MAT &&
  S.reputation === CONFIG.HUASHEN_RATIO_REP);

// 13.8 炼虚识别
S = defaultState();
S.realm = 5;
S.milestones = { heartdemon: 1, zifu: 1, huashen: 1 };
const peLx = pendingRealmEvent();
assert("炼虚期识别出虚空裂缝", peLx && peLx.key === "lianxu");

// 13.9 封镇裂缝
S = defaultState();
S.realm = 5; S.reputation = 0;
const relBeforeSeal = S.factions.qingyun.relation;
S.activeEvent = { chain: "lianxu", stage: 1, flags: {} };
const rSeal = resolveEvent("seal");
assert("封镇裂缝得声望与青云关系",
  rSeal.ok === true && S.reputation === CONFIG.LIANXU_SEAL_REP &&
  S.factions.qingyun.relation === relBeforeSeal + CONFIG.LIANXU_SEAL_REL);
assert("封镇后事件关闭", S.activeEvent === null);

// 13.10 探入裂缝
S = defaultState();
S.realm = 5; S.stone = 2000;
S.activeEvent = { chain: "lianxu", stage: 1, flags: {} };
const rEnterLx = resolveEvent("enter");
assert("探入裂缝扣灵石并进入二阶段",
  rEnterLx.next === true && S.stone === 2000 - CONFIG.LIANXU_ENTER_STONE &&
  S.activeEvent && S.activeEvent.stage === 2);

// 13.11 灵石不足
S.stone = 0;
S.activeEvent = { chain: "lianxu", stage: 1, flags: {} };
assert("灵石不足无法探入裂缝", resolveEvent("enter").ok === false);

// 13.12 深入得宝
S = defaultState();
S.realm = 5; S.stone = 2000; S.artifacts = [];
S.activeEvent = { chain: "lianxu", stage: 2, flags: {} };
mockRandom = 0;
const rDeep = resolveEvent("deepen");
assert("深入虚空成功获得灵宝",
  rDeep.win === true && S.artifacts.length === 1 &&
  S.artifacts[0].tier === CONFIG.LIANXU_ARTIFACT_TIER);

// 13.13 深入受创
S = defaultState();
S.realm = 5; S.stone = 2000; S.reputation = 100; S.artifacts = [];
S.activeEvent = { chain: "lianxu", stage: 2, flags: {} };
mockRandom = 0.999;
const rDeepFail = resolveEvent("deepen");
assert("深入失败损失灵石且无所得",
  rDeepFail.win === false && S.stone < 2000 && S.artifacts.length === 0);
assert("深入失败后事件关闭", S.activeEvent === null);

// 13.14 回溯虚影
S = defaultState();
S.realm = 5; S.qi = 0; invSet("material", 0);
S.activeEvent = { chain: "lianxu", stage: 2, flags: {} };
const rEcho = resolveEvent("echo");
assert("回溯虚影得灵气与灵材",
  rEcho.ok === true && S.qi > 0 && S.materials === 8 && S.activeEvent === null);

// 13.15 两阶段事件卡完整
let lxMetaOk = true;
for (const st of [1, 2]) {
  const m = eventMeta({ chain: "lianxu", stage: st, flags: {} });
  if (!m.title || !m.desc || !Array.isArray(m.choices) || m.choices.length === 0) lxMetaOk = false;
  if (m.choices.some(x => !x.key || !x.label)) lxMetaOk = false;
}
assert("虚空裂缝两阶段事件卡完整", lxMetaOk);

// 13.16 境界事件齐全（v0.6.4：金丹~渡劫全覆盖）
assert("境界事件覆盖金丹~渡劫共 7 条",
  CONFIG.REALM_EVENTS.length === 7 &&
  CONFIG.REALM_EVENTS.map(e => e.realm).join(",") === "2,3,4,5,6,7,8");

// 13.17 逐级触发顺序（已金丹未完成时优先金丹）
S = defaultState();
S.realm = 5; S.milestones = {};
const peOrder = pendingRealmEvent();
assert("未完成低境事件时优先触发低境", peOrder && peOrder.key === "heartdemon");

// 13.18 eventTick 真实触发（不受冷却与势力条件限制）
S = defaultState();
S.realm = 4;
S.milestones = { heartdemon: 1, zifu: 1 };
mockRandom = 0.99;
eventTick();
assert("化神境界事件在每日判定中优先触发",
  S.activeEvent && S.activeEvent.chain === "huashen");
assert("触发后记录化神里程碑", S.milestones.huashen != null);

// ===== 阶段 14：词条洗练（v0.6.3）=====
console.log("\n== 14. 法宝词条洗练 ==");

// 14.1 成本公式
const rc4 = rerollCost(4);
assert("洗练成本 = 该阶材料×0.5 + 该阶灵石×0.3",
  rc4.material === Math.floor(24 * CONFIG.REROLL_MAT_RATIO) &&
  rc4.stone === Math.floor(2600 * CONFIG.REROLL_STONE_RATIO));

// 14.2 低阶不可洗练
S = defaultState();
const lowA = makeArtifact(2, "attack");
S.artifacts = [lowA];
assert("灵品法宝判定为不可洗练", canReroll(lowA) === false);
assert("低阶洗练被拒绝", rerollAffixes(lowA.id).ok === false);

// 14.3 资源不足
S = defaultState();
invSet("material", 0); S.stone = 0;
const a4 = makeArtifact(4, "attack");
S.artifacts = [a4];
assert("资源不足时洗练失败", rerollAffixes(a4.id).ok === false);

// 14.4 洗练成功并扣资源
invSet("material", 999); S.stone = 99999;
const cost4 = rerollCost(4);
mockRandom = 0.1;
const rRoll = rerollAffixes(a4.id);
assert("洗练成功", rRoll.ok === true);
assert("洗练扣除灵材与灵石",
  S.materials === 999 - cost4.material && S.stone === 99999 - cost4.stone);
assert("洗练后词条条数符合品阶",
  a4.affixes.length === CONFIG.AFFIX_COUNT[a4.tier - 1]);
assert("洗练返回旧词条快照", Array.isArray(rRoll.oldAffixes));

// 14.5 已装备时即时生效
S = defaultState();
invSet("material", 9999); S.stone = 999999;
S.artifacts = [];
S.equipped = { attack: null, defense: null, support: null };
const eqA = makeArtifact(6, "attack");
eqA.affixes = [{ key: "crit", name: "暴击", color: "#A93F2E", value: 0.11 }];
S.artifacts.push(eqA);
S.equipped.attack = eqA.id;
mockRandom = 0.5;
rerollAffixes(eqA.id);
const sumCrit = eqA.affixes.filter(x => x.key === "crit").reduce((s, x) => s + x.value, 0);
assert("洗练后已装备法宝词条即时生效",
  Math.abs(artifactAffix().crit - Math.min(sumCrit, CONFIG.AFFIX_CAP.crit)) < 1e-9);

// 14.6 洗练不改动主属性
const mainAtkBefore = eqA.atk;
rerollAffixes(eqA.id);
assert("洗练不改动主属性", eqA.atk === mainAtkBefore);

// 14.7 多次洗练数值始终合法
S = defaultState();
invSet("material", 99999); S.stone = 9999999;
const a4b = makeArtifact(4, "attack");
S.artifacts = [a4b];
let rollValid = true;
for (let i = 0; i < 30; i++) {
  const rr = rerollAffixes(a4b.id);
  if (!rr.ok) { rollValid = false; break; }
  for (const af of a4b.affixes) {
    if (!(af.value > 0) || af.value > 0.3) rollValid = false;
    if (!CONFIG.AFFIX_TYPES.some(t => t.key === af.key)) rollValid = false;
  }
}
assert("多次洗练词条数值与种类始终合法", rollValid);

// ===== 阶段 15：合体 / 大乘 / 渡劫事件（v0.6.4）=====
console.log("\n== 15. 合体 / 大乘 / 渡劫事件 ==");

// 15.1 识别
S = defaultState();
S.realm = 6;
S.milestones = { heartdemon: 1, zifu: 1, huashen: 1, lianxu: 1 };
assert("合体期识别出道基归一", (pendingRealmEvent() || {}).key === "heti");

// 15.2 事件卡
const mHt = eventMeta({ chain: "heti", stage: 1, flags: {} });
assert("道基归一为两选一且描述完整",
  mHt.title && mHt.desc && mHt.choices.length === 2 &&
  mHt.choices.every(c => c.key && c.label));

// 15.3 以灵材固本
S = defaultState();
S.realm = 6; invSet("material", 100); S.stone = 5000; S.qi = 0;
S.activeEvent = { chain: "heti", stage: 1, flags: {} };
const rHarden = resolveEvent("harden");
assert("以灵材固本扣灵材灵石并得灵气",
  rHarden.ok === true && S.materials === 100 - CONFIG.HETI_MAT &&
  S.stone === 5000 - CONFIG.HETI_STONE && S.qi > 0);
assert("固本后事件关闭", S.activeEvent === null);

// 15.4 资源不足
S = defaultState();
S.realm = 6; invSet("material", 0); S.stone = 5000;
S.activeEvent = { chain: "heti", stage: 1, flags: {} };
assert("灵材不足无法固本", resolveEvent("harden").ok === false);

// 15.5 硬合失败
S = defaultState();
S.realm = 6; S.qi = 10000; S.stamina = 20;
S.activeEvent = { chain: "heti", stage: 1, flags: {} };
mockRandom = 0.999;
const rForceFail = resolveEvent("force");
assert("硬合肉身失败损失灵气并力竭",
  rForceFail.ok === true && rForceFail.win === false &&
  S.qi < 10000 && S.stamina === 0);

// 15.6 硬合成功
S = defaultState();
S.realm = 6; S.qi = 0; invSet("material", 0); S.reputation = 0;
S.activeEvent = { chain: "heti", stage: 1, flags: {} };
mockRandom = 0;
const rForceWin = resolveEvent("force");
assert("硬合肉身成功得灵气灵材声望",
  rForceWin.win === true && S.qi > 0 &&
  S.materials === CONFIG.HETI_WIN_MAT && S.reputation === CONFIG.HETI_WIN_REP);

// 15.7 大乘识别 + 闭关
S = defaultState();
S.realm = 7;
S.milestones = { heartdemon: 1, zifu: 1, huashen: 1, lianxu: 1, heti: 1 };
assert("大乘期识别出众生愿力", (pendingRealmEvent() || {}).key === "dacheng");

S = defaultState();
S.realm = 7; S.qi = 0;
S.activeEvent = { chain: "dacheng", stage: 1, flags: {} };
const rSeclude = resolveEvent("seclude");
assert("闭关自守得灵气并关闭事件", rSeclude.ok === true && S.qi > 0 && S.activeEvent === null);

// 15.8 下山传道
S = defaultState();
S.realm = 7; S.stone = 5000;
S.activeEvent = { chain: "dacheng", stage: 1, flags: {} };
const rPreach = resolveEvent("preach");
assert("下山传道扣灵石并进入二阶段",
  rPreach.next === true && S.stone === 5000 - CONFIG.DACHENG_STONE &&
  S.activeEvent && S.activeEvent.stage === 2);

// 15.9 灵石不足
S.stone = 0;
S.activeEvent = { chain: "dacheng", stage: 1, flags: {} };
assert("灵石不足无法传道", resolveEvent("preach").ok === false);

// 15.10 广纳愿力
S = defaultState();
S.realm = 7; S.reputation = 0; invSet("material", 0);
const relBeforeGather = S.factions.qingyun.relation;
S.activeEvent = { chain: "dacheng", stage: 2, flags: {} };
const rGather = resolveEvent("gather");
assert("广纳愿力得声望关系灵材",
  rGather.ok === true && S.reputation === CONFIG.DACHENG_REP &&
  S.materials === CONFIG.DACHENG_MAT &&
  S.factions.qingyun.relation === relBeforeGather + CONFIG.DACHENG_REL);

// 15.11 只取一缕
S = defaultState();
S.realm = 7; S.qi = 0;
S.activeEvent = { chain: "dacheng", stage: 2, flags: {} };
const rQuiet = resolveEvent("quiet");
assert("只取一缕愿力得灵气", rQuiet.ok === true && S.qi > 0 && S.activeEvent === null);

// 15.12 渡劫识别
S = defaultState();
S.realm = 8;
S.milestones = { heartdemon: 1, zifu: 1, huashen: 1, lianxu: 1, heti: 1, dacheng: 1 };
assert("渡劫期识别出九霄雷劫", (pendingRealmEvent() || {}).key === "dujie");

// 15.13 雷劫三选一
const mDj = eventMeta({ chain: "dujie", stage: 1, flags: {} });
assert("九霄雷劫为三选一", mDj.title && mDj.choices.length === 3);

// 15.14 硬抗成功
S = defaultState();
S.realm = 8; S.qi = 0; S.reputation = 0; S.artifacts = [];
S.activeEvent = { chain: "dujie", stage: 1, flags: {} };
mockRandom = 0;
const rResist = resolveEvent("resist");
assert("硬抗雷劫成功得灵气声望与法宝",
  rResist.win === true && S.qi > 0 &&
  S.reputation === CONFIG.DUJIE_WIN_REP && S.artifacts.length === 1 &&
  S.artifacts[0].tier === CONFIG.DUJIE_WIN_TIER);

// 15.15 硬抗失败
S = defaultState();
S.realm = 8; S.qi = 10000; S.stamina = 20;
S.activeEvent = { chain: "dujie", stage: 1, flags: {} };
mockRandom = 0.999;
const rResistFail = resolveEvent("resist");
assert("硬抗雷劫失败损失灵气并力竭",
  rResistFail.win === false && S.qi < 10000 && S.stamina === 0);

// 15.16 以法宝挡劫
S = defaultState();
S.realm = 8; S.qi = 0;
S.artifacts = [{ id: 201, name: "替劫甲", tier: 3, type: "defense", atk: 0, def: 0.10, hp: 0.05, cult: 0, roll: 1, affixes: [] }];
S.equipped = { attack: null, defense: null, support: null };
S.activeEvent = { chain: "dujie", stage: 1, flags: {} };
const rSac = resolveEvent("sacrifice");
assert("以法宝挡劫消耗法宝换灵气",
  rSac.ok === true && S.artifacts.length === 0 && S.qi > 0 &&
  S.reputation === CONFIG.DUJIE_SAC_REP);

// 15.17 无法宝可挡
S = defaultState();
S.realm = 8; S.artifacts = [];
S.equipped = { attack: null, defense: null, support: null };
S.activeEvent = { chain: "dujie", stage: 1, flags: {} };
assert("无法宝时挡劫被拒绝", resolveEvent("sacrifice").ok === false);

// 15.18 静待雷消
S = defaultState();
S.realm = 8; S.qi = 0;
S.activeEvent = { chain: "dujie", stage: 1, flags: {} };
const rWait = resolveEvent("wait");
assert("静待雷消得少量灵气", rWait.ok === true && S.qi > 0 && S.activeEvent === null);

// ===== 阶段 16：词条锁定洗练（v0.6.4）=====
console.log("\n== 16. 词条锁定洗练 ==");

// 16.1 锁定成本翻倍
const rcLock = rerollCost(6, true);
const rcBase = rerollCost(6, false);
assert("锁定洗练消耗为普通的两倍",
  rcLock.material === rcBase.material * 2 && rcLock.stone === rcBase.stone * 2);

// 16.2 单条词条不可锁定
S = defaultState();
invSet("material", 9999); S.stone = 99999;
const oneAffix = makeArtifact(4, "attack");
S.artifacts = [oneAffix];
assert("单条词条不可锁定洗练", canLockReroll(oneAffix) === false);

// 16.3 两条词条可锁定
const twoAffix = makeArtifact(6, "attack");
S.artifacts = [twoAffix];
assert("两条词条可锁定洗练", canLockReroll(twoAffix) === true);

// 16.4 锁定后该条不变
invSet("material", 5000); S.stone = 999999;
const beforeAff = twoAffix.affixes.map(x => ({ key: x.key, value: x.value }));
mockRandom = 0.3;
const rLock = rerollAffixes(twoAffix.id, 0);
assert("锁定洗练成功", rLock.ok === true && rLock.locked != null);
assert("被锁定词条保持原样",
  twoAffix.affixes[0].key === beforeAff[0].key &&
  twoAffix.affixes[0].value === beforeAff[0].value);
assert("锁定后词条条数不变",
  twoAffix.affixes.length === CONFIG.AFFIX_COUNT[twoAffix.tier - 1]);
assert("锁定后其余词条不与锁定项同类",
  twoAffix.affixes.slice(1).every(x => x.key !== twoAffix.affixes[0].key));

// 16.5 锁定扣双倍资源
invSet("material", 5000); S.stone = 999999;
const costL = rerollCost(twoAffix.tier, true);
rerollAffixes(twoAffix.id, 1);
assert("锁定洗练按双倍扣除",
  S.materials === 5000 - costL.material && S.stone === 999999 - costL.stone);

// 16.6 越界锁定索引退化为普通洗练
invSet("material", 5000); S.stone = 999999;
const rBadLock = rerollAffixes(twoAffix.id, 99);
assert("越界锁定索引退化为普通洗练", rBadLock.ok === true && rBadLock.locked === null);

// ===== 阶段 17：道途录（成就 + 图鉴，v0.6.5）=====
console.log("\n== 17. 道途录 ==");

// 17.1 配置与判定器一一对应
const achKeys = CONFIG.ACHIEVEMENTS.map(a => a.key).sort();
const chkKeys = Object.keys(ACHIEVEMENT_CHECKERS).sort();
assert("成就配置与判定器数量一致", achKeys.length === chkKeys.length);
assert("成就 key 无孤儿（配置↔判定器完全对应）",
  achKeys.join(",") === chkKeys.join(","));

// 17.2 新档无成就
S = defaultState();
S.lastOnline = Date.now();
const firstTick = codexTick();
assert("新档初始无成就", achievementCount() === 0 && firstTick.length === 0);

// 17.3 境界成就
S.realm = 1;
codexTick();
assert("达到筑基解锁成就", S.achievements.realm_1 != null);

// 17.4 奖励真实发放（realm_1 rep5 + realm_2 rep8）
S = defaultState();
const repBeforeAch = S.reputation;
S.realm = 2;
codexTick();
assert("成就奖励真实发放到声望", S.reputation === repBeforeAch + 5 + 8);

// 17.5 只发一次
const repAfterAch = S.reputation;
codexTick();
codexTick();
assert("重复判定不重复发奖", S.reputation === repAfterAch);

// 17.6 战斗统计与首胜成就
S = defaultState();
S.stamina = 30;
const rb0 = startBattle(0);
assert("战斗胜利计入累计战绩", rb0.win === true && S.stats.battleWins === 1);
codexTick();
assert("首胜解锁成就", S.achievements.battle_first != null);

// 17.7 BOSS 统计
S = defaultState();
S.realm = 3; S.stamina = 30;
const rbBoss = startBattle(5);
assert("击败 BOSS 计入 bossWins",
  rbBoss.win === true && S.stats.bossWins === 1);
codexTick();
assert("首斩妖王成就解锁", S.achievements.battle_boss != null);

// 17.8 法宝图鉴收录与去重
S = defaultState();
assert("初始法宝图鉴为空", codexArtifactCount() === 0);
makeArtifact(3, "attack");
assert("生成法宝即收录图鉴", codexArtifactCount() === 1 && codexArtifactSeen(3, "attack"));
makeArtifact(3, "attack");
assert("同品阶同类型不重复收录", codexArtifactCount() === 1);
makeArtifact(4, "defense");
assert("不同组合分别收录", codexArtifactCount() === 2);
assert("法宝图鉴格数=品阶×类型", codexArtifactTotal() === CONFIG.ARTIFACT_TIERS.length * CONFIG.ARTIFACT_TYPES.length);

// 17.9 带词条法宝记录标记
S = defaultState();
makeArtifact(5, "attack");
assert("带词条法宝记录词条标记", S.codex.affixSeen === true);
codexTick();
assert("词条成就解锁", S.achievements.art_affix != null);

// 17.10 满图鉴成就
S = defaultState();
for (let t = 1; t <= 6; t++) {
  for (const tp of CONFIG.ARTIFACT_TYPES) makeArtifact(t, tp.key);
}
assert("满图鉴收录全部格位", codexArtifactCount() === codexArtifactTotal());
codexTick();
assert("图鉴大成成就解锁", S.achievements.codex_full != null);

// 17.11 事件图鉴收录与去重
S = defaultState();
recordEventCodex("beasttide");
assert("事件图鉴收录", codexEventSeen("beasttide") === true && codexEventCount() === 1);
recordEventCodex("beasttide");
assert("事件图鉴去重", codexEventCount() === 1);
assert("事迹图鉴共 15 条（含 v0.11.0 两条新链）", codexEventTotal() === 15);

// 17.12 事件触发即收录（走 eventTick 真实路径）
S = defaultState();
mockRandom = 0;
eventTick();
assert("事件触发即收录图鉴", S.activeEvent != null && codexEventCount() >= 1);

// 17.13 迁移补齐道途录字段
const migCodex = migrateState({ version: 6, artifacts: [] });
assert("迁移补齐道途录字段",
  migCodex.achievements && migCodex.stats &&
  typeof migCodex.stats.battleWins === "number" &&
  typeof migCodex.stats.bossWins === "number" &&
  migCodex.codex && migCodex.codex.artifacts && migCodex.codex.events);

// 17.14 成就分类覆盖所有分组
const allGroups = ["境界", "历练", "洞府", "法宝", "世间", "图鉴"];
assert("成就分类覆盖全部 6 个分组",
  allGroups.every(g => CONFIG.ACHIEVEMENTS.some(d => achievementGroup(d) === g)));

// 17.15 全成就配置合理（每条都有名称/描述/奖励）
assert("每条成就均有名称、描述与非空奖励",
  CONFIG.ACHIEVEMENTS.every(d =>
    d.key && d.name && d.desc && d.reward &&
    (d.reward.rep || d.reward.mat || d.reward.stone)));

// ===== 阶段 18：章节扩容与战力闭合（v0.7.0）=====
console.log("\n== 18. 章节扩容与战力闭合 ==");
assert("章节数为 7，共 42 关",
  CONFIG.CHAPTERS.length === 7 &&
  CONFIG.CHAPTERS.length * (CONFIG.STAGES_PER_CHAPTER + 1) === 42);
assert("每章最后一关均为 BOSS",
  [5, 11, 17, 23, 29, 35, 41].every(n => CONFIG.isBoss(n)));
assert("末关归属第 7 章且章节名存在",
  CONFIG.chapterOf(41) === 6 && CONFIG.CHAPTERS[6] != null);

// 战力闭合：末关必须能由渡劫满层收尾，否则主线无法通关
function canClearStage(n) {
  const p = playerCombat();
  const pDmg = Math.max(p.attack - CONFIG.enemyDefense(n), p.attack * 0.05);
  const eAtk = CONFIG.enemyAttack(n);
  const eDmg = Math.max(eAtk - p.defense, eAtk * 0.05);
  return Math.ceil(CONFIG.enemyHp(n) / pDmg) <= Math.ceil(p.hp / eDmg);
}
S = defaultState();
S.realm = 8; S.layer = 8;
S.artifacts = []; S.equipped = { attack: null, defense: null, support: null };
assert("真仙满层过不了末关（仙界段梯度成立）", (() => {
  S.realm = 9; S.layer = 8;
  return canClearStage(41) === false;
})());
S.realm = 10; S.layer = 8;
assert("金仙满层裸装可通过末关（主线可收尾）", canClearStage(41) === true);

S.realm = 8; S.layer = 8;
assert("渡劫满层无法通过末关（新章需要真仙/金仙）", canClearStage(41) === false);

S.realm = 2; S.layer = 8;
assert("金丹满层无法通过末关（难度梯度成立）", canClearStage(41) === false);

S.realm = 4; S.layer = 8;
assert("化神满层可打第 3 章中段，但章末 BOSS 仍需更高境界",
  canClearStage(16) === true && canClearStage(17) === false);

S.realm = 8; S.layer = 8;
assert("渡劫满层可通第 30 关（旧终点前收尾）", canClearStage(30) === true);

mockRandom = 0.99;

// ===== 阶段 19：药力系统与修炼加成（v0.8.0）=====
console.log("\n== 19. 药力与修炼加成 ==");
S = defaultState();
S.lastOnline = Date.now();
assert("默认药力为 0", S.pillBuff === 0);

// A 方案（v0.10.0）：突破成本增速与飞升时长
assert("突破成本使用 BREAK_GROWTH 单一数据源", CONFIG.BREAK_GROWTH === 1.29);
assert("breakCost(0) = 100（起点不变）", Math.abs(CONFIG.breakCost(0) - 100) < 1e-9);
assert("breakCost 按 BREAK_GROWTH 指数增长",
  Math.abs(CONFIG.breakCost(10) - 100 * Math.pow(CONFIG.BREAK_GROWTH, 10)) < 1e-6);
// 飞升时长推算：从炼气1层到渡劫9层
function _ascendDays(mult) {
  // v0.13.0：境界数动态（11 境 99 层），末层 k=98
  const maxK = CONFIG.REALMS.length * CONFIG.LAYERS_PER_REALM - 1;
  let t = 0;
  for (let k = 0; k < maxK; k++) {
    const r = Math.floor(k / CONFIG.LAYERS_PER_REALM);
    const l = k % CONFIG.LAYERS_PER_REALM;
    t += CONFIG.breakCost(k) / (CONFIG.baseRate(r, l) * mult);
  }
  return t / 86400;
}
const _multOf = (pLv, gLv, pillLv, art, bless) =>
  (1 + CONFIG.PRACTICE_RATE_BONUS * pLv) * (1 + CONFIG.GONGFA_RATE_BONUS * gLv)
  * (1 + Math.min(pillLv * CONFIG.PILL_RATE_BONUS, CONFIG.PILL_BONUS_CAP))
  * (1 + art) * (bless ? 1.1 : 1);
const _idleDays = _ascendDays(1);
const _normalDays = _ascendDays(_multOf(8, 8, 30, 0, false));
const _maxDays = _ascendDays(_multOf(25, 25, 100, 0.28, true));
assert("纯挂机飞升约 50 天", _idleDays > 45 && _idleDays < 55);
assert("常规经营飞升约 2 周（12~16 天）", _normalDays >= 12 && _normalDays <= 16);
assert("极限配置飞升不短于 2 天（避免一天通关）", _maxDays >= 2);
assert("飞升时长梯度成立（挂机 > 常规 > 极限）", _idleDays > _normalDays && _normalDays > _maxDays);

// 无炼丹房时不能炼化药力（药力上限 = 炼丹房等级 × 10）
invSet("pill", 5);
const noAlch = usePill();
assert("无炼丹房时拒绝炼化药力", !noAlch.ok && S.pills === 5);

// 建炼丹房后可炼化
S.buildings.alchemy = 3;
const rateBefore19 = cultivationRate();
const up = usePill();
assert("炼化药力后药力 +1", S.pillBuff === 1 && up.ok);
assert("炼化药力消耗 1 枚丹药", S.pills === 4);
assert("药力提升修炼速率", cultivationRate() > rateBefore19);
assert("炼化药力不再直接给突破灵气（堵住灵石换灵气的指数漏洞）",
  (() => { const q = S.qi; usePill(); return S.qi === q; })());

// 药力上限与炼丹房等级挂钩，并受 CONFIG 封顶
assert("药力上限 = 炼丹房 Lv3 × 10 = 30 层", pillBuffCapLayers() === 30);
S.buildings.alchemy = 10;
assert("炼丹房 Lv10 药力上限 50 层（恰为 CONFIG 封顶）", pillBuffCapLayers() === 50);
S.buildings.alchemy = 50;
assert("炼丹房再高也不超过 CONFIG 封顶", pillBuffCapLayers() === 50);

// 装满药力后不再消耗丹药
invSet("pill", 500);
S.buildings.alchemy = 10;
for (let i = 0; i < 120; i++) usePill();
assert("药力不超过上限（50 层封顶）", S.pillBuff === 50);
const pillsLeft19 = S.pills;
const full = usePill();
assert("药力已满时拒绝并保留丹药", !full.ok && S.pills === pillsLeft19);

// 药力封顶后倍率 = 1 + PILL_BONUS_CAP
S.realm = 0; S.layer = 0; S.buildings.practice = 0; S.gongfa = 0;
const capRate19 = cultivationRate();
assert("药力满档倍率为 ×2", Math.abs(capRate19 / CONFIG.baseRate(0, 0) / daoDef(S.dao).cult - (1 + CONFIG.PILL_BONUS_CAP)) < 1e-9);

// 练功房/功法按 CONFIG 常量计算（修复 ui 硬编码 5% 的隐患）
S.pillBuff = 0; S.qi = 0;
const baseRate0 = cultivationRate();
S.buildings.practice = 10;
assert("练功房 Lv10 倍率符合 CONFIG.PRACTICE_RATE_BONUS",
  Math.abs(cultivationRate() / baseRate0 - (1 + CONFIG.PRACTICE_RATE_BONUS * 10)) < 1e-9);
S.buildings.practice = 0; S.gongfaBooks.changsheng.lv = 3;   // 长生诀圆满
const _gfCult = gongfaBonus().cult;
assert("长生诀圆满：(2%×3层 + 关窍4%) × 2 = 20%",
  Math.abs(_gfCult - 0.20) < 1e-9);
assert("功法收益接入修炼速率",
  Math.abs(cultivationRate() / baseRate0 - (1 + _gfCult)) < 1e-9);

// 存档迁移补 pillBuff / towerBest
store["wenchangsheng_save_v2"] = JSON.stringify({ realm: 2, layer: 1, qi: 0, stone: 0, buildings: { farm: 0, alchemy: 0, forge: 0, practice: 0, recruit: 0 } });
const migratedPill = migrateState(JSON.parse(store["wenchangsheng_save_v2"]));
assert("旧档迁移补 pillBuff=0", migratedPill.pillBuff === 0);
assert("旧档迁移补 towerBest=0", migratedPill.towerBest === 0);

// ===== 阶段 20：声望双出口（v0.8.0）=====
console.log("\n== 20. 声望消耗出口 ==");
S = defaultState();
S.lastOnline = Date.now();
S.reputation = 100;
const ex1 = exchangeRepForTribPill();
assert("声望兑换渡劫丹成功", ex1.ok && S.tribPills === 1 && S.reputation === 100 - CONFIG.REP_TO_TRIBPILL);
S.reputation = 0;
const ex2 = exchangeRepForTribPill();
assert("声望不足时兑换失败", !ex2.ok && S.tribPills === 1);

// 提弟子资质
S = defaultState();
S.reputation = 500;
S.disciples = [{ id: 901, name: "测试弟子", aptitude: 1, realm: 0, layer: 0, loyalty: 60, mood: 80, assignedTo: null, cultivation: 0 }];
const apt1 = upgradeDiscipleAptitude(901);
assert("凡品 → 灵品 提升成功", apt1.ok && S.disciples[0].aptitude === 2 && S.reputation === 500 - CONFIG.REP_APTITUDE_COST[1]);
const apt2 = upgradeDiscipleAptitude(901);
assert("灵品 → 仙品 提升成功", apt2.ok && S.disciples[0].aptitude === 3);
const apt3 = upgradeDiscipleAptitude(901);
assert("仙品无法再提", !apt3.ok);
S.reputation = 0;
S.disciples[0].aptitude = 1;
const apt4 = upgradeDiscipleAptitude(901);
assert("声望不足时提资质失败", !apt4.ok);
// 资质提升会增强产出
S.disciples[0].aptitude = 1;
const outLow = discipleOutputBonus(S.disciples[0]);
S.disciples[0].aptitude = 3;
const outHigh = discipleOutputBonus(S.disciples[0]);
assert("资质提升增强弟子产出", outHigh > outLow);

// ===== 阶段 21：无尽试炼塔（v0.8.0）=====
console.log("\n== 21. 无尽试炼塔 ==");
S = defaultState();
S.lastOnline = Date.now();
S.stamina = 30;
assert("塔敌战力随层数单调递增", towerFloorPower(1) < towerFloorPower(10) && towerFloorPower(10) < towerFloorPower(30));
assert("第 1 层可被炼气初期击破", (() => {
  S.realm = 0; S.layer = 0; S.artifacts = []; S.equipped = { attack: null, defense: null, support: null };
  const e = towerEnemy(1);
  return simulateBattleWith(e.attack, e.defense, e.hp).win === true;
})());
assert("每 10 层为守关妖兽", towerIsBoss(10) && towerIsBoss(25) === false && towerIsBoss(40));
assert("守关层敌人更强", towerEnemy(10).power > towerEnemy(9).power * 1.15);
assert("奖励随层数增长", towerReward(20).stone > towerReward(1).stone);
assert("每 5 层给灵材", towerReward(5).mat > 0 && towerReward(4).mat === 0);

// 挑战：胜利推进
S.stamina = 30; S.towerBest = 0;
const t1 = challengeTower();
assert("第 1 层挑战成功并推进", t1.ok && t1.win && S.towerBest === 1);
assert("挑战消耗 1 体力", S.stamina === 29);
const stoneAfterTower = S.stone;
assert("通关发放灵石奖励", stoneAfterTower > 50);

// 挑战：失败不推进
S.towerBest = 500;   // 远超炼气实力
const t2 = challengeTower();
assert("高层挑战失败但无惩罚", t2.ok && !t2.win && S.towerBest === 500);
assert("失败不扣灵石", S.stone === stoneAfterTower);

// 体力不足
S.stamina = 0;
const t3 = challengeTower();
assert("体力不足时拒绝挑战", !t3.ok);
S.stamina = 1;
assert("体力为 1 时可挑战", (() => { const r = challengeTower(); return r.ok; })());

// 守关层奖励翻倍灵石
assert("守关层灵石翻倍", towerReward(10).stone >= towerReward(9).stone * 2 * 0.9);

// ===== 阶段 22：妖兽 / 秘境图鉴与新增成就（v0.8.0）=====
console.log("\n== 22. 图鉴扩展与新增成就 ==");
assert("妖兽图鉴配置 10 条", CONFIG.CODEX_BEASTS.length === 10);
assert("秘境图鉴配置 7 条（对应 7 章）", CONFIG.CODEX_REGIONS.length === CONFIG.CHAPTERS.length);

S = defaultState();
S.lastOnline = Date.now();
assert("默认妖兽图鉴为空", codexBeastCount() === 0 && codexRegionCount() === 0);
recordBeastCodex("wolf");
recordRegionCodex("region_ch0");
assert("图鉴收录生效", codexBeastSeen("wolf") && codexRegionSeen("region_ch0"));
assert("图鉴收录幂等（重复不覆盖首见记录）", (() => {
  const first = S.codex.beasts.wolf;
  recordBeastCodex("wolf");
  return S.codex.beasts.wolf === first;
})());

// 击杀章节 BOSS 自动收录
S = defaultState();
S.lastOnline = Date.now();
S.stamina = 30;
S.realm = 8; S.layer = 8;   // 渡劫满层，必能打过第 1 章 BOSS（第 5 关）
const bossRes = startBattle(5);
assert("击杀第 1 章 BOSS 收录妖兽与秘境",
  bossRes.win && codexBeastSeen("wolf") && codexRegionSeen("region_ch0"));

// 新增成就
assert("成就总数 49（v0.11.0 +7 / v0.12.0 +3 / v0.13.0 +5）", CONFIG.ACHIEVEMENTS.length === 49);
assert("试炼塔成就存在", ["tower_10", "tower_25", "tower_40"].every(k =>
  CONFIG.ACHIEVEMENTS.some(d => d.key === k)));
assert("图鉴补全成就存在", ["beast_all", "region_all"].every(k =>
  CONFIG.ACHIEVEMENTS.some(d => d.key === k)));
assert("成就分类包含「试炼」", CONFIG.ACHIEVEMENTS.some(d => achievementGroup(d) === "试炼"));
assert("新成就均有判定器", CONFIG.ACHIEVEMENTS.every(d => typeof ACHIEVEMENT_CHECKERS[d.key] === "function"));

// 塔成就判定
S = defaultState();
S.achievements = {}; S.towerBest = 10;
codexTick();
assert("达到 10 层即解锁 tower_10 成就", S.achievements["tower_10"] != null);
assert("未达 25 层不解锁 tower_25", S.achievements["tower_25"] == null);

// ===== 阶段 23：塔币与塔阁（v0.9.0）=====
console.log("\n== 23. 塔币与塔阁 ==");
S = defaultState();
S.lastOnline = Date.now();
S.stamina = 30;
assert("塔币初始为 0", (S.towerCoin || 0) === 0);
assert("第 1 层塔币 = 1", towerCoinFor(1) === 1);
assert("第 10 层塔币 = 2（每 10 层 +1）", towerCoinFor(10) === 2);
assert("第 25 层塔币 = 3", towerCoinFor(25) === 3);
assert("塔币随层数单调不减", towerCoinFor(44) >= towerCoinFor(30) && towerCoinFor(30) >= towerCoinFor(5));

// 通关得塔币
const coinBefore23 = S.towerCoin || 0;
const tw1 = (() => { S.realm = 0; S.layer = 0; S.artifacts = []; S.equipped = { attack: null, defense: null, support: null }; return challengeTower(); })();
assert("通关第 1 层获得塔币", tw1.ok && tw1.win && S.towerCoin === coinBefore23 + 1);
assert("返回值带塔币数量", tw1.coin === 1);

// 失败不得塔币
S.towerBest = 500;
const coinMid23 = S.towerCoin;
const tw2 = challengeTower();
assert("失败不获得塔币", !tw2.win && S.towerCoin === coinMid23);

// 兑换法宝
S = defaultState();
S.lastOnline = Date.now();
S.towerCoin = 100;
const exT1 = exchangeTower("art_attack");
assert("兑换塔阁法宝成功", exT1.ok && exT1.artifact && S.artifacts.length === 1);
assert("塔阁法宝为仙器阶（6 品）", exT1.artifact.tier === 6);
assert("塔阁法宝带专属命名", exT1.artifact.name === "试炼·本命法宝" && exT1.artifact.fromTower === true);
assert("兑换扣除塔币", S.towerCoin === 70);
assert("塔阁法宝进入法宝图鉴", codexArtifactSeen(6, "attack"));

// 三种类型都可兑换
const exT2 = exchangeTower("art_defense");
const exT3 = exchangeTower("art_support");
assert("护身/辅道塔阁法宝可兑换", exT2.ok && exT3.ok && S.artifacts.length === 3 && S.towerCoin === 10);

// 资源兑换
const matBefore23 = S.materials || 0;
const exT4 = exchangeTower("mat20");
assert("兑换灵材包", exT4.ok && (S.materials || 0) === matBefore23 + 20 && S.towerCoin === 0);
const exT5 = exchangeTower("stone2k");
assert("塔币不足时兑换失败", !exT5.ok);

// 未知物品
assert("未知兑换项被拒绝", !exchangeTower("not_exist").ok);

// 迁移补 towerCoin
const migTower23 = migrateState({ realm: 1, layer: 0, qi: 0, stone: 0, buildings: { farm: 0, alchemy: 0, forge: 0, practice: 0, recruit: 0 } });
assert("旧档迁移补 towerCoin=0", migTower23.towerCoin === 0);

// ===== 阶段 25：弟子专精与师徒情谊（v0.10.0）=====
console.log("\n== 25. 弟子专精与师徒情谊 ==");
S = defaultState();
S.lastOnline = Date.now();
assert("专精配置 4 类", CONFIG.SPECIALTIES.length === 4);

const _d25 = createDisciple();
assert("新弟子带专精字段", typeof _d25.specialty === "string" && _d25.specialty.length > 0);
assert("新弟子专精属于合法值", CONFIG.SPECIALTIES.some(x => x.key === _d25.specialty));
assert("新弟子情谊为 0", _d25.bond === 0);

// 专精匹配加成
const _base = { id: 1, name: "甲", aptitude: 1, realm: 0, layer: 0, loyalty: 60, mood: 80, cultivation: 0, specialty: "farm", bond: 0 };
const _outUnassigned = discipleOutputBonus(_base);
const _outMatched = discipleOutputBonus(Object.assign({}, _base, { assignedTo: "farm" }));
const _outMismatch = discipleOutputBonus(Object.assign({}, _base, { assignedTo: "forge" }));
assert("专精匹配时产出 +50%",
  Math.abs(_outMatched / _outUnassigned - (1 + CONFIG.SPECIALTY_MATCH_BONUS)) < 1e-9);
assert("委派到非专精建筑无额外加成",
  Math.abs(_outMismatch - _outUnassigned) < 1e-9);
assert("specialtyMatched 判定正确",
  specialtyMatched(Object.assign({}, _base, { assignedTo: "farm" })) === true &&
  specialtyMatched(Object.assign({}, _base, { assignedTo: "forge" })) === false);

// 嫡传加成
const _outElite = discipleOutputBonus(Object.assign({}, _base, { assignedTo: "farm", bond: CONFIG.BOND_ELITE_THRESHOLD }));
const _outNormal = discipleOutputBonus(Object.assign({}, _base, { assignedTo: "farm", bond: 89 }));
assert("情谊达嫡传门槛再 +20%",
  Math.abs(_outElite / _outNormal - (1 + CONFIG.BOND_ELITE_BONUS)) < 1e-9);

// 情谊每日增长
S = defaultState(); S.lastOnline = Date.now();
S.disciples = [
  { id: 1, name: "甲", aptitude: 1, realm: 0, layer: 0, loyalty: 60, mood: 80, assignedTo: "farm", cultivation: 0, specialty: "farm", bond: 0 },
  { id: 2, name: "乙", aptitude: 1, realm: 0, layer: 0, loyalty: 60, mood: 80, assignedTo: null, cultivation: 0, specialty: "forge", bond: 0 },
];
npcTick();
assert("委派中弟子情谊每日 +2", S.disciples[0].bond === CONFIG.BOND_GAIN_ASSIGNED);
assert("空闲弟子情谊每日 +1", S.disciples[1].bond === CONFIG.BOND_GAIN_IDLE);
assert("情谊不超过上限", (() => {
  S.disciples[0].bond = CONFIG.BOND_MAX;
  npcTick();
  return S.disciples[0].bond === CONFIG.BOND_MAX;
})());

// 情谊 ≥60 时忠诚不再自然下降（即便心境低）
S.disciples = [
  { id: 3, name: "丙", aptitude: 1, realm: 0, layer: 0, loyalty: 50, mood: 10, assignedTo: null, cultivation: 0, specialty: "farm", bond: CONFIG.BOND_LOYALTY_GUARD },
];
mockRandom = 0;   // mood -5 → 5，触发低心境分支
npcTick();
assert("情谊达守护线后忠诚不再自然下降", S.disciples[0].loyalty === 50);
S.disciples[0].bond = 0; S.disciples[0].loyalty = 50; S.disciples[0].mood = 10;
npcTick();
assert("情谊不足时低心境仍会掉忠诚", S.disciples[0].loyalty < 50);
mockRandom = 0.99;

// 情谊称号
assert("情谊称号分级正确",
  bondTitle({ bond: 0 }) === "生疏" &&
  bondTitle({ bond: 30 }) === "相熟" &&
  bondTitle({ bond: CONFIG.BOND_LOYALTY_GUARD }) === "亲近" &&
  bondTitle({ bond: CONFIG.BOND_ELITE_THRESHOLD }) === "嫡传");

// 迁移补字段
const _migD = migrateState({
  realm: 0, layer: 0, qi: 0, stone: 0,
  buildings: { farm: 0, alchemy: 0, forge: 0, practice: 0, recruit: 0 },
  disciples: [{ id: 1, name: "旧", aptitude: 1, realm: 0, layer: 0, loyalty: 60, mood: 80, assignedTo: "forge", cultivation: 0 }],
});
assert("旧档弟子补专精（对齐委派建筑）", _migD.disciples[0].specialty === "forge");
assert("旧档弟子补情谊=0", _migD.disciples[0].bond === 0);

// ===== 阶段 27：剧本分支与道心结局（v0.12.0）=====
console.log("\n== 27. 剧本分支与道心结局 ==");
S = defaultState(); S.lastOnline = Date.now();
assert("五章均有二选一分支", CONFIG.CHAPTERS.every(c => c.story.choices && c.story.choices.length === 2));
assert("初始无道心加成", storyBonus().chosen === 0 && storyBonus().atk === 0);
assert("未选满时不结算道心", storyEnding() === null);

// 全选「战」
const NCH = CONFIG.CHAPTERS.length;
const _atk0 = playerCombat().attack;
for (let i = 0; i < NCH; i++) chooseStory(i, "war");
const _sb = storyBonus();
assert("全战：战 = 章节数 道 0", _sb.war === NCH && _sb.dao === 0);
assert("全战攻击加成 = 章节数 × 2%", Math.abs(_sb.atk - NCH * CONFIG.STORY_WAR_ATK) < 1e-9);
const _atk1 = playerCombat().attack;
assert("攻击随战之选择提升", _atk1 > _atk0);
const _end1 = storyEnding();
assert("全战结局为剑心通明", _end1 && _end1.key === "war" && _end1.title === "剑心通明");
assert("战之道心成就可解锁", (() => { S.achievements = {}; codexTick(); return S.achievements["story_war"] != null; })());

// 全选「道」
S = defaultState(); S.lastOnline = Date.now();
const _rate0 = cultivationRate();
for (let i = 0; i < NCH; i++) chooseStory(i, "dao");
const _sb2 = storyBonus();
assert("全道：修炼加成 = 章节数 × 1.5%", Math.abs(_sb2.cult - NCH * CONFIG.STORY_DAO_CULT) < 1e-9);
assert("修炼速率随道之选择提升", cultivationRate() > _rate0);
assert("全道结局为道心澄澈", storyEnding().key === "dao");
assert("道之道心成就可解锁", (() => { S.achievements = {}; codexTick(); return S.achievements["story_dao"] != null; })());

// 均衡（4 战 3 道，占比 57% < 70%）
S = defaultState(); S.lastOnline = Date.now();
const _bal = [];
for (let i = 0; i < NCH; i++) _bal.push(i < Math.ceil(NCH / 2) ? "war" : "dao");
_bal.forEach((p, i) => chooseStory(i, p));
assert("均衡结局为心剑双修", storyEnding().key === "balance");
assert("双修成就可解锁", (() => { S.achievements = {}; codexTick(); return S.achievements["story_balance"] != null; })());

// 迁移与边界
const _mig27 = migrateState({ realm: 0, layer: 0, qi: 0, stone: 0, buildings: { farm: 0, alchemy: 0, forge: 0, practice: 0, recruit: 0 } });
assert("旧档迁移补 storyChoices", _mig27.storyChoices && typeof _mig27.storyChoices === "object");
assert("无效章节被拒绝", chooseStory(99, "war").ok === false);
assert("无效选项被拒绝", chooseStory(0, "nope").ok === false);

// ===== 阶段 26：章节叙事与 v0.11.0 新内容 =====
console.log("\n== 26. 章节叙事 / 新事件链 / 新成就 ==");

// 26.1 章节叙事
S = defaultState(); S.lastOnline = Date.now(); S.stamina = 30;
assert("五章均有叙事文本", CONFIG.CHAPTERS.every(c => c.story && c.story.title && c.story.text));
S.realm = 8; S.layer = 8;
const _b26 = startBattle(5);   // 第 1 章 BOSS
assert("首次通关章节 BOSS 返回叙事与分支", !!(_b26.win && _b26.story && _b26.story.title && _b26.story.choices && _b26.story.choices.length === 2));
assert("未做选择前不写 storySeen（中途离开会重弹）", !S.storySeen || S.storySeen[0] == null);
S.stamina = 30;
const _b26b = startBattle(5);
assert("未选择时重刷同章仍会弹叙事", _b26b.win && !!_b26b.story);

// 做出选择后：记录 + 永久加成 + 不再弹
const _atkBefore = playerCombat().attack;
const _ch26 = chooseStory(0, "war");
assert("选择成功并记录 storyChoices", _ch26.ok && S.storyChoices[0] === "war");
assert("选择后写入 storySeen", S.storySeen[0] != null);
assert("选「战」提升攻击", playerCombat().attack > _atkBefore);
assert("同一章不可重复选择", chooseStory(0, "dao").ok === false);
S.stamina = 30;
const _b26c = startBattle(5);
assert("已选择后重刷不再弹叙事", _b26c.win && !_b26c.story);

// 26.2 古战场遗迹
S = defaultState(); S.lastOnline = Date.now(); S.stamina = 30; S.realm = 2;
S.activeEvent = { chain: "battleground", stage: 1, flags: {} };
const _mat26 = S.materials || 0;
const _bg1 = resolveEvent("search");
assert("古战场·外围搜刮得灵材", _bg1.ok && S.materials === _mat26 + CONFIG.BATTLEGROUND_SEARCH_MAT);
assert("外围搜刮后事件结束", S.activeEvent === null);

S.activeEvent = { chain: "battleground", stage: 1, flags: {} };
S.stamina = 30;
mockRandom = 0;   // 保证战斗胜利
const _bg2 = resolveEvent("enter");
assert("古战场·探入胜利进入阵心", _bg2.ok && _bg2.next === true && S.activeEvent.stage === 2);
assert("探入消耗 1 体力", S.stamina === 29);
const _artCount26 = S.artifacts.length;
const _bg3 = resolveEvent("loot");
assert("阵心掘取残兵得灵材与法宝",
  _bg3.ok && S.artifacts.length === _artCount26 + 1 && S.artifacts[S.artifacts.length - 1].tier === CONFIG.BATTLEGROUND_ART_TIER);
assert("掘取残兵累计 battlegroundWins", S.stats.battlegroundWins === 1);
assert("古战场事件结束后清空", S.activeEvent === null);

// 若体力不足则拒绝
S.activeEvent = { chain: "battleground", stage: 1, flags: {} };
S.stamina = 0;
assert("体力不足时不能探入战阵", resolveEvent("enter").ok === false);
S.activeEvent = null;

// 26.3 丹道大会
S = defaultState(); S.lastOnline = Date.now(); S.buildings.alchemy = 3; invSet("pill", 10);
S.activeEvent = { chain: "pillmeet", stage: 1, flags: {} };
const _pm1 = resolveEvent("attend");
assert("赴会消耗丹药并进入比试", _pm1.ok && _pm1.next && S.pills === 10 - CONFIG.PILLMEET_ENTRY_PILLS && S.activeEvent.stage === 2);
mockRandom = 0;   // 保证夺魁
const _rep26 = S.reputation;
const _stone26 = S.stone;
const _pm2 = resolveEvent("contest");
assert("斗丹夺魁得声望与灵石",
  _pm2.ok && S.reputation === _rep26 + CONFIG.PILLMEET_WIN_REP && S.stone === _stone26 + CONFIG.PILLMEET_WIN_STONE);
assert("夺魁累计 pillmeetWins", S.stats.pillmeetWins === 1);

// 丹药不足
S.activeEvent = { chain: "pillmeet", stage: 1, flags: {} };
invSet("pill", 1);
assert("丹药不足时不能赴会", resolveEvent("attend").ok === false);
S.activeEvent = { chain: "pillmeet", stage: 2, flags: {} };
assert("丹药不足时不能斗丹", resolveEvent("contest").ok === false);
S.activeEvent = null;
mockRandom = 0.99;

// 26.4 新事件链收录图鉴
assert("两条新事件链已入事迹图鉴配置",
  CONFIG.CODEX_EVENTS.some(e => e.key === "battleground") &&
  CONFIG.CODEX_EVENTS.some(e => e.key === "pillmeet"));
S = defaultState(); S.codex = { artifacts: {}, events: {} };
S.activeEvent = { chain: "pillmeet", stage: 1, flags: {} };
markChain("pillmeet");
assert("触发即收录新链图鉴", codexEventSeen("pillmeet"));
S.activeEvent = null;

// 26.5 新成就判定
S = defaultState(); S.achievements = {};
S.storySeen = {};
for (let i = 0; i < CONFIG.CHAPTERS.length; i++) S.storySeen[i] = i + 1;
S.towerBest = 44;
S.reputation = 500;
S.disciples = [{ id: 1, name: "甲", aptitude: 1, realm: 0, layer: 0, loyalty: 60, mood: 80, assignedTo: null, cultivation: 0, specialty: "farm", bond: 90 }];
S.artifacts = [];
const _a1 = makeArtifact(6, "attack"), _a2 = makeArtifact(6, "defense"), _a3 = makeArtifact(6, "support");
S.artifacts.push(_a1, _a2, _a3);
S.equipped = { attack: _a1.id, defense: _a2.id, support: _a3.id };
S.stats = { battleWins: 0, bossWins: 0, battlegroundWins: 1, pillmeetWins: 1 };
codexTick();
["story_all", "battleground_win", "pillmeet_win", "art_t6_x3", "disciple_elite", "rep_500", "tower_44"].forEach(k => {
  assert(`新成就「${k}」可解锁`, S.achievements[k] != null);
});
assert("新成就均有判定器", CONFIG.ACHIEVEMENTS.every(d => typeof ACHIEVEMENT_CHECKERS[d.key] === "function"));
assert("新成就均有名称/描述/奖励", CONFIG.ACHIEVEMENTS.every(d => d.name && d.desc && d.reward));
assert("成就分组含「剧情」", CONFIG.ACHIEVEMENTS.some(d => achievementGroup(d) === "剧情"));

// 26.6 迁移补齐
const _mig26 = migrateState({
  realm: 0, layer: 0, qi: 0, stone: 0,
  buildings: { farm: 0, alchemy: 0, forge: 0, practice: 0, recruit: 0 },
});
assert("旧档迁移补 storySeen", _mig26.storySeen && typeof _mig26.storySeen === "object");
assert("旧档迁移补 battlegroundWins/pillmeetWins",
  _mig26.stats.battlegroundWins === 0 && _mig26.stats.pillmeetWins === 0);

// ===== 阶段 28：仙界段（v0.13.0 境界扩展 / 新章节 / 塔上限）=====
console.log("\n== 28. 仙界段与内容扩展 ==");
S = defaultState(); S.lastOnline = Date.now();
assert("境界共 11 境", CONFIG.REALMS.length === 11);
assert("含真仙与金仙", CONFIG.REALMS[9] === "真仙" && CONFIG.REALMS[10] === "金仙");

// 满层判定
S.realm = 8; S.layer = 8;
assert("渡劫满层不再视为终局", isMaxRealm() === false);
S.realm = 10; S.layer = 7;
assert("金仙 8 层仍未终局", isMaxRealm() === false);
S.realm = 10; S.layer = 8;
assert("金仙 9 层为终局（可飞升）", isMaxRealm() === true);

// 渡劫满层可继续突破到真仙（含渡劫判定）
S = defaultState(); S.lastOnline = Date.now();
S.realm = 8; S.layer = 8;
S.qi = CONFIG.breakCost(80) * 2;
mockRandom = 0;   // 渡劫必成
const _br28 = doBreak();
assert("渡劫满层可渡劫晋真仙", _br28.ok && _br28.trib && _br28.success && S.realm === 9);
mockRandom = 0.99;

// 分段难度曲线
assert("第 29 关沿用旧曲线", Math.abs(CONFIG.enemyAttack(29) - 5 * Math.pow(1.5, 29)) < 1e-6);
assert("第 30 关起换用 TIER2_GROWTH",
  Math.abs(CONFIG.enemyAttack(30) - 5 * Math.pow(1.5, 29) * CONFIG.TIER2_GROWTH) < 1e-6);
assert("分段处无跳变（第29→30 关连续）",
  CONFIG.enemyAttack(30) / CONFIG.enemyAttack(29) < 1.3);

// 新章节 BOSS 收录妖兽 / 秘境
S = defaultState(); S.lastOnline = Date.now(); S.stamina = 30;
S.realm = 10; S.layer = 8;
const _b35 = startBattle(35);   // 第 6 章 BOSS
assert("第 6 章 BOSS 收录星骸巨兽与星陨古域",
  _b35.win && codexBeastSeen("starbeast") && codexRegionSeen("region_ch5"));
S.stamina = 30;
const _b41 = startBattle(41);   // 第 7 章 BOSS
assert("第 7 章 BOSS 收录混元守道人与混元道场",
  _b41.win && codexBeastSeen("chaoslord") && codexRegionSeen("region_ch6"));

// 塔上限随境界提升（C 项）
function _towerMax(realm) {
  S.realm = realm; S.layer = 8;
  S.artifacts = []; S.equipped = { attack: null, defense: null, support: null };
  let f = 1;
  while (f < 200) {
    const e = towerEnemy(f);
    const p = playerCombat();
    const pD = Math.max(p.attack - e.defense, p.attack * 0.05);
    const eD = Math.max(e.attack - p.defense, e.attack * 0.05);
    if (Math.ceil(e.hp / pD) > Math.ceil(p.hp / eD)) break;
    f++;
  }
  return f - 1;
}
const _t8 = _towerMax(8), _t10 = _towerMax(10);
assert("渡劫满层塔上限约 44 层", _t8 >= 40 && _t8 <= 48);
assert("金仙满层塔上限超过 45 层（C 项达成）", _t10 > 45);
assert("境界提升可推进塔层", _t10 > _t8);

// 成就
S = defaultState(); S.achievements = {};
S.towerBest = 54; S.bestStage = 42; S.realm = 10;
codexTick();
assert("塔 54 层成就可解锁", S.achievements["tower_54"] != null);
assert("通关第 7 章成就可解锁", S.achievements["battle_ch7"] != null);
assert("金仙境界成就可解锁", S.achievements["realm_10"] != null);

// ===== 阶段 29：秘境战场（v0.16.0）=====
console.log("\n== 29. 秘境战场 ==");
const _prevRandom = Math.random;
let _seed = 20261115;
Math.random = () => { _seed = (_seed * 1664525 + 1013904223) >>> 0; return _seed / 4294967296; };

function _mkField(realm) {
  S = defaultState();
  S.realm = realm; S.layer = 5;
  S.buildings = { farm: 0, alchemy: 0, forge: 3, practice: 5, recruit: 0 };
  S.gongfa = 5;
  S.fieldSlots = [];
  return fldCreate(1);
}

function _dummyMon(f, dx, dy, hp) {
  return {
    id: 900 + Math.floor(Math.random() * 1000), kind: "normal", name: "靶",
    x: f.player.x + dx, y: f.player.y + dy, homeX: f.player.x + dx, homeY: f.player.y + dy,
    r: 18, hp: hp || 1e6, hpMax: hp || 1e6, atk: 10, def: 0, speed: 0,
    atkCd: 99, facing: 0, slowT: 0, aoe: false, aoeCd: 99,
    channel: 0, channelTarget: null, alive: true, hurtT: 0,
  };
}

// —— 生成 ——
const _f0 = _mkField(4);
assert("秘境生成怪物与 BOSS", _f0.monsters.length >= 4 && _f0.monsters.some(m => m.kind === "boss"));
assert("BOSS 固定守在地图北端", _f0.monsters.filter(m => m.kind === "boss")[0].y < _f0.size * 0.3);
assert("秘境名取自章节", _f0.map.name === CONFIG.CHAPTERS[1].name);
assert("技能盘非空", _f0.slots.length > 0);
assert("技能盘不超上限", _f0.slots.length <= CONFIG.FIELD.SKILL_SLOTS);

// —— 移动与边界 ——
const _f1 = _mkField(4);
_f1.auto = false;
const _px0 = _f1.player.x;
for (let i = 0; i < 10; i++) fldStep(_f1, 1 / 60, { mx: 1, my: 0.4 });
assert("摇杆输入改变玩家坐标", Math.abs(_f1.player.x - _px0) > 1);
_f1.player.x = 3; _f1.player.y = 3;
for (let i = 0; i < 6; i++) fldStep(_f1, 1 / 60, { mx: -1, my: -1 });
assert("玩家不能走出地图边界", _f1.player.x >= _f1.player.r - 0.01 && _f1.player.y >= _f1.player.r - 0.01);

// —— 直线技能 ——
const _f2 = _mkField(4);
_f2.auto = false;
_f2.monsters = [_dummyMon(_f2, 150, 0)];
assert("直线技能可释放", fldCast(_f2, "jian_qi", 1, 0).ok);
assert("直线技能生成投射物", _f2.projectiles.length > 0);
for (let i = 0; i < 60 && _f2.projectiles.length; i++) fldStep(_f2, 1 / 60, { mx: 0, my: 0 });
assert("直线技能命中前方目标", _f2.monsters[0].hp < 1e6);
assert("技能进入冷却", (_f2.cds["jian_qi"] || 0) > 0);
assert("冷却中拒绝释放", !fldCast(_f2, "jian_qi", 1, 0).ok);

// —— 方向性：反向释放打不中 ——
const _f3 = _mkField(4);
_f3.auto = false;
_f3.monsters = [_dummyMon(_f3, 150, 0)];
fldCast(_f3, "jian_qi", -1, 0);
for (let i = 0; i < 60 && _f3.projectiles.length; i++) fldStep(_f3, 1 / 60, { mx: 0, my: 0 });
assert("反向释放打不中正面目标（技能有方向）", _f3.monsters[0].hp === 1e6);

// —— 扇形 ——
const _f4 = _mkField(4);
_f4.auto = false;
_f4.monsters = [_dummyMon(_f4, 120, 0), _dummyMon(_f4, -120, 0)];
fldCast(_f4, "huo_hai", 1, 0);
assert("扇形命中正面敌人", _f4.monsters[0].hp < 1e6);
assert("扇形不打背后敌人", _f4.monsters[1].hp === 1e6);

// —— 环身 ——
const _f5 = _mkField(4);
_f5.auto = false;
_f5.monsters = [_dummyMon(_f5, 60, 40), _dummyMon(_f5, 500, 500)];
fldCast(_f5, "bing_huan", 1, 0);
assert("环身命中贴身敌人", _f5.monsters[0].hp < 1e6);
assert("环身不打远处敌人", _f5.monsters[1].hp === 1e6);
assert("环身施加减速", _f5.monsters[0].slowT > 0);

// —— 自身增益 ——
const _f6 = _mkField(4);
_f6.player.hp = Math.floor(_f6.player.hpMax * 0.3);
fldCast(_f6, "hui_chun", 1, 0);
assert("回春术回复气血", _f6.player.hp > _f6.player.hpMax * 0.3);
const _before = _f6.player.shield;
fldCast(_f6, "xuan_jia", 1, 0);
assert("玄甲术获得护盾", _f6.player.shield > _before);

// —— 真元 ——
const _f7 = _mkField(4);
_f7.player.mana = 0;
assert("真元不足拒绝释放", !fldCast(_f7, "jian_qi", 1, 0).ok);

// —— 怪物追击 ——
const _f8 = _mkField(4);
_f8.auto = false;
_f8.monsters = [_dummyMon(_f8, 200, 0)];
_f8.monsters[0].speed = 100;
const _d0 = Math.hypot(_f8.monsters[0].x - _f8.player.x, _f8.monsters[0].y - _f8.player.y);
for (let i = 0; i < 20; i++) fldStep(_f8, 1 / 60, { mx: 0, my: 0 });
const _d1 = Math.hypot(_f8.monsters[0].x - _f8.player.x, _f8.monsters[0].y - _f8.player.y);
assert("怪物会朝玩家移动", _d1 < _d0);

// —— 击杀与胜负 ——
const _f9 = _mkField(0);
_f9.auto = false;
_f9.monsters = [_dummyMon(_f9, 100, 0, 20), _dummyMon(_f9, -100, 0, 20)];
fldCast(_f9, "jian_qi", 1, 0);
for (let i = 0; i < 60; i++) fldStep(_f9, 1 / 60, { mx: 0, my: 0 });
assert("击杀累计计数", _f9.killCount >= 1);
assert("击杀后怪物标记死亡", _f9.monsters.some(m => !m.alive));

// —— 遁速 ——
const _f10 = _mkField(4);
_f10.auto = false;
const _x10 = _f10.player.x;
fldStep(_f10, 0.05, { mx: 1, my: 0, dash: true });
assert("遁速触发冲刺", _f10.dashT > 0 && _f10.player.x > _x10);

// —— 存档 ——
S = defaultState();
assert("存档含技能盘字段", Array.isArray(S.fieldSlots));

// ===== 阶段 30：秘境探索与派遣（v0.17.0）=====
console.log("\n== 30. 秘境探索与派遣 ==");

S = defaultState(); S.realm = 4; S.layer = 5;
S.buildings = { farm: 0, alchemy: 0, forge: 3, practice: 5, recruit: 0 };
S.gongfa = 5; S.fieldSlots = []; S.bestStage = 12; S.clearedMaps = {}; S.mapTeam = {};

const _e1 = fldCreate(1);
assert("秘境生成采集节点", _e1.nodes.length === CONFIG.FIELD_MAP_NODES[1]);
assert("节点覆盖多类资源", new Set(_e1.nodes.map(n => n.kind)).size >= 3);
_e1.auto = false;
const _nd = _e1.nodes[0];
_e1.player.x = _nd.x; _e1.player.y = _nd.y;
const _res0 = S.stone + S.qi + S.herbs + (S.materials || 0);
for (let i = 0; i < 150; i++) fldStep(_e1, 1 / 60, { mx: 0, my: 0 });
assert("贴近节点自动采集完成", _nd.done);
assert("采集产出资源", (S.stone + S.qi + S.herbs + (S.materials || 0)) > _res0);
assert("采集增加探索度", _e1.explore > 0);

const _e2 = fldCreate(1);
_e2.auto = false;
const _nd2 = _e2.nodes[1];
_e2.player.x = _nd2.x; _e2.player.y = _nd2.y;
fldStep(_e2, 0.25, { mx: 0, my: 0 });
assert("采集中有进度", _e2.nodes.some(n => n.progress > 0));
_e2.player.x = _nd2.x + 500;
fldStep(_e2, 0.05, { mx: 0, my: 0 });
assert("走开则采集进度归零", _nd2.progress === 0);

const _e3 = fldCreate(1);
assert("本章探索总量已计算", _e3.exploreMax > 0);
fldAddExplore(_e3, Math.ceil(_e3.exploreMax * 0.8), 0, 0);
assert("探索度达 75% 开启传送阵", !!_e3.portal);
_e3.auto = false;
_e3.player.x = _e3.portal.x; _e3.player.y = _e3.portal.y;
fldStep(_e3, 1 / 60, { mx: 0, my: 0 });
assert("走进传送阵即通关", _e3.over && _e3.win);

// 派遣
S = defaultState(); S.realm = 3; S.bestStage = 12;
S.clearedMaps = {}; S.mapTeam = {};
S.disciples = [
  { id: "dx1", name: "甲", realm: 2, aptitude: 1, specialty: "farm", loyalty: 80, bond: 95, assignedTo: null, mood: 70, cultivation: 0 },
  { id: "dx2", name: "乙", realm: 1, aptitude: 0, specialty: "forge", loyalty: 60, bond: 10, assignedTo: null, mood: 70, cultivation: 0 },
];
assert("未探明不能派遣", !assignDispatch(1, "dx1").ok);
S.clearedMaps[1] = true;
S.clearedMaps[2] = true;
assert("探明后可派遣", assignDispatch(1, "dx1").ok);
assert("队伍含该弟子", dispatchTeam(1).length === 1);
assert("派遣产出大于零", dispatchRate(1).stone > 0);
const _st0 = S.stone;
dispatchTick(10);
assert("派遣随时间产出灵石", S.stone > _st0);
assignDispatch(2, "dx1");
assert("转派后原秘境移除", dispatchTeam(1).length === 0 && dispatchTeam(2).length === 1);
assert("离线结算有产出", dispatchOffline(3600).stone > 0);
assert("弟子境界参与派遣产出（realm 字段真实生效）",
  dispatchRateOne({ realm: 3, loyalty: 60, specialty: "forge", bond: 0 }) >
  dispatchRateOne({ realm: 0, loyalty: 60, specialty: "forge", bond: 0 }));

// 回归：事件缓冲不得随时间膨胀（v0.17.1 全场抖动修复）
const _evt = fldCreate(1);
_evt.auto = false;
const _cnt = [];
for (let i = 0; i < 400; i++) {
  fldStep(_evt, 1 / 60, { mx: 0, my: 0 });
  const _ee = fldDrainEvents(_evt);
  _cnt.push(_ee.length);
  if (_evt.over) break;
}
const _early = _cnt.slice(0, 20).reduce((a, b) => a + b, 0);
const _late = _cnt.slice(-20).reduce((a, b) => a + b, 0);
assert("每帧事件数不随时间膨胀", _late <= _early * 3 + 10);
assert("事件缓冲被消费后清空", _evt.events.length === 0);

const _evt2 = fldCreate(1);
_evt2.auto = false;
const _r1 = fldStep(_evt2, 1 / 60, { mx: 0, my: 0 });
const _r2 = fldStep(_evt2, 1 / 60, { mx: 0, my: 0 });
assert("fldStep 只返回本帧事件", _r1.length <= 12 && _r2.length <= 12);

// 技能方向控制（v0.17.2）
const _aimR = fsScreenDirToWorld(100, 0);      // 屏幕右 → 世界 +x -y
assert("屏幕右拖拽映射为世界右上方向", _aimR.x > 0 && _aimR.y < 0);
const _aimD = fsScreenDirToWorld(0, 100);      // 屏幕下 → 世界 +x +y
assert("屏幕下拖拽映射为世界右下方向", _aimD.x > 0 && _aimD.y > 0);
const _aimL = fsScreenDirToWorld(-100, 0);     // 屏幕左 → 世界 -x +y
assert("屏幕左拖拽映射为世界左下方向", _aimL.x < 0 && _aimL.y > 0);

const _aimF = fldCreate(1);
_aimF.auto = false;
const _aimP = _aimF.player;
_aimF.monsters = [_dummyMon(_aimF, 120, 0, 1e6)];
assert("扇形指向怪物时命中判定成立",
  fldInCone(_aimF.monsters[0].x, _aimF.monsters[0].y, _aimP.x, _aimP.y, 1, 0, 200, 0.52, _aimF.monsters[0].r));
assert("扇形反向时判定不成立",
  !fldInCone(_aimF.monsters[0].x, _aimF.monsters[0].y, _aimP.x, _aimP.y, -1, 0, 200, 0.52, _aimF.monsters[0].r));

Math.random = _prevRandom;
mockRandom = 0.99;


// ===== 阶段 60：装备 12 格 / 器纹 / 共鸣 / 法宝神通（v0.18.0）=====
console.log("\n== 60. 装备 12 格体系 ==");
S = defaultState();
assert("栏位总数为 12", CONFIG.LOADOUT_SLOTS.length === 12);

S.realm = 0;
assert("炼气期开启 3 格", CONFIG.LOADOUT_SLOTS.filter(x => slotUnlocked(x)).length === 3);
S.realm = 4;
assert("元婴期开启 7 格", CONFIG.LOADOUT_SLOTS.filter(x => slotUnlocked(x)).length === 7);
S.realm = 7;
assert("大乘期 12 格全开", CONFIG.LOADOUT_SLOTS.filter(x => slotUnlocked(x)).length === 12);

S = defaultState();
S.realm = 7;
const _q60fab = { id: 7001, name: "九幽葫芦", tier: 4, type: "fabao", atk: 0, def: 0, hp: 0, cult: 0.15, roll: 1, skill: "fb_zijin", affixes: [], engrave: [] };
const _q60rel = { id: 7002, name: "太古印", tier: 3, type: "relic", atk: 0.05, def: 0.05, hp: 0.03, cult: 0, roll: 1, affixes: [], engrave: [] };
const _q60rel2 = { id: 7003, name: "混沌碑", tier: 3, type: "relic", atk: 0.05, def: 0.05, hp: 0.03, cult: 0, roll: 1, affixes: [], engrave: [] };
S.artifacts.push(_q60fab, _q60rel, _q60rel2);

const _q60r1 = equipToSlot("fabao0", 7001);
assert("法宝可装入法宝栏位", _q60r1.ok === true && slotOfArtifact(7001) === "fabao0");
assert("类型不符不可装入（法宝进古宝栏）", equipToSlot("relic0", 7001).ok === false);
S.realm = 0;
assert("未解锁栏位不可装备", equipToSlot("fabao1", 7001).ok === false);
S.realm = 7;
equipToSlot("relic0", 7002); equipToSlot("relic1", 7003);
const _q60dup = equipToSlot("relic2", 7002);
assert("同一件法宝不能占两格", slotOfArtifact(7002) === "relic2" && _q60dup.ok === true);

// v0.53.3：法宝技独立第五格，不再混入普通境界术式槽。
assert("装备后法宝神通进入独立候选池",
  equippedFabaoSkills().some(x => x.key === "fb_zijin"));
assert("法宝技不占普通术式槽候选池",
  !fldUnlockedSkills(S.realm).some(x => x.key === "fb_zijin"));
S.fabaoSkillSlot = "fb_zijin";
assert("选定法宝技后可进入独立第五格",
  selectedFabaoSkill()?.key === "fb_zijin");
unequipSlot("fabao0");
assert("卸下后法宝神通移出可选池",
  !fldUnlockedSkills(S.realm).some(x => x.key === "fb_zijin"));

// 共鸣：同品阶 ≥2 且品阶 ≥3
let _q60res = resonanceBonus();
assert("两件宝器触发共鸣 +4%", Math.abs(_q60res.bonus - 0.04) < 1e-9 && _q60res.count === 2);
S.artifacts.push({ id: 7004, name: "灵品珠", tier: 1, type: "support", atk: 0, def: 0, hp: 0, cult: 0.1, roll: 1, affixes: [], engrave: [] });
equipToSlot("trinket", 7004);
assert("凡品不参与共鸣", resonanceBonus().count === 2);

// 器纹
S = defaultState();
invSet("material", 9999); S.stone = 999999;
const _q60eng = { id: 7101, name: "测试法器", tier: 4, type: "attack", atk: 0.1, def: 0, hp: 0, cult: 0, roll: 1, affixes: [], engrave: [] };
S.artifacts.push(_q60eng);
const _q60e1 = engraveArtifact(7101);
assert("淬灵成功产出一条器纹", _q60e1.ok === true && _q60eng.engrave.length === 1);
const _q60maxE = engraveMax(_q60eng);
assert("器纹上限按品阶（法器 2 条）", _q60maxE === 2);
engraveArtifact(7101);
assert("器纹满后拒绝再淬", engraveArtifact(7101).ok === false);
equipToSlot("weapon", 7101);
const _q60bb = artifactBonus();
assert("器纹加成计入总加成", (_q60bb.atk + _q60bb.def + _q60bb.hp + _q60bb.cult) > 0.1);

// 存档迁移：旧三槽 → 新栏位
const _q60old = migrateState({ version: 5, artifacts: [{ id: 8801, name: "旧剑", tier: 1, type: "attack", atk: 0.03, def: 0, hp: 0, cult: 0, roll: 1, affixes: [] }], equipped: { attack: 8801, defense: null, support: null } });
assert("旧三槽自动迁入 loadout.weapon", _q60old.loadout.weapon === 8801);
assert("旧法宝补器纹与神通字段", Array.isArray(_q60old.artifacts[0].engrave) && _q60old.artifacts[0].skill === null);


// ===== 阶段 61：功法十阶（v0.20.0，对标一念逍遥）=====
console.log("\n== 61. 功法十阶体系 ==");
S = defaultState();
assert("功法共 25 部", CONFIG.GONGFA_BOOKS.length === 25);
assert("正式目录覆盖六阶，旧十阶字段仍保留兼容", new Set(CONFIG.GONGFA_BOOKS.map(b => b.grade)).size === 6 && new Set(CONFIG.GONGFA_BOOKS.map(b => b.tier)).size === 10);

// 六阶 → 层数与境界
const _gradeLayers = [0, 3, 6, 9, 9, 12, 12];
const _gradeRealms = [0, 0, 1, 2, 3, 4, 9];
const _layerOk = CONFIG.GONGFA_BOOKS.every(b => b.layers === _gradeLayers[b.grade] && b.unlockRealm === _gradeRealms[b.grade]);
assert("六阶层数/境界符合设计稿（3/6/9/9/12/12）", _layerOk);
assert("25 部功法均明确归入四类装备位", CONFIG.GONGFA_BOOKS.every(b => ["xin", "shu", "shen", "dao"].includes(b.category)) && new Set(CONFIG.GONGFA_BOOKS.map(b => b.category)).size === 4);
S.realm = 1;

// 每 3 层必有节点
const _nodeOk = CONFIG.GONGFA_BOOKS.every(b => {
  const ats = b.nodes.map(n => n.at);
  for (let a = 3; a <= b.layers; a += 3) if (ats.indexOf(a) < 0) return false;
  return true;
});
assert("每部功法的关窍节点均落在其可修层数内", _nodeOk && CONFIG.GONGFA_BOOKS.every(b => b.nodes.every(n => n.at <= b.layers)));

// 六阶解锁采用境界门槛 + 上一阶任意一部圆满 + 对应秘籍数量。
assert("二阶须先圆满一阶功法", gongfaUnlocked(CONFIG.GONGFA_BOOKS.find(b => b.grade === 2)) === false);
S.gongfaBooks.changsheng.lv = 3;
assert("一阶圆满后可解锁二阶（境界达标）", gongfaUnlocked(CONFIG.GONGFA_BOOKS.find(b => b.grade === 2)) === true);

// 领悟
assert("长生诀默认已领悟", gongfaLearned("changsheng") === true);
assert("三花聚顶默认未领悟", gongfaLearned("sanhua") === false);
S.realm = 1;
assert("未领悟不可修炼", upgradeGongfa("sanhua").ok === false);
invSet("talisman", 0); invSet("book:sanhua", 0);
assert("秘籍不足不可领悟", learnGongfa("sanhua").ok === false);
invSet("book:sanhua", 3);
const _q61learn = learnGongfa("sanhua");
const _q61migrated = migrateState({ version: 14, realm: 9, wudao: 777, gongfaEquip: { xin: "changsheng", shu: "qingyun", shen: null, dao: null }, gongfaBooks: {
  changsheng: { lv: 3, learned: true }, tiangang: { lv: 9, learned: true }, qingyun: { lv: 6, learned: true }, tianyan: { lv: 12, learned: true }, yuhua: { lv: 12, learned: true }
} });
assert("旧十阶存档迁移为六阶层数且保留原层数审计值", _q61migrated.gongfaBooks.tiangang.lv === 6 && _q61migrated.gongfaBooks.tiangang.legacyLv === 9 && _q61migrated.gongfaBooks.qingyun.lv === 6 && _q61migrated.gongfaBooks.qingyun.legacyLv === 6 && _q61migrated.gongfaBooks.tianyan.lv === 9 && _q61migrated.gongfaBooks.tianyan.legacyLv === 12);
assert("旧档保留悟道、装备与已领悟状态", _q61migrated.wudao === 777 && _q61migrated.gongfaEquip.shu === "qingyun" && _q61migrated.gongfaBooks.yuhua.learned === true);
const _q61migratedAgain = migrateState(_q61migrated);
assert("六阶目录迁移幂等，不重复折算", _q61migratedAgain.gongfaBooks.qingyun.lv === _q61migrated.gongfaBooks.qingyun.lv && _q61migratedAgain.gongfaBooks.qingyun.legacyLv === 6);
const _q61allLegacyBooks = {};
for (const _gb of CONFIG.GONGFA_BOOKS) _q61allLegacyBooks[_gb.key] = { lv: _gb.legacyLayers, learned: true };
const _q61allMigrated = migrateState({ version: 14, gongfaBooks: _q61allLegacyBooks });
assert("25部功法的旧圆满进度均迁移为新圆满且保留旧层数", CONFIG.GONGFA_BOOKS.every(_gb => _q61allMigrated.gongfaBooks[_gb.key].lv === _gb.layers && _q61allMigrated.gongfaBooks[_gb.key].legacyLv === _gb.legacyLayers));
assert("消耗秘籍可领悟", _q61learn.ok === true && bookHeldCount("sanhua") === 2 && gongfaLearned("sanhua"));
assert("未达境界不可领悟（四阶需元婴 realm4）", (S.realm = 1, learnGongfa("tianyan").ok === false));

// 修炼与关窍
S = defaultState();
S.realm = 1; S.stone = 99999999; S.qi = 99999999; S.wudao = 99999999;
const _q61b = gongfaBook("changsheng");
assert("1 层收益 = 2%", Math.abs(gongfaLayerBonus(_q61b, 1).cult - 0.02) < 1e-9);
assert("2 层收益 = 4%（无节点）", Math.abs(gongfaLayerBonus(_q61b, 2).cult - 0.04) < 1e-9);
assert("3 层关窍 +4% 且圆满翻倍 = 20%", Math.abs(gongfaLayerBonus(_q61b, 3).cult - 0.20) < 1e-9);
const _stoneBeforeWudao = S.stone, _qiBeforeWudao = S.qi;
const _q61up = upgradeGongfa("changsheng");
assert("参悟返回层数", _q61up.ok === true && gongfaLv("changsheng") === 1);
assert("功法升层只消耗悟道，不挤占灵石与突破灵气", S.stone === _stoneBeforeWudao && S.qi === _qiBeforeWudao);
assert("满层后拒绝再升", (S.gongfaBooks.changsheng.lv = 3, upgradeGongfa("changsheng").ok === false));
assert("功法四类装备位默认有心法", gongfaEquipState().xin === "changsheng" && gongfaCategory("changsheng") === "xin");
S.gongfaBooks.sanhua.learned = true; S.gongfaBooks.sanhua.lv = 2;
const _eqV2 = equipGongfaV2("sanhua");
assert("已领悟功法可装备到对应类别", _eqV2.ok && gongfaEquipState().xin === "sanhua");
assert("心法装备提供真元战斗加成", Math.abs(gongfaV2Profile().mana - 0.08) < 1e-9);

// 六阶功法：3 处关窍
const _q61s = gongfaBook("sanhua");
const _q61max = gongfaLayerBonus(_q61s, 6);
assert("二阶六层圆满：cult = (1.6%×6 + 3.2%) × 2", Math.abs(_q61max.cult - 0.256) < 1e-9);
assert("二阶六层圆满：hp = (0.8%×6 + 1.6%) × 2", Math.abs(_q61max.hp - 0.128) < 1e-9);

// 多维属性
S = defaultState();
S.gongfaBooks.qingyun.lv = 12;
assert("青云剑诀提供会心", gongfaBonus().crit > 0);
S = defaultState();
S.gongfaBooks.huaxue.lv = 12;
assert("化血神功提供噬血", gongfaBonus().lifesteal > 0);
S = defaultState();
S.gongfaBooks.xingyuan.lv = 12;
assert("星元秘法提供秘境收获与闭关收益",
  gongfaBonus().field > 0 && gongfaBonus().offline > 0);

// 旧存档折算
const _q61old = migrateState({ version: 6, gongfa: 5, artifacts: [], disciples: [] });
assert("旧功法 5 级折算为长生诀 3 层 + 三花聚顶 2 层",
  _q61old.gongfaBooks.changsheng.lv === 3 && _q61old.gongfaBooks.sanhua.lv === 2);
assert("折算后已领悟", _q61old.gongfaBooks.sanhua.learned === true);
assert("旧字段清零不重复折算",
  migrateState(_q61old).gongfaBooks.changsheng.lv === 3);

// 秘境通关给要诀
S = defaultState();
const _q61f = fldCreate(1);
const _q61t0 = S.talisman;
fldEnd(_q61f, true);
assert("秘境通关产出功法残卷", S.talisman > _q61t0);

// 成就
S = defaultState();
S.gongfaBooks.changsheng.lv = 3;
codexTick();
assert("任一功法圆满解锁「功法通玄」", S.achievements.gongfa_10 != null);


// ===== 阶段 62：灵兽跟宠（v0.21.0）=====
console.log("\n== 62. 灵兽系统 ==");
S = defaultState();
assert("灵兽图鉴共 8 种", CONFIG.PETS.length === 8);
assert("初始无灵兽", S.pets.length === 0 && S.petActive === null);

const _q62c = capturePet("chiyan");
assert("收服成功并入库", _q62c.ok === true && S.pets.length === 1);
assert("首只灵兽自动出战", S.petActive === _q62c.pet.id);
assert("图鉴收录灵兽", petSeen("chiyan") === true);

// 出战属性
const _q62pc = petCombat(_q62c.pet);
const _q62p = playerCombat();
assert("灵兽攻击按主人攻击折算", _q62pc.atk > 0 && _q62pc.atk < _q62p.attack);
assert("灵兽攻击等级放大", petCombat({ key: "chiyan", lv: 10 }).atk > petCombat({ key: "chiyan", lv: 1 }).atk);

// 培养
S.stone = 9999999;
const _q62t = trainPet(_q62c.pet.id);
assert("培养消耗灵石并积累经验", _q62t.ok === true && S.pets[0].exp === 1);
S.pets[0].exp = CONFIG.PET_EXP_PER_LV * S.pets[0].lv - 1;
const _q62up = trainPet(_q62c.pet.id);
assert("经验满则升级", _q62up.ok === true && _q62up.levelUp === true && S.pets[0].lv === 2);
S.pets[0].lv = CONFIG.PET_MAX_LV;
assert("满级后拒绝培养", trainPet(_q62c.pet.id).ok === false);

// 数量上限
S = defaultState();
for (let i = 0; i < CONFIG.PET_MAX; i++) capturePet("chiyan");
assert("灵兽栏上限生效", S.pets.length === CONFIG.PET_MAX && capturePet("chiyan").ok === false);

// 战场接入：跟宠实体 + 跟随 + 自动出手
S = defaultState();
capturePet("chiyan");
const _q62f = fldCreate(1);
assert("战场生成跟宠实体", !!_q62f.pet && _q62f.pet.atk > 0);
const _q62x0 = _q62f.pet.x, _q62y0 = _q62f.pet.y;
for (let i = 0; i < 30; i++) fldStep(_q62f, 1 / 30, { mx: 1, my: 0, dash: false });
assert("跟宠随主人移动", Math.hypot(_q62f.pet.x - _q62x0, _q62f.pet.y - _q62y0) > 5);

// 跟宠自动攻击：把一只怪拖到身边，跑够时间应造成伤害
S = defaultState();
capturePet("chiyan");
const _q62f2 = fldCreate(1);
_q62f2.monsters = [{
  id: 99, kind: "normal", name: "木桩", x: _q62f2.player.x + 60, y: _q62f2.player.y,
  homeX: 0, homeY: 0, r: 18, hp: 1e9, hpMax: 1e9, atk: 0, def: 0,
  speed: 0, atkCd: 99, facing: 0, slowT: 0, aoe: false, aoeCd: 99, alive: true,
}];
let _q62hit = false;
// 关闭怪物脱战回血，否则木桩每帧回血会盖过伤害
const _q62res = CONFIG.FIELD.MON_HP_RESET;
CONFIG.FIELD.MON_HP_RESET = 0;
for (let i = 0; i < 90 && !_q62hit; i++) {
  const evs = fldStep(_q62f2, 1 / 30, { mx: 0, my: 0, dash: false });
  for (const e of evs) if (e.type === "petcast") _q62hit = true;
}
CONFIG.FIELD.MON_HP_RESET = _q62res;
assert("跟宠自动索敌出手", _q62hit === true);
assert("跟宠对怪物造成伤害", _q62f2.monsters[0].hp < 1e9);

// 放生
S = defaultState();
const _q62r = capturePet("qinglin");
const _q62rel = releasePet(_q62r.pet.id);
assert("放生移除灵兽", _q62rel.ok === true && S.pets.length === 0 && S.petActive === null);

// 存档迁移
const _q62m = migrateState({ version: 6, artifacts: [], disciples: [], pets: [{ id: 5, key: "chiyan" }] });
assert("旧档补灵兽等级与出战位", _q62m.pets[0].lv === 1 && _q62m.petActive === 5);
assert("灵兽图鉴字段补全", typeof _q62m.codex.pets === "object");


// ===== 阶段 63：角色形象（v0.22.0）=====
console.log("\n== 63. 角色形象 ==");
S = defaultState();
assert("可选形象共 6 个", CONFIG.AVATARS.length === 6);
assert("默认形象为青衫剑客", S.avatar === "qingshan" && currentAvatar().name === "青衫剑客");
assert("每个形象都有立绘路径", CONFIG.AVATARS.every(a => a.img && a.img.indexOf("assets/") === 0));

const _q63before = playerCombat();
const _q63r = setAvatar("hongyi");
assert("切换形象成功", _q63r.ok === true && S.avatar === "hongyi" && currentAvatar().name === "红衣魔修");
const _q63after = playerCombat();
assert("形象不改变任何战斗属性",
  Math.abs(_q63before.attack - _q63after.attack) < 1e-9 &&
  Math.abs(_q63before.defense - _q63after.defense) < 1e-9 &&
  Math.abs(_q63before.hp - _q63after.hp) < 1e-9);
assert("形象不改变修炼速率",
  Math.abs(avatarTint().cult) < 1e-9 && Math.abs(avatarTint().atk) < 1e-9);

assert("无效形象拒绝", setAvatar("不存在").ok === false);
const _q63m = migrateState({ version: 6, artifacts: [], disciples: [], avatar: "bad_key" });
assert("非法形象值回退默认", _q63m.avatar === "qingshan");
const _q63m2 = migrateState({ version: 6, artifacts: [], disciples: [] });
assert("缺失形象补默认", _q63m2.avatar === "qingshan");

// ===== 阶段 64：灵兽深度养成（v0.24.0）=====
console.log("\n== 64. 灵兽深度养成 ==");
assert("星级上限=5、每星加成=8%、亲密上限=100", CONFIG.PET_STAR_MAX === 5 && CONFIG.PET_STAR_ATK === 0.08 && CONFIG.PET_BOND_MAX === 100);
assert("技能池含 5 技能且定义完整", CONFIG.PET_SKILLS.length === 5 && CONFIG.PET_SKILLS.every(s => s.key && s.name && s.type && s.desc));
// 新灵兽自带 star/bond/skills
const _q64a = capturePet("chiyan");
assert("新灵兽自带星级1/亲密度0/技能数组", _q64a.ok && _q64a.pet.star === 1 && _q64a.pet.bond === 0 && Array.isArray(_q64a.pet.skills));
assert("技能均来自合法池", _q64a.pet.skills.every(k => !!CONFIG.petSkillDef(k)));
// 融合升星
S.stone = 100000;
const _q64b = capturePet("chiyan");   // 同名素材
const _q64beforeAtk = petCombat(_q64a.pet).atk;
const _q64f1 = fuseStar(_q64a.pet.id, _q64b.pet.id);
assert("融合升星成功且素材消失", _q64f1.ok === true && _q64f1.star === 2 && S.pets.length === 1 && !S.pets.some(p => p.id === _q64b.pet.id));
assert("升星消耗灵石", _q64f1.cost === CONFIG.PET_STAR_STONE * 1 && S.stone === 100000 - CONFIG.PET_STAR_STONE);
const _q64afterAtk = petCombat(_q64a.pet).atk;
assert("每星攻击 +8%（乘算）", Math.abs(_q64afterAtk - _q64beforeAtk * (1 + CONFIG.PET_STAR_ATK)) < 1e-6);
// 异常路径
const _q64c = capturePet("qinglin");
assert("不同名拒绝融合", fuseStar(_q64a.pet.id, _q64c.pet.id).ok === false);
assert("不能与自身融合", fuseStar(_q64a.pet.id, _q64a.pet.id).ok === false);
// 亲密度
invSet("herb", 10);   // 喂食前置资源
const _q64d = feedBond(_q64a.pet.id);
assert("喂食消耗 1 灵草 +8 亲密度", _q64d.ok === true && _q64d.pet.bond === CONFIG.PET_BOND_FEED_HERB && S.herbs === 9);
const _q64bondPet = petState().find(p => p.id === _q64a.pet.id);
_q64bondPet.bond = CONFIG.PET_BOND_MAX;
const _q64fullAtk = petCombat(_q64bondPet).atk;
const _q64zeroAtk = petCombat(Object.assign({}, _q64bondPet, { bond: 0 })).atk;
assert("满亲密攻击 +10%", Math.abs(_q64fullAtk - _q64zeroAtk * (1 + CONFIG.PET_BOND_ATK)) < 1e-6);
const _q64g = petBondGain(_q64bondPet, 10, true);
assert("满亲密不再增长", _q64g === 0 && _q64bondPet.bond === CONFIG.PET_BOND_MAX);
_q64bondPet.bond = 50;
const _q64g2 = petBondGain(_q64bondPet, 10, true);
assert("击杀10+BOSS → +9 亲密度", Math.abs(_q64g2 - 9) < 1e-6);
// 技能掷取规则（mockRandom 为固定值会使概率退化，此处临时换用带种子 LCG 验证真实分布）
const _q64prevRand = Math.random;
let _q64seed = 20261116;
Math.random = () => { _q64seed = (_q64seed * 1103515245 + 12345) % 2147483648; return _q64seed / 2147483648; };
let _q64t4 = 0, _q64t1 = 0;
for (let i = 0; i < 400; i++) {
  const s4 = CONFIG.petSkillRoll(4), s1 = CONFIG.petSkillRoll(1);
  if (s4.length === 2) _q64t4++;
  if (s1.length >= 1) _q64t1++;
}
Math.random = _q64prevRand;
assert("t4 必得 2 技能", _q64t4 === 400);
assert("t1 约 30% 得 1 技能（90~140/400）", _q64t1 >= 90 && _q64t1 <= 140);
// 旧档迁移补子字段
const _q64mig = migrateState({ version: 6, artifacts: [], disciples: [], pets: [{ id: 9, key: "jiuwei", lv: 3, exp: 0 }] });
assert("旧档灵兽补 star/bond/skills", _q64mig.pets[0].star === 1 && _q64mig.pets[0].bond === 0 && Array.isArray(_q64mig.pets[0].skills));
const _q64mig2 = migrateState({ version: 6, artifacts: [], disciples: [], pets: [{ id: 10, key: "chiyan", lv: 1, exp: 0, star: 9, bond: 999, skills: ["bad_key", "fang"] }] });
assert("非法 star/bond 钳制、非法技能过滤", _q64mig2.pets[0].star === CONFIG.PET_STAR_MAX && _q64mig2.pets[0].bond === CONFIG.PET_BOND_MAX && _q64mig2.pets[0].skills.length === 1 && _q64mig2.pets[0].skills[0] === "fang");

// ===== 阶段 65：v0.25.0 建角 / 道号分档 / 秘境修炼加成 =====
console.log("\n== 65. v0.25.0 建角与道号分档 ==");
S = defaultState();
assert("空档未建角", S.playerName === null && needsOnboardingPlaceholder());
function needsOnboardingPlaceholder() { return !S.playerName; }
// 道号长度校验
const cShort = createCharacter("一", "qingshan");
assert("道号过短被拒", cShort.ok === false);
const cLong = createCharacter("一二三四五六七八九", "qingshan");
assert("道号过长被拒", cLong.ok === false);
const cOk = createCharacter("沈青霜", "baishang");
assert("建角成功并写入道号", cOk.ok === true && S.playerName === "沈青霜" && S.avatar === "baishang");
assert("当前档已按道号落盘", !!store[CONFIG.SAVE_KEY_PREFIX + encodeURIComponent("沈青霜")]);
assert("旧版单档键已清理", !store["wenchangsheng_save_v1"] && !store["wenchangsheng_save_v2"]);
// 初始化其余模块后再建第二角色（save 需要 gongfa 等）
S.stone = 9999;
S.buildings.farm = 3;
save();
const firstStone = S.stone;
const c2 = createCharacter("李玄机", "hongyi");
assert("第二道号建角成功", c2.ok === true && S.playerName === "李玄机");
assert("新角色为全新档（进度归零）", S.stone === 50 && S.buildings.farm === 0);
const cDup = createCharacter("沈青霜", "qingshan");
assert("重名道号被拒（防覆盖旧档）", cDup.ok === false);
// 切回旧道号 → 进度完整
const sw = switchCharacter("沈青霜");
assert("切换道号成功", sw.ok === true && S.playerName === "沈青霜");
assert("切回后进度一致（灵石/灵田）", S.stone === firstStone && S.buildings.farm === 3);
const swBad = switchCharacter("不存在的道号");
assert("切换不存在道号被拒", swBad.ok === false);
const _names = listProfiles().map(p => p.name);
assert("道号列表含两名新建修士", _names.indexOf("沈青霜") >= 0 && _names.indexOf("李玄机") >= 0);

// 秘境探明 → 修炼加成
S = defaultState();
S.playerName = "测试者";
const _baseRate = cultivationRate();
S.clearedMaps = { 0: true, 1: true, 2: true };
const _b3 = cultivationBreakdown();
assert("探明 3 章 → field 乘区 1.03", Math.abs(_b3.field - 1.03) < 1e-9 && _b3.fieldChapters === 3);
assert("修炼速率按 1.03 生效", Math.abs(cultivationRate() / _baseRate - 1.03) < 1e-9);
S.buildings.practice = 5;
S.pillBuff = 3;
const _bd = cultivationBreakdown();
const _prod = _bd.base * _bd.practice * _bd.gongfa * _bd.pill * _bd.bless * _bd.art * _bd.story * _bd.field * _bd.dao;
assert("明细各乘区之积 === 总速率（唯一来源）", Math.abs(_prod - _bd.total) < 1e-9);
assert("练功房 lv5 明细 = 1.35", Math.abs(_bd.practice - 1.35) < 1e-9);
assert("修炼速率接口与明细一致", Math.abs(cultivationRate() - _bd.total) < 1e-9);
// 未探明不产生加成
S.clearedMaps = {};
assert("无探明时 field 乘区 = 1", Math.abs(cultivationBreakdown().field - 1) < 1e-9);
// 幂等：重复标记同一章不叠加
S.clearedMaps = { 0: true };
S.clearedMaps[0] = true;
assert("同章重复探明不叠加", cultivationBreakdown().fieldChapters === 1);

// ===== 阶段 66：v0.26.0 技能四类与秘境驻守 =====
console.log("\n== 66. v0.26.0 技能四类与秘境驻守 ==");
const _q66locks = CONFIG.SKILL_LOCKS.map(x => x.key);
assert("四类技能标签齐全", _q66locks.length === 4 && ["target", "single", "area", "support"].every(k => _q66locks.indexOf(k) >= 0));
assert("全部神通均有合法类型", CONFIG.FIELD_SKILLS.every(sk => _q66locks.indexOf(sk.lock) >= 0));
assert("存在强锁技能", CONFIG.FIELD_SKILLS.some(sk => sk.lock === "target"));
assert("存在单体技能", CONFIG.FIELD_SKILLS.some(sk => sk.lock === "single"));
assert("存在群体技能", CONFIG.FIELD_SKILLS.some(sk => sk.lock === "area"));
assert("存在辅助技能", CONFIG.FIELD_SKILLS.some(sk => sk.lock === "support"));

// 强锁：无目标拒绝（不扣真元、不进 CD）
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now(); S.realm = 5;
const _q66f1 = fldCreate(0);
_q66f1.monsters = [];
_q66f1.player.mana = 999;
const _q66rNo = fldCast(_q66f1, "yu_jian", 1, 0);
assert("强锁无目标：拒绝释放", _q66rNo.ok === false && /目标/.test(_q66rNo.msg));
assert("强锁无目标：不扣真元/不进冷却", _q66f1.player.mana === 999 && !_q66f1.cds["yu_jian"]);
// 强锁：有目标 → 追踪弹道（方向以目标为准，无视传入方向）
_q66f1.monsters = [{ id: 1, kind: "normal", x: _q66f1.player.x + 200, y: _q66f1.player.y, r: 18, alive: true, hp: 100, hpMax: 100, atk: 10, def: 0 }];
const _q66rYes = fldCast(_q66f1, "yu_jian", -1, 0);
assert("强锁有目标：释放成功", _q66rYes.ok === true);
const _q66pr = _q66f1.projectiles[_q66f1.projectiles.length - 1];
assert("强锁弹道朝目标并带追踪", !!_q66pr && _q66pr.dx > 0.9 && !!_q66pr.homing && _q66pr.homing.id === 1);
// 单体：按传入方向发射
const _q66f2 = fldCreate(0);
_q66f2.player.mana = 999;
fldCast(_q66f2, "jian_qi", 0, 1);
const _q66pr2 = _q66f2.projectiles[_q66f2.projectiles.length - 1];
assert("单体技能按指向发射", !!_q66pr2 && Math.abs(_q66pr2.dy - 1) < 1e-6 && !_q66pr2.homing);

// 秘境驻守 / 灵脉 / 领地
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
S.clearedMaps = { 0: true };
S.stone = 100000; S.folk = 100;   // v0.32.0：灵脉升级需派驻凡人
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
const _q66g0 = dispatchRate(0);
assert("弟子驻守后有资源产出", _q66g0.total > 0 && _q66g0.stone > 0);
assert("驻守 1 处秘境 = 领地 1 块", playerTerritory() === 1);
const _q66vc = fieldVeinCost(0);
const _q66up = upgradeFieldVein(0);
assert("灵脉升级成功并扣灵石与凡人", _q66up.ok === true && fieldVeinLv(0) === 1 && S.stone === 100000 - _q66vc && S.folk === 99);
const _q66g1 = dispatchRate(0);
assert("灵脉 Lv1 驻守产出 ×1.15", Math.abs(_q66g1.stone / _q66g0.stone - 1.15) < 1e-9);
assert("凡人聚落额外产灵草", _q66g1.herb > _q66g0.herb);
S.fieldVein[0] = CONFIG.FIELD_VEIN.MAX;
assert("灵脉满级拒绝继续升级", upgradeFieldVein(0).ok === false);
// 未探明秘境不能建灵脉
const _q66upBad = upgradeFieldVein(6);
assert("未探明秘境不可建灵脉", _q66upBad.ok === false);

// ===== 阶段 67：v0.27.0 练功房弟子 / 背包来源 / 要诀获取 =====
console.log("\n== 67. v0.27.0 练功房弟子与物品获取 ==");
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
S.buildings.practice = 2;
const _q67r0 = cultivationRate();
const _q67b0 = cultivationBreakdown();
assert("无弟子时练功房乘区 = 等级乘区", Math.abs(_q67b0.practice - _q67b0.practiceBase) < 1e-12 && _q67b0.practiceDisc === 1);
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "practice", bond: 0, assignedTo: "practice", cultivation: 0 }];
const _q67r1 = cultivationRate();
const _q67b1 = cultivationBreakdown();
assert("弟子入驻练功房提升修炼速率（缺陷修复）", _q67r1 > _q67r0 * 1.01);
assert("明细暴露弟子乘区 practiceDisc > 1", _q67b1.practiceDisc > 1);
assert("弟子乘区参与总量计算", Math.abs(_q67b1.total - _q67r1) < 1e-9);
S.disciples[0].assignedTo = null;
assert("撤出弟子后速率完全回落", Math.abs(cultivationRate() - _q67r0) < 1e-9);
// 专精匹配（入驻自身专精建筑 +50%）
S.disciples[0].assignedTo = "practice";
const _q67spec = practiceDiscipleMult();
S.disciples[0].specialty = "farm";
S.disciples[0].assignedTo = "practice";
const _q67nospec = practiceDiscipleMult();
assert("练功房专精匹配弟子加成更高", _q67spec > _q67nospec);

// 坊市购买功法残卷
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
S.stone = 1000; invSet("talisman", 0);
const _q67buy = buyTalisman();
assert("坊市可购功法残卷（150 灵石/本）", _q67buy.ok === true && S.talisman === 1 && S.stone === 850);
S.stone = 10;
assert("灵石不足时拒绝购买", buyTalisman().ok === false && S.talisman === 1);

// ===== 阶段 68：v0.28.0 派遣 id 兼容 / 名额随境界 / 凡人招募 =====
console.log("\n== 68. v0.28.0 驻守修复与凡人收徒 ==");
// 漏洞1：UI 传字符串 id（dataset 都是字符串）
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now(); S.realm = 3;
S.clearedMaps = { 2: true };
S.disciples = [{ id: 7, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
const _q68a = assignDispatch(2, "7");     // 字符串 id（模拟按钮 dataset）
assert("字符串 id 可驻守（修复弟子不存在）", _q68a.ok === true && dispatchTeam(2).map(String).indexOf("7") >= 0);
const _q68b = removeDispatch(2, "7");
assert("字符串 id 可撤回", _q68b.ok === true && dispatchTeam(2).length === 0);

// 漏洞2：名额随境界
S = defaultState(); S.playerName = "测试者";
S.buildings.recruit = 0;
const _q68s0 = discipleSlots();
S.realm = 5;
const _q68s5 = discipleSlots();
assert("弟子名额随境界提升", _q68s5 === _q68s0 + 5 * CONFIG.DISCIPLE_SLOT_PER_REALM);
S.buildings.recruit = 2; S.realm = 2;
const _q68slots = discipleSlots();
assert("名额按经营公式计算（≥ 基础+招募堂+境界）", _q68slots >= CONFIG.SLOTS.BASE + 2 + 2 * CONFIG.DISCIPLE_SLOT_PER_REALM);

// 漏洞2：收徒消耗凡人
S = defaultState(); S.playerName = "测试者"; S.stone = 10000; S.folk = 0;
const _q68no = recruitDisciple();
assert("无凡人时拒绝收徒", _q68no.ok === false && /凡人/.test(_q68no.msg));
S.folk = 3;
const _q68yes = recruitDisciple();
assert("有凡人时可收徒并扣 1 名", _q68yes.ok === true && S.folk === 2 && S.disciples.length === 1);

// 驻守繁衍凡人
S = defaultState(); S.playerName = "测试者"; S.realm = 2;
S.clearedMaps = { 0: true };
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
S.folk = 0;
dispatchTick(60);   // 60 秒
const _q68f1 = S.folk;
assert("驻守秘境繁衍凡人", _q68f1 > 0);
S.fieldVein = { 0: 5 };
S.folk = 0;
dispatchTick(60);
assert("灵脉越高凡人繁衍越快", S.folk > _q68f1);
// 无驻守则不繁衍
S.mapTeam = {};
S.folk = 0;
dispatchTick(60);
assert("无驻守弟子时不繁衍凡人", S.folk === 0);
// 离线结算含凡人
S.mapTeam = { 0: [1] };
S.folk = 0;
const _q68off = dispatchOffline(3600);
assert("离线结算补发凡人", _q68off.folk > 0 && S.folk > 0);

// 驻守资源点刷新（v0.28.0）
S = defaultState(); S.playerName = "测试者"; S.realm = 2;
S.clearedMaps = { 0: true };
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
S.mapNodeT = {}; invSet("material", 0); invSet("herb", 0);
dispatchNodeTick(CONFIG.DISPATCH.NODE_INTERVAL);
assert("驻守资源点刷新产出灵材/灵草", S.materials >= 1 && S.herbs >= 3);
assert("刷新后计时回绕", (S.mapNodeT[0] || 0) < CONFIG.DISPATCH.NODE_INTERVAL);
assert("资源点剩余秒数可计算", dispatchNodeLeft(0) > 0 && dispatchNodeLeft(0) <= CONFIG.DISPATCH.NODE_INTERVAL);
invSet("material", 0); invSet("herb", 0);
const _q68off2 = dispatchOffline(3600);
assert("离线补算资源点刷新（封顶生效）", _q68off2.material >= 1 && _q68off2.material <= CONFIG.DISPATCH.NODE_OFFLINE_CAP * 2);

// ===== 阶段 69：v0.29.0 道途 / 吐纳 / 元神受损 / 日常 / 特产 =====
console.log("\n== 69. v0.29.0 道途与日常闭环 ==");
// 道途
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
const _q69rateFa = cultivationRate();
S.dao = "ti";
const _q69rateTi = cultivationRate();
assert("体修修炼慢于法修", _q69rateTi < _q69rateFa);
S.dao = "dual";
assert("双修修炼速率 ×0.75", Math.abs(cultivationRate() - _q69rateFa * (0.75 / 1.08)) < 1e-6);
S.dao = "jian";
const _q69p = playerCombat();
assert("剑修攻击高于法修", _q69p.attack > (function () { S.dao = "fa"; const a = playerCombat(); S.dao = "jian"; return a.attack; })());
const _q69set = setDao("ti");
assert("改修道途成功", _q69set.ok === true && S.dao === "ti");
assert("非法道途被拒", setDao("bogus").ok === false);
// 吐纳
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
S.gameTime = { year: 1, month: 1, day: 1, dayTick: 0 };
S.tunaDate = ""; S.tunaLeft = CONFIG.TUNA.DAILY; S.tunaCount = 0;
const _q69t1 = tunaPerform(1.0);
assert("吐纳成功并消耗次数", _q69t1.ok === true && S.tunaLeft === CONFIG.TUNA.DAILY - 1 && _q69t1.gain > 0);
assert("前 5 次吐纳给功法残卷", _q69t1.talisman >= 1 && (S.talisman || 0) >= 1);
S.tunaLeft = 0;
assert("次数用尽拒绝吐纳", tunaPerform(0.5).ok === false);
S.gameTime.day = 2;
assert("跨日重置吐纳次数", tunaLeftToday() === CONFIG.TUNA.DAILY);
// 暴击：松手在满格且随机数极低时必暴击
mockRandom = 0;
S.tunaLeft = 10;
const _q69crit = tunaPerform(1.0);
mockRandom = 0.99;
assert("满格松手可暴击（≥2 倍）", _q69crit.ok === true && _q69crit.crit >= CONFIG.TUNA.CRIT_MIN);
// 元神受损
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
S.realm = 1; S.layer = 8; S.qi = 1e9; S.tribFails = 0;
mockRandom = 0.99;
const _q69fail = doBreak();
assert("渡劫失败写入元神受损", _q69fail.ok && _q69fail.trib && !_q69fail.success && S.soulHurtUntil > Date.now());
assert("受损期间拒绝渡劫", doBreak().ok === false);
S.soulHurtUntil = Date.now() - 1;
assert("受损结束后可再渡劫", doBreak().ok !== false || /灵气/.test(doBreak().msg || ""));
// 日常任务
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
S.gameTime = { year: 1, month: 2, day: 3, dayTick: 0 };
S.daily = {}; S.fate = 0;
dailyProgress("break1", 1);
const _q69dl = dailyState().find(t => t.key === "break1");
assert("日常进度记录", _q69dl.cur === 1 && _q69dl.done === true);
const _q69claim = claimTask("daily", "break1");
assert("领取日常得机缘", _q69claim.ok === true && S.fate === _q69claim.fate);
assert("重复领取被拒", claimTask("daily", "break1").ok === false);
S.gameTime.day = 4;
assert("跨日日常进度重置", dailyState().find(t => t.key === "break1").cur === 0);
// 周常
S.weekly = {}; S.gameTime = { year: 1, month: 1, day: 1, dayTick: 0 };
weeklyProgress("clear3", 2);
assert("周常进度累计", weeklyState().find(t => t.key === "clear3").cur === 2);
S.gameTime.day = 10;
assert("跨周周常重置", weeklyState().find(t => t.key === "clear3").cur === 0);
// 天机阁
S = defaultState(); S.playerName = "测试者"; S.fate = 10;
const _q69fu = fateFuQi();
assert("修为福袋扣机缘并给灵气", _q69fu.ok === true && S.fate === 10 - CONFIG.FATE.FU_QI_COST && _q69fu.gain > 0);
const _q69tal = fateTalisman();
assert("机缘可换功法残卷", _q69tal.ok === true && S.talisman >= 1);
S.fate = 0;
assert("机缘不足时拒绝兑换", fateFuQi().ok === false && fateTalisman().ok === false);
// 章节特产
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
S.clearedMaps = { 1: true };
invSet("sp:1", 0); invSet("sp:2", 0);
const _q69drop = specialtyDrop(1, "boss");
assert("秘境 BOSS 掉落特产", _q69drop === 3 && specialtyCount(1) === 3);
const _q69need = practiceSpecialtyNeed(6);
assert("练功房 6 级需下一章特产", _q69need && _q69need.ch === 1 && _q69need.n === 3);
S.buildings.practice = 5; S.stone = 1e9;
invSet("sp:1", 0); invSet("sp:2", 0);   // 清空特产，验证门槛
const _q69up1 = upgradeBuilding("practice");
assert("特产不足时拒绝升级练功房", _q69up1.ok === false && /不足/.test(_q69up1.msg));
invSet("sp:1", 5);
const _q69up2 = upgradeBuilding("practice");
assert("有特产时可升级并扣除", _q69up2.ok === true && S.buildings.practice === 6 && S.specialty[1] === 2);
// 坊市特产与刷新
S = defaultState(); S.playerName = "测试者"; S.stone = 10000; S.clearedMaps = { 0: true };
const _q69buy = buySpecialty(0, 1);
assert("坊市可买入特产", _q69buy.ok === true && specialtyCount(0) === 1 && S.stone === 10000 - specialtyPrice(0));
const _q69sell = sellSpecialty(0, 1);
assert("坊市可卖出特产", _q69sell.ok === true && specialtyCount(0) === 0 && _q69sell.gain > 0);
S.stone = 10000; S.marketRefresh = {};
const _q69rf = refreshMarket();
assert("行情刷新消耗灵石并减次数", _q69rf.ok && S.stone === 10000 - CONFIG.MARKET_REFRESH.COST && ensureMarketRefresh().left === CONFIG.MARKET_REFRESH.DAILY - 1);

// ===== 阶段 70：v0.30.0 古宝体系 / 坊市特价 =====
console.log("\n== 70. v0.30.0 古宝与坊市特价 ==");
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now(); S.ancient = {}; invSet("frag:qingyun", 0);
const _q70g1 = grantAncient("qf_sword");
assert("首次获得古宝", _q70g1.ok === true && !_q70g1.dup && ancientOwned("qf_sword") && ancientStar("qf_sword") === 1);
const _q70g2 = grantAncient("qf_sword");
assert("重复获得转碎片", _q70g2.ok === true && _q70g2.dup === true && ancientFragCount("qingyun") === 3);
// 章节映射
assert("第 0 章古宝属青云套", ancientByChapter(0).set === "qingyun");
assert("第 4 章古宝属魔渊套", ancientByChapter(4).set === "moyuan");
assert("第 6 章古宝属混元套", ancientByChapter(6).set === "hunyuan");
// 升星
invSet("frag:qingyun", 0);
const _q70starNo = starUpAncient("qf_sword");
assert("碎片不足拒绝升星", _q70starNo.ok === false);
invSet("frag:qingyun", 5);
const _q70star1 = starUpAncient("qf_sword");
assert("升星消耗 5 碎片到 2 星", _q70star1.ok === true && ancientStar("qf_sword") === 2 && ancientFragCount("qingyun") === 0);
S.ancient.qf_sword.star = CONFIG.ANCIENT.MAX_STAR;
assert("满星拒绝升星", starUpAncient("qf_sword").ok === false);
// 星级加成：2 星 = 1.2 倍
S.ancient.qf_sword.star = 2;
const _q70b2 = ancientItemBonus("qf_sword");
assert("2 星古宝属性 ×1.2", Math.abs(_q70b2.atk - ancientDef("qf_sword").atk * 1.2) < 1e-9);
// 注灵
S = defaultState(); S.playerName = "测试者"; S.ancient = { qf_sword: { star: 1, infuse: 0 } };
invSet("material", 0); S.stone = 10000;
assert("灵材不足拒绝注灵", infuseAncient("qf_sword").ok === false);
invSet("material", 100);
const _q70inf = infuseAncient("qf_sword");
assert("注灵消耗灵材与灵石", _q70inf.ok === true && S.materials === 100 - CONFIG.ANCIENT.INFUSE_MAT && ancientInfuse("qf_sword") === 1);
S.ancient.qf_sword.infuse = CONFIG.ANCIENT.INFUSE_MAX;
assert("注灵满级拒绝", infuseAncient("qf_sword").ok === false);
// 套装
S = defaultState(); S.playerName = "测试者"; S.ancient = {}; invSet("frag:qingyun", 0);
["qf_sword", "qf_jade", "qf_mirror"].forEach(k => { S.ancient[k] = { star: 1, infuse: 0 }; });
const _q70set3 = ancientBonus();
const _q70itemSum = ["qf_sword", "qf_jade", "qf_mirror"].reduce((acc, k) => {
  const b = ancientItemBonus(k); acc.atk += b.atk; acc.def += b.def; acc.hp += b.hp; acc.cult += b.cult; return acc;
}, { atk: 0, def: 0, hp: 0, cult: 0 });
assert("3 件套额外 +5% 修炼", Math.abs(_q70set3.cult - (_q70itemSum.cult + 0.05)) < 1e-9);
["qf_seal", "qf_bell"].forEach(k => { S.ancient[k] = { star: 1, infuse: 0 }; });
const _q70set5 = ancientBonus();
const _q70all5 = ["qf_sword", "qf_jade", "qf_mirror", "qf_seal", "qf_bell"].reduce((acc, k) => {
  const b = ancientItemBonus(k); acc.atk += b.atk; return acc;
}, { atk: 0 }).atk;
assert("5 件套额外 +5% 攻防", Math.abs(_q70set5.atk - (_q70all5 + 0.05)) < 1e-9);
// 汇总进入战斗与修炼唯一来源
S = defaultState(); S.playerName = "测试者";
const _q70atk0 = playerCombat().attack;
const _q70rate0 = cultivationRate();
S.ancient = { qf_mirror: { star: 1, infuse: 0 }, qf_sword: { star: 1, infuse: 0 } };
assert("古宝提升修炼速率（唯一来源）", cultivationRate() > _q70rate0);
assert("古宝提升攻击", playerCombat().attack > _q70atk0);
// 碎片合成
S = defaultState(); S.playerName = "测试者"; S.ancient = { qf_sword: { star: 1, infuse: 0 } }; invSet("frag:qingyun", 10);
const _q70forge = forgeAncient("qingyun");
assert("碎片合成下一件古宝", _q70forge.ok === true && Object.keys(S.ancient).length === 2 && ancientFragCount("qingyun") === 0);
// 坊市特价
S = defaultState(); S.playerName = "测试者"; S.stone = 100000; S.marketDeals = {};
const _q70d = ensureDeals();
assert("每日生成 3 件特价", _q70d.items.length === CONFIG.MARKET_DEALS.COUNT);
assert("特价折扣在 7~9 折区间", _q70d.items.every(it => it.mult >= CONFIG.MARKET_DEALS.MIN - 1e-9 && it.mult <= CONFIG.MARKET_DEALS.MAX + 1e-9));
const _q70before = S.stone;
const _q70buy = buyDeal(0);
assert("购买特价扣灵石并发货", _q70buy.ok === true && S.stone < _q70before && _q70buy.item.bought === true);
assert("特价售罄后不可重复购买", buyDeal(0).ok === false);

// ===== 阶段 71：v0.31.0 秘境建设 / 养成 / 立宗 =====
console.log("\n== 71. v0.31.0 秘境建设与立宗 ==");
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
S.clearedMaps = { 0: true };
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
const _q71base = dispatchRate(0);
S.stone = 1e9; S.folk = 100;   // v0.32.0：矿场/药圃升级需凡人
const _q71mine = upgradeFieldMine(0);
assert("矿场升级成功", _q71mine.ok === true && fieldMineLv(0) === 1);
const _q71garden = upgradeFieldGarden(0);
assert("药圃升级成功", _q71garden.ok === true && fieldGardenLv(0) === 1);
const _q71after = dispatchRate(0);
assert("矿场/药圃提升驻守产出", _q71after.stone > _q71base.stone && _q71after.herb > _q71base.herb);
S.fieldMine[0] = CONFIG.FIELD_VEIN.MAX;
assert("矿场满级拒绝升级", upgradeFieldMine(0).ok === false);

// 法宝温养
S = defaultState(); S.playerName = "测试者"; S.artifacts = [makeArtifact(3, "attack")]; invSet("material", 100); S.stone = 10000;
const _q71artId = S.artifacts[0].id;
const _q71score0 = artifactScore(S.artifacts[0]);
const _q71warm = warmArtifact(_q71artId);
assert("温养扣料并升级", _q71warm.ok === true && artWarmLv(_q71artId) === 1 && S.materials === 100 - CONFIG.WARM.MAT);
assert("温养提升法宝评分", artifactScore(S.artifacts[0]) > _q71score0);
S.artWarm[_q71artId] = CONFIG.WARM.MAX;
assert("温养满级拒绝", warmArtifact(_q71artId).ok === false);

// 神通参悟
S = defaultState(); S.playerName = "测试者"; invSet("talisman", 3); S.stone = 10000;
const _q71ins = insightSkill("jian_qi");
assert("参悟扣要诀并升级", _q71ins.ok === true && skillInsightLv("jian_qi") === 1 && S.talisman === 2);
assert("参悟倍率 +3%", Math.abs(skillInsightMult("jian_qi") - 1.03) < 1e-9);
// 战场应用
const _q71f = fldCreate(0);
_q71f.player.mana = 9999;
fldCast(_q71f, "jian_qi", 1, 0);
const _q71pr = _q71f.projectiles[_q71f.projectiles.length - 1];
const _q71sk = CONFIG.FIELD_SKILLS.find(x => x.key === "jian_qi");
assert("参悟提升实际技能倍率", _q71pr && Math.abs(_q71pr.dmgMult - _q71sk.mult * 1.03) < 1e-9);
S.skillInsight.jian_qi = CONFIG.INSIGHT.MAX;
assert("参悟满级拒绝", insightSkill("jian_qi").ok === false);

// 立宗
S = defaultState(); S.playerName = "测试者"; S.realm = 3;
S.clearedMaps = { 0: true, 1: true, 2: true };
S.mapTeam = { 0: [1], 1: [2], 2: [3] };
S.disciples = [1, 2, 3].map(i => ({ id: i, name: "丁" + i, realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }));
S.stone = 10000; invSet("sp:2", 10);
assert("三处驻守满足立宗条件", sectReady() === true && playerTerritory() === 3);
const _q71sect = foundSect("长生宗");
assert("立宗成功并扣灵石与特产", _q71sect.ok === true && S.sect.lv === 1 && S.specialty[2] === 5);
const _q71atkBefore = playerCombat().attack;
const _q71rateBefore = cultivationRate();
S.sect.lv = 3;
assert("宗门等级提升修炼", cultivationRate() > _q71rateBefore);
assert("宗门等级提升攻击", playerCombat().attack > _q71atkBefore);
S.sect.lv = 1; S.stone = 100000;
const _q71cost = sectUpgradeCost();
const _q71up = upgradeSect();
assert("升宗消耗灵石与特产", _q71up.ok === true && S.sect.lv === 2 && S.specialty[2] === 5 - _q71cost.spc);
assert("已立宗不可重复立宗", foundSect("再立").ok === false);
// 不足条件
S = defaultState(); S.playerName = "测试者"; S.clearedMaps = { 0: true }; S.mapTeam = { 0: [1] };
assert("驻守不足拒绝立宗", foundSect("小宗").ok === false && /根基|秘境/.test(foundSect("小宗").msg));

// ===== 阶段 72：v0.32.0 弟子与凡人体系 v2 =====
console.log("\n== 72. v0.32.0 弟子凡人体系 ==");
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
// 凡人容量
S.clearedMaps = { 0: true, 1: true };
S.mapTeam = { 0: [1], 1: [2] };
assert("凡人容量随驻守秘境增加", folkCap() >= CONFIG.LABOR.FOLK_CAP_BASE * 2);
S.sect = { name: "长生宗", lv: 2 };
const _q72capSect = folkCap();
assert("宗门提升凡人容量", _q72capSect >= CONFIG.LABOR.FOLK_CAP_BASE * 2 + CONFIG.LABOR.FOLK_CAP_SECT * 2);
S.dynasty = { name: "大衍王朝" };
assert("立朝大幅提升凡人容量", folkCap() >= _q72capSect + CONFIG.LABOR.FOLK_CAP_DYNASTY);

// 建筑派驻凡人（工种）
S = defaultState(); S.playerName = "测试者"; S.clearedMaps = { 0: true }; S.stone = 1e6; S.folk = 0;
assert("凡人不足拒绝升级灵脉", upgradeFieldVein(0).ok === false && /灵脉师/.test(upgradeFieldVein(0).msg));
S.folk = 1;
const _q72v = upgradeFieldVein(0);
assert("灵脉升级消耗灵脉师", _q72v.ok === true && S.folk === 0 && fieldLaborOf(0, "vein") === 1);
assert("矿工不足拒绝升级矿场", upgradeFieldMine(0).ok === false && /矿工/.test(upgradeFieldMine(0).msg));
S.folk = 1;
const _q72m = upgradeFieldMine(0);
assert("矿场升级消耗矿工", _q72m.ok === true && fieldLaborOf(0, "mine") === 1);
S.folk = 1;
const _q72g = upgradeFieldGarden(0);
assert("药圃升级消耗药农", _q72g.ok === true && fieldLaborOf(0, "garden") === 1);

// 招徒选拔
S = defaultState(); S.playerName = "测试者"; S.clearedMaps = { 0: true };
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
S.folk = 10; S.stone = 1e6;
assert("未驻守秘境不可选拔", recruitCandidates(0).ok === false);
assignDispatch(0, 1);
const _q72c = recruitCandidates(0);
assert("驻守后可开山收徒（3 名候选）", _q72c.ok === true && S.recruitPool.list.length === CONFIG.RECRUIT.CANDIDATES);
assert("候选含灵根与成本", S.recruitPool.list.every(c => c.root && c.cost > 0 && c.aptitude >= 1));
const _q72folkBefore = S.folk, _q72stoneBefore = S.stone;
const _q72hire = hireCandidate(0);
assert("录用扣灵石与凡人", _q72hire.ok === true && S.folk === _q72folkBefore - 1 && S.stone < _q72stoneBefore);
assert("录用弟子资质取自灵根", S.disciples.length === 2 && S.disciples[1].aptitude >= 1 && !!S.disciples[1].root);
const _q72refresh = refreshCandidates();
assert("刷新候选消耗 50 灵石", _q72refresh.ok === true);
const _q72PoolKeep = S.recruitPool;
const _q72StoneBeforeNoGuard = S.stone;
S.mapTeam[0] = [];
const _q72NoGuardHire = hireCandidate(0);
assert("候选生成后撤走驻守弟子则禁止录用", !_q72NoGuardHire.ok && /驻守/.test(_q72NoGuardHire.msg));
const _q72NoGuardRefresh = refreshCandidates();
assert("无弟子驻守时刷新失败且不扣灵石", !_q72NoGuardRefresh.ok && S.stone === _q72StoneBeforeNoGuard && S.recruitPool === _q72PoolKeep);

// 安定度
S = defaultState(); S.playerName = "测试者"; S.clearedMaps = { 0: true };
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
assert("先天安定度为 60", fieldStableOf(0) === CONFIG.STABLE.INIT && stableMult(0) === 1);
S.fieldStable[0] = 20;
const _q72low = dispatchRate(0);
S.fieldStable[0] = 80;
const _q72high = dispatchRate(0);
assert("安定度低于 30 产出减半", _q72low.stone < _q72high.stone);
S.stone = 1e6;
const _q72soothe = sootheField(0);
assert("安抚提升安定度", _q72soothe.ok === true && fieldStableOf(0) === 100);
S.folk = 10; S.stone = 1e6;
const _q72temple = upgradeTemple(0);
assert("建庙消耗灵石与凡人并提升安定", _q72temple.ok === true && fieldTempleLv(0) === 1);
// 每日衰减
S.fieldStable[0] = 50;
stableDailyTick();
assert("每日安定度衰减", fieldStableOf(0) === 50 - CONFIG.STABLE.DAILY_DECAY);

// 立朝
S = defaultState(); S.playerName = "测试者"; S.sect = { name: "长生宗", lv: 3 }; S.folk = 100; S.stone = 1e6;
assert("立朝条件满足", dynastyReady() === true);
const _q72dyn = foundDynasty("大衍王朝");
assert("立朝成功并扣灵石", _q72dyn.ok === true && S.dynasty.name === "大衍王朝" && S.stone === 1e6 - CONFIG.DYNASTY.STONE);
assert("立朝提升弟子名额", discipleSlots() >= CONFIG.SLOTS.BASE + 3 * CONFIG.SLOTS.PER_SECT + CONFIG.SLOTS.DYNASTY);
const _q72atk = playerCombat().attack;
const _q72rate = cultivationRate();
S = defaultState(); S.playerName = "测试者";
assert("立朝提供属性加成", _q72atk > playerCombat().attack);
assert("立朝提供修炼加成", _q72rate > cultivationRate());
assert("已立朝不可重复立朝", foundDynasty("再立").ok === false);

// ===== 阶段 73：v0.33.0 弟子职务 / 任务 / 争夺 / 王朝官职 =====
console.log("\n== 73. v0.33.0 弟子经营完整版 ==");
function _mkFieldState() {
  S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
  S.clearedMaps = { 0: true }; S.stone = 1e6; S.folk = 50;
  S.disciples = [
    { id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 5, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 },
    { id: 2, name: "乙", realm: 0, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 },
  ];
  assignDispatch(0, 1);
  assignDispatch(0, 2);
}
// 职务
_mkFieldState();
assert("未驻守弟子不可任命", appointStaff(0, "kuang", 99).ok === false);
const _q73app = appointStaff(0, "kuang", 1);
assert("任命矿正成功", _q73app.ok === true && S.staff[0].office === "kuang");
const _q73baseRate = dispatchRate(0);
appointStaff(0, "miao", 1);
assert("一人只能任一处职务（覆盖旧职）", S.staff[0].office === "miao");
assert("庙祝提升凡人繁衍", dispatchRate(0).folk > dispatchRate(0).folk * 0.99 && dispatchRate(0).folk > 0);
// 矿正加灵石
appointStaff(0, "kuang", 1);
const _q73stone = dispatchRate(0).stone;
S.staff = {};
const _q73stone0 = dispatchRate(0).stone;
assert("矿正提升灵石产出", _q73stone > _q73stone0);
// 城主容量
S.staff = {};
const _q73cap0 = folkCap();
appointStaff(0, "cheng", 1);
assert("城主提升凡人容量", folkCap() === _q73cap0 + 20);
// 护法
appointStaff(0, "hu", 1);
assert("护法状态可判定", hasGuard(0) === true);

// 任务：成功
_mkFieldState();
S.stamina = 30;
const _q73m = missionStart("clear", 0, 1);
assert("派出任务成功并扣体力", _q73m.ok === true && S.stamina === 29 && S.missions.length === 1);
assert("任务进行中弟子忙碌", discipleBusy(1) === true && missionStart("clear", 0, 1).ok === false);
S.missions[0].endAt = Date.now() - 1;
S.fieldStable[0] = 60;
const _q73rep0 = S.reputation;
mockRandom = 0;   // 必成功
missionsTick();
assert("任务完成发放奖励（安定/声望）", S.missions[0].success === true && S.reputation > _q73rep0);
mockRandom = 0.99;
// 任务：失败惩罚
_mkFieldState();
S.stamina = 30;
missionStart("escort", null, 2);
S.missions[0].endAt = Date.now() - 1;
const _q73loy = S.disciples[1].loyalty;
Math.random = () => 0.999;   // 必失败
missionsTick();
Math.random = () => mockRandom;
assert("任务失败扣忠诚", S.missions[0] && S.missions[0].success === false && S.disciples[1].loyalty === _q73loy - CONFIG.MISSION.FAIL_LOYALTY);

// 争夺：护法抵御
_mkFieldState();
S.factions.moyuan.relation = -10;
appointStaff(0, "hu", 1);
S.fieldStable[0] = 60;
Math.random = () => 0;   // 必触发
const _q73guardHits = conflictDaily();
Math.random = () => mockRandom;
assert("护法抵御魔道窥伺", _q73guardHits.length === 1 && _q73guardHits[0].guarded === true && !(S.lostFields[0]));
// 争夺：新规则只缓慢侵蚀教化，不再整块夺取秘境
_mkFieldState();
S.factions.moyuan.relation = -10;
S.fieldEducation[0] = { progress: 0.4, private: false, totalGuardSec: 0 };
Math.random = () => 0;
const _q73lose = conflictDaily();
Math.random = () => mockRandom;
assert("无护法时势力窥伺只侵蚀教化", _q73lose.length === 1 && _q73lose[0].guarded === false && !S.lostFields[0] && S.fieldEducation[0].progress < 0.4);
assert("遭窥伺后秘境驻守产出仍持续", dispatchRate(0).stone > 0 && dispatchRate(0).total > 0);
assert("遭窥伺后弟子队伍不被强制撤回", dispatchTeam(0).length === 2);
assert("新机制不需要支付赎回费用", ransomField(0).ok === false && S.stone === 1e6);
// 旧存档 lostFields 仍可通过旧赎回入口恢复。
S.lostFields = { 0: true };
const _q73ransom = ransomField(0);
assert("旧存档失守记录仍兼容赎回", _q73ransom.ok === true && !S.lostFields[0] && S.stone < 1e6);

// 争夺：高关系不触发
_mkFieldState();
S.factions.moyuan.relation = 50;
Math.random = () => 0;
const _q73none = conflictDaily();
Math.random = () => mockRandom;
assert("关系达标不被窥伺", _q73none.length === 0);

// 王朝官职
_mkFieldState();
S.dynasty = { name: "大衍王朝" }; S.sect = { name: "长生宗", lv: 3 };
const _q73rate0 = cultivationRate();
const _q73off = dynastyAppoint("guoshi", 1);
assert("任命国师成功", _q73off.ok === true && S.dynastyOffice.guoshi == 1);
assert("国师提升修炼", cultivationRate() > _q73rate0);
S.buildings.farm = 5;   // 需有灵田才有灵草产出
const _q73herb0 = (function () { invSet("herb", 0); buildTick(10); return S.herbs; })();
dynastyAppoint("sinong", 2);
invSet("herb", 0); buildTick(10);
assert("司农提升灵草产出", S.herbs > _q73herb0);
dynastyAppoint("zhoumu", 1);
assert("州牧提升凡人繁衍", dispatchRate(0).folk > 0);
// 赋税
S.folk = 200; S.stone = 0;
const _q73tax = taxDaily();
assert("王朝收取赋税", _q73tax > 0 && S.stone === _q73tax);

// ===== 阶段 74：v0.34.0 宗门完整版 =====
console.log("\n== 74. v0.34.0 宗门任务与试炼 ==");
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
S.sect = { name: "长生宗", lv: 2 }; S.contribution = 0; S.sectDaily = {}; S.stone = 10000;
S.gameTime = { year: 1, month: 1, day: 1, dayTick: 0 };
// 供奉
const _q74d = sectDonate();
assert("供奉扣灵石得贡献", _q74d.ok === true && S.stone === 9500 && S.contribution === 15);
assert("供奉不可重复", sectDonate().ok === false);
// 行为任务
assert("未完成不可领任务", claimSectTask("mission").ok === false);
sectTaskProgress("mission", 1);
const _q74m = claimSectTask("mission");
assert("完成弟子任务后领贡献", _q74m.ok === true && S.contribution === 25);
assert("任务不可重复领取", claimSectTask("mission").ok === false);
sectTaskProgress("enter", 1);
assert("入秘境任务可领取", claimSectTask("enter").ok === true && S.contribution === 35);
// 跨日重置
S.gameTime.day = 2;
assert("跨日宗门任务重置", sectTaskState().every(t => !t.claimed));
// 藏经阁
S.contribution = 10;
assert("贡献不足拒绝兑换", buySectItem("talisman").ok === false);
S.contribution = 200; invSet("talisman", 0);
const _q74buy = buySectItem("talisman");
assert("兑换功法残卷扣贡献", _q74buy.ok === true && S.talisman === 1 && S.contribution === 170);
invSet("material", 0);
buySectItem("material");
assert("兑换灵材", S.materials === 10);
S.specialty = {};
invSet("frag:qingyun", 0);
S.clearedMaps = { 4: true };
buySectItem("frag");
assert("兑换古宝碎片按最高章套系发放", ancientFragCount("moyuan") === 5);
// 护法试炼
S = defaultState(); S.playerName = "测试者";
assert("未立宗不可试炼", sectTrialRun().ok === false);
S.sect = { name: "长生宗", lv: 2 }; S.stamina = 10; S.contribution = 0; S.stone = 0;
S.disciples = [{ id: 1, name: "甲", realm: 3, layer: 0, loyalty: 90, mood: 80, aptitude: 5, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
S.clearedMaps = { 0: true }; assignDispatch(0, 1); appointStaff(0, "hu", 1);
mockRandom = 1;
const _q74t = sectTrialRun();
assert("试炼消耗体力并至少过一波", _q74t.ok === true && S.stamina === 9 && _q74t.wave >= 1);
assert("试炼发放贡献与灵石", _q74t.contrib > 0 && _q74t.stone > 0 && S.contribution > 0);
assert("试炼记录最佳波次", S.sectTrial.best >= 1);
mockRandom = 0.99;
// 外交
S.contribution = 50; S.factions.moyuan.relation = -20;
const _q74p = sectDiplomacy("moyuan");
assert("贡献换关系", _q74p.ok === true && S.factions.moyuan.relation === -15 && S.contribution === 30);
S.contribution = 0;
assert("贡献不足拒绝外交", sectDiplomacy("qingyun").ok === false);

// ===== 阶段 75：v0.35.0 古宝特效 / 灵兽内丹合击 / 据点 =====
console.log("\n== 75. v0.35.0 古宝特效与灵兽内丹 ==");
// 古宝特效汇总
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
S.ancient = { qf_sword: { star: 1, infuse: 0 } };
assert("古宝特效：伤害 +5%", Math.abs(ancientEffectSum("atk") - 0.05) < 1e-9);
S.ancient.qf_sword.star = 2;
assert("古宝特效随星级放大", Math.abs(ancientEffectSum("atk") - 0.06) < 1e-9);
S.ancient = { hy_umbrella: { star: 1, infuse: 0 }, my_seal: { star: 1, infuse: 0 }, hy_tower: { star: 1, infuse: 0 } };
assert("渡劫/反伤/技能倍率特效存在", ancientEffectSum("trib") > 0 && ancientEffectSum("thorns") > 0 && ancientEffectSum("skill") > 0);
assert("特效摘要可读", /渡劫/.test(ancientEffectSummary()));
// 战斗接入：伤害
S = defaultState(); S.playerName = "测试者";
let _f = fldCreate(0);
_f.player.mana = 9999;
_f.player.atk = 1000;   // 放大伤害，避免取整掩盖差异
let _mon = { id: 1, kind: "normal", x: _f.player.x + 100, y: _f.player.y, r: 18, alive: true, hp: 1e9, hpMax: 1e9, atk: 10, def: 0 };
_f.monsters = [_mon];
mockRandom = 0.99;
fldHit(_f, { atk: _f.player.atk }, _mon, 1, "#000", true);
const _dmgNoAnc = 1e9 - _mon.hp;
S.ancient = { qf_sword: { star: 1, infuse: 0 } };
_mon.hp = 1e9;
fldHit(_f, { atk: _f.player.atk }, _mon, 1, "#000", true);
const _dmgAnc = 1e9 - _mon.hp;
assert("古宝提升实际伤害", _dmgAnc > _dmgNoAnc);
// CD 缩减
S.ancient = { qf_bell: { star: 1, infuse: 0 } };
_f.player.mana = 9999;
fldCast(_f, "jian_qi", 1, 0);
const _skCd = CONFIG.FIELD_SKILLS.find(x => x.key === "jian_qi").cd;
assert("古宝缩短技能冷却", _f.cds["jian_qi"] < _skCd);
// 减伤
S.ancient = { qf_jade: { star: 1, infuse: 0 } };
const _p2 = fldCreate(0);
_p2.player.shield = 0;
const _hp0 = _p2.player.hp;
fldHit(_p2, { atk: 1000 }, _p2.player, 1, "#000", false);
const _takeWith = _hp0 - _p2.player.hp;
S.ancient = {};
const _p3 = fldCreate(0);
_p3.player.shield = 0;
const _hp1 = _p3.player.hp;
fldHit(_p3, { atk: 1000 }, _p3.player, 1, "#000", false);
const _takeWithout = _hp1 - _p3.player.hp;
assert("古宝降低受伤", _takeWith < _takeWithout);
// 渡劫率
S = defaultState(); S.playerName = "测试者"; S.realm = 2; S.layer = 8;
const _tr0 = tribulationRate();
S.ancient = { hy_umbrella: { star: 1, infuse: 0 } };
assert("古宝提升渡劫成功率", tribulationRate() > _tr0);

// 灵兽内丹
S = defaultState(); S.playerName = "测试者";
S.pets = [{ id: 1, key: "chiyan", lv: 5, exp: 0, star: 1, bond: 10, skills: [] }];
S.petActive = 1;
assert("初始内丹为空", petInnerBonus("atk") === 0);
setPetInner(1, "atk");
assert("锐金丹提升主人攻击", Math.abs(petInnerBonus("atk") - 0.08) < 1e-9);
const _atkNoInner = (function () { S.petInner = {}; const v = playerCombat().attack; S.petInner = { 1: "atk" }; return v; })();
assert("内丹攻击加成进入战斗属性", playerCombat().attack > _atkNoInner);
setPetInner(1, "guard");
const _fg = fldCreate(0);
assert("护体丹进场给护盾", _fg.player.shield > 0);
setPetInner(1, "mana");
assert("回元丹加成真元", Math.abs(petInnerBonus("mana") - 0.2) < 1e-9);
assert("非法内丹被拒", setPetInner(1, "bogus").ok === false);
clearPetInner(1);
assert("取出内丹后失效", petInnerBonus("mana") === 0);

// 合击
S = defaultState(); S.playerName = "测试者";
S.pets = [{ id: 1, key: "chiyan", lv: 5, exp: 0, star: 1, bond: 90, skills: [] }];
S.petActive = 1;
const _fc = fldCreate(0);
if (_fc.pet, _fc.monsters = [{ id: 1, kind: "normal", x: _fc.player.x + 100, y: _fc.player.y, r: 18, alive: true, hp: 1e9, hpMax: 1e9, atk: 10, def: 0, homeX: _fc.player.x + 100, homeY: _fc.player.y, speed: 0, atkCd: 9, aoeCd: 9, facing: 0, hurtT: 0, slowT: 0 }], false) {}
_fc.comboT = CONFIG.PET_COMBO.CD_SEC;
const _evs = fldStep(_fc, 0.016, { mx: 0, my: 0 });
assert("亲密度达标触发人兽合击", _evs.some(e => e.type === "combo"));
S.pets[0].bond = 10;
const _fc2 = fldCreate(0);
_fc2.monsters = [{ id: 1, kind: "normal", x: _fc2.player.x + 100, y: _fc2.player.y, r: 18, alive: true, hp: 1e9, hpMax: 1e9, atk: 10, def: 0, homeX: _fc2.player.x + 100, homeY: _fc2.player.y, speed: 0, atkCd: 9, aoeCd: 9, facing: 0, hurtT: 0, slowT: 0 }];
_fc2.comboT = CONFIG.PET_COMBO.CD_SEC;
const _evs2 = fldStep(_fc2, 0.016, { mx: 0, my: 0 });
assert("亲密度不足不触发合击", !_evs2.some(e => e.type === "combo"));

// 据点争夺
S = defaultState(); S.playerName = "测试者"; S.stamina = 10; S.stone = 0; S.reputation = 0;
S.factions.moyuan.relation = 0;
Math.random = () => 0;   // 敌方偏弱 → 胜
const _rw = raidMoyuan();
Math.random = () => mockRandom;
assert("攻占据点成功：扣体力/得灵石/声望/关系恶化", _rw.ok && _rw.win && S.stamina === 8 && S.stone > 0 && S.reputation > 0 && S.factions.moyuan.relation === -CONFIG.RAID.REL_HIT && S.conquered === 1);
S.stamina = 0;
assert("体力不足拒绝攻打", raidMoyuan().ok === false);

// ===== 阶段 76：v0.36.0 药园 / 化身 / 仙友 / 五行 =====
console.log("\n== 76. v0.36.0 生活与社交 ==");
// 药园
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now(); S.stone = 100000;
assert("药园初始 3×3", gardenPlotCount() === 9);
assert("袋中无种子不可种植", gardenPlant(0, "lingcao").ok === false);
const _q76buy = buySeed("lingcao", 3);
assert("买种子入袋扣灵石", _q76buy.ok === true && invCount("seed:lingcao") === 3 && S.stone === 100000 - CONFIG.GARDEN.CROPS[0].seed * 3);
const _q76p = gardenPlant(0, "lingcao");
assert("种植消耗袋内种子", _q76p.ok === true && invCount("seed:lingcao") === 2);
assert("重复种植被拒", gardenPlant(0, "lingcao").ok === false);
assert("未成熟不可收获", gardenHarvest(0).ok === false);
S.garden.plots[0].plantedAt = Date.now() - 200000;   // 模拟成熟
invSet("herb", 0);
const _q76h = gardenHarvest(0);
assert("成熟可收获", _q76h.ok === true && S.herbs === CONFIG.GARDEN.CROPS[0].herb);
// 枯萎减半
gardenPlant(1, "lingcao");
S.garden.plots[1].plantedAt = Date.now() - CONFIG.GARDEN.CROPS[0].sec * 1000 * CONFIG.GARDEN.WITHER_MULT - 1000;
invSet("herb", 0);
const _q76w = gardenHarvest(1);
assert("枯萎收获减半", _q76w.ok === true && _q76w.withered === true && S.herbs === Math.floor(CONFIG.GARDEN.CROPS[0].herb * 0.5));
// 浇水
gardenPlant(2, "lingcao");
const _q76before = gardenGrowMs(S.garden.plots[2]);
gardenWater(2);
assert("浇水缩短生长时间", gardenGrowMs(S.garden.plots[2]) < _q76before);
// 开垦
const _q76ex = gardenExpand();
assert("开垦药园消耗灵石", _q76ex.ok === true && gardenPlotCount() === 16);
S.garden.size = 5;
assert("药园上限 5×5", gardenExpand().ok === false);
// 药童
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 2, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
S.clearedMaps = { 0: true };
assignDispatch(0, 1);
appointStaff(0, "yaotong", 1);
assert("药童加速药园", gardenLaborBonus() > 0);

// 化身
S = defaultState(); S.playerName = "测试者"; S.realm = 2; S.stone = 1e6;
assert("境界不足不可开辟化身", avatarUnlock().ok === false);
S.realm = 3;
const _q76av = avatarUnlock();
assert("开辟化身扣灵石", _q76av.ok === true && S.avatarBody.unlocked === true && S.avatarBody.lv === 1);
S.clearedMaps = { 0: true };
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 2, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
assert("化身派驻已探明秘境", avatarSetMap(0).ok === true);
S.avatarBody.lastClaim = Date.now() - 3600 * 1000;   // 1 小时
const _q76pend = avatarPending();
assert("化身累积产出", _q76pend && _q76pend.stone > 0 && _q76pend.sec > 3000);
S.stone = 0; S.qi = 0;
const _q76cl = avatarClaim();
assert("收取化身产出", _q76cl.ok === true && S.stone > 0);
S.stone = 1e7;
const _q76up = avatarUpgrade();
assert("化身升级提升系数", _q76up.ok === true && S.avatarBody.lv === 2);

// 仙友
S = defaultState(); S.playerName = "测试者"; S.realm = 2; S.qi = 1e9; S.stone = 1e6;
S.gameTime = { year: 1, month: 1, day: 10, dayTick: 0 };
ensureFriends();
assert("随天数结识仙友", S.friends.length >= 3);
const _q76f = S.friends[0];
const _q76rel0 = _q76f.rel;
const _q76tr = friendTrain(_q76f.id);
assert("传功提升好感", _q76tr.ok === true && _q76f.rel > _q76rel0);
assert("传功每日一次", friendTrain(_q76f.id).ok === false);
const _q76g = friendGift(_q76f.id);
assert("赠礼提升好感", _q76g.ok === true && _q76f.rel >= _q76rel0 + CONFIG.FRIEND.TRAIN_REL + CONFIG.FRIEND.GIFT_REL);
const _q76rate0 = cultivationRate();
_q76f.rel = 100;
const _q76lv = friendBeLover(_q76f.id);
assert("好感满可结道侣", _q76lv.ok === true && _q76f.lover === true);
assert("道侣提升修炼", cultivationRate() > _q76rate0);
const _q76dual = friendDualCultivate(_q76f.id);
assert("道侣双修得灵气", _q76dual.ok === true && _q76dual.gain > 0);

// 五行
S = defaultState(); S.playerName = "测试者";
const _q76me = mainElement();
assert("主修流派可确定", _q76me !== null);
assert("五行克制关系成立", elementBeats("metal", "wood") && elementBeats("wood", "earth") && elementBeats("water", "fire") && elementBeats("fire", "metal") && elementBeats("earth", "water"));
// 克制伤害
S.gongfaBooks = {};
S.gongfaBooks[CONFIG.GONGFA_BOOKS[0].key] = { lv: 10, learned: true };   // 金
const _q76multWin = elementCombatMult("wood");
const _q76multLose = elementCombatMult("fire");
assert("克制元素伤害 +15%", Math.abs(_q76multWin - (1 + CONFIG.ELEMENT_COUNTER)) < 1e-9);
assert("被克元素伤害 -10%", Math.abs(_q76multLose - (1 - CONFIG.ELEMENT_COUNTERED)) < 1e-9);
assert("流派专精加成", elementMasteryBonus() > 0);
// 战场实际伤害差
const _q76fld = fldCreate(0);
_q76fld.player.atk = 1000;
const _mWin = { id: 1, kind: "normal", element: "wood", x: 0, y: 0, r: 18, alive: true, hp: 1e9, hpMax: 1e9, atk: 1, def: 0 };
const _mLose = { id: 2, kind: "normal", element: "fire", x: 0, y: 0, r: 18, alive: true, hp: 1e9, hpMax: 1e9, atk: 1, def: 0 };
mockRandom = 0.99;
fldHit(_q76fld, { atk: 1000 }, _mWin, 1, "#000", true);
fldHit(_q76fld, { atk: 1000 }, _mLose, 1, "#000", true);
const _dWin = 1e9 - _mWin.hp, _dLose = 1e9 - _mLose.hp;
assert("克制敌人伤害更高", _dWin > _dLose);

// ===== 阶段 77：v0.37.0 储物法器（容器 / 堆叠 / 溢出 / 出售）=====
console.log("\n== 77. v0.37.0 储物法器 ==");
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now();
assert("初始法器和格数正确", invDef().key === "cloth" && invSlots() === 12 && invDef().stack === 500);
assert("初始要诀自动入袋", invCount("talisman") === 1 && S.talisman === 1);
// 堆叠：600 灵草 → 500 + 100 两格
invAdd("herb", 600);
assert("同类物品按单格上限堆叠", invCount("herb") === 600 && invStacksOf("herb") === 2);
assert("单格不超过上限", Math.max(...S.bag.slots.filter(x => x && x.key === "herb").map(x => x.n)) <= 500);
invAdd("herb", 400);
assert("未满堆叠优先填满", invStacksOf("herb") === 2 && invCount("herb") === 1000);
assert("镜像字段与袋内一致", S.herbs === invCount("herb"));
// 不同物品堆叠上限不同（受容器承载力约束取小）
assert("丹药与要诀堆叠上限不同", invStackCap(invItemDef("talisman")) === 99 && invStackCap(invItemDef("herb")) === 500);
// 扣除
invRemove("herb", 200);
assert("扣除后镜像同步", S.herbs === 800 && invCount("herb") === 800);
invRemove("herb", 800);
assert("扣空后释放格子", invCount("herb") === 0 && invStacksOf("herb") === 0);
// 满袋溢出散卖
const _stoneBefore = S.stone;
const _room = invRoomFor("herb");
invAdd("herb", _room);
assert("剩余格位全部装满", invFreeSlots() === 0 && invCount("herb") === _room);
const _g = gainItem("herb", 100);
assert("袋满时溢出并散卖", _g.added === 0 && _g.overflow === 100 && S.stone > _stoneBefore);
assert("散卖按售价 60% 折算", S.stone - _stoneBefore === Math.floor(100 * 3 * CONFIG.INV.OVERFLOW_SELL));
// invSet
invSet("herb", 120);
assert("invSet 可重设持有量", invCount("herb") === 120 && S.herbs === 120);
// 出售
const _st2 = S.stone;
const _rs = invSell("herb", 20);
assert("出售得灵石并扣物", _rs.ok === true && _rs.gain === 60 && invCount("herb") === 100 && S.stone === _st2 + 60);
// 丢弃
const _rd = invDrop("herb", 10);
assert("丢弃扣物不返灵石", _rd.ok === true && invCount("herb") === 90);
// 升级法器
S.realm = 0; S.stone = 1e6;
assert("境界不足不可换法器", invUpgrade().ok === false);
S.realm = 1;
const _ru = invUpgrade();
assert("换法器扩容并提升堆叠", _ru.ok === true && invSlots() === 18 && invDef().stack === 1000 && invTier() === 1);
assert("升级后扣灵石", S.stone === 1e6 - CONFIG.INV.CONTAINERS[1].price);
// 升级压缩：小堆叠合并
invCompact();
assert("整理后同类堆叠压紧", invStacksOf("herb") === 1 && invCount("herb") === 90);
// 动态物品定义
assert("种子物品定义可用", invItemDef("seed:lingcao") && invItemDef("seed:lingcao").name.indexOf("种子") >= 0);
assert("古宝碎片定义可用", invItemDef("frag:qingyun") && invItemDef("frag:qingyun").cat === "frag");
// 只有真实存在的物品才出现在持有列表
const _owned = invOwnedKeys();
assert("持有列表不含未拥有物品", _owned.indexOf("tribPill") < 0 && _owned.indexOf("herb") >= 0);
// 袋满时交易被拒（不扣资源、不静默散卖）
S = defaultState(); S.playerName = "测试者"; S.stone = 1e6;
invAdd("herb", invRoomFor("herb"));
const _st3 = S.stone;
const _rbuy = buyHerb();
assert("袋满时买入被拒绝且不扣灵石", _rbuy.ok === false && S.stone === _st3);
const _rc2 = invRoomCheck("pill", 1);
assert("空间校验按剩余格位判定", invFreeSlots() === 0 ? _rc2.ok === false : true);

// 不可售之物溢出进袋口暂存（碎片不蒸发）
S = defaultState(); S.playerName = "测试者";
gainItem("frag:qingyun", 11000);   // 远超 12 格 × 500 的限制，走产出入口
const _stashBefore = invStashTotal();
assert("碎片装满袋后进袋口暂存", _stashBefore > 0 && ancientFragCount("qingyun") + _stashBefore >= 6000);
const _stashStone = S.stone;
assert("不可售之物不散卖", _stashStone === 50);
S.realm = 1; S.stone = 1e6; invUpgrade();   // 扩容到 18 格
const _rc = invRecallStash();
assert("扩容后可取回暂存", _rc.got.length >= 1 && ancientFragCount("qingyun") > 0);

// 旧档迁移装袋
const _legacy = migrateState({ realm: 2, layer: 1, herbs: 88, materials: 7, pills: 3, talisman: 2, tribPills: 1, ancientFrag: { qingyun: 5 } });
S = _legacy;
invEnsure();
assert("旧档资源装进袋子", invCount("herb") === 88 && invCount("material") === 7 && invCount("pill") === 3 && invCount("talisman") === 2);
assert("旧档碎片转为物品", invCount("frag:qingyun") === 5 && S.ancientFrag.qingyun === 5);
assert("迁移后镜像与袋一致", S.herbs === 88 && S.materials === 7 && S.pills === 3);

// ===== 阶段 78：v0.38.0 秘籍 / 丹药 / 装备物品化 =====
console.log("\n== 78. v0.38.0 物品化 ==");
// ---- 秘籍 ----
S = defaultState(); S.playerName = "测试者"; S.realm = 2; S.stone = 1e7; S.qi = 1e9;
S.gongfaBooks.changsheng.lv = CONFIG.GONGFA_BOOKS.find(b => b.key === "changsheng").layers;
invEnsure();
assert("秘籍是独立物品且不可堆叠", invItemDef("book:sanhua") && invStackCap(invItemDef("book:sanhua")) === 1);
assert("未持有秘籍不可领悟", learnGongfa("sanhua").ok === false);
invSet("book:sanhua", 2);
const _learn78 = learnGongfa("sanhua");
assert("领悟消耗秘籍", _learn78.ok === true && bookHeldCount("sanhua") === 1 && gongfaLearned("sanhua"));
// 残卷参悟
invSet("talisman", CONFIG.PILLS.REFINE_TALISMAN);
const _ref78 = refineTalisman();
assert("残卷参悟得秘籍", _ref78.ok === true && bookHeldCount(_ref78.book.key) >= 1 && Math.floor(S.talisman) === 0);
invSet("talisman", 1);
assert("残卷不足不可参悟", refineTalisman().ok === false);
// 寻访
const _before78 = Object.keys(S.bag.slots).filter(i => S.bag.slots[i] && S.bag.slots[i].key.indexOf("book:") === 0).length;
const _search78 = searchGongfaBook();
assert("灵石可寻访秘籍", _search78.ok === true && _search78.price > 0 && bookHeldCount(_search78.book.key) >= 1);

// ---- 丹药效果 ----
S = defaultState(); S.playerName = "测试者"; S.realm = 1; S.qi = 0;
invEnsure();
invAdd("qiPill", 2);
const _qi78 = useQiPill();
const _expectQi = Math.max(1, Math.floor(CONFIG.breakCost(kNow()) * CONFIG.PILLS.QI_PILL));
assert("聚气丹补灵气", _qi78.ok === true && Math.floor(S.qi) >= _expectQi && invCount("qiPill") === 1);
invAdd("breakPill", 1);
const _rate78a = tribulationRate();
useBreakPill();
assert("破境丹提升渡劫率", tribulationRate() > _rate78a);
S.realm = 8;   // 渡劫率逼近上限时仍受钳制
assert("渡劫率不越上限", tribulationRate() <= CONFIG.TRIB_MAX_RATE);
S.realm = 1;
invAdd("healPill", 1);
const _heal78 = useHealPill();
assert("回春丹给护盾状态", _heal78.ok === true && S.healShield === CONFIG.PILLS.HEAL_SHIELD);
assert("护盾状态不可叠加使用", useHealPill().ok === false);
const _fld78 = fldCreate(0);
assert("回春丹护盾在秘境生效", _fld78.player.shield >= Math.floor(_fld78.player.hpMax * CONFIG.PILLS.HEAL_SHIELD));
invAdd("marrowPill", 1);
const _mar78 = useMarrowPill();
assert("洗髓丹给免费洗练", _mar78.ok === true && S.rerollFree === 1);
invAdd("daoPill", 1);
const _dao78 = useDaoPill();
assert("悟道丹给功法折扣", _dao78.ok === true && S.gongfaCut === 1);
// 悟道丹折扣真实生效
S.wudao = 1e9; S.stone = 1e9; S.qi = 1e12; S.realm = 3;
const _gf = "changsheng";
const _costBefore = gongfaCost(gongfaBook(_gf), gongfaLv(_gf) + 1);
const _wd78 = S.wudao;
const _up78 = upgradeGongfa(_gf);
assert("悟道丹令功法悟道按 70% 扣", _up78.ok === true && (_wd78 - S.wudao) === Math.floor(_costBefore.wudao * (1 - CONFIG.PILLS.DAO_WUDAO_CUT)));
assert("悟道丹用后消耗", S.gongfaCut === 0);

// ---- 法宝入袋 ----
S = defaultState(); S.playerName = "测试者"; S.stone = 1e8; invSet("material", 5000);
S.buildings.forge = 6;
invEnsure();
mockRandom = 0;
const _forge78 = forgeArtifact(1);
assert("炼制成功直接入袋", _forge78.ok === true && _forge78.success === true && invArtSlotIndex(_forge78.artifact.id) >= 0);
const _aid78 = _forge78.artifact.id;
const _eq78 = equipArtifact(_aid78);
assert("装备后移出储物袋", _eq78.ok === true && invArtSlotIndex(_aid78) < 0);
const _slotKey78 = slotOfArtifact(_aid78);
const _uneq78 = unequipSlot(_slotKey78);
assert("卸下后回到储物袋", _uneq78.ok === true && invArtSlotIndex(_aid78) >= 0);
invSet("herb", invRoomFor("herb"));
assert("袋满时不可炼制法宝", forgeArtifact(1).ok === false);
invSet("herb", 0);
const _sal78 = dismantleArtifact(_aid78);
assert("分解后清空袋内格位", _sal78.ok === true && invArtSlotIndex(_aid78) < 0 && !S.artifacts.some(x => x.id === _aid78));

// ---- 旧档法宝入袋迁移 ----
const _mig78 = migrateState({
  realm: 2, layer: 1, herbs: 10, materials: 5, pills: 1, talisman: 0,
  artifacts: [{ id: 9001, name: "旧剑", tier: 2, type: "attack", atk: 0.05, def: 0, hp: 0, cult: 0, roll: 1, affixes: [] }],
  loadout: {},
});
S = _mig78;
invEnsure();
assert("旧档法宝自动入袋", invArtSlotIndex(9001) >= 0);

// ===== 阶段 79：v0.39.0 丹方配伍 =====
console.log("\n== 79. v0.39.0 丹房 ==");
S = defaultState(); S.playerName = "测试者"; S.realm = 3; S.stone = 1e7; invSet("herb", 500); invSet("material", 100);
invEnsure();
assert("丹方表已配置", danRecipes().length >= 6);
S.buildings.alchemy = 0;
assert("未建炼丹房不可开炉", danStart("recipe_pill").ok === false);
S.buildings.alchemy = 4;
S.realm = 0;
assert("境界不足不可开炉（高阶方）", danStart("recipe_dao").ok === false);
S.realm = 3;
assert("炉火等级不足不可开炉", danStart("recipe_dao").ok === false);
invSet("herb", 5);
assert("材料不足不可开炉", danStart("recipe_pill").ok === false);
invSet("herb", 500); invSet("material", 100);
const _h0 = Math.floor(S.herbs);
const _start79 = danStart("recipe_pill");
assert("开炉扣灵草并记录状态", _start79.ok === true && Math.floor(S.herbs) === _h0 - 25 && danBusy() === true);
assert("多炉位可并行开炉", danSlotCount() >= 2 && danStart("recipe_qi").ok === true);
assert("炉位占满后拒绝开炉", danStart("recipe_heal").ok === (danFreeSlot() >= 0));
// 全部炉位到期
danState().slots.forEach(sl => { if (sl) sl.startAt = Date.now() - sl.dur - 1000; });
assert("到期后判定可收", danReady() === true);
mockRandom = 0;   // 成功 + 上品
const _out0 = invCount("pill");
const _claim79 = danClaim(0);
assert("收丹成功且上品双倍", _claim79.ok === true && _claim79.success === true && _claim79.crit === true && invCount("pill") === _out0 + 5 * CONFIG.DAN.CRIT_MULT);
assert("收丹后该炉为空", danState().slots[0] === null);
// 清空其余炉
danState().slots.forEach((sl, i) => { if (sl) danAbort(i); });
// 失败分支
invSet("herb", 500); invSet("material", 100);
danStart("recipe_pill");
danState().slots[0].startAt = Date.now() - danState().slots[0].dur - 1000;
mockRandom = 0.99;  // 失败
const _h1 = Math.floor(S.herbs);
const _fail79 = danClaim(0);
assert("炸炉返还半数材料", _fail79.ok === true && _fail79.success === false && Math.floor(S.herbs) === _h1 + Math.floor(25 * CONFIG.DAN.FAIL_REFUND));
// 撤炉
invSet("herb", 500);
danStart("recipe_qi", 1, undefined);
const _h2 = Math.floor(S.herbs);
const _ab79 = danAbort(0);
assert("撤炉返还三成材料", _ab79.ok === true && Math.floor(S.herbs) === _h2 + Math.floor(20 * 0.3) && danState().slots[0] === null);
// 加料档位（v0.42.0）
invSet("herb", 1000); invSet("material", 300);
const _rStd = danRate(danRecipe("recipe_pill"), 1);
const _rTri = danRate(danRecipe("recipe_pill"), 3);
assert("加料提升成功率", _rTri > _rStd);
const _h3 = Math.floor(S.herbs);
const _startTri = danStart("recipe_pill", 3);
assert("三倍投料按三倍扣料", _startTri.ok === true && _startTri.mult === 3 && Math.floor(S.herbs) === _h3 - 75);
danAbort(0);
// 三炉位
S.buildings.alchemy = 9;
assert("炉火足够开三炉", danSlotCount() === 3);
// 袋满且无同类堆叠余量时不可开炉（产出入袋需空位）
invSet("herb", 500);                                // 灵草足量
invSet("pill", invDef().slots * invDef().stack * 2); // 丹药把剩余格位填满（每格顶满）
const _danFull = danStart("recipe_pill");
assert("袋满时开炉被拒并说明空间", _danFull.ok === false && /空间不足/.test(_danFull.msg || ""));
// 成功率随炉火提升
invSet("herb", 500);
S.buildings.alchemy = 4;
const _rate79a = danRate(danRecipe("recipe_pill"));
S.buildings.alchemy = 8;
const _rate79b = danRate(danRecipe("recipe_pill"));
assert("炉火越高成功率越高", _rate79b > _rate79a);
assert("成功率不超过上限", _rate79b <= CONFIG.DAN.MAX_RATE);

// ===== 阶段 80：v0.40.0 章节特产物品化 =====
console.log("\n== 80. v0.40.0 特产入袋 ==");
S = defaultState(); S.playerName = "测试者"; S.stone = 1e7; invEnsure();
S.clearedMaps = { 0: true, 1: true };
assert("特产是真实物品", !!invItemDef("sp:1") && invItemDef("sp:1").name === CONFIG.FIELD_SPECIALTIES[1]);
specialtyDrop(1, "boss");
assert("特产掉落入袋且镜像一致", specialtyCount(1) === 3 && S.specialty[1] === 3 && invCount("sp:1") === 3);
const _spPrice = specialtyPrice(1);
const _st80 = S.stone;
const _sell80 = sellSpecialty(1, 1);
assert("卖特产扣袋内实物", _sell80.ok === true && specialtyCount(1) === 2 && S.stone === _st80 + _sell80.gain);
const _buy80 = buySpecialty(1, 2);
assert("买特产入袋扣灵石", _buy80.ok === true && specialtyCount(1) === 4 && S.stone === _st80 + _sell80.gain - _buy80.cost);
// 练功房门槛
S.buildings.practice = 5; S.stone = 1e9;
invSet("sp:1", 0);
assert("无特产无法升练功房 6 级", upgradeBuilding("practice").ok === false);
invSet("sp:1", 3);
const _up80 = upgradeBuilding("practice");
assert("有特产可升级并扣实物", _up80.ok === true && S.buildings.practice === 6 && specialtyCount(1) === 0);
// 丹方特产需求
S.buildings.alchemy = 7; S.realm = 6; invSet("herb", 1200); invSet("material", 200);
invSet("sp:6", 0);
const _d80 = danStart("recipe_dao");
assert("秘方缺特产不可开炉", _d80.ok === false && /混元露/.test(_d80.msg || ""));
invSet("sp:6", 5);
const _d80b = danStart("recipe_dao");
assert("补齐特产可开炉并扣实物", _d80b.ok === true && specialtyCount(6) === 2);
danAbort();
// 旧档迁移
const _mig80 = migrateState({ realm: 2, layer: 1, specialty: { 0: 7, 2: 4 } });
S = _mig80;
invEnsure();
assert("旧档特产品入袋", specialtyCount(0) === 7 && specialtyCount(2) === 4);

// ===== 阶段 81：v0.41.0 法宝套装 =====
console.log("\n== 81. v0.41.0 法宝套装 ==");
S = defaultState(); S.playerName = "测试者"; S.realm = 8; S.stone = 1e8; invEnsure();
assert("套装表已配置", (CONFIG.ARTIFACT_SETS || []).length >= 3);
const mkA81 = (id, type, tier, setKey) => ({
  id, name: "测器" + id, tier, type, atk: 0.01, def: 0.01, hp: 0, cult: 0,
  roll: 1, affixes: [], setKey,
});
S.artifacts = [mkA81(1, "attack", 3, "qingyun_gear"), mkA81(2, "defense", 3, "qingyun_gear"),
               mkA81(3, "support", 3, "qingyun_gear"), mkA81(4, "attack", 3, null)];
assert("未装备时套装未生效", artifactSetBonus().atk === 0 && activeArtifactSets().length === 0);
equipArtifact(1); equipArtifact(2);
assert("装备 2 件触发套装一档", artifactSetBonus().atk === CONFIG.ARTIFACT_SETS[0].bonus2.atk);
const _baseAtk81 = artifactBonus().atk;
equipArtifact(3);
const _full81 = artifactSetBonus();
assert("装备 3 件触发满档", _full81.atk === CONFIG.ARTIFACT_SETS[0].bonus3.atk && _full81.cult === CONFIG.ARTIFACT_SETS[0].bonus3.cult);
assert("套装加成进入法宝总加成", artifactBonus().atk > _baseAtk81);
const _slot81 = slotOfArtifact(3);
unequipSlot(_slot81);
assert("卸下后回落一档", artifactSetBonus().atk === CONFIG.ARTIFACT_SETS[0].bonus2.atk);
// 不同套装不串味
S.artifacts.push(mkA81(5, "relic", 5, "moyuan_gear"));
equipArtifact(5);
assert("异套不叠加", activeArtifactSets().length === 1);
// 生成器赋予套装（受概率控制）
mockRandom = 0;
const _gen81 = makeArtifact(3, "attack");
assert("炼制可携器韵成套装", _gen81.setKey === "qingyun_gear");
mockRandom = 0.99;
const _gen81b = makeArtifact(3, "attack");
assert("非必出：概率未中则无套", !_gen81b.setKey);

// ===== 阶段 82：v0.43.0 药园品质（施肥/变异/稀有作物）=====
console.log("\n== 82. v0.43.0 药园品质 ==");
S = defaultState(); S.playerName = "测试者"; S.realm = 5; S.stone = 1e7;
invSet("herb", 0); invSet("material", 200); invEnsure();
buySeed("lingcao", 4);
assert("稀有作物需境界", gardenPlant(0, "zizhi").ok === false);
const _p82 = gardenPlant(0, "lingcao");
assert("种下灵草", _p82.ok === true);
const _mat0 = Math.floor(S.materials);
const _f82 = gardenFert(0);
assert("施肥消耗灵材", _f82.ok === true && Math.floor(S.materials) === _mat0 - CONFIG.GARDEN.FERT.matCost);
assert("同地块不可重复施肥", gardenFert(0).ok === false);
S.garden.plots[0].plantedAt = Date.now() - CONFIG.GARDEN.CROPS[0].sec * 1000 - 2000;
mockRandom = 0.99;   // 不触发变异
invSet("herb", 0);
const _h1base = gardenHarvest(0);
const _expect82 = Math.floor(CONFIG.GARDEN.CROPS[0].herb * (1 + CONFIG.GARDEN.FERT.yieldBonus));
assert("施肥增产 30%", _h1base.ok === true && _h1base.mutated === false && _h1base.out.herb === _expect82);
// 变异：随机数压到 0 必触发
gardenPlant(1, "lingcao");
S.garden.plots[1].plantedAt = Date.now() - CONFIG.GARDEN.CROPS[0].sec * 1000 - 2000;
mockRandom = 0;
invSet("herb", 0);
const _h2base = gardenHarvest(1);
assert("变异翻倍并额外得灵材", _h2base.ok === true && _h2base.mutated === true
  && _h2base.out.herb === CONFIG.GARDEN.CROPS[0].herb * CONFIG.GARDEN.FERT.mutMult
  && _h2base.out.material === CONFIG.GARDEN.FERT.mutMat);
assert("变异次数记入药园", (S.garden.mutated || 0) >= 1);
assert("变异额外产出同作物异种灵种", invCount("seed:rare:lingcao") === 1 && invItemDef("seed:rare:lingcao").rare === true);
const _rareGrow = gardenPlant(3, "lingcao", true);
assert("异种灵种可种植并消耗库存", _rareGrow.ok === true && _rareGrow.rare === true && invCount("seed:rare:lingcao") === 0);
assert("异种灵种生长时间缩短 10%", gardenPlotInfo(3).leftSec <= Math.ceil(CONFIG.GARDEN.CROPS[0].sec * 0.9));
S.garden.plots[3].plantedAt = Date.now() - CONFIG.GARDEN.CROPS[0].sec * 1000;
mockRandom = 0.99;
invSet("herb", 0);
const _rareHarvest = gardenHarvest(3);
assert("异种灵种收获产量提高 50%", _rareHarvest.ok === true && _rareHarvest.rare === true
  && _rareHarvest.out.herb === Math.floor(CONFIG.GARDEN.CROPS[0].herb * CONFIG.GARDEN.RARE_SEED_YIELD));
// 稀有作物
invSet("material", 200);
const _buyJY = buySeed("jiuye", 1);
assert("稀有种子可购买入袋", _buyJY.ok === true && invCount("seed:jiuye") === 1);
const _plantJY = gardenPlant(2, "jiuye");
assert("高境界可种九叶灵芝", _plantJY.ok === true);
S.garden.plots[2].plantedAt = Date.now() - CONFIG.GARDEN.CROPS[3].sec * 1000 - 2000;
mockRandom = 0.99;
const _h3base = gardenHarvest(2);
assert("稀有作物产丹药与灵材", _h3base.ok === true && _h3base.out.pill >= 4 && _h3base.out.material >= 4);
mockRandom = 0.99;

// ===== 阶段 83：v0.44.0 化身职能 =====
console.log("\n== 83. v0.44.0 化身职能 ==");
S = defaultState(); S.playerName = "测试者"; S.realm = 4; S.stone = 1e7;
S.buildings.alchemy = 3; invSet("herb", 3000); invSet("material", 300); invEnsure();
S.clearedMaps = { 0: true };
avatarUnlock();
assert("默认职能为秘境挂机", avatarDuty() === "field");
avatarSetMap(0);
S.disciples = [{ id: 1, name: "甲", realm: 2, layer: 0, loyalty: 80, mood: 80, aptitude: 2, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
avatarBodyState().lastClaim = Date.now() - 3600 * 1000;
const _pField = avatarPending();
assert("秘境职能产出灵石", _pField && _pField.duty === "field" && _pField.stone > 0);
const _claimF = avatarClaim();
assert("收取后重置计时", _claimF.ok === true && avatarPending().sec < 5);
// 代炼丹
const _dutyDan = avatarSetDuty("dan");
assert("可改派代炼丹", _dutyDan.ok === true && avatarDuty() === "dan");
avatarBodyState().lastClaim = Date.now() - 2 * 3600 * 1000;
const _pDan = avatarPending();
assert("代炼丹按时间耗料产丹", _pDan && _pDan.duty === "dan" && _pDan.useHerb > 0 && _pDan.pill > 0);
const _h83 = Math.floor(S.herbs);
const _pill83 = Math.floor(S.pills);
const _claimD = avatarClaim();
assert("收取时真实扣料入丹", _claimD.ok === true && Math.floor(S.herbs) < _h83 && Math.floor(S.pills) > _pill83);
// 材料不足时按比例衰减
invSet("herb", 0); invSet("material", 0);
avatarBodyState().lastClaim = Date.now() - 3600 * 1000;
const _pDan2 = avatarPending();
assert("材料不足按比例衰减", _pDan2 && _pDan2.ratio === 0 && _pDan2.pill === 0);
invSet("herb", 3000); invSet("material", 300);
// 代采药
avatarSetDuty("dan");
avatarBodyState().lastClaim = Date.now() - 2 * 3600 * 1000;  // 让切换被拒
assert("有未收产出时不可换职能", avatarSetDuty("garden").ok === false);
avatarClaim();
buySeed("lingcao", 2); gardenPlant(0, "lingcao"); gardenPlant(1, "lingcao");
const _dutyG = avatarSetDuty("garden");
assert("可改派代采药", _dutyG.ok === true && avatarDuty() === "garden");
avatarBodyState().lastClaim = Date.now() - 2 * 3600 * 1000;
const _pGar = avatarPending();
assert("代采药按作物估算产出", _pGar && _pGar.duty === "garden" && _pGar.herb > 0);
const _h9 = Math.floor(S.herbs);
const _claimG = avatarClaim();
assert("代采药收取入袋", _claimG.ok === true && Math.floor(S.herbs) >= _h9);
// 无炼丹房不可代炼
delete S.buildings.alchemy; S.buildings.alchemy = 0;
avatarBodyState().lastClaim = Date.now() - 3600 * 1000;
avatarClaim();
assert("无炼丹房不可改派代炼", avatarSetDuty("dan").ok === false);

// ===== 阶段 84：v0.45.0 仙友事件链 =====
console.log("\n== 84. v0.45.0 仙友交游 ==");
S = defaultState(); S.playerName = "测试者"; S.realm = 2; S.qi = 0; S.stone = 1e6;
S.gameTime = { year: 1, month: 1, day: 20, dayTick: 0 };
ensureFriends();
const _f84 = S.friends[0];
assert("仙友带事件进度字段", Array.isArray(_f84.events));
_f84.rel = 20;
assert("好感不足无交游", friendNextEvent(_f84) === null);
_f84.rel = 30;
const _ev84 = friendNextEvent(_f84);
assert("好感 30 解锁首段交游", _ev84 && _ev84.key === "ev1");
const _qi84 = S.qi;
const _do84 = friendEventDo(_f84.id);
assert("交游给灵气且记进度", _do84.ok === true && S.qi > _qi84 && _f84.events.includes("ev1"));
assert("同段交游不可重复", friendNextEvent(_f84) === null);
_f84.rel = 60;
const _ev84b = friendNextEvent(_f84);
assert("好感 55 解锁第二段（给丹药）", _ev84b && _ev84b.key === "ev2");
const _pill84 = Math.floor(S.pills);
friendEventDo(_f84.id);
assert("第二段真实发丹药", Math.floor(S.pills) === _pill84 + 6);
_f84.rel = 85;
const _ev84c = friendNextEvent(_f84);
assert("好感 80 解锁第三段（给残卷）", _ev84c && _ev84c.key === "ev3");
const _tal84 = Math.floor(S.talisman);
friendEventDo(_f84.id);
assert("第三段真实发残卷", Math.floor(S.talisman) === _tal84 + 2);
// 请援
_f84.rel = 40;
assert("好感不足不可请援", friendHelp(_f84.id).ok === false);
_f84.rel = 60;
const _rate84 = cultivationRate();
const _help84 = friendHelp(_f84.id);
assert("请援生效且每日一次", _help84.ok === true && helpBuffActive() === true && friendHelp(_f84.id).ok === false);
assert("请援提升修炼速率", cultivationRate() > _rate84);
// 道侣机缘
assert("无道侣无机缘", loverGift().ok === false);
_f84.lover = true;
S.loverGiftAt = 0;
mockRandom = 0.1;
const _gift84 = loverGift();
assert("道侣机缘给收益", _gift84.ok === true && _gift84.text.length > 0);
assert("机缘有冷却", loverGift().ok === false);
mockRandom = 0.99;

// ===== 阶段 85：v0.46.0 五行相生连携 =====
console.log("\n== 85. v0.46.0 五行相生 ==");
assert("相生链配置完整", elementGenerates("wood", "fire") && elementGenerates("fire", "earth")
  && elementGenerates("earth", "metal") && elementGenerates("metal", "water") && elementGenerates("water", "wood"));
assert("非相生不成立", elementGenerates("wood", "metal") === false);
assert("技能带五行属性", CONFIG.FIELD_SKILLS.every(x => !!x.element));
S = defaultState(); S.playerName = "测试者"; S.realm = 6; S.bestStage = 12; invEnsure();
const _f85 = fldCreate(0);
_f85.player.mana = 9999;
_f85.monsters = [{ id: 11, kind: "normal", element: null, x: _f85.player.x, y: _f85.player.y - 70, r: 18, alive: true, hp: 1e9, hpMax: 1e9, atk: 1, def: 0, speed: 0 }];
// 木（回春术）→ 火（火海术）：相生
const _castWood = fldCast(_f85, "hui_chun", 0, 1);
assert("木系技能记录上次元素", _castWood.ok === true && _f85.lastElem === "wood");
_f85.cds["huo_hai"] = 0; _f85.player.mana = 9999;
const _hitBefore = 1e9 - _f85.monsters[0].hp;
const _castFire = fldCast(_f85, "huo_hai", 0, -1);
const _hitAfter = 1e9 - _f85.monsters[0].hp;
assert("相生连携触发", _castFire.ok === true && _castFire.gen === true);
assert("相生伤害确实更高", _hitAfter > _hitBefore);
const _evGen = _f85.events.filter(e => e.type === "elem_gen");
assert("相生事件推给渲染层", _evGen.length >= 1);
// 不顺相生无加成
_f85.lastElem = "water"; _f85.lastElemAt = Date.now();
_f85.cds["jian_qi"] = 0; _f85.player.mana = 9999;
const _castMetal = fldCast(_f85, "jian_qi", 1, 0);
assert("水→金不构成相生（水克火生木）", _castMetal.ok === true && _castMetal.gen === false);
// 窗口过期不触发
_f85.lastElem = "wood"; _f85.lastElemAt = Date.now() - (CONFIG.ELEMENT_GEN_WINDOW * 1000 + 5000);
_f85.cds["huo_hai"] = 0; _f85.player.mana = 9999;
const _castLate = fldCast(_f85, "huo_hai", 0, -1);
assert("超出连携窗口不触发", _castLate.ok === true && _castLate.gen === false);

// ===== 阶段 86：v0.47.0 新手引路 + 离线增产 =====
console.log("\n== 86. v0.47.0 引路与离线 ==");
S = defaultState(); S.playerName = "测试者"; S.lastOnline = Date.now(); invEnsure();
assert("引路共七步", CONFIG.GUIDE.length === 7);
const _cur86 = guideCurrent();
assert("初始停在第 1 步", _cur86 && _cur86.step === 1 && _cur86.def.key === "g1");
assert("未达成时判定为假", guideStepDone("g1") === false);
S.tunaCount = 1;
const _got86 = guideTick();
assert("达成后自动发奖并推进", _got86.length === 1 && guideState().done.includes("g1") && S.stone >= 50 + 300);
assert("连续达成的可一次跳步", (() => {
  S.buildings.farm = 1; S.bestStage = 1;
  const before = guideState().done.length;
  guideTick();
  return guideState().done.length >= before + 2;
})());
// 第 4 步：两部功法
S.gongfaBooks.changsheng.learned = true;
S.gongfaBooks.sanhua.learned = true;
guideTick();
assert("领悟两部功法达成第 4 步", guideState().done.includes("g4"));
// 第 5 步：收丹标记
S.guideFlags.danClaimed = true;
guideTick();
assert("收丹达成第 5 步", guideState().done.includes("g5"));
// 第 6 步：法宝
S.artifacts = [{ id: 1, name: "测", tier: 2, type: "attack", atk: 0.05, def: 0, hp: 0, cult: 0, roll: 1, affixes: [] }];
guideTick();
assert("炼出法宝达成第 6 步", guideState().done.includes("g6"));
// 第 7 步：交游
S.friends = [{ id: 1, name: "甲", rel: 60, lover: false, events: ["ev1"], lastTrain: "", lastGift: "", lastDual: "" }];
guideTick();
assert("交游后七步全成", guideCurrent() === null && guideState().done.length === 7);
// 离线增产
S = defaultState(); S.playerName = "测试者"; S.realm = 2; S.buildings.farm = 2; S.buildings.alchemy = 1;
S.clearedMaps = { 0: true }; S.disciples = [{ id: 1, name: "甲", realm: 2, layer: 0, loyalty: 80, mood: 80, aptitude: 2, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
S.lastOnline = Date.now() - 3600 * 1000;
invEnsure();
const _wudaoOffBefore = S.wudao;
const _off86 = computeOffline();
assert("离线结算含洞府与秘境产出", _off86.elapsed > 3000 && _off86.detail && _off86.detail.herb > 0);
assert("离线灵草真实入袋", Math.floor(S.herbs) > 0);
assert("离线结算同步发放悟道", _off86.detail.wudao > 0 && S.wudao > _wudaoOffBefore);


// ===== 阶段 87：内视——经脉与丹田（v0.50.0）=====
console.log("\n== 87. 内视：经脉与丹田 ==");
S = defaultState(); S.playerName = "测试者"; S.stone = 1e9; S.materials = 1e4;
S.realm = 0; S.layer = 0;
const M = CONFIG.MERIDIAN, D = CONFIG.DANTIAN;
assert("初始经脉全未通", meridianTotal() === 0 && CONFIG.MERIDIANS.every(d => meridianHoles(d.key) === 0));
assert("初始未凝丹", dantianLv() === 0);
const _mst0 = S.stone, _mmt0 = S.materials;
const _o1 = openMeridianHole("ren");
assert("炼气可通第 1 穴", _o1.ok && meridianHoles("ren") === 1);
assert("打通扣灵石与灵材", S.stone < _mst0 && S.materials < _mmt0);
assert("通第 2 穴", openMeridianHole("ren").ok && meridianHoles("ren") === 2);
const _mst1 = S.stone, _mmt1 = S.materials;
const _o3 = openMeridianHole("ren");
assert("第 3 穴被境界拦住（炼气→需筑基）", !_o3.ok && meridianHoles("ren") === 2);
assert("被拒时不扣资源", S.stone === _mst1 && S.materials === _mmt1);
S.realm = 1;
assert("筑基可通第 3 穴", openMeridianHole("ren").ok && meridianHoles("ren") === 3);
S.realm = 2;
assert("另一脉从第 1 穴起（不可跳穴）", meridianHoles("du") === 0 && openMeridianHole("du").ok && meridianHoles("du") === 1);
const _mst2 = S.stone;
S.stone = 0;
assert("灵石不足被拒且不扣穴", !openMeridianHole("du").ok && meridianHoles("du") === 1);
// 满配：18 穴
S.stone = 1e9; S.materials = 1e6; S.realm = 5;
for (const d of CONFIG.MERIDIANS) {
  let guard = 0;
  while (meridianHoles(d.key) < M.MAX_PER && guard++ < 20) openMeridianHole(d.key);
}
const _sum = meridianSum();
const wantAttr = M.PER_HOLE * M.MAX_PER + M.ZHOUTIAN + M.GREAT_ATTR;
assert("满配三属性各 +22%", Math.abs(_sum.atk - wantAttr) < 1e-9 && Math.abs(_sum.def - wantAttr) < 1e-9 && Math.abs(_sum.hp - wantAttr) < 1e-9);
assert("满配修炼 +9%", Math.abs(_sum.cult - M.ZHOUTIAN_CULT * 3) < 1e-9);
assert("满配渡劫 +3%", Math.abs(_sum.trib - M.GREAT_TRIB) < 1e-9);
assert("经脉总数 18", meridianTotal() === 18);
// 丹田
S.realm = 1;
assert("金丹前凝丹被拒", !raiseDantian().ok && dantianLv() === 0);
S.realm = 2;
const _dt1 = raiseDantian();
assert("金丹可凝丹", _dt1.ok && _dt1.first && dantianLv() === 1);
S.stone = 1e12; S.materials = 1e9;
let dguard = 0;
while (dantianLv() < D.MAX && dguard++ < 20) raiseDantian();
assert("丹田可至九转", dantianLv() === D.MAX);
assert("九转满阶不再升", !raiseDantian().ok);
const _sum2 = meridianSum();
assert("九转修炼 +18%（叠加经脉 +9%）", Math.abs(_sum2.cult - (M.ZHOUTIAN_CULT * 3 + D.MAX * D.CULT)) < 1e-9);
assert("九转真元 +72", _sum2.mana === D.MAX * D.MANA);
// 四乘区接入
assert("真元上限计入丹田", Math.abs(fldManaMax() - (Math.round((120 + S.realm * 26) * daoDef(S.dao).mana) + D.MAX * D.MANA)) <= 1);
assert("渡劫率含经脉丹田加成", tribulationRate() > CONFIG.TRIB_MIN_RATE - 1e-9);
const _cb50 = cultivationBreakdown();
assert("修炼明细含经脉乘区", _cb50.meridian > 1.2);
assert("修炼总量 = 各乘区连乘", Math.abs(_cb50.total - _cb50.base * _cb50.practice * _cb50.gongfa * _cb50.pill * _cb50.bless * _cb50.art * _cb50.story * _cb50.field * _cb50.dao * _cb50.anci * _cb50.sect * _cb50.meridian) < 1e-4);
const _pc50 = playerCombat();
assert("战斗属性含经脉加成且无 NaN", isFinite(_pc50.attack) && _pc50.attack > 0 && isFinite(_pc50.hp));
// 存档版本（不硬编码：断言「不低于 v12」+「迁移后等于当前版本」，避免每次升版都要改测试）
assert("存档版本不低于 v12", SAVE_VERSION >= 12);
const _mig50 = migrateState({ version: 11, meridian: { ren: 99 }, dantian: -3 });
assert("旧档经脉越界被钳制", _mig50.meridian.ren === M.MAX_PER && _mig50.meridian.du === 0 && _mig50.meridian.chong === 0);
assert("旧档丹田越界被钳制", _mig50.dantian === 0);
assert("迁移后版本等于当前版本", _mig50.version === SAVE_VERSION);

// ===== 阶段 88：v0.51.0 内视反馈 + 驻守结算单 =====
console.log("\n== 88. v0.51.0 内视反馈与驻守结算 ==");
S = defaultState();
S.playerName = "测试者";
S.realm = 2;
S.stone = 1000000;
invSet("material", 500);
const _s51b = openMeridianHole("ren");
assert("开穴返回打通前后快照", _s51b.ok && _s51b.before && _s51b.after);
assert("开穴后主属性高于开穴前", _s51b.after[_s51b.attr] > _s51b.before[_s51b.attr]);
assert("开穴返回主属性键", _s51b.attr === "hp" || _s51b.attr === "atk" || _s51b.attr === "def");
S.realm = 5;
S.stone = 1000000; invSet("material", 500);
const _d51 = raiseDantian();
assert("凝丹返回前后快照", _d51.ok && _d51.after.cult > _d51.before.cult && _d51.after.mana > _d51.before.mana);

// 驻守结算单：累计 → 出单 → 清零，且不重复发钱
S = defaultState();
S.playerName = "测试者";
S.realm = 2;
S.clearedMaps = { 0: true };
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
S.settle = {};
assignDispatch(0, 1);
assert("新档结算单为空", dispatchSettleInfo(0).sec === 0);
dispatchTick(30);
const _st51a = dispatchSettleInfo(0);
assert("tick 累计驻守时长", Math.abs(_st51a.sec - 30) < 0.01);
assert("tick 累计灵石账目", _st51a.stone > 0);
assert("不足 60 秒不出单", !dispatchSettleReady(0) && !dispatchSettle(0).ok);
dispatchTick(40);
assert("满 60 秒可出单", dispatchSettleReady(0));
const _stone51 = S.stone;
const _rs51 = dispatchSettle(0);
assert("出单成功且带账目快照", _rs51.ok && _rs51.rec.stone > 0 && _rs51.name.length > 0);
assert("出单后累计清零", dispatchSettleInfo(0).sec === 0 && dispatchSettleInfo(0).stone === 0);
assert("出单不回收也不重发资源", Math.abs(S.stone - _stone51) < 1e-6);
assert("出单写入世界大事", (S.eventLog || []).some(x => String(typeof x === "object" ? x.text : x).indexOf("驻守结算") >= 0));

// 收益明细
const _dt51 = dispatchDetail(0);
assert("明细含驻守弟子", _dt51.team.length === 1 && _dt51.team[0].name === "甲");
assert("明细含倍率链", Array.isArray(_dt51.chain) && _dt51.chain.length >= 5);
assert("明细含每秒产出", _dt51.rate.stone > 0 && _dt51.rate.total > 0);
assert("明细含结算状态", typeof _dt51.settleReady === "boolean");

// 失守秘境不累计
S.lostFields = { 0: true };
dispatchTick(120);
assert("失守秘境不累计结算单", dispatchSettleInfo(0).sec === 0);
S.lostFields = {};

// 汇总
S = defaultState(); S.playerName = "测试者"; S.realm = 2;
S.clearedMaps = { 0: true };
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
dispatchTick(70);
const _all51 = dispatchSettleAll();
assert("汇总统计待结算秘境", _all51.maps === 1 && _all51.ready === 1 && _all51.stone > 0);

// 存档迁移：settle 脏数据清理
const _mig51 = migrateState({ version: 12, settle: { 0: { sec: 100, stone: 50, qi: -3, herb: "x" }, 1: null, 2: { sec: 0 } } });
assert("迁移保留合法结算单", _mig51.settle[0] && _mig51.settle[0].sec === 100 && _mig51.settle[0].stone === 50);
assert("迁移清零非法账目", _mig51.settle[0].qi === 0 && _mig51.settle[0].herb === 0);
assert("迁移丢弃空记录", !_mig51.settle[1] && !_mig51.settle[2]);
assert("迁移后版本等于当前版本", _mig51.version === SAVE_VERSION);

// ===== P1-1：引魔香与长时挂机 =====
console.log("\\n== P1-1. 引魔香与长时挂机 ==");
S = defaultState(); S.playerName = "P1引魔香测试"; S.fate = CONFIG.FATE.INCENSE_COST;
const _fateInc = fateIncense();
assert("天机阁可用机缘兑换引魔香", _fateInc.ok && invCount("incense") === 1 && S.fate === 0);
const _useInc = useItem("incense");
assert("引魔香可从储物袋使用并进入待结算状态", _useInc.ok && S.huntingIncense === 1 && invCount("incense") === 0);
const _incDup = useHuntingIncense();
assert("引魔香加持不可叠加", !_incDup.ok && S.huntingIncense === 1);
S.lastOnline = Date.now() - 5 * 1000;
const _shortInc = computeOffline();
assert("短暂切后台不消耗引魔香", _shortInc.elapsed === 0 && S.huntingIncense === 1);
S.lastOnline = Date.now() - 20 * 3600 * 1000;
const _oldDispatchRate = dispatchRate;
dispatchRate = () => ({ stone: 1, material: 1, qi: 0, herb: 0, folk: 0, total: 1 });
S.clearedMaps = { 0: true }; S.buildings = { farm: 0, alchemy: 0, forge: 0, practice: 0, recruit: 0 };
const _incOff = computeOffline();
assert("引魔香将下一次离线结算上限延长至13小时", Math.abs(_incOff.elapsed - 13 * 3600) < 1 && _incOff.detail.incense && _incOff.detail.capSec === 13 * 3600);
assert("引魔香离线驻守产出提高50%", Math.abs(_incOff.detail.stone - 13 * 3600 * CONFIG.OFFLINE_RATE * 0.5 * 1.5) < 1);
assert("有效离线结算后引魔香自动燃尽", S.huntingIncense === 0);
// 离线驻守的五类产出必须与在线驻守保持同一资源闭环。
S = defaultState(); S.lastOnline = Date.now() - 20 * 3600 * 1000;
S.clearedMaps = { 0: true }; S.mapTeam = { 0: [1] }; S.folk = 0;
S.buildings = { farm: 0, alchemy: 0, forge: 0, practice: 0, recruit: 0 };
S.huntingIncense = 1;
dispatchRate = () => ({ stone: 1, material: 1, qi: 2, herb: 3, folk: 4, total: 1 });
const _dispatchStoneBefore = S.stone;
const _dispatchOffline = computeOffline();
const _dispatchFactor = 13 * 3600 * CONFIG.OFFLINE_RATE * 0.5 * CONFIG.OFFLINE_INCENSE_DISPATCH_MULT;
assert("离线驻守灵气按离线效率与引魔香倍率入账", Math.abs(_dispatchOffline.detail.dispatchQi - 2 * _dispatchFactor) < 1);
assert("离线驻守灵草计入结算并按背包溢出规则处理", Math.abs(_dispatchOffline.detail.dispatchHerb - 3 * _dispatchFactor) < 1 && S.stone - _dispatchStoneBefore >= _dispatchOffline.detail.stone);
assert("离线驻守灵材计入结算并通过背包入账", Math.abs(_dispatchOffline.detail.material - _dispatchFactor) < 1 && (S.materials > 0 || S.stone > 170210));
assert("离线驻守凡人受领地容量约束", S.folk === folkCap() && _dispatchOffline.detail.dispatchFolk === folkCap());
assert("离线繁衍人口落入对应秘境聚落", settlementPopulation(0) === folkCap());
assert("离线结算同步补记资源点材料", _dispatchOffline.detail.nodeMaterial > 0 && _dispatchOffline.detail.nodeHerb > 0);
dispatchRate = _oldDispatchRate;
// 离线炼丹不能绕过灵草成本。
S = defaultState(); S.buildings = { farm: 0, alchemy: 1, forge: 0, practice: 0, recruit: 0 };
S.lastOnline = Date.now() - 3600 * 1000;
const _noHerbOffline = computeOffline();
assert("无灵草库存且无灵田产出时离线炼丹不凭空产丹", _noHerbOffline.detail.pill === 0 && invCount("pill") === 0);
assert("离线炼丹无灵草时灵草净变化为零", Math.abs(_noHerbOffline.detail.herbNet) < 1e-9);
S = defaultState(); S.buildings = { farm: 1, alchemy: 1, forge: 0, practice: 0, recruit: 0 };
S.lastOnline = Date.now() - 3600 * 1000;
const _farmAlchemyOffline = computeOffline();
assert("离线炼丹按灵草消耗比例产丹", Math.abs(_farmAlchemyOffline.detail.pill - 450) < 1 && Math.abs(_farmAlchemyOffline.detail.herbConsumed - 900) < 1 && invCount("herb") === 0);
assert("离线结算摘要的灵草净变化不把已炼化部分算作新增", Math.abs(_farmAlchemyOffline.detail.herbNet) < 1e-9);
S = defaultState(); S.lastOnline = Date.now() - 20 * 3600 * 1000;
const _plainOff = computeOffline();
assert("未使用引魔香仍保持基础8小时离线上限", Math.abs(_plainOff.elapsed - 8 * 3600) < 1);
S = defaultState(); S.realm = CONFIG.AVATAR_BODY.UNLOCK_REALM;
S.avatarBody = { unlocked: true, lv: 1, duty: "field", map: 0, lastClaim: Date.now() - 30 * 3600 * 1000 };
dispatchRate = () => ({ stone: 1, material: 1, qi: 1, herb: 1 });
const _avatarLong = avatarPending();
assert("化身挂机累积上限扩展至25小时", _avatarLong && Math.abs(_avatarLong.sec - 25 * 3600) < 1);
dispatchRate = _oldDispatchRate;

// v0.54.2：秘境人口按聚落独立记账
S = defaultState();
S.playerName = "聚落分账测试";
S.clearedMaps = { 0: true, 1: true };
S.mapTeam = { 0: [101], 1: [102] };
S.disciples = [
  { id: 101, name: "甲", aptitude: 1, realm: 0, layer: 0, loyalty: 100, mood: 100, assignedTo: null, cultivation: 0 },
  { id: 102, name: "乙", aptitude: 1, realm: 0, layer: 0, loyalty: 100, mood: 100, assignedTo: null, cultivation: 0 },
];
S.folk = 0;
addFolk(12, 0); addFolk(7, 1);
assert("不同秘境驻守后形成独立凡人聚落", settlementPopulation(0) === 12 && settlementPopulation(1) === 7 && S.folk === 19);
assert("当地招募/建设只消耗当地聚落人口", consumeFolk(3, 0) && settlementPopulation(0) === 9 && settlementPopulation(1) === 7 && S.folk === 16);
assert("本地人口不足时不能挪用其他秘境聚落人口", consumeFolk(10, 0) === false && settlementPopulation(1) === 7 && S.folk === 16);

// v0.54.2：回前台/卡顿离线结算只走一个入口，不重复发放驻守收益。
S = defaultState(); S.lastOnline = Date.now() - 120 * 1000; S.clearedMaps = { 0: true }; S.mapTeam = { 0: [201] };
S.disciples = [{ id: 201, name: "离线驻守者", aptitude: 1, realm: 0, layer: 0, loyalty: 100, mood: 100, assignedTo: null, cultivation: 0 }];
S.buildings = { farm: 0, alchemy: 0, forge: 0, practice: 0, recruit: 0 };
const _offlineRateBefore = dispatchRate;
dispatchRate = () => ({ stone: 1, qi: 0, herb: 0, material: 0, folk: 0, total: 1 });
const _offlineOnce = computeOffline();
const _offlineExpected = _offlineOnce.elapsed * CONFIG.OFFLINE_RATE * 0.5;
assert("统一离线入口只发放一次驻守灵石", Math.abs((S.stone - 50) - _offlineExpected) < 1);
assert("离线驻守收益同步记入结算单", Math.abs(dispatchSettleInfo(0).stone - _offlineExpected) < 1);
dispatchRate = _offlineRateBefore;
const _mainSource = fs.readFileSync(path.join(__dirname, "js/main.js"), "utf8");
assert("回前台与长时卡顿路径不再二次调用 dispatchOffline", !/dispatchOffline\s*\(\s*o\.elapsed\s*\)/.test(_mainSource));

console.log("\n===== 结果：" + pass + " 通过，" + fail + " 失败 =====");
process.exit(fail === 0 ? 0 : 1);
