const fs=require('fs'),path=require('path'),vm=require('vm');
const store={}; global.localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=String(v),removeItem:k=>delete store[k]};
global.window={addEventListener:()=>{},removeEventListener:()=>{}}; global.document={hidden:false}; global.confirm=()=>true; global.location={reload:()=>{}};
// 固定随机种子，确保敌人生成、会心与掉落模拟可复现。
let _seed=20261116; Math.random=()=>{_seed=(_seed*1664525+1013904223)>>>0;return _seed/4294967296;};
function load(f){vm.runInThisContext(fs.readFileSync(path.join(__dirname,f),'utf8'),{filename:f});}
[
'js/config.js','js/state.js','js/inventory.js','js/gongfa.js','js/avatar.js','js/pet.js','js/artifact.js','js/idle.js','js/combat.js','js/tower.js','js/build.js','js/dan.js','js/guide.js','js/time.js','js/faction.js','js/event.js','js/npc.js','js/economy.js','js/codex.js','js/field.js','js/dispatch.js','js/dao.js','js/tuna.js','js/daily.js','js/specialty.js','js/ancient.js','js/meridians.js','js/realm.js','js/recruit.js','js/staff.js','js/sect.js','js/element.js','js/life.js','js/field_view.js','js/field_ui.js','js/breath.js'
].forEach(load);
// stop delayed UI settlement in this deterministic harness
setTimeout=()=>0;
function sim(ch,realm,layer,runs){let rows=[];for(let n=0;n<runs;n++){
 S=defaultState(); S.realm=realm; S.layer=layer; S.bestStage=ch*6; S.stamina=30; S.playerName='sim';
 const f=fldCreate(ch); breathNormalizeEnemies(f); BREATH.field=f; BREATH.profile=gongfaV2Profile(); BREATH.active=true; BREATH.playerGas=0; BREATH.enemyGas=0; BREATH.enemyIndex=0; BREATH.slotCursor=0; BREATH.cooldowns={}; BREATH.tick=0; BREATH.resultShown=false;
 f.monsters.sort((a,b)=>({normal:0,elite:1,wild:2,boss:3}[a.kind]??0)-({normal:0,elite:1,wild:2,boss:3}[b.kind]??0));
 let ticks=0; while(BREATH.active && ticks<900){breathTick();ticks++;}
 rows.push({win:!!f.win,ticks,hp:Math.max(0,f.player.hp),hpPct:Math.max(0,f.player.hp/f.player.hpMax),monsters:f.monsters.length});
 }
 const wins=rows.filter(x=>x.win).length; const avg=rows.reduce((a,x)=>a+x.ticks,0)/rows.length; const hp=rows.filter(x=>x.win).reduce((a,x)=>a+x.hpPct,0)/Math.max(1,wins);
 return {chapter:ch,realm,wins,runs,avgTicks:+avg.toFixed(1),avgHpPct:+(hp*100).toFixed(1),rows};}
const perChapter=[1429,1429,1429,1429,1428,1428,1428];
const results=perChapter.map((n,ch)=>sim(ch,ch,0,n));
let failed=false;
for(const r of results){
 const winRate=r.wins/r.runs;
 console.log(`[${winRate>=0.9?'PASS':'FAIL'}] 第${r.chapter+1}章（境界${r.realm}）胜率 ${r.wins}/${r.runs}，平均 ${r.avgTicks.toFixed(1)} 息，胜场剩余气血 ${r.avgHpPct.toFixed(1)}%`);
 if(winRate<0.9 || r.avgTicks>120) failed=true;
}
console.log(`数值抽样：${results.reduce((a,r)=>a+r.runs,0)} 场，${failed?'未通过':'全部通过'}`);
if(failed)process.exit(1);

// 无限血木桩：比较运功流（60%）与术式流（0%）的真实引擎期望 DPS。
function dummyDps(ratio, slots, ticks=2400) {
 S=defaultState(); S.realm=7; S.yungongRatio=ratio; S.gongfaBooks={changsheng:{lv:3,learned:true},chiyang:{lv:6,learned:true},zixiao:{lv:6,learned:true}}; S.gongfaEquip={xin:'changsheng',shu:'chiyang',shen:null,dao:'zixiao'};
 const target={name:'木桩',hp:1e12,hpMax:1e12,def:0,atk:0,alive:true,kind:'normal'};
 Math.random=()=>0.99; // 木桩比较排除会心随机波动，比较基础期望输出
 BREATH.field={player:{atk:100,def:0,hp:1e9,hpMax:1e9,mana:200,manaMax:200,shield:0},monsters:[target],slots:slots.slice(),dmgDealt:0,killCount:0,bossKilled:false};
 BREATH.profile={crit:0,lifesteal:0,atk:0,yungong:0,speed:0,dodge:0,manaRegen:0}; BREATH.buffs={}; BREATH.enemySlow=null; BREATH.cooldowns={}; BREATH.playerGas=0; BREATH.enemyGas=0; BREATH.enemyIndex=0; BREATH.slotCursor=0; BREATH.tick=0; BREATH.active=true; BREATH.el=null;
 const start=BREATH.field.dmgDealt; for(let i=0;i<ticks;i++) breathTick(); BREATH.active=false; return BREATH.field.dmgDealt/(ticks);
}
const dpsYungong=dummyDps(.6,[]);
// 红线比较必须使用合法、输出定位明确的术式流构筑；旧五技能夹具混入低倍率轻式，
// 且把多槽真元竞争与流派基础输出混为一谈。保留旧夹具作为资源饥饿诊断，不用于流派等价门禁。
const spellBuild=['jian_qi','huo_hai','chiyang_burst','zixiao_thunder'];
S=defaultState(); S.realm=7; S.gongfaBooks={changsheng:{lv:3,learned:true},chiyang:{lv:6,learned:true},zixiao:{lv:6,learned:true}};
S.gongfaEquip={xin:'changsheng',shu:'chiyang',shen:null,dao:'zixiao'}; S.fieldSlots=spellBuild.slice();
const unlocked=new Set(fldUnlockedSkills(7).map(x=>x.key));
const illegal=spellBuild.filter(k=>!unlocked.has(k));
if(illegal.length) throw new Error(`DPS 门禁构筑包含未解锁术式：${illegal.join(',')}`);
const legalSpellBuild=fldNormalizeSlots(spellBuild,7).filter(k=>spellBuild.includes(k));
const dpsSpell=dummyDps(0,legalSpellBuild);
const dpsLegacyFive=dummyDps(0,['jian_qi','lingxi_zhang','huo_hai','chiyang_burst','zixiao_thunder']);
const gap=Math.abs(dpsYungong-dpsSpell)/Math.max(dpsYungong,dpsSpell)*100;
console.log(`[${gap<=8?'PASS':'FAIL'}] 运功流/合法输出术式流木桩 DPS：运功 ${dpsYungong.toFixed(3)}，术式 ${dpsSpell.toFixed(3)}，差异 ${gap.toFixed(2)}%（红线≤8%）`);
console.log(`[DIAG] 旧五技能混合夹具 DPS ${dpsLegacyFive.toFixed(3)}（仅作真元竞争诊断，不参与流派等价门禁）`);
console.log(`[INFO] 术式流合法技能：${legalSpellBuild.join(', ')}`);
if(gap>8) process.exitCode=1;
