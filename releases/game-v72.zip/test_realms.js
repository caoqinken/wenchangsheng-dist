// v0.58.0 P0：秘境统一身份注册表与旧账本绑定专项回归。
const fs = require("fs"), path = require("path"), vm = require("vm");
const store = {};
global.localStorage = { getItem:k => store[k] || null, setItem:(k,v) => store[k] = String(v), removeItem:k => delete store[k] };
global.window = { addEventListener:() => {} };
global.document = { hidden:false };
global.confirm = () => true;
function load(f) { vm.runInThisContext(fs.readFileSync(path.join(__dirname, f), "utf8"), { filename:f }); }
load("js/config.js"); load("js/state.js"); load("js/realms.js");
let pass = 0, fail = 0;
function a(name, ok) { if (ok) { pass++; console.log("[PASS] " + name); } else { fail++; console.log("[FAIL] " + name); } }

const legacy = {
  version:17, realm:0, buildings:{farm:2,alchemy:3,forge:1,practice:1,recruit:0},
  stone:1234, folk:40, herbs:17, materials:9, pills:5,
  clearedMaps:{0:true,1:true}, mapTeam:{0:[11,12],1:[]},
  fieldEducation:{0:{progress:1,private:true,totalGuardSec:100},1:{progress:0.4,private:false,totalGuardSec:20}},
  fieldCommerce:{0:{buildings:{auction:1},market:{} }},
  fieldVein:{0:2}, fieldMine:{0:1}, fieldGarden:{0:3}, fieldStable:{0:75},
  fieldTemple:{0:1}, fieldLabor:{0:{vein:2}},
  fieldSettlements:{0:{population:40,name:"青竹聚落",foundedAt:"1-1-1"},_reserve:0},
  fieldSociety:{0:{treasury:22,marriedCouples:3}},
  fieldResidents:{0:{cultivators:4,wallets:[{id:1,balance:7},{id:2,balance:8},{id:3,balance:9},{id:4,balance:10}]}},
  staff:{0:{discipleId:11,office:"yaotong"}}, settle:{0:{sec:60,stone:50}}, mapNodeT:{0:12}, lostFields:{}
};
const migrated = migrateState(legacy);
a("v17旧档平滑迁移到v18", migrated.version === 18 && SAVE_VERSION === 18);
a("已探明秘境生成稳定field_章节ID", !!migrated.realms.field_0 && !!migrated.realms.field_1);
a("已私有化秘境正确标记玩家所有", migrated.realms.field_0.status === "private" && migrated.realms.field_0.ownership === "player");
a("未私有化秘境仍标记为已探明而非玩家私有", migrated.realms.field_1.status === "discovered" && migrated.realms.field_1.ownership === "unclaimed");
a("秘境名称优先沿用旧聚落名称", migrated.realms.field_0.name === "青竹聚落");
a("统一身份记录绑定全部主要旧账本", ["exploration","dispatch","education","commerce","vein","mine","fieldGarden","stability","temple","labor","settlement","society","cultivators","staff","settlementLedger","resourceNodes","lossState"].every(k => !!migrated.realms.field_0.legacyBindings[k]));
a("统一身份层不复制旧人口、库存、建筑或资金", migrated.folk === 40 && migrated.herbs === 17 && migrated.materials === 9 && migrated.pills === 5 && migrated.stone === 1234 && migrated.fieldSettlements[0].population === 40 && migrated.fieldSociety[0].treasury === 22);
a("统一身份层保留旧设施与驻守数据原位", migrated.fieldCommerce[0].buildings.auction === 1 && migrated.mapTeam[0].length === 2 && migrated.fieldVein[0] === 2);

S = Object.assign(defaultState(), migrated);
a("章节号与统一秘境ID可双向解析", realmIdForChapter(0) === "field_0" && realmChapterOf("field_0") === "0" && realmChapterOf("1") === "1");
a("统一身份层可读取旧账本而非副本", realmLegacyData("field_0", "settlement").population === 40 && realmLegacyData(0, "society").treasury === 22);
a("私有化状态由教化真源判断", realmIsPrivate(0) && !realmIsPrivate(1));
a("秘境列表支持筛选私有领地", realmList({privateOnly:true}).length === 1 && realmList({privateOnly:true})[0].id === "field_0");
const before = JSON.stringify({folk:S.folk,bag:S.bag,buildings:S.buildings,settlements:S.fieldSettlements,society:S.fieldSociety,commerce:S.fieldCommerce});
S = migrateState(S); S = migrateState(S);
const after = JSON.stringify({folk:S.folk,bag:S.bag,buildings:S.buildings,settlements:S.fieldSettlements,society:S.fieldSociety,commerce:S.fieldCommerce});
a("重复迁移幂等，不重复创建或复制业务资源", before === after && Object.keys(S.realms).length === 2);
const lost = migrateState({...legacy, lostFields:{0:true}});
a("旧失守记录只改变领地状态，不删除身份", lost.realms.field_0.status === "lost" && !!lost.realms.field_0.legacyBindings);
console.log(`\n秘境统一身份专项：${pass} 通过，${fail} 失败`); if (fail) process.exit(1);
