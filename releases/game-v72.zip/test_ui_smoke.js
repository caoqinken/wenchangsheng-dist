// UI 冒烟检查：校验各视图 HTML 无 undefined/NaN/异常
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const store = {};
global.localStorage = {
  getItem: k => (k in store ? store[k] : null),
  setItem: (k, v) => { store[k] = String(v); },
  removeItem: k => { delete store[k]; },
};
const stubEl = () => ({ textContent: "", innerHTML: "", style: {}, classList: { add(){}, remove(){}, toggle(){} }, dataset: {} });
const els = {};
global.window = { addEventListener: () => {} };
global.document = {
  hidden: false,
  getElementById: id => (els[id] = els[id] || stubEl()),
  querySelectorAll: () => [],
  body: { addEventListener: () => {} },
};
global.confirm = () => true;
global.location = { reload: () => {} };

function load(f) {
  vm.runInThisContext(fs.readFileSync(path.join(__dirname, f), "utf8"), { filename: f });
}

const files = ["js/config.js", "js/state.js", "js/artifact.js", "js/idle.js", "js/combat.js",
  "js/tower.js", "js/build.js", "js/dan.js", "js/guide.js", "js/time.js", "js/faction.js", "js/event.js", "js/npc.js", "js/economy.js",
  "js/codex.js", "js/gongfa.js", "js/avatar.js", "js/pet.js", "js/field.js", "js/dispatch.js", "js/field_view.js", "js/dao.js", "js/tuna.js", "js/daily.js", "js/specialty.js", "js/ancient.js", "js/meridians.js", "js/realm.js", "js/recruit.js", "js/staff.js", "js/field_education.js", "js/sect.js", "js/element.js", "js/life.js", "js/ui.js", "js/field_ui.js"];
for (const f of files) load(f);
load("js/onboard.js");   // v0.25.0 建角模块（依赖 ui.js 的 el/esc）
load("js/inventory.js"); // v0.27.0 储物袋（依赖 ui.js 的 esc/tierInfo）

let fail = 0;
function check(name, html) {
  const bad = [];
  if (/undefined/.test(html)) bad.push("undefined");
  if (/NaN/.test(html)) bad.push("NaN");
  if (/\[object Object\]/.test(html)) bad.push("[object Object]");
  if (!html || html.length < 30) bad.push("输出过短");
  if (bad.length) {
    fail++;
    console.log(`  [FAIL] ${name} -> ${bad.join(",")}`);
    const m = html.match(/.{0,70}(undefined|NaN|\[object Object\]).{0,70}/);
    if (m) console.log("        上下文: " + m[0].replace(/\n/g, " "));
  } else {
    console.log(`  [PASS] ${name} (${html.length} 字符)`);
  }
}

// 场景1：全新存档
S = defaultState();
S.lastOnline = Date.now();
check("洞府视图", viewHome());
check("历练视图", viewBattle());
check("宗门视图(空法宝)", viewBuild());
const herbFlowHtml = viewBuild();
if (herbFlowHtml.includes("灵草净流入") || herbFlowHtml.includes("灵草净流出")) console.log("  [PASS] 洞府灵田/炼丹房显示实时灵草净流量"); else { fail++; console.log("  [FAIL] 洞府缺少灵草净流量反馈"); }
check("世界视图", viewWorld());
check("人物视图", viewChar());

// 场景2：丰富数据（法宝/弟子/事件/渡劫中）
S = defaultState();
S.realm = 3; S.layer = 8; S.qi = 123456; S.stone = 999999; invSet("material", 42);
S.buildings = { farm: 5, alchemy: 3, forge: 6, practice: 4, recruit: 3 };
S.gongfa = 4; invSet("pill", 9); invSet("tribPill", 2); S.tribPillBuff = 1; S.tribFails = 1;
S.reputation = 230;
S.disciples = [
  { id: 1, name: "青玄", aptitude: 3, realm: 2, layer: 3, loyalty: 88, mood: 75, assignedTo: "farm", cultivation: 10 },
  { id: 2, name: "白芷", aptitude: 1, realm: 0, layer: 4, loyalty: 30, mood: 20, assignedTo: null, cultivation: 0 },
];
S.factions.qingyun.relation = 60;
S.activeEvent = { chain: "invasion", stage: 1, flags: {} };
S.eventLog = [{ day: "第1年1月", text: "测试事件" }];
S.market = { herb: 15, pill: 70, tribPill: 620, material: 95 };
S.artifacts = [
  { id: 1, name: "赤霄剑", tier: 4, type: "attack", atk: 0.15, def: 0, hp: 0.075, cult: 0, roll: 1.0,
    affixes: [{ key: "crit", name: "暴击", color: "#A93F2E", value: 0.065 }] },
  { id: 2, name: "玄龟甲", tier: 3, type: "defense", atk: 0, def: 0.10, hp: 0.05, cult: 0, roll: 1.0,
    affixes: [{ key: "thorns", name: "反伤", color: "#5C7A6E", value: 0.07 }] },
  { id: 3, name: "清心珠", tier: 5, type: "support", atk: 0, def: 0, hp: 0.105, cult: 0.21, roll: 1.0,
    affixes: [
      { key: "lifesteal", name: "吸血", color: "#8B2E4A", value: 0.08 },
      { key: "crit", name: "暴击", color: "#A93F2E", value: 0.095 },
    ] },
  { id: 4, name: "裂云刀", tier: 3, type: "attack", atk: 0.10, def: 0, hp: 0.05, cult: 0, roll: 1.0,
    affixes: [] },
];
S.equipped = { attack: 1, defense: 2, support: 3 };
check("洞府视图(渡劫中)", viewHome());
check("历练视图(有通关记录)", viewBattle());
check("宗门视图(丰富法宝)", viewBuild());
check("世界视图(事件中)", viewWorld());
check("人物视图(已装备)", viewChar());

// 场景2.5：八条事件链 × 两阶段的事件卡渲染（v0.6.1 + v0.6.2 + v0.6.3）
let evFail = 0;
for (const chain of ["invasion", "beasttide", "auction", "demonraid", "heartdemon", "zifu", "huashen", "lianxu", "heti", "dacheng", "dujie"]) {
  for (const st of [1, 2]) {
    S.activeEvent = { chain, stage: st, flags: {} };
    const html = viewWorld();
    if (/undefined|NaN|\[object Object\]/.test(html)) {
      evFail++;
      console.log(`  [FAIL] 事件卡 ${chain} 阶段${st}`);
    }
  }
}
if (!evFail) console.log("  [PASS] 十一条事件链 × 两阶段事件卡渲染 (22 组)");
else fail += evFail;
S.activeEvent = null;

// 场景2.6：法宝词条渲染（v0.6.2）
S.activeEvent = null;
const buildHtml = viewBuild();
if (/affix-tag/.test(buildHtml) && /暴击 6\.5%/.test(buildHtml)) {
  console.log("  [PASS] 法宝列表渲染词条标签");
} else {
  fail++;
  console.log("  [FAIL] 法宝词条未渲染");
}
const charHtml = viewChar();
if (/法宝词条/.test(charHtml) && /暴击|吸血|反伤/.test(charHtml)) {
  console.log("  [PASS] 人物页渲染词条汇总");
} else {
  fail++;
  console.log("  [FAIL] 人物页词条汇总未渲染");
}

// 场景3：弹窗
showForgeModal();
check("炼制弹窗", els["modal"] ? els["modal"].innerHTML : "");
// 构造两件同阶同类型法宝，确保炼化弹窗能真正渲染
S.artifacts.push({ id: 5, name: "裂云刀·副", tier: 3, type: "attack", atk: 0.10, def: 0, hp: 0.05, cult: 0, roll: 1.0 });
showRefineModal(4);
const refHtml = els["modal"] ? els["modal"].innerHTML : "";
check("炼化弹窗(有祭品)", refHtml);
if (!/炼化升阶/.test(refHtml)) { fail++; console.log("  [FAIL] 炼化弹窗内容未渲染（提前返回）"); }
else console.log("  [PASS] 炼化弹窗已渲染祭品列表");

// 场景3.4：词条洗练弹窗与结果对比（v0.6.3）
S = defaultState();
invSet("material", 999); S.stone = 99999;
const rrArt = {
  id: 900, name: "洗练剑", tier: 4, type: "attack",
  atk: 0.15, def: 0, cult: 0, hp: 0.075, roll: 1,
  affixes: [{ key: "crit", name: "暴击", color: "#A93F2E", value: 0.055 }],
};
S.artifacts = [rrArt];
showRerollModal(900);
const rrHtml = els["modal"] ? els["modal"].innerHTML : "";
check("洗练弹窗", rrHtml);
if (!/词条洗练/.test(rrHtml)) {
  fail++;
  console.log("  [FAIL] 洗练弹窗内容缺失");
} else {
  console.log("  [PASS] 洗练弹窗含当前词条与消耗");
}
const rRes = rerollAffixes(900);
if (rRes.ok) {
  renderRerollResult(rRes);
  const rrResHtml = els["modal"] ? els["modal"].innerHTML : "";
  check("洗练结果弹窗", rrResHtml);
  if (!/洗练完成/.test(rrResHtml) || !/原词条/.test(rrResHtml) || !/新词条/.test(rrResHtml)) {
    fail++;
    console.log("  [FAIL] 洗练结果弹窗缺少新旧对比");
  } else {
    console.log("  [PASS] 洗练结果弹窗含新旧词条对比");
  }
} else {
  fail++;
  console.log("  [FAIL] 洗练未能执行: " + rRes.msg);
}

// 场景3.4b：锁定洗练弹窗（两条词条，v0.6.4）
S = defaultState();
invSet("material", 9999); S.stone = 999999;
const lockArt = {
  id: 901, name: "锁洗剑", tier: 6, type: "attack",
  atk: 0.28, def: 0, cult: 0, hp: 0.14, roll: 1,
  affixes: [
    { key: "crit", name: "暴击", color: "#A93F2E", value: 0.1265 },
    { key: "thorns", name: "反伤", color: "#5C7A6E", value: 0.161 },
  ],
};
S.artifacts = [lockArt];
showRerollModal(901);
const lockHtml = els["modal"] ? els["modal"].innerHTML : "";
check("锁定洗练弹窗", lockHtml);
if (!/data-lock="0"/.test(lockHtml) || !/data-lock="1"/.test(lockHtml)) {
  fail++;
  console.log("  [FAIL] 锁定洗练弹窗缺少逐条锁定按钮");
} else {
  console.log("  [PASS] 锁定洗练弹窗含逐条锁定按钮");
}

// 场景3.5：存档导入导出弹窗（v0.6.2）
showExportSaveModal();
const expHtml = els["modal"] ? els["modal"].innerHTML : "";
check("导出存档弹窗", expHtml);
if (!/复制存档码/.test(expHtml)) {
  fail++;
  console.log("  [FAIL] 导出弹窗缺少操作按钮");
} else {
  console.log("  [PASS] 导出弹窗含存档码与按钮");
}
showImportSaveModal();
const impHtml = els["modal"] ? els["modal"].innerHTML : "";
check("导入存档弹窗", impHtml);
if (!/import-text/.test(impHtml)) {
  fail++;
  console.log("  [FAIL] 导入弹窗缺少输入域");
} else {
  console.log("  [PASS] 导入弹窗含输入域");
}

// 场景4：经济/战斗/事件链路（确保不崩）
S = defaultState();
S.stone = 5000; invSet("material", 50); S.stamina = 30;
try {
  buyMaterial(); sellMaterial();
  economyTick();
  forgeArtifact(1);
  equipArtifact(S.artifacts.length ? S.artifacts[0].id : 0);
  timeTick(120);
  console.log("  [PASS] 系统联动链路无异常");
} catch (e) {
  fail++;
  console.log("  [FAIL] 系统联动链路异常: " + e.message);
}

// 场景5：道途录视图（v0.6.5）
S = defaultState();
check("道途录视图(空)", viewCodex());

S.realm = 4;
S.achievements = { realm_1: 1, realm_2: 2, realm_3: 3, battle_first: 4 };
S.codex = { artifacts: {}, events: {}, affixSeen: true };
makeArtifact(3, "attack");
makeArtifact(5, "support");
recordEventCodex("beasttide");
const codexHtml = viewCodex();
check("道途录视图(有进度)", codexHtml);
if (!/道途录/.test(codexHtml) || !/成就/.test(codexHtml) || !/法宝图鉴/.test(codexHtml)) {
  fail++;
  console.log("  [FAIL] 道途录视图缺少核心区块");
} else {
  console.log("  [PASS] 道途录三区块齐全（成就/法宝图鉴/事迹图鉴）");
}
const gotAch = codexTick();
if (Array.isArray(gotAch)) console.log("  [PASS] 成就判定可正常执行");
else { fail++; console.log("  [FAIL] 成就判定返回值异常"); }

// 场景6：v0.8.0 新增内容（药力 / 声望出口 / 试炼塔 / 新图鉴）
S = defaultState();
S.lastOnline = Date.now();
S.stamina = 30;
S.reputation = 600;
invSet("pill", 5);
S.pillBuff = 12;
S.towerBest = 7;
S.disciples = [{ id: 9001, name: "青玄", aptitude: 1, realm: 1, layer: 3, loyalty: 66, mood: 80, assignedTo: "farm", cultivation: 10 }];
check("人物视图(含药力)", viewChar());
check("宗门视图(含提资质按钮)", viewBuild());
check("世界视图(含声望出口)", viewWorld());
const battleHtml6 = viewBattle();
check("历练视图(含试炼塔)", battleHtml6);
if (!/无尽试炼塔/.test(battleHtml6) || !/第 8 层/.test(battleHtml6)) {
  fail++; console.log("  [FAIL] 历练视图缺少试炼塔区块或层数错误");
} else console.log("  [PASS] 试炼塔区块显示下一待挑战层");

const buildHtml6 = viewBuild();
if (!/提资质/.test(buildHtml6)) { fail++; console.log("  [FAIL] 弟子行缺少提资质按钮"); }
else console.log("  [PASS] 弟子行含提资质按钮");

const worldHtml6 = viewWorld();
if (!/兑换渡劫丹/.test(worldHtml6)) { fail++; console.log("  [FAIL] 世界视图缺少声望兑换入口"); }
else console.log("  [PASS] 世界视图含声望兑换渡劫丹入口");

// 新图鉴渲染
S.codex = { artifacts: {}, events: {}, beasts: { wolf: 1, tower_stone: 2 }, regions: { region_ch0: 1 } };
const codexHtml2 = viewCodex();
check("道途录视图(含妖兽/秘境图鉴)", codexHtml2);
if (!/妖兽图鉴/.test(codexHtml2) || !/秘境图鉴/.test(codexHtml2) || !/赤目狼王/.test(codexHtml2)) {
  fail++; console.log("  [FAIL] 道途录缺少妖兽/秘境图鉴区块");
} else console.log("  [PASS] 妖兽/秘境图鉴渲染正常");

// v0.24.2 防回归：图鉴图标必须是 <img>，路径不能以裸文本出现
// 回归 B-008：icon 函数返回路径字符串，调用方直接插值 → 页面显示 assets/xxx.webp ???
const barePath = /(^|>)\s*assets\/(妖兽|秘境|事迹)_[^<"]*\.webp/;
if (barePath.test(codexHtml2)) {
  fail++; console.log("  [FAIL] 图鉴出现裸路径文本（assets/... 未包 <img>）");
} else console.log("  [PASS] 图鉴无裸路径文本");
if (!/<img src="assets\/妖兽_赤目狼王\.webp"/.test(codexHtml2)) {
  fail++; console.log("  [FAIL] 已解锁妖兽图鉴未渲染 <img>");
} else console.log("  [PASS] 已解锁妖兽图鉴渲染 <img>");
// 未解锁不显示真实插图（防剧透）：全空图鉴渲染不含任何图片标签
S.codex = { artifacts: {}, events: {}, beasts: {}, regions: {} };
const codexEmpty = viewCodex();
if (/<img src="assets\/(妖兽|秘境|事迹)_/.test(codexEmpty)) {
  fail++; console.log("  [FAIL] 未解锁图鉴泄露真实插图");
} else console.log("  [PASS] 未解锁图鉴不泄露插图");

// 场景7：v0.9.0 增量渲染 + 塔阁
S = defaultState();
S.lastOnline = Date.now();
S.towerCoin = 35;
S.towerBest = 12;
S.stamina = 30;

// 7.1 洞府页绑定节点齐全
const home7 = viewHome();
["rate", "qi-nums", "qi-fill", "break-btn"].forEach(k => {
  if (!new RegExp('data-bind="' + k + '"').test(home7)) {
    fail++; console.log("  [FAIL] 洞府页缺少 data-bind=" + k);
  }
});
console.log("  [PASS] 洞府页四个动态绑定节点齐全");

// 7.2 updateHomeDynamic 只改节点、不重建整页
const fakeNodes = {
  "[data-bind=rate]": { textContent: "" },
  "[data-bind=qi-nums]": { textContent: "" },
  "[data-bind=qi-fill]": { style: { width: "" } },
  "[data-bind=break-btn]": { disabled: true },
};
let domWrites = 0;
els["view"] = {
  innerHTML: "",
  style: {},
  classList: { add() {}, remove() {}, toggle() {} },
  querySelector: sel => fakeNodes[sel] || null,
};
S.qi = 50; S.realm = 0; S.layer = 0;
updateHomeDynamic();
if (S.qi === 50 && fakeNodes["[data-bind=qi-nums]"].textContent === "50 / 100") {
  console.log("  [PASS] 增量更新：灵气数值节点正确");
} else { fail++; console.log("  [FAIL] 增量更新灵气数值异常: " + fakeNodes["[data-bind=qi-nums]"].textContent); }
if (fakeNodes["[data-bind=qi-fill]"].style.width === "50%") {
  console.log("  [PASS] 增量更新：进度条正确");
} else { fail++; console.log("  [FAIL] 进度条异常"); }
if (fakeNodes["[data-bind=break-btn]"].disabled === true) {
  console.log("  [PASS] 增量更新：灵气不足时按钮禁用");
} else { fail++; console.log("  [FAIL] 按钮禁用态异常"); }
S.qi = 500;
updateHomeDynamic();
if (fakeNodes["[data-bind=break-btn]"].disabled === false && fakeNodes["[data-bind=qi-fill]"].style.width === "100%") {
  console.log("  [PASS] 增量更新：灵气充足时按钮解锁且进度封顶 100%");
} else { fail++; console.log("  [FAIL] 解锁态异常"); }
if (els["view"].innerHTML === "") {
  console.log("  [PASS] 增量更新未重写 innerHTML（无整页重建）");
} else { fail++; console.log("  [FAIL] 增量更新意外重写了 innerHTML"); }

// 7.3 showView 维护渲染缓存
showView("build");
if (currentTab === "build" && _lastHtml.length > 30 && _homeSig === "") {
  console.log("  [PASS] showView 写入渲染缓存");
} else { fail++; console.log("  [FAIL] showView 渲染缓存异常"); }
showView("home");
if (currentTab === "home" && _homeSig === homeStructSig()) {
  console.log("  [PASS] 回到洞府页刷新结构签名");
} else { fail++; console.log("  [FAIL] 洞府签名异常: " + _homeSig); }

// 7.4 塔阁弹窗
showTowerShopModal();
const shopHtml = el("modal").innerHTML;
check("塔阁弹窗", shopHtml);
if (!/塔阁/.test(shopHtml) || !/试炼·本命法宝/.test(shopHtml) || !/持有塔币 <b>35<\/b>/.test(shopHtml)) {
  fail++; console.log("  [FAIL] 塔阁弹窗内容不完整");
} else console.log("  [PASS] 塔阁弹窗含塔币与兑换项");
if (!/灵材 ×20/.test(shopHtml) || !/灵石 ×2000/.test(shopHtml)) {
  fail++; console.log("  [FAIL] 塔阁缺少资源兑换项");
} else console.log("  [PASS] 塔阁含资源兑换项");

// 7.5 塔阁兑换可执行
const buyRes = exchangeTower("mat20");
if (buyRes.ok && S.towerCoin === 25) console.log("  [PASS] 塔阁兑换扣减塔币");
else { fail++; console.log("  [FAIL] 塔阁兑换异常"); }

// 7.6 历练页显示塔币
S.towerCoin = 7;
S.bestStage = 0;
const battle7 = viewBattle();
if (/塔阁（塔币 7）/.test(battle7)) console.log("  [PASS] 历练页显示塔币余额");
else { fail++; console.log("  [FAIL] 历练页塔币显示异常"); }

// 场景8：法宝库分页 / 筛选 / 排序（v0.10.0）
S = defaultState();
S.lastOnline = Date.now();
S.realm = 5;
for (let i = 0; i < 45; i++) S.artifacts.push(makeArtifact(1 + (i % 6), ["attack", "defense", "support"][i % 3]));
artifactPage = 0; artifactFilter = "all"; artifactSort = "score";

const artHtml0 = viewBuild();
check("宗门视图(45 件法宝)", artHtml0);
const cardCount = (artHtml0.match(/class="art-row/g) || []).length;
if (cardCount === CONFIG.ARTIFACT_PAGE_SIZE) {
  console.log(`  [PASS] 分页生效：45 件只渲染 ${cardCount} 件`);
} else { fail++; console.log(`  [FAIL] 分页失效，渲染了 ${cardCount} 件`); }
if (/1 \/ 3（共 45 件）/.test(artHtml0)) console.log("  [PASS] 分页信息正确（1/3，共 45 件）");
else { fail++; console.log("  [FAIL] 分页信息异常"); }

// 翻页
artifactPage = 2;
const artHtml2 = viewBuild();
if ((artHtml2.match(/class="art-row/g) || []).length === 5) console.log("  [PASS] 末页只渲染余数 5 件");
else { fail++; console.log("  [FAIL] 末页渲染数量异常"); }

// 越界钳制
artifactPage = 99;
const artHtmlX = viewBuild();
if (/3 \/ 3/.test(artHtmlX)) console.log("  [PASS] 页码越界自动钳制到末页");
else { fail++; console.log("  [FAIL] 页码钳制失效"); }

// 筛选
artifactPage = 0; artifactFilter = "attack";
const artAtk = viewBuild();
const atkCount = S.artifacts.filter(a => a.type === "attack").length;
const atkCards = (artAtk.match(/class="art-row/g) || []).length;
if (atkCards === 15 && atkCount === 15) console.log("  [PASS] 按类型筛选生效（本命 15 件）");
else { fail++; console.log("  [FAIL] 筛选异常：渲染 " + atkCards + " 件，应为 15"); }

// 排序
artifactFilter = "all"; artifactSort = "tier";
const sortedByTier = artifactFilteredList();
let tierOk = true;
for (let i = 1; i < sortedByTier.length; i++) if (sortedByTier[i - 1].tier < sortedByTier[i].tier) { tierOk = false; break; }
if (tierOk) console.log("  [PASS] 按品阶排序正确（降序）");
else { fail++; console.log("  [FAIL] 品阶排序异常"); }

artifactSort = "newest";
const newest = artifactFilteredList();
if (newest[0].id > newest[newest.length - 1].id) console.log("  [PASS] 按最新排序正确");
else { fail++; console.log("  [FAIL] 最新排序异常"); }

// 筛选后无结果
artifactFilter = "support";
S.artifacts = S.artifacts.filter(a => a.type !== "support");
const emptyFiltered = viewBuild();
if (/当前筛选条件下没有法宝/.test(emptyFiltered)) console.log("  [PASS] 筛选无结果有明确提示");
else { fail++; console.log("  [FAIL] 空筛选提示缺失"); }
artifactFilter = "all"; artifactSort = "score"; artifactPage = 0;

// 场景9：势力领地地图（C）与弟子专精/情谊（D），v0.10.0
S = defaultState();
S.lastOnline = Date.now();
S.factions.qingyun.territory = 5;
S.factions.moyuan.territory = 3;
S.factions.sanxiu.territory = 2;
S.factions.sanxiu.relation = 60;   // 触发庇护
const world9 = viewWorld();
check("世界视图(含领地地图)", world9);
["青云门", "魔渊宗", "散修联盟", "天下形势"].forEach(k => {
  if (!new RegExp(k).test(world9)) { fail++; console.log("  [FAIL] 地图缺少 " + k); }
});
console.log("  [PASS] 领地地图含三势力与标题");
if (/领地 5（50%）/.test(world9)) console.log("  [PASS] 领地占比计算正确（5/10 = 50%）");
else { fail++; console.log("  [FAIL] 领地占比异常"); }
if (/关系 \+60 · 庇护/.test(world9)) console.log("  [PASS] 关系达标的势力显示庇护");
else { fail++; console.log("  [FAIL] 庇护标记缺失"); }

// 弟子专精与情谊展示
S = defaultState();
S.lastOnline = Date.now();
S.realm = 2;
S.buildings.recruit = 3;
S.disciples = [
  { id: 1, name: "青玄", aptitude: 2, realm: 1, layer: 3, loyalty: 70, mood: 80, assignedTo: "farm", cultivation: 10, specialty: "farm", bond: 95 },
  { id: 2, name: "白芷", aptitude: 1, realm: 0, layer: 5, loyalty: 55, mood: 60, assignedTo: null, cultivation: 3, specialty: "forge", bond: 35 },
];
const build9 = viewBuild();
check("宗门视图(含专精/情谊)", build9);
if (/灵植✦/.test(build9)) console.log("  [PASS] 专精匹配标记 ✦ 显示正确");
else { fail++; console.log("  [FAIL] 专精匹配标记缺失"); }
if (/嫡传/.test(build9) && /相熟/.test(build9)) console.log("  [PASS] 情谊称号分档显示");
else { fail++; console.log("  [FAIL] 情谊称号显示异常"); }
if (/专精✦匹配委派/.test(build9)) console.log("  [PASS] 弟子说明含专精加成提示");
else { fail++; console.log("  [FAIL] 专精说明缺失"); }

// 场景10：v0.11.0 叙事与新事件卡
S = defaultState(); S.lastOnline = Date.now();
check("古战场事件卡(阶段1)", renderEventCard({ chain: "battleground", stage: 1, flags: {} }));
check("古战场事件卡(阶段2)", renderEventCard({ chain: "battleground", stage: 2, flags: {} }));
check("丹道大会事件卡(阶段1)", renderEventCard({ chain: "pillmeet", stage: 1, flags: {} }));
check("丹道大会事件卡(阶段2)", renderEventCard({ chain: "pillmeet", stage: 2, flags: {} }));
const bgCard = renderEventCard({ chain: "battleground", stage: 1, flags: {} });
if (/古战场遗迹/.test(bgCard) && /探入战阵/.test(bgCard) && /外围搜刮/.test(bgCard)) {
  console.log("  [PASS] 古战场卡片含两个可选分支");
} else { fail++; console.log("  [FAIL] 古战场卡片内容异常"); }

// 章节叙事弹窗（首次通关 BOSS）
S = defaultState(); S.lastOnline = Date.now(); S.realm = 8; S.layer = 8; S.stamina = 30;
currentTab = "battle";
doBattle(5);
const storyHtml = el("modal").innerHTML;
check("章节叙事弹窗", storyHtml);
if (/第一章 · 青云秘境/.test(storyHtml) && /story-text/.test(storyHtml)) {
  console.log("  [PASS] 首次通关弹出章节叙事");
} else { fail++; console.log("  [FAIL] 章节叙事未弹出"); }
if ((storyHtml.match(/story-choice/g) || []).length >= 2 && /此选择永久生效/.test(storyHtml)) {
  console.log("  [PASS] 叙事含两个分支选项且标注永久生效");
} else { fail++; console.log("  [FAIL] 分支选项缺失"); }

// 未选择时重刷仍会弹
S.stamina = 30;
doBattle(5);
if (/第一章 · 青云秘境/.test(el("modal").innerHTML)) console.log("  [PASS] 未选择时重刷仍弹出");
else { fail++; console.log("  [FAIL] 未选择却不再弹出"); }

// 选择后不再弹
chooseStory(0, "war");
S.stamina = 30;
doBattle(5);
if (!/第一章 · 青云秘境/.test(el("modal").innerHTML)) console.log("  [PASS] 选择后重刷不再弹叙事");
else { fail++; console.log("  [FAIL] 选择后仍弹叙事"); }

// 道途录含「剧情」分组
S = defaultState();
S.achievements = {};
const codexStory = viewCodex();
check("道途录(含剧情分组)", codexStory);
if (/剧情/.test(codexStory)) console.log("  [PASS] 道途录出现「剧情」成就分组");
else { fail++; console.log("  [FAIL] 缺少剧情分组"); }

// 场景11：v0.13.0 仙界段（新章节 / 新境界 / 塔上限）
S = defaultState(); S.lastOnline = Date.now();
S.bestStage = 30;   // 第 6 章起点
const battle11 = viewBattle();
check("历练视图(第6章)", battle11);
if (/星陨古域/.test(battle11)) console.log("  [PASS] 第 6 章名称正确渲染");
else { fail++; console.log("  [FAIL] 第 6 章名称缺失"); }

S.bestStage = 36;   // 第 7 章起点
const battle11b = viewBattle();
if (/混元道场/.test(battle11b)) console.log("  [PASS] 第 7 章名称正确渲染");
else { fail++; console.log("  [FAIL] 第 7 章名称缺失"); }

S.bestStage = 42;   // 全通关
const battle11c = viewBattle();
if (/已通关全部秘境/.test(battle11c)) console.log("  [PASS] 42 关全通后显示完结文案");
else { fail++; console.log("  [FAIL] 全通文案缺失"); }

S = defaultState();
S.realm = 10; S.layer = 8;   // 金仙满层
const home11 = viewHome();
check("洞府视图(金仙满层)", home11);
if (/金仙/.test(home11) && /渡劫飞升/.test(home11)) console.log("  [PASS] 金仙满层显示飞升入口");
else { fail++; console.log("  [FAIL] 金仙满层入口异常"); }

S.realm = 9; S.layer = 3;
const home11b = viewHome();
if (/真仙/.test(home11b)) console.log("  [PASS] 真仙境界正确显示");
else { fail++; console.log("  [FAIL] 真仙显示异常"); }

// 场景12：配图（v0.14.0）
S = defaultState(); S.lastOnline = Date.now();
const bgOk = CONFIG.CHAPTERS.every(c => typeof c.bg === "string" && c.bg.indexOf("assets/") === 0 && /\.webp$/.test(c.bg));
if (bgOk) console.log("  [PASS] 全部章节配置了 webp 背景");
else { fail++; console.log("  [FAIL] 章节背景配置缺失"); }

if (chapterBg(0).indexOf("秘境_青云山门") >= 0) console.log("  [PASS] 第 1 章取到青云秘境背景");
else { fail++; console.log("  [FAIL] 第 1 章背景异常: " + chapterBg(0)); }
if (chapterBg(30).indexOf("星陨古域") >= 0) console.log("  [PASS] 第 30 关（第 6 章）取到星陨古域背景");
else { fail++; console.log("  [FAIL] 第 6 章背景异常: " + chapterBg(30)); }
if (chapterBg(41).indexOf("混元道场") >= 0) console.log("  [PASS] 末关取到混元道场背景");
else { fail++; console.log("  [FAIL] 末关背景异常"); }
if (chapterBg(999).indexOf("混元道场") >= 0) console.log("  [PASS] 越界关卡回退末章背景");
else { fail++; console.log("  [FAIL] 越界回退异常"); }

// 各页面含背景
const pages = [
  ["洞府", viewHome(), "洞府主背景"],
  ["人物", viewChar(), "修士立绘"],
  ["宗门", viewBuild(), "宗门山门"],
  ["世界", viewWorld(), "天下山川"],
  ["道途", viewCodex(), "道途书卷"],
];
pages.forEach(([name, html, file]) => {
  if (html.indexOf("assets/" + file + ".webp") >= 0) console.log(`  [PASS] ${name}页配图就位`);
  else { fail++; console.log(`  [FAIL] ${name}页缺少配图 ${file}`); }
});

// 战斗页随章节切换
S.bestStage = 0;
if (viewBattle().indexOf("秘境_青云山门") >= 0) console.log("  [PASS] 历练页第 1 章用青云秘境");
else { fail++; console.log("  [FAIL] 历练页第 1 章背景异常"); }
S.bestStage = 30;
if (viewBattle().indexOf("星陨古域") >= 0) console.log("  [PASS] 历练页推进到第 6 章自动换图");
else { fail++; console.log("  [FAIL] 历练页换图失败"); }

// ===== 场景13：秘境战场（v0.16.0）=====
console.log("\n-- 场景13：秘境战场 --");
S.bestStage = 0;
const bhtml = viewBattle();
if (bhtml.indexOf("入秘境") >= 0) console.log("  [PASS] 历练页含「入秘境」入口（收敛进秘境条目）");
else { fail++; console.log("  [FAIL] 历练页缺少入秘境入口"); }
if (bhtml.indexOf("入秘境 · 自由战斗") < 0) console.log("  [PASS] 已移除重复的入秘境大按钮");
else { fail++; console.log("  [FAIL] 重复的入秘境大按钮仍存在"); }
if (bhtml.indexOf("已通关（可重刷掉落）") < 0) console.log("  [PASS] 已移除分关重刷列表（并入秘境条目）");
else { fail++; console.log("  [FAIL] 分关重刷列表仍存在"); }
if (bhtml.indexOf("速战") >= 0) console.log("  [PASS] 历练页保留「速战」入口");
else { fail++; console.log("  [FAIL] 历练页缺少速战入口"); }

if (typeof startFieldBattle === "function") console.log("  [PASS] 秘境入口函数存在");
else { fail++; console.log("  [FAIL] startFieldBattle 未定义"); }
if (typeof fldCreate === "function" && typeof fldStep === "function") console.log("  [PASS] 战场引擎函数存在");
else { fail++; console.log("  [FAIL] 战场引擎函数缺失"); }
if (typeof flvDraw === "function" && typeof flvToWorld === "function") console.log("  [PASS] Canvas 渲染与坐标转换存在");
else { fail++; console.log("  [FAIL] 渲染层缺失"); }

let skBad = 0;
for (const sk of CONFIG.FIELD_SKILLS) {
  if (!sk.key || !sk.name || !sk.shape || typeof sk.cd !== "number") skBad++;
}
if (!skBad) console.log("  [PASS] " + CONFIG.FIELD_SKILLS.length + " 个神通配置完整");
else { fail++; console.log("  [FAIL] 神通配置缺失（" + skBad + " 个）"); }

const shapes = CONFIG.FIELD_SKILLS.map(s => s.shape);
if (shapes.indexOf("line") >= 0 && shapes.indexOf("cone") >= 0 && shapes.indexOf("nova") >= 0)
  console.log("  [PASS] 含直线/扇形/环身三类方向技能");
else { fail++; console.log("  [FAIL] 方向技能类型不全"); }

const chtml = viewChar();
if (chtml.indexOf("技能盘") >= 0) console.log("  [PASS] 人物页含技能盘配置");
else { fail++; console.log("  [FAIL] 人物页缺少技能盘配置"); }
if (typeof artSlotList === "function" && Array.isArray(artSlotList())) console.log("  [PASS] 技能盘列表可取");
else { fail++; console.log("  [FAIL] 技能盘列表异常"); }

FLDV.w = 340; FLDV.h = 380; FLDV.camX = 0; FLDV.camY = 0;
const rt = flvToWorld(flvSX(700, 300), flvSY(700, 300));
if (Math.abs(rt.x - 700) < 1 && Math.abs(rt.y - 300) < 1) console.log("  [PASS] 等轴测投影可逆");
else { fail++; console.log("  [FAIL] 投影往返误差过大 " + rt.x + "," + rt.y); }

// ===== 场景14：秘境探索与派遣（v0.17.0）=====
console.log("\n-- 场景14：秘境探索与派遣 --");
S = defaultState();
S.bestStage = 12;
S.clearedMaps = { 0: true };
S.mapTeam = {};
const fb = viewBattle();
if (fb.indexOf("秘境") >= 0) console.log("  [PASS] 历练页含秘境区块");
else { fail++; console.log("  [FAIL] 历练页缺少秘境区块"); }
if (fb.indexOf("入秘境") >= 0) console.log("  [PASS] 秘境条目含入秘境按钮");
else { fail++; console.log("  [FAIL] 秘境条目缺少入口"); }
if (fb.indexOf("采集点") >= 0) console.log("  [PASS] 显示采集点数量");
else { fail++; console.log("  [FAIL] 未显示采集点"); }
if (fb.indexOf("驻守") >= 0) console.log("  [PASS] 已探明秘境显示驻守");
else { fail++; console.log("  [FAIL] 已探明秘境未显示驻守"); }
if (fb.indexOf("第 ") >= 0 && fb.indexOf("关") >= 0) console.log("  [PASS] 秘境条目显示章内进度");
else { fail++; console.log("  [FAIL] 秘境条目缺章内进度"); }

if (typeof dispatchRate === "function" && typeof dispatchTick === "function")
  console.log("  [PASS] 派遣引擎函数存在");
else { fail++; console.log("  [FAIL] 派遣引擎函数缺失"); }
if (typeof showDispatchModal === "function") console.log("  [PASS] 派遣弹窗函数存在");
else { fail++; console.log("  [FAIL] 派遣弹窗缺失"); }
if (typeof viewFieldMaps === "function") console.log("  [PASS] 秘境列表渲染函数存在");
else { fail++; console.log("  [FAIL] 秘境列表函数缺失"); }

const nodeKinds = CONFIG.FIELD_NODES.map(n => n.key);
if (nodeKinds.indexOf("ore") >= 0 && nodeKinds.indexOf("vein") >= 0 && nodeKinds.indexOf("herb") >= 0 && nodeKinds.indexOf("ruin") >= 0)
  console.log("  [PASS] 矿脉/灵脉/灵植/遗迹四类节点齐全");
else { fail++; console.log("  [FAIL] 节点类型不全"); }

// ===== 场景15：技能方向轮盘与瞄准扇形（v0.17.2）=====
console.log("\n-- 场景15：方向轮盘与瞄准扇形 --");
if (typeof fsScreenDirToWorld === "function") console.log("  [PASS] 屏幕→世界方向换算存在");
else { fail++; console.log("  [FAIL] 方向换算缺失"); }
if (typeof flvDrawAimCone === "function") console.log("  [PASS] 扇形瞄准绘制函数存在");
else { fail++; console.log("  [FAIL] 扇形瞄准绘制缺失"); }
if (FLDV && FLDV.aim && typeof FLDV.aim.x === "number") console.log("  [PASS] 渲染层含瞄准方向状态");
else { fail++; console.log("  [FAIL] 渲染层缺瞄准状态"); }
if (typeof fsGetAimDir === "function") console.log("  [PASS] 瞄准方向解析函数存在");
else { fail++; console.log("  [FAIL] 瞄准方向解析缺失"); }


// ===== 场景16：二次进入秘境后画布必须重建（回归 v0.17.2 二次进图畸形）=====
console.log("\n-- 场景16：二次进图画布重建 --");
global.Image = function () { this.onload = null; this.src = ""; };
const _mkCanvas = () => ({
  width: 300, height: 150, clientWidth: 390, clientHeight: 700,
  getBoundingClientRect: () => ({ width: 390, height: 700, left: 0, top: 0 }),
  getContext: () => ({ setTransform() {}, save() {}, restore() {} }),
  addEventListener() {},
});
const _fakeField = { player: { x: 0, y: 0 }, map: { bg: "" } };
const _c1 = _mkCanvas();
flvInit(_c1, _fakeField);
if (_c1.width === 390 && _c1.height === 700) console.log("  [PASS] 首次进入画布尺寸正确");
else { fail++; console.log("  [FAIL] 首次进入画布尺寸 = " + _c1.width + "x" + _c1.height); }
const _c2 = _mkCanvas();
flvInit(_c2, _fakeField);
if (_c2.width === 390 && _c2.height === 700) console.log("  [PASS] 二次进入画布重建为正确尺寸");
else { fail++; console.log("  [FAIL] 二次进入画布停在 " + _c2.width + "x" + _c2.height + "（浏览器默认 300x150，会被 CSS 拉成竖长畸形）"); }
if (typeof fsUnbindGlobalPointers === "function" && typeof fsBindGlobalPointers === "function") console.log("  [PASS] 全局指针监听可绑定/解绑（防二次进图重复累积）");
else { fail++; console.log("  [FAIL] 全局指针监听无法解绑"); }

// ===== v0.25.0：建角 / 道号 / 修炼明细 =====
console.log("\n== v0.25.0 建角与修炼明细 ==");
S = defaultState();
S.lastOnline = Date.now();
if (needsOnboarding()) console.log("  [PASS] 空档判定需要建角");
else { fail++; console.log("  [FAIL] 空档未判定需要建角"); }

const onbHtml = onboardHtml();
const onbOk = ["onb-name", "data-onb-start", "data-onb-random"].every(k => onbHtml.indexOf(k) >= 0)
  && (onbHtml.match(/data-onb-avatar=/g) || []).length === CONFIG.AVATARS.length;
if (onbOk) console.log("  [PASS] 建角界面含道号输入/随机/全部形象");
else { fail++; console.log("  [FAIL] 建角界面缺元素"); }
if (onbHtml.indexOf("不 是") < 0 && onbHtml.indexOf("undefined") < 0 && onbHtml.indexOf("NaN") < 0) pass0("建角界面无脏数据");
function pass0(n) { console.log("  [PASS] " + n); }

// 已建角 → 修炼页展示道号与加成入口
S.playerName = "沈青霜";
S.buildings.practice = 4;
S.clearedMaps = { 0: true, 1: true };
const homeHtml = viewHome();
if (!needsOnboarding()) console.log("  [PASS] 已建角不再要求建角");
else { fail++; console.log("  [FAIL] 已建角仍要求建角"); }
if (homeHtml.indexOf("沈青霜") >= 0 && homeHtml.indexOf("加成明细") >= 0) console.log("  [PASS] 修炼页显示道号与加成明细入口");
else { fail++; console.log("  [FAIL] 修炼页缺道号或明细入口"); }
if (homeHtml.indexOf("练功房 ×") >= 0 && homeHtml.indexOf("秘境 +2%") >= 0) console.log("  [PASS] 修炼页加成摘要含练功房与秘境");
else { fail++; console.log("  [FAIL] 修炼页加成摘要缺失"); }

showCultDetail();
const cdHtml = el("modal").innerHTML;
if (cdHtml.indexOf("修炼加成明细") >= 0 && cdHtml.indexOf("秘境探明 2/") >= 0 && cdHtml.indexOf("undefined") < 0 && cdHtml.indexOf("NaN") < 0) {
  console.log("  [PASS] 加成明细弹窗完整");
} else { fail++; console.log("  [FAIL] 加成明细弹窗异常"); }

// 换角色弹窗（需先写入档案）
store[CONFIG.SAVE_KEY_PREFIX + encodeURIComponent("沈青霜")] = JSON.stringify(S);
const _bk = { last: "沈青霜", names: { "沈青霜": { avatar: "qingshan", createdAt: 1 } } };
store[CONFIG.PROFILE_KEY] = JSON.stringify(_bk);
showSwitchCharModal();
const swHtml = el("modal").innerHTML;
if (swHtml.indexOf("道号") >= 0 && swHtml.indexOf("新建道号") >= 0) console.log("  [PASS] 换角色弹窗可用");
else { fail++; console.log("  [FAIL] 换角色弹窗异常"); }

// 战斗层：弹道/预警绘制函数存在且不抛错
try {
  const _ctx = { save(){}, restore(){}, translate(){}, scale(){}, rotate(){}, beginPath(){}, moveTo(){}, lineTo(){}, arc(){}, ellipse(){}, closePath(){}, fill(){}, stroke(){}, setLineDash(){}, createRadialGradient(){ return { addColorStop(){} }; }, fillRect(){}, fillText(){}, drawImage(){} };
  flvDrawAimCone(_ctx, { player: { x: 100, y: 100, r: 14, facing: 0 }, monsters: [], nodes: [] }, { x: 1, y: 0 });
  flvDrawNodeGuide(_ctx, { player: { x: 100, y: 100, r: 14 }, nodes: [{ x: 220, y: 180, r: 18, done: false, glow: "#D4A017" }] });
  FLDV.warns = [{ x: 200, y: 200, r: 90, dur: 1, t: 0, kind: "boss", srcX: 260, srcY: 240 }];
  flvDrawWarns(_ctx, 0.016);
  console.log("  [PASS] 弹道/资源引导/分色预警绘制无异常");
} catch (e) { fail++; console.log("  [FAIL] 战斗绘制抛错: " + e.message); }

// ===== v0.26.0：技能类型 / 世界配图 / 速率精度 =====
console.log("\n== v0.26.0 技能类型与世界配图 ==");
const _skillCard = viewArtSlotCard();
if (_skillCard.indexOf("slot-lock") >= 0 && _skillCard.indexOf("强锁") >= 0) console.log("  [PASS] 技能盘显示类型角标");
else { fail++; console.log("  [FAIL] 技能盘缺类型角标"); }
if (_skillCard.indexOf("undefined") < 0 && _skillCard.indexOf("NaN") < 0) console.log("  [PASS] 技能盘无脏数据");
else { fail++; console.log("  [FAIL] 技能盘含脏数据"); }

S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者";
const _wHtml = viewWorld();
if (_wHtml.indexOf("assets/世界_山河长卷.webp") >= 0) console.log("  [PASS] 世界页接入山河长卷配图");
else { fail++; console.log("  [FAIL] 世界页缺横幅配图"); }
if (_wHtml.indexOf("assets/势力_青云门.webp") >= 0 && _wHtml.indexOf("assets/势力_魔渊宗.webp") >= 0 && _wHtml.indexOf("assets/势力_散修联盟.webp") >= 0) {
  console.log("  [PASS] 三势力卡片均接入配图");
} else { fail++; console.log("  [FAIL] 势力卡片缺配图"); }
if (_wHtml.indexOf("领地") >= 0 && _wHtml.indexOf("undefined") < 0) console.log("  [PASS] 世界页显示领地");
else { fail++; console.log("  [FAIL] 世界页领地异常"); }

// 速率精度：小数值保留两位（1.07 不再显示为 1）
S.buildings.practice = 1;
const _r1 = cultivationRate();
if (rateText(_r1).indexOf(".") >= 0) console.log("  [PASS] 低速率两位小数显示（" + rateText(_r1) + "/秒）");
else { fail++; console.log("  [FAIL] 速率精度仍被吞（" + rateText(_r1) + "）"); }
const _home2 = viewHome();
if (_home2.indexOf(rateText(_r1) + "/秒") >= 0) console.log("  [PASS] 修炼页速率与明细一致");
else { fail++; console.log("  [FAIL] 修炼页速率显示不一致"); }

// ===== v0.27.0：储物袋 / 坊市要诀 / 练功房弟子 =====
console.log("\n== v0.27.0 储物袋与衔接 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者";
invSet("pill", 3); invSet("tribPill", 2); invSet("herb", 12); invSet("material", 7); invSet("talisman", 4);
S.artifacts = [{ id: 1, name: "青锋", tier: 2, type: "attack", atk: 0.05, def: 0, hp: 0, cult: 0, roll: 1 }];
showInventory();
const _invHtml = el("modal").innerHTML;
if (["布囊", "已用", "单格上限", "bag-grid", "丹药", "功法残卷", "灵草", "12"].every(k => _invHtml.indexOf(k) >= 0)) {
  console.log("  [PASS] 储物袋容器信息/格子/持有物齐全");
} else { fail++; console.log("  [FAIL] 储物袋内容缺失"); }
if (_invHtml.indexOf("undefined") < 0 && _invHtml.indexOf("NaN") < 0 && _invHtml.indexOf("[object Object]") < 0) {
  console.log("  [PASS] 储物袋无脏数据");
} else { fail++; console.log("  [FAIL] 储物袋含脏数据"); }

const _wHtml2 = viewWorld();
if (_wHtml2.indexOf("功法残卷") >= 0 && _wHtml2.indexOf("buytalisman") >= 0) console.log("  [PASS] 坊市出现功法残卷购买");
else { fail++; console.log("  [FAIL] 坊市缺功法残卷"); }

// 练功房弟子：页面产出文案体现弟子乘区
S.buildings.practice = 2;
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "practice", bond: 0, assignedTo: "practice", cultivation: 0 }];
const _bHtml = viewBuild();
if (_bHtml.indexOf("含弟子") >= 0) console.log("  [PASS] 练功房卡片显示弟子加成");
else { fail++; console.log("  [FAIL] 练功房未显示弟子加成"); }

// 衔接提示
S = defaultState(); S.playerName = "测试者"; S.buildings.forge = 1; invSet("material", 20);
const _homeH = viewHome();
if (_homeH.indexOf("下一步：") >= 0) console.log("  [PASS] 修炼页显示下一步引导");
else { fail++; console.log("  [FAIL] 修炼页缺下一步引导"); }

// ===== v0.28.0：凡人收徒 / 名额 / 驻守 =====
console.log("\n== v0.28.0 凡人收徒与驻守 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者";
S.folk = 6; S.stone = 5000; S.buildings.recruit = 1; S.realm = 2;
const _bHtml2 = viewBuild();
if (_bHtml2.indexOf("凡人") >= 0 && _bHtml2.indexOf("开山收徒") >= 0) console.log("  [PASS] 洞府显示凡人与收徒入口");
else { fail++; console.log("  [FAIL] 洞府缺凡人展示"); }
if (_bHtml2.indexOf("名额 = ") >= 0) console.log("  [PASS] 弟子名额规则已说明");
else { fail++; console.log("  [FAIL] 缺名额规则说明"); }
if (_bHtml2.indexOf("undefined") < 0 && _bHtml2.indexOf("NaN") < 0) pass0b("洞府页无脏数据");
function pass0b(n) { console.log("  [PASS] " + n); }

showInventory();
const _inv2 = el("modal").innerHTML;
if (_inv2.indexOf("凡人") < 0) console.log("  [PASS] 凡人不占储物格（人口归洞府）");
else { fail++; console.log("  [FAIL] 储物袋误列凡人"); }

// 驻守弹窗：字符串 id 场景不报错
S = defaultState(); S.playerName = "测试者"; S.realm = 2;
S.clearedMaps = { 0: true };
S.disciples = [{ id: 3, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
showDispatchModal(0);
const _disp = el("modal").innerHTML;
if (_disp.indexOf("驻守 · ") >= 0 && _disp.indexOf("灵脉") >= 0 && _disp.indexOf("undefined") < 0) console.log("  [PASS] 驻守弹窗含灵脉与产出");
else { fail++; console.log("  [FAIL] 驻守弹窗异常"); }

// 驻守弹窗显示资源点刷新（v0.28.0）
S = defaultState(); S.playerName = "测试者"; S.realm = 2;
S.clearedMaps = { 0: true };
S.disciples = [{ id: 3, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 3);
showDispatchModal(0);
const _disp2 = el("modal").innerHTML;
if (_disp2.indexOf("资源点刷新") >= 0 && _disp2.indexOf("undefined") < 0) console.log("  [PASS] 驻守弹窗显示资源点刷新");
else { fail++; console.log("  [FAIL] 驻守弹窗缺资源点刷新"); }

// ===== v0.29.0：道途 / 吐纳 / 日常 / 特产 =====
console.log("\n== v0.29.0 道途与日常 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者";
S.gameTime = { year: 1, month: 1, day: 1, dayTick: 0 }; S.tunaDate = ""; S.tunaLeft = 100;
const _h29 = viewHome();
// v0.49.0：修炼页只留吐纳（修炼行为），日常移到世界页，不再两处各来一遍
if (_h29.indexOf("吐纳") >= 0 && _h29.indexOf('data-action="daily"') < 0) console.log("  [PASS] 修炼页只保留吐纳入口");
else { fail++; console.log("  [FAIL] 修炼页入口异常（应只留吐纳）"); }
const _w29d = viewWorld();
if (_w29d.indexOf('data-action="daily"') >= 0 && _w29d.indexOf("机缘") >= 0) console.log("  [PASS] 日常与机缘归入世界页");
else { fail++; console.log("  [FAIL] 世界页缺日常入口"); }

S.realm = 1; S.layer = 8; S.qi = 1e9; S.soulHurtUntil = Date.now() + 60000;
const _h29b = viewHome();
if (_h29b.indexOf("元神受损") >= 0) console.log("  [PASS] 元神受损提示与按钮禁用");
else { fail++; console.log("  [FAIL] 缺元神受损提示"); }

const _c29 = viewChar();
if (_c29.indexOf("道途") >= 0 && _c29.indexOf("法修") >= 0) console.log("  [PASS] 人物页显示道途");
else { fail++; console.log("  [FAIL] 人物页缺道途"); }
showDaoPicker();
if (el("modal").innerHTML.indexOf("改修") >= 0) console.log("  [PASS] 道途改修弹窗可用");
else { fail++; console.log("  [FAIL] 道途弹窗异常"); }

S = defaultState(); S.playerName = "测试者"; S.stone = 5000; S.clearedMaps = { 1: true };
S.marketRefresh = {};
const _w29 = viewWorld();
if (_w29.indexOf("刷新行情") >= 0 && _w29.indexOf("第2章特产") >= 0) console.log("  [PASS] 坊市含刷新与章特产");
else { fail++; console.log("  [FAIL] 坊市缺刷新或特产"); }
if (_w29.indexOf("undefined") < 0 && _w29.indexOf("NaN") < 0) pass29("坊市无脏数据");
function pass29(n) { console.log("  [PASS] " + n); }

showTunaModal();
const _tunaHtml = el("modal").innerHTML;
if (_tunaHtml.indexOf("tuna-track") >= 0 && _tunaHtml.indexOf("剩余") >= 0 && _tunaHtml.indexOf("tuna-result") >= 0) console.log("  [PASS] 吐纳弹窗渲染（含结果区）");
else { fail++; console.log("  [FAIL] 吐纳弹窗异常"); }
showDailyPanel();
const _dailyHtml = el("modal").innerHTML;
if (_dailyHtml.indexOf("每日任务") >= 0 && _dailyHtml.indexOf("周常任务") >= 0 && _dailyHtml.indexOf("天机阁") >= 0) {
  console.log("  [PASS] 日常面板含每日/周常/天机阁");
} else { fail++; console.log("  [FAIL] 日常面板缺内容"); }

const _onb29 = onboardHtml();
if (_onb29.indexOf("data-onb-dao") >= 0 && _onb29.indexOf("法修") >= 0) console.log("  [PASS] 建角含道途选择");
else { fail++; console.log("  [FAIL] 建角缺道途选择"); }

// ===== v0.30.0：古宝 / 坊市特价 =====
console.log("\n== v0.30.0 古宝与特价 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者";
S.ancient = { qf_sword: { star: 2, infuse: 1 } };
invSet("frag:qingyun", 6);
const _c30 = viewChar();
// v0.49.0：人物页古宝只留「去古宝图鉴」导航；收集详情归道途录
if (_c30.indexOf("古宝") >= 0 && _c30.indexOf('data-tab="codex"') >= 0) console.log("  [PASS] 人物页古宝只留图鉴导航");
else { fail++; console.log("  [FAIL] 人物页古宝入口异常"); }
const _codex30 = viewCodex();
if (_codex30.indexOf("古宝图鉴") >= 0 && _codex30.indexOf('data-action="ancset"') >= 0 && _codex30.indexOf("undefined") < 0) {
  console.log("  [PASS] 道途录收编古宝简卡（点击看详情）");
} else { fail++; console.log("  [FAIL] 道途录缺古宝图鉴"); }
showAncientSetDetail("qingyun");
const _ancHtml = el("modal").innerHTML;
if (_ancHtml.indexOf("青锋古剑") >= 0 && _ancHtml.indexOf("升星") >= 0 && _ancHtml.indexOf("注灵") >= 0 && _ancHtml.indexOf("undefined") < 0) {
  console.log("  [PASS] 古宝详情含升星/注灵");
} else { fail++; console.log("  [FAIL] 古宝详情异常"); }
if (_ancHtml.indexOf("ancforge") < 0) console.log("  [PASS] 古宝详情不再重复碎片合成按钮");
else { fail++; console.log("  [FAIL] 古宝详情仍有合成按钮"); }
showAncientPanel();
const _ancPanel = el("modal").innerHTML;
if (_ancPanel.indexOf("青云遗宝") >= 0 && _ancPanel.indexOf("undefined") < 0) console.log("  [PASS] 古宝总览为套装简卡");
else { fail++; console.log("  [FAIL] 古宝总览异常"); }

S = defaultState(); S.playerName = "测试者"; S.stone = 5000; S.marketDeals = {};
const _w30 = viewWorld();
if (_w30.indexOf("特价") >= 0) console.log("  [PASS] 坊市显示今日特价");
else { fail++; console.log("  [FAIL] 坊市缺特价"); }
if (_w30.indexOf("undefined") < 0 && _w30.indexOf("NaN") < 0) pass30("坊市特价无脏数据");
function pass30(n) { console.log("  [PASS] " + n); }

// ===== v0.31.0：秘境建设 / 温养 / 参悟 / 立宗 =====
console.log("\n== v0.31.0 秘境建设与立宗 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者";
S.realm = 2; S.stone = 99999; S.clearedMaps = { 0: true };
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
showDispatchModal(0);
const _d31 = el("modal").innerHTML;
if (_d31.indexOf("矿场") >= 0 && _d31.indexOf("药圃") >= 0) console.log("  [PASS] 驻守弹窗含矿场与药圃");
else { fail++; console.log("  [FAIL] 驻守弹窗缺建设项"); }

S.mapTeam = {};   // 未立宗态
const _b31a = viewBuild();
if (_b31a.indexOf("宗门") >= 0 && _b31a.indexOf("立宗") >= 0) console.log("  [PASS] 洞府页显示宗门卡（未立宗）");
else { fail++; console.log("  [FAIL] 洞府页缺宗门卡"); }
S.mapTeam = { 0: [1], 1: [2], 2: [3] };
S.clearedMaps = { 0: true, 1: true, 2: true };
S.sect = { name: "长生宗", lv: 2 };
const _b31b = viewBuild();
if (_b31b.indexOf("长生宗") >= 0 && _b31b.indexOf("Lv.2") >= 0 && _b31b.indexOf("全属性") >= 0) console.log("  [PASS] 已立宗显示等级与加成");
else { fail++; console.log("  [FAIL] 已立宗展示异常"); }

// 法宝温养按钮
S = defaultState(); S.playerName = "测试者"; S.artifacts = [makeArtifact(3, "attack")]; S.stone = 9999; invSet("material", 99);
S.realm = 3;
const _b31c = viewBuild();
if (_b31c.indexOf("温养") >= 0) console.log("  [PASS] 法宝行含温养");
else { fail++; console.log("  [FAIL] 法宝行缺温养"); }

// 技能盘参悟
const _c31 = viewChar();
if (_c31.indexOf("悟0") >= 0 || _c31.indexOf("insightskill") >= 0) console.log("  [PASS] 技能盘含参悟入口");
else { fail++; console.log("  [FAIL] 技能盘缺参悟"); }
if (_c31.indexOf("undefined") < 0 && _c31.indexOf("NaN") < 0) pass31("人物页无脏数据");
function pass31(n) { console.log("  [PASS] " + n); }

// ===== v0.32.0：弟子凡人体系 =====
console.log("\n== v0.32.0 弟子凡人体系 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者";
S.realm = 2; S.clearedMaps = { 0: true }; S.stone = 99999; S.folk = 30;
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
showDispatchModal(0);
const _d32 = el("modal").innerHTML;
if (_d32.indexOf("安定度") >= 0 && _d32.indexOf("建庙") >= 0 && _d32.indexOf("安抚") >= 0) console.log("  [PASS] 驻守弹窗含安定/建庙/安抚");
else { fail++; console.log("  [FAIL] 驻守弹窗缺安定相关"); }
if (_d32.indexOf("灵脉师") >= 0 && _d32.indexOf("矿工") >= 0 && _d32.indexOf("药农") >= 0) console.log("  [PASS] 建设显示工种与凡人需求");
else { fail++; console.log("  [FAIL] 建设缺工种说明"); }

const _b32 = viewBuild();
if (_b32.indexOf("凡人 30/") >= 0 && _b32.indexOf("开山收徒") >= 0) console.log("  [PASS] 洞府弟子卡显示凡人容量与收徒");
else { fail++; console.log("  [FAIL] 弟子卡异常"); }

showRecruitModal();
const _r32 = el("modal").innerHTML;
if (_r32.indexOf("开山收徒") >= 0 && _r32.indexOf("选拔") >= 0) console.log("  [PASS] 招徒弹窗可用");
else { fail++; console.log("  [FAIL] 招徒弹窗异常"); }

S.sect = { name: "长生宗", lv: 3 }; S.folk = 120; S.stone = 999999;
const _b32b = viewBuild();
if (_b32b.indexOf("立朝") >= 0 && _b32b.indexOf("王朝") >= 0) console.log("  [PASS] 宗门卡含立朝入口");
else { fail++; console.log("  [FAIL] 宗门卡缺立朝"); }
if (_b32b.indexOf("undefined") < 0 && _b32b.indexOf("NaN") < 0) pass32("洞府页无脏数据");
function pass32(n) { console.log("  [PASS] " + n); }

// ===== v0.33.0：职务 / 任务 / 争夺 / 王朝官职 =====
console.log("\n== v0.33.0 弟子经营完整版 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者";
S.realm = 2; S.clearedMaps = { 0: true }; S.stone = 99999; S.folk = 30; S.stamina = 30;
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 3, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
showDispatchModal(0);
const _d33 = el("modal").innerHTML;
if (_d33.indexOf("弟子职务") >= 0 && _d33.indexOf("任庙祝") >= 0 && _d33.indexOf("任矿正") >= 0) console.log("  [PASS] 驻守弹窗含职务任命");
else { fail++; console.log("  [FAIL] 驻守弹窗缺职务"); }
showMissionPanel();
const _m33 = el("modal").innerHTML;
if (_m33.indexOf("弟子任务") >= 0 && _m33.indexOf("清剿妖患") >= 0 && _m33.indexOf("护送商队") >= 0 && _m33.indexOf("传道四方") >= 0) {
  console.log("  [PASS] 任务面板含三类任务");
} else { fail++; console.log("  [FAIL] 任务面板异常"); }

S.dynasty = { name: "大衍王朝" }; S.sect = { name: "长生宗", lv: 3 };
showDynastyOfficeModal();
const _o33 = el("modal").innerHTML;
if (_o33.indexOf("州牧") >= 0 && _o33.indexOf("司农") >= 0 && _o33.indexOf("国师") >= 0 && _o33.indexOf("赋税") >= 0) {
  console.log("  [PASS] 王朝官职面板");
} else { fail++; console.log("  [FAIL] 王朝官职异常"); }

S.lostFields = { 0: true };
const _b33 = viewBattle();
if (_b33.indexOf("旧版失守记录") >= 0 && _b33.indexOf("赎回") >= 0) console.log("  [PASS] 旧版失守记录显示与赎回兼容");
else { fail++; console.log("  [FAIL] 失守展示异常"); }
if (_b33.indexOf("undefined") < 0 && _b33.indexOf("NaN") < 0) pass33("历练页无脏数据");
function pass33(n) { console.log("  [PASS] " + n); }

// ===== v0.34.0：宗门事务 =====
console.log("\n== v0.34.0 宗门事务 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者";
S.sect = { name: "长生宗", lv: 2 }; S.contribution = 40; S.stamina = 20;
S.gameTime = { year: 1, month: 1, day: 1, dayTick: 0 };
showSectPanel();
const _sp34 = el("modal").innerHTML;
if (_sp34.indexOf("宗门任务") >= 0 && _sp34.indexOf("藏经阁") >= 0 && _sp34.indexOf("护法试炼") >= 0 && _sp34.indexOf("宗门外交") >= 0) {
  console.log("  [PASS] 宗门面板含任务/藏经阁/试炼/外交");
} else { fail++; console.log("  [FAIL] 宗门面板缺模块"); }
if (_sp34.indexOf("贡献 <b>40</b>") >= 0) console.log("  [PASS] 宗门面板显示贡献");
else { fail++; console.log("  [FAIL] 宗门面板缺贡献"); }
const _b34 = viewBuild();
if (_b34.indexOf("宗门事务") >= 0 && _b34.indexOf("贡献") >= 0) console.log("  [PASS] 洞府宗门卡含事务入口");
else { fail++; console.log("  [FAIL] 宗门卡缺事务入口"); }
if (_sp34.indexOf("undefined") < 0 && _sp34.indexOf("NaN") < 0) pass34("宗门面板无脏数据");
function pass34(n) { console.log("  [PASS] " + n); }

// ===== v0.35.0：古宝特效 / 内丹 / 据点 =====
console.log("\n== v0.35.0 古宝特效与内丹 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者";
S.ancient = { qf_sword: { star: 2, infuse: 1 } };
showAncientPanel();
const _anc35 = el("modal").innerHTML;
if (_anc35.indexOf("古宝特效") >= 0 && _anc35.indexOf("伤害 +") >= 0) console.log("  [PASS] 古宝面板显示特效");
else { fail++; console.log("  [FAIL] 古宝面板缺特效"); }

S = defaultState(); S.playerName = "测试者";
S.pets = [{ id: 1, key: "chiyan", lv: 5, exp: 0, star: 1, bond: 10, skills: [] }];
S.petActive = 1;
const _c35 = viewChar();
if (_c35.indexOf("内丹") >= 0) console.log("  [PASS] 灵兽行含内丹入口");
else { fail++; console.log("  [FAIL] 灵兽行缺内丹"); }

S.stamina = 10; S.stone = 9999;
const _w35 = viewWorld();
if (_w35.indexOf("魔渊据点") >= 0 && _w35.indexOf("攻打") >= 0) console.log("  [PASS] 世界页含据点争夺");
else { fail++; console.log("  [FAIL] 世界页缺据点"); }
if (_w35.indexOf("undefined") < 0 && _w35.indexOf("NaN") < 0) pass35("世界页无脏数据");
function pass35(n) { console.log("  [PASS] " + n); }

// ===== v0.36.0：药园 / 化身 / 仙友 / 五行 =====
console.log("\n== v0.36.0 生活与社交 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者"; S.stone = 1e6;
showGardenPanel();
const _gd36 = el("modal").innerHTML;
if (_gd36.indexOf("garden-grid") >= 0 && _gd36.indexOf("garden-cell") >= 0) log36("药园面板含格子");
if (_gd36.indexOf("药园 3×3") >= 0) log36("药园显示规模");
else { fail++; console.log("  [FAIL] 药园规模缺失"); }
if (_gd36.indexOf("undefined") < 0 && _gd36.indexOf("NaN") < 0) log36("药园面板无脏数据");
else { fail++; console.log("  [FAIL] 药园面板脏数据"); }
S.realm = 3;
showAvatarPanel();
const _av36 = el("modal").innerHTML;
if (_av36.indexOf("化身") >= 0 && _av36.indexOf("开辟化身") >= 0) log36("化身面板含开辟入口");
else { fail++; console.log("  [FAIL] 化身面板缺入口"); }
S.avatarBody = { unlocked: true, lv: 2, map: 0, lastClaim: Date.now() - 7200000, acc: { stone: 0, qi: 0, herb: 0 } };
S.clearedMaps = { 0: true };
showAvatarPanel();
const _av36b = el("modal").innerHTML;
if (_av36b.indexOf("待收产出") >= 0 && _av36b.indexOf("收取") >= 0) log36("化身面板含待收产出");
else { fail++; console.log("  [FAIL] 化身面板缺待收"); }
S = defaultState(); S.playerName = "测试者"; S.stone = 1e6; S.qi = 1e7;
S.gameTime = { year: 1, month: 1, day: 15, dayTick: 0 };
ensureFriends();
showFriendPanel();
const _fr36 = el("modal").innerHTML;
if (_fr36.indexOf("friend-row") >= 0 && _fr36.indexOf("传功") >= 0 && _fr36.indexOf("赠礼") >= 0) log36("仙友面板含传功/赠礼");
else { fail++; console.log("  [FAIL] 仙友面板缺按钮"); }
if (_fr36.indexOf("道侣加成") >= 0) log36("仙友面板显示道侣加成");
else { fail++; console.log("  [FAIL] 仙友面板缺道侣加成"); }
if (_fr36.indexOf("undefined") < 0 && _fr36.indexOf("NaN") < 0) log36("仙友面板无脏数据");
else { fail++; console.log("  [FAIL] 仙友面板脏数据"); }
// 人物页功法流派
S.gongfaBooks = {}; S.gongfaBooks[CONFIG.GONGFA_BOOKS[0].key] = { lv: 6, learned: true };
const _ch36 = viewChar();
if (_ch36.indexOf("主修") >= 0) log36("人物页显示主修流派");
else { fail++; console.log("  [FAIL] 人物页缺主修流派"); }
// 洞府生活入口
const _bd36 = viewBuild();
if (_bd36.indexOf("药园") >= 0 && _bd36.indexOf("化身") >= 0 && _bd36.indexOf("仙友") >= 0) log36("洞府含生活入口");
else { fail++; console.log("  [FAIL] 洞府缺生活入口"); }
function log36(n) { console.log("  [PASS] " + n); }

// ===== v0.37.0：储物法器网游式背包 =====
console.log("\n== v0.37.0 储物法器 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者";
invSet("talisman", 0);
showInventory();
const _bag0 = el("modal").innerHTML;
const _cellCount = (_bag0.match(/bag-cell/g) || []).length;
if (_cellCount === invSlots()) log37("格子数等于法器空间（" + invSlots() + " 格）");
else { fail++; console.log("  [FAIL] 格子数与空间不符 " + _cellCount + "/" + invSlots()); }
if (_bag0.indexOf("袋中空空") >= 0) log37("空袋只显示空格与提示");
else { fail++; console.log("  [FAIL] 空袋渲染异常"); }
if (_bag0.indexOf("单格上限") >= 0 && _bag0.indexOf("已用") >= 0) log37("显示空间占用与单格上限");
else { fail++; console.log("  [FAIL] 缺容器信息"); }
invAdd("herb", 600); invAdd("frag:qingyun", 12);
showInventory();
const _bag1 = el("modal").innerHTML;
if (_bag1.indexOf("灵草") >= 0 && _bag1.indexOf("袋中空空") < 0) log37("有物时显示持有物");
else { fail++; console.log("  [FAIL] 持有物未显示"); }
if ((_bag1.match(/bag-cell full/g) || []).length === 3) log37("600 灵草占 2 格 + 碎片 1 格");
else { fail++; console.log("  [FAIL] 占用格数不符：" + (_bag1.match(/bag-cell full/g) || []).length); }
showInventory("pill");
const _bag2 = el("modal").innerHTML;
if (_bag2.indexOf("bag-cell full dim") >= 0) log37("分类筛选非本类置暗");
else { fail++; console.log("  [FAIL] 分类筛选无效"); }
showInventory("all");
showItemDetail("herb");
const _det = el("modal").innerHTML;
if (_det.indexOf("灵草") >= 0 && _det.indexOf("出售 1") >= 0 && _det.indexOf("全部出售") >= 0 && _det.indexOf("丢弃 1") >= 0) log37("物品详情含使用/出售/丢弃");
else { fail++; console.log("  [FAIL] 物品详情缺操作"); }
if (_det.indexOf("undefined") < 0 && _det.indexOf("NaN") < 0) log37("物品详情无脏数据");
else { fail++; console.log("  [FAIL] 物品详情脏数据"); }
// 洞府储物法器卡
const _bd37 = viewBuild();
if (_bd37.indexOf("储物法器") >= 0 && _bd37.indexOf("布囊") >= 0 && _bd37.indexOf("打开储物袋") >= 0) log37("洞府显示储物法器卡");
else { fail++; console.log("  [FAIL] 洞府缺储物法器卡"); }
// 药园买种子入口
S.stone = 5000;
showGardenPanel();
const _gd37 = el("modal").innerHTML;
if (_gd37.indexOf("买 1 包") >= 0 && _gd37.indexOf("袋内种子") >= 0) log37("药园显示买种子与袋内种子");
else { fail++; console.log("  [FAIL] 药园缺种子入口"); }
S = defaultState(); S.realm = 5; S.stone = 5000; invAdd("seed:rare:lingcao", 1);
showModal(`<button data-action="gardenplant" data-i="0">种植</button>`);
showGardenPanel();
const _rareGardenUI = el("modal").innerHTML;
if (_rareGardenUI.indexOf("异种灵种") >= 0 && /data-rare=\"1\"/.test(fs.readFileSync(path.join(__dirname, "js/ui.js"), "utf8"))) log37("药园显示异种灵种库存与种植入口");
else { fail++; console.log("  [FAIL] 药园异种灵种入口缺失"); }
function log37(n) { console.log("  [PASS] " + n); }

// ===== v0.38.0：秘籍 / 丹药 / 装备物品化 =====
console.log("\n== v0.38.0 物品化 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者"; S.stone = 1e8;
invSet("material", 3000); S.buildings.forge = 6;
invEnsure();
const _random38 = Math.random;
Math.random = () => 0; // 固定炼器成功分支，避免冒烟测试偶发失败
const _fa38 = forgeArtifact(1);
Math.random = _random38;
showInventory();
const _bag38 = el("modal").innerHTML;
if (_bag38.indexOf("装备") >= 0 && _bag38.indexOf("秘籍") >= 0) log38("背包分类含装备与秘籍");
else { fail++; console.log("  [FAIL] 背包缺装备/秘籍分类"); }
if (_bag38.indexOf("bag-cell full gear") >= 0 && _bag38.indexOf("border-color") >= 0) log38("法宝格显示品质色边框");
else { fail++; console.log("  [FAIL] 法宝格无品质色"); }
showItemDetail("art:" + _fa38.artifact.id);
const _det38 = el("modal").innerHTML;
if (_det38.indexOf("装备") >= 0 && _det38.indexOf("分解") >= 0 && _det38.indexOf("inv") >= 0) log38("法宝详情含装备/分解");
else { fail++; console.log("  [FAIL] 法宝详情缺操作"); }
if (_det38.indexOf("undefined") < 0 && _det38.indexOf("NaN") < 0) log38("法宝详情无脏数据");
else { fail++; console.log("  [FAIL] 法宝详情脏数据"); }
invAdd("qiPill", 3);
showItemDetail("qiPill");
const _pillHit = el("modal").innerHTML;
if (_pillHit.indexOf("聚气丹") >= 0 && _pillHit.indexOf("使用 1 枚") >= 0) log38("丹药详情含使用入口");
else { fail++; console.log("  [FAIL] 丹药详情缺使用"); }
invAdd("book:tiangang", 1);
showItemDetail("book:tiangang");
const _bkHit = el("modal").innerHTML;
if (_bkHit.indexOf("《天罡培元功》") >= 0 && _bkHit.indexOf("秘籍") >= 0) log38("秘籍详情正确显示书名");
else { fail++; console.log("  [FAIL] 秘籍详情异常"); }
// 功法卡：秘籍持有 + 参悟/寻访入口
S.realm = 3; S.gongfaBooks.changsheng.lv = CONFIG.GONGFA_BOOKS.find(b => b.key === "changsheng").layers; invSet("talisman", 5);
const _char38 = viewChar();
if (_char38.indexOf("秘籍：") >= 0 && _char38.indexOf("参悟残卷") >= 0 && _char38.indexOf("寻访秘籍") >= 0) log38("功法卡含秘籍数与参悟/寻访");
else { fail++; console.log("  [FAIL] 功法卡缺秘籍入口"); }
if (_char38.indexOf("undefined") < 0 && _char38.indexOf("NaN") < 0) log38("人物页无脏数据");
else { fail++; console.log("  [FAIL] 人物页脏数据"); }
function log38(n) { console.log("  [PASS] " + n); }

// ===== v0.39.0：丹房 · 丹方配伍 =====
console.log("\n== v0.39.0 丹房 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者"; S.realm = 3;
S.buildings.alchemy = 4; invSet("herb", 900); invSet("material", 200); invEnsure();
const _bd39 = viewBuild();
if (_bd39.indexOf("开炉炼丹") >= 0) log39("洞府炼丹房含开炉入口");
else { fail++; console.log("  [FAIL] 洞府缺开炉入口"); }
showDanPanel();
const _dn39 = el("modal").innerHTML;
if (_dn39.indexOf("丹房") >= 0 && _dn39.indexOf("炉空闲") >= 0 && _dn39.indexOf("成功率") >= 0) log39("丹房面板含炉位与成功率");
else { fail++; console.log("  [FAIL] 丹房面板异常"); }
if (_dn39.indexOf("培元丹方") >= 0 && _dn39.indexOf("开炉") >= 0 && _dn39.indexOf("火候") >= 0) log39("丹方列表含名称/材料/火候");
else { fail++; console.log("  [FAIL] 丹方列表缺失"); }
if (_dn39.indexOf("undefined") < 0 && _dn39.indexOf("NaN") < 0) log39("丹房无脏数据");
else { fail++; console.log("  [FAIL] 丹房脏数据"); }
const _st39 = danStart("recipe_pill");
showDanPanel();
const _dn39b = el("modal").innerHTML;
if (_st39.ok && _dn39b.indexOf("dan-bar") >= 0 && _dn39b.indexOf("撤炉") >= 0) log39("开炉后显示火候进度条与撤炉");
else { fail++; console.log("  [FAIL] 开炉状态渲染异常"); }
danState().slots.forEach(sl => { if (sl) sl.startAt = Date.now() - sl.dur - 1000; });
showDanPanel();
const _dn39c = el("modal").innerHTML;
if (_dn39c.indexOf("收丹") >= 0 && _dn39c.indexOf("丹成出炉") >= 0) log39("到期显示收丹按钮");
else { fail++; console.log("  [FAIL] 收丹入口缺失"); }
danAbort();
// 未建炼丹房时的空态
S = defaultState(); S.playerName = "测试者"; S.buildings.alchemy = 0;
showDanPanel();
const _dn39d = el("modal").innerHTML;
if (_dn39d.indexOf("尚无炼丹房") >= 0) log39("未建炼丹房给出明确提示");
else { fail++; console.log("  [FAIL] 空态提示缺失"); }
function log39(n) { console.log("  [PASS] " + n); }

// ===== v0.40.0：章节特产入袋 / 秘方特产门槛 =====
console.log("\n== v0.40.0 特产入袋 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者"; S.stone = 1e7;
S.clearedMaps = { 1: true }; S.realm = 6; S.buildings.alchemy = 7;
invSet("herb", 1200); invSet("material", 200); invSet("sp:6", 0); invEnsure();
specialtyDrop(1, "boss");
showInventory();
const _inv40 = el("modal").innerHTML;
if (_inv40.indexOf(CONFIG.FIELD_SPECIALTIES[1]) >= 0 && _inv40.indexOf("特") >= 0) log40("特产在背包中可见");
else { fail++; console.log("  [FAIL] 背包缺特产"); }
showDanPanel();
const _dan40 = el("modal").innerHTML;
if (_dan40.indexOf(CONFIG.FIELD_SPECIALTIES[6]) >= 0) log40("悟道丹方显示混元露门槛");
else { fail++; console.log("  [FAIL] 丹方缺特产需求"); }
if (_dan40.indexOf("undefined") < 0 && _dan40.indexOf("NaN") < 0) log40("丹房无脏数据");
else { fail++; console.log("  [FAIL] 丹房脏数据"); }
const _w40 = viewWorld();
if (_w40.indexOf("undefined") < 0 && _w40.indexOf("NaN") < 0) log40("世界页无脏数据");
else { fail++; console.log("  [FAIL] 世界页脏数据"); }
function log40(n) { console.log("  [PASS] " + n); }

// ===== v0.41.0：法宝套装 =====
console.log("\n== v0.41.0 法宝套装 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者"; S.realm = 8; invEnsure();
S.artifacts = [
  { id: 1, name: "测器一", tier: 3, type: "attack", atk: 0.01, def: 0, hp: 0, cult: 0, roll: 1, affixes: [], setKey: "qingyun_gear" },
  { id: 2, name: "测器二", tier: 3, type: "defense", atk: 0, def: 0.01, hp: 0, cult: 0, roll: 1, affixes: [], setKey: "qingyun_gear" },
];
equipArtifact(1); equipArtifact(2);
const _ch41 = viewBuild();
if (_ch41.indexOf("法宝套装") >= 0 && _ch41.indexOf(CONFIG.ARTIFACT_SETS[0].name) >= 0 && _ch41.indexOf("2/3") >= 0) log41("洞府显示套装进度");
else { fail++; console.log("  [FAIL] 洞府缺套装段"); }
if (_ch41.indexOf("套·") >= 0) log41("法宝行标注套装来源");
else { fail++; console.log("  [FAIL] 法宝行缺套装标记"); }
if (_ch41.indexOf("undefined") < 0 && _ch41.indexOf("NaN") < 0) log41("法宝区无脏数据");
else { fail++; console.log("  [FAIL] 法宝区脏数据"); }
function log41(n) { console.log("  [PASS] " + n); }

// ===== v0.42.0：多炉位与加料档位 =====
console.log("\n== v0.42.0 多炉位 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者"; S.realm = 5;
S.buildings.alchemy = 6; invSet("herb", 2000); invSet("material", 400); invEnsure();
if (danSlotCount() === 3) console.log("  [PASS] 炉位数随炉火增长");
else { fail++; console.log("  [FAIL] 炉位数异常"); }
showDanPanel();
const _dan42 = el("modal").innerHTML;
if (_dan42.indexOf("第 1 炉空闲") >= 0 && _dan42.indexOf("第 3 炉空闲") >= 0) log42("三炉位并列显示");
else { fail++; console.log("  [FAIL] 多炉位显示异常"); }
showDanPick("recipe_pill");
const _pick42 = el("modal").innerHTML;
if (_pick42.indexOf("标准") >= 0 && _pick42.indexOf("双料") >= 0 && _pick42.indexOf("精料") >= 0 && _pick42.indexOf("上品率") >= 0) log42("选料弹窗含三档与上品率");
else { fail++; console.log("  [FAIL] 选料弹窗缺失"); }
danStart("recipe_pill", 2);
danStart("recipe_qi", 1);
showDanPanel();
const _dan42b = el("modal").innerHTML;
if ((_dan42b.match(/dan-furnace/g) || []).length >= 2 && _dan42b.indexOf("撤炉") >= 0) log42("并行两炉显示");
else { fail++; console.log("  [FAIL] 并行炉渲染异常"); }
if (_dan42b.indexOf("undefined") < 0 && _dan42b.indexOf("NaN") < 0) log42("丹房无脏数据");
else { fail++; console.log("  [FAIL] 丹房脏数据"); }
danState().slots.forEach((sl, i) => { if (sl) danAbort(i); });
function log42(n) { console.log("  [PASS] " + n); }

// ===== v0.43.0：药园品质 =====
console.log("\n== v0.43.0 药园品质 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者"; S.realm = 5;
S.stone = 1e7; invSet("material", 100); invEnsure();
buySeed("lingcao", 2); gardenPlant(0, "lingcao");
showGardenPanel();
const _gd43 = el("modal").innerHTML;
if (_gd43.indexOf("施肥") >= 0 && _gd43.indexOf("变异") >= 0) log43("药园面板含施肥与变异说明");
else { fail++; console.log("  [FAIL] 药园缺施肥/变异文案"); }
if (_gd43.indexOf("九叶灵芝") >= 0) log43("稀有作物出现在种子列表");
else { fail++; console.log("  [FAIL] 稀有作物缺失"); }
showGardenPlot(0);
const _gp43 = el("modal").innerHTML;
if (_gp43.indexOf("施肥") >= 0 && _gp43.indexOf("浇水") >= 0) log43("地块弹窗含浇水/施肥");
else { fail++; console.log("  [FAIL] 地块弹窗缺操作"); }
if (_gp43.indexOf("undefined") < 0 && _gp43.indexOf("NaN") < 0) log43("地块弹窗无脏数据");
else { fail++; console.log("  [FAIL] 地块弹窗脏数据"); }
function log43(n) { console.log("  [PASS] " + n); }

// ===== v0.44.0：化身职能 =====
console.log("\n== v0.44.0 化身职能 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者"; S.realm = 4;
S.stone = 1e7; S.buildings.alchemy = 3; invSet("herb", 3000); invSet("material", 300);
S.clearedMaps = { 0: true }; invEnsure();
avatarUnlock();
showAvatarPanel();
const _av44 = el("modal").innerHTML;
if (_av44.indexOf("秘境挂机") >= 0 && _av44.indexOf("代炼丹") >= 0 && _av44.indexOf("代采药") >= 0) log44("化身面板含三职能");
else { fail++; console.log("  [FAIL] 化身职能入口缺失"); }
avatarSetDuty("dan");
avatarBodyState().lastClaim = Date.now() - 3600 * 1000;
showAvatarPanel();
const _av44b = el("modal").innerHTML;
if (_av44b.indexOf("培元丹") >= 0 && _av44b.indexOf("耗灵草") >= 0) log44("代炼丹显示耗料与产出");
else { fail++; console.log("  [FAIL] 代炼丹展示异常"); }
if (_av44b.indexOf("undefined") < 0 && _av44b.indexOf("NaN") < 0) log44("化身面板无脏数据");
else { fail++; console.log("  [FAIL] 化身面板脏数据"); }
avatarClaim();
function log44(n) { console.log("  [PASS] " + n); }

// ===== v0.45.0：仙友交游 =====
console.log("\n== v0.45.0 仙友交游 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者"; S.realm = 2; S.stone = 1e6; S.qi = 1e6;
S.gameTime = { year: 1, month: 1, day: 30, dayTick: 0 };
ensureFriends();
S.friends[0].rel = 60;
S.friends[0].lover = true;
showFriendPanel();
const _fr45 = el("modal").innerHTML;
if (_fr45.indexOf("交游") >= 0 && _fr45.indexOf("请援") >= 0) log45("仙友面板含交游与请援");
else { fail++; console.log("  [FAIL] 仙友面板缺交游/请援"); }
if (_fr45.indexOf("道侣机缘") >= 0 && _fr45.indexOf("有新交游") >= 0) log45("面板含道侣机缘与交游提示");
else { fail++; console.log("  [FAIL] 缺道侣机缘/交游提示"); }
if (_fr45.indexOf("undefined") < 0 && _fr45.indexOf("NaN") < 0) log45("仙友面板无脏数据");
else { fail++; console.log("  [FAIL] 仙友面板脏数据"); }
function log45(n) { console.log("  [PASS] " + n); }

// ===== v0.46.0：五行相生连携 =====
console.log("\n== v0.46.0 五行相生 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者"; S.realm = 6; S.bestStage = 12;
invEnsure();
const _f46 = fldCreate(0);
_f46.player.mana = 9999;
_f46.lastElem = "wood"; _f46.lastElemAt = Date.now();
fsRenderSkills && (function () { try { fsRenderSkills(); } catch (e) {} })();
if (CONFIG.FIELD_SKILLS.every(x => !!x.element)) log46("全部神通带五行属性");
else { fail++; console.log("  [FAIL] 神通缺五行"); }
// 相生事件进入渲染层
const _ev46 = { type: "elem_gen", from: "wood", to: "fire", mult: 0.2 };
flvOnEvent(_ev46);
if (FLDV.floaters && FLDV.floaters.some(x => String(x.text).indexOf("木生火") >= 0)) log46("相生浮动提示进入渲染层");
else { fail++; console.log("  [FAIL] 相生提示缺失"); }
// 相生结算
_f46.cds["huo_hai"] = 0;
const _c46 = fldCast(_f46, "huo_hai", 0, -1);
if (_c46.ok === true && _c46.gen === true) log46("相生连携结算生效");
else { fail++; console.log("  [FAIL] 相生结算未生效"); }
function log46(n) { console.log("  [PASS] " + n); }

// ===== v0.47.0：引路卡 + 离线面板 =====
console.log("\n== v0.47.0 引路与离线 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者"; invEnsure();
const _home47 = viewHome();
if (_home47.indexOf("引路 · 第 1/7 步") >= 0 && _home47.indexOf("吐纳养气") >= 0 && _home47.indexOf("去做") >= 0) log47("修炼页显示引路卡");
else { fail++; console.log("  [FAIL] 引路卡缺失"); }
S.guide.done = CONFIG.GUIDE.map(g => g.key); S.guide.step = 7;
const _home47b = viewHome();
if (_home47b.indexOf("七步引路已走完") >= 0) log47("七步走完显示收束文案");
else { fail++; console.log("  [FAIL] 引路完成态异常"); }
if (_home47.indexOf("undefined") < 0 && _home47.indexOf("NaN") < 0) log47("修炼页无脏数据");
else { fail++; console.log("  [FAIL] 修炼页脏数据"); }
function log47(n) { console.log("  [PASS] " + n); }

// ===== v0.48.0：视图重构（页头/分区/宫格/红点/统一关闭） =====
console.log("\n== v0.48.0 视图重构 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者"; S.stone = 1e6;
S.stamina = 10; invEnsure();
const _h48 = viewHome();
if (_h48.indexOf("page-head") >= 0 && _h48.indexOf("quick-grid") < 0 && _h48.indexOf("吐纳") >= 0) log48("修炼页含页头与吐纳，无重复宫格");
else { fail++; console.log("  [FAIL] 修炼页框架缺失"); }
const _b48 = viewBuild();
if (_b48.indexOf("page-head") >= 0 && _b48.indexOf("sec-head") >= 0 && _b48.indexOf("洞府建筑") >= 0 && _b48.indexOf("生活 · 药园化身仙友") >= 0) log48("洞府页按建筑/生活/宗门/法宝分区");
else { fail++; console.log("  [FAIL] 洞府页分区缺失"); }
const _c48 = viewChar();
if (_c48.indexOf("道体") >= 0 && _c48.indexOf("道途与功法") >= 0 && _c48.indexOf("收藏与灵兽") >= 0) log48("人物页分区清晰");
else { fail++; console.log("  [FAIL] 人物页分区缺失"); }
const _w48 = viewWorld();
if (_w48.indexOf("坊市与天机") >= 0 && _w48.indexOf("势力与据点") >= 0) log48("世界页分区清晰");
else { fail++; console.log("  [FAIL] 世界页分区缺失"); }
const _badges = tabBadges();
if (typeof _badges === "object" && _badges.battle === true) log48("红点判定：有体力则历练亮");
else { fail++; console.log("  [FAIL] 红点判定异常"); }
showModal("<div>测试</div>");
const _m48 = el("modal").innerHTML;
if (_m48.indexOf("modal-x") >= 0 && _m48.indexOf("data-close") >= 0) log48("弹窗统一关闭按钮与遮罩关闭");
else { fail++; console.log("  [FAIL] 弹窗缺统一出口"); }
closeModal();
if (_h48.indexOf("undefined") < 0 && _h48.indexOf("NaN") < 0 && _b48.indexOf("undefined") < 0) log48("重构后无脏数据");
else { fail++; console.log("  [FAIL] 重构后出现脏数据"); }
function log48(n) { console.log("  [PASS] " + n); }
// ===== v0.50.0：内视（人物简图 / 经脉 / 丹田）+ 炼器坊整合 =====
console.log("\n== v0.50.0 内视与炼器坊 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者";
S.stone = 1e6; S.materials = 500; S.realm = 2; invEnsure();
const _h50 = viewHome();
if (_h50.indexOf("mi-svg") >= 0 && _h50.indexOf("内视") >= 0) log48("修炼页含人物简图");
else { fail++; console.log("  [FAIL] 修炼页缺人物简图"); }
if (_h50.indexOf('data-action="innerview"') >= 0) log48("人物简图可点进内视");
else { fail++; console.log("  [FAIL] 简图无内视入口"); }
check("修炼页（含内视简图）", _h50);
showInnerView();
const _iv50 = el("modal").innerHTML;
if (_iv50.indexOf("任脉") >= 0 && _iv50.indexOf("督脉") >= 0 && _iv50.indexOf("冲脉") >= 0 && _iv50.indexOf("丹田") >= 0) log48("内视面板含三脉与丹田");
else { fail++; console.log("  [FAIL] 内视面板内容缺失"); }
if (_iv50.indexOf('data-action="meridianopen"') >= 0 && _iv50.indexOf('data-action="dantianraise"') >= 0) log48("内视面板可点穴与升丹");
else { fail++; console.log("  [FAIL] 内视面板缺操作按钮"); }
check("内视面板", _iv50);
S.ancient = { qf_sword: { star: 1, infuse: 0 } };
showCraftPanel();
const _cp50 = el("modal").innerHTML;
if (_cp50.indexOf("炼器坊") >= 0 && _cp50.indexOf("古宝升星") >= 0 && _cp50.indexOf("古宝注灵") >= 0) log48("炼器坊含炼制/升星/注灵三区");
else { fail++; console.log("  [FAIL] 炼器坊分区缺失"); }
if (_cp50.indexOf('data-action="ancstar"') >= 0 && _cp50.indexOf('data-action="ancinfuse"') >= 0) log48("升星与注灵在炼器坊可操作");
else { fail++; console.log("  [FAIL] 炼器坊缺升星或注灵按钮"); }
check("炼器坊面板", _cp50);
showAncientSetDetail("qingyun");
const _sd50 = el("modal").innerHTML;
if (_sd50.indexOf('data-action="ancstar"') < 0 && _sd50.indexOf('data-action="craft"') >= 0) log48("古宝详情只读并导航炼器坊");
else { fail++; console.log("  [FAIL] 古宝详情仍在做器物养成"); }
check("古宝套装详情", _sd50);
const _b50 = viewBuild();
if (_b50.indexOf('data-action="craft"') >= 0) log48("洞府炼器坊卡打开炼器坊面板");
else { fail++; console.log("  [FAIL] 洞府缺炼器坊入口"); }


// ===== v0.51.0：开穴反馈 + 驻守收益明细与结算单 =====
console.log("\n== v0.51.0 内视反馈与驻守结算 ==");
S = defaultState(); S.lastOnline = Date.now(); S.playerName = "测试者";
S.stone = 1e6; S.realm = 2; invEnsure(); invSet("material", 500);
const _b51 = meridianSum();
S.meridian = { ren: 1, du: 0, chong: 0 };
const _a51 = meridianSum();
showInnerView({ flash: { key: "ren", idx: 0 }, delta: { before: _b51, after: _a51, label: "任脉「会阴」打通", note: "第 1 穴" } });
const _iv51 = el("modal").innerHTML;
if (_iv51.indexOf("mi-burst") >= 0) log48("开穴后穴位有扩散光环");
else { fail++; console.log("  [FAIL] 开穴无视觉反馈"); }
if (_iv51.indexOf("inner-delta") >= 0 && _iv51.indexOf("任脉「会阴」打通") >= 0) log48("内视面板显示本次开穴增量");
else { fail++; console.log("  [FAIL] 面板缺开穴增量条"); }
check("内视开穴反馈", _iv51);
const _home51 = viewHome();
if (_home51.indexOf("inner-open-dot") >= 0 && _home51.indexOf("可打通") >= 0) log48("付得起时修炼页提示可开穴");
else { fail++; console.log("  [FAIL] 可开穴无提示"); }

// 驻守面板：明细 + 结算
S = defaultState(); S.playerName = "测试者"; S.realm = 2;
S.stone = 1e5; S.clearedMaps = { 0: true }; invEnsure();
S.disciples = [{ id: 1, name: "甲", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
dispatchTick(70);
showDispatchModal(0);
const _dm51 = el("modal").innerHTML;
if (_dm51.indexOf("收益明细") >= 0 && _dm51.indexOf("ds-chain") >= 0) log48("驻守面板含倍率链与弟子贡献");
else { fail++; console.log("  [FAIL] 驻守面板缺收益明细"); }
if (_dm51.indexOf('data-action="dispatchsettle"') >= 0) log48("满时长可出结算单");
else { fail++; console.log("  [FAIL] 结算入口缺失"); }
check("驻守面板", _dm51);
const _rs51 = dispatchSettle(0);
showSettleModal(0, _rs51);
const _sm51 = el("modal").innerHTML;
if (_sm51.indexOf("set-row") >= 0 && _sm51.indexOf("驻守时长") >= 0) log48("结算单展示账目明细");
else { fail++; console.log("  [FAIL] 结算单内容缺失"); }
check("驻守结算单", _sm51);
const _bm51 = viewFieldMaps();
if (_bm51.indexOf("undefined") < 0 && _bm51.indexOf("NaN") < 0) log48("历练页驻守行无脏数据");
else { fail++; console.log("  [FAIL] 历练页驻守行出现脏数据"); }

// v0.51.1：招募入口冲突与候选池重绘回归
S = defaultState(); S.playerName = "测试者"; S.realm = 2; S.stone = 1e5; S.folk = 10;
S.clearedMaps = { 0: true };
S.disciples = [{ id: 1, name: "驻守弟子", realm: 1, layer: 0, loyalty: 80, mood: 80, aptitude: 1, specialty: "farm", bond: 0, assignedTo: null, cultivation: 0 }];
assignDispatch(0, 1);
const _pool511 = recruitCandidates(0);
const _poolRef511 = S.recruitPool;
showRecruitCandidates(0);
if (S.recruitPool === _poolRef511) log48("打开候选页不重抽候选池");
else { fail++; console.log("  [FAIL] 打开候选页意外重抽候选池"); }
const _left511 = S.recruitPool.list.length;
const _hire511 = hireCandidate(0);
showRecruitCandidates(0);
if (_hire511.ok && S.recruitPool === _poolRef511 && S.recruitPool.list.length === _left511 - 1) log48("录用后保留剩余候选");
else { fail++; console.log("  [FAIL] 录用后候选池被重置"); }
const _uiSrc511 = fs.readFileSync(path.join(__dirname, "js/ui.js"), "utf8");
const _recruitCases511 = (_uiSrc511.match(/case "recruit"\s*:/g) || []).length;
if (_recruitCases511 === 1 && /case "recruit": showRecruitModal\(\); break;/.test(_uiSrc511)) log48("开山收徒按钮唯一指向秘境选拔流程");
else { fail++; console.log("  [FAIL] recruit action 存在重复分发或错误路由"); }
const _modalSrc511 = fs.readFileSync(path.join(__dirname, "css/style.css"), "utf8");
if (_modalSrc511.includes("max-height: calc(100dvh - 16px)") && _modalSrc511.includes(".modal-box-wide")) log48("长弹窗视口高度与宽屏适配规则存在");
else { fail++; console.log("  [FAIL] 弹窗视口适配规则缺失"); }

const _ui52 = fs.readFileSync(path.join(__dirname, "js/ui.js"), "utf8");
if (/data-action="settings"/.test(viewChar())) log48("人物页含设置入口"); else { fail++; console.log("  [FAIL] 人物页缺少设置入口"); }
if (_ui52.includes('data-setting="combatSpeed"') && _ui52.includes('function updateSetting')) log48("设置项有持久化更新逻辑"); else { fail++; console.log("  [FAIL] 设置项逻辑缺失"); }
const _breath52 = fs.readFileSync(path.join(__dirname, "js/breath.js"), "utf8");
if (_breath52.includes("function startFieldBattle(chapter)") && _breath52.includes("function breathTick()")) log48("气息战斗 v2 引擎与秘境入口存在"); else { fail++; console.log("  [FAIL] 气息战斗 v2 引擎缺失"); }
const _css52 = fs.readFileSync(path.join(__dirname, "css/style.css"), "utf8");
if (_css52.includes("@media (max-width:380px)") && _css52.includes("@media (min-width:760px)")) log48("气息战界面包含窄屏与桌面断点适配"); else { fail++; console.log("  [FAIL] 气息战界面缺少响应式断点"); }


// v0.53.2：新增功法术式池后的槽位顺序与重复项归一化
S = defaultState(); S.realm = 4; S.gongfaBooks = {};
S.gongfaBooks.changsheng = { lv: 3, learned: true };
S.gongfaBooks.chiyang = { lv: 1, learned: true };
S.gongfaEquip = { xin: "changsheng", shu: "chiyang", shen: null, dao: null };
S.fieldSlots = ["huo_hai", "lingxi_zhang", "huo_hai", "jian_qi"];
const _slots532 = artSlotList();
if (_slots532.indexOf("huo_hai") === 0 && _slots532.indexOf("lingxi_zhang") === 1 && new Set(_slots532).size === _slots532.length) log48("技能盘去重并保留玩家原有顺序");
else { fail++; console.log("  [FAIL] 技能盘重复项未归一化或顺序被破坏"); }
if (S.fieldSlots.length === 3 && new Set(S.fieldSlots).size === S.fieldSlots.length && S.fieldSlots[0] === "huo_hai") log48("技能盘旧存档重复项已归一化");
else { fail++; console.log("  [FAIL] 技能盘旧存档重复项未归一化"); }
const _artset532 = fs.readFileSync(path.join(__dirname, "js/ui.js"), "utf8");
if (_artset532.includes("const allowed = fldUnlockedSkills(S.realm).some(x => x.key === key)") && _artset532.includes("const duplicate = slots.some((x, idx) => x === key && idx !== i)")) log48("技能替换入口二次校验未解锁与重复技能");
else { fail++; console.log("  [FAIL] 技能替换入口缺少二次校验"); }
// v0.53.3：法宝主动术式独立第五格，不占用境界术式槽。
const _fabaoSlotSrc = fs.readFileSync(path.join(__dirname, "js/ui.js"), "utf8");
const _fabaoBattleSrc = fs.readFileSync(path.join(__dirname, "js/breath.js"), "utf8");
if (_fabaoSlotSrc.includes('data-action="fabaoSkillPick"') && _fabaoSlotSrc.includes('case "fabaoSkillSet"') && _fabaoSlotSrc.includes("equippedFabaoSkills().some(x => x.key === key)")) log48("法宝技独立第五格具备选择与装备校验");
else { fail++; console.log("  [FAIL] 法宝技独立第五格入口或校验缺失"); }
if (_fabaoBattleSrc.includes("function breathConfiguredSlots()") && _fabaoBattleSrc.includes("slots.push(fabao.key)")) log48("法宝技进入独立战斗循环且不占普通槽容量");
else { fail++; console.log("  [FAIL] 法宝技未接入独立战斗循环"); }

// v0.54.0：P1 引魔香与长时挂机 UI
S = defaultState(); S.playerName = "测试者"; S.fate = 10; invEnsure(); gainItem("incense", 1);
showItemDetail("incense");
const _incDetail540 = el("modal").innerHTML;
if (_incDetail540.includes("引魔香") && _incDetail540.includes('data-action="invuse"')) log48("引魔香物品详情提供使用入口");
else { fail++; console.log("  [FAIL] 引魔香物品缺少使用入口"); }
S.huntingIncense = 1; showDailyPanel();
const _daily540 = el("modal").innerHTML;
if (_daily540.includes('data-action="fateincense"') && _daily540.includes("引魔香已点燃")) log48("天机阁展示引魔香兑换与点燃状态");
else { fail++; console.log("  [FAIL] 天机阁引魔香入口或状态缺失"); }
S = defaultState(); showAvatarPanel();
const _avatar540 = el("modal").innerHTML;
if (_avatar540.includes("离线累积上限 25 小时")) log48("化身解锁提示显示25小时累积上限");
else { fail++; console.log("  [FAIL] 化身挂机时长提示未同步"); }
const _offlineSummary541 = fs.readFileSync(path.join(__dirname, "js/main.js"), "utf8");
if (_offlineSummary541.includes("d.dispatchQi") && _offlineSummary541.includes("d.herbNet")) log48("离线结算摘要显示驻守灵气与灵草净变化");
else { fail++; console.log("  [FAIL] 离线结算摘要未体现驻守灵气或灵草净额"); }

// v0.54.2：开局五弟子、成长培养与本地聚落 UI
S = defaultState(); S.playerName = "v542界面测试";
S.disciples = Array.from({ length: 5 }, (_, i) => ({ id: i + 1, name: i ? `弟子${i}` : "守山童子", aptitude: 1, realm: 0, layer: 0, loyalty: 100, mood: 90, assignedTo: null, cultivation: 12, specialty: "farm", bond: 0, origin: "开山赠礼" }));
S.clearedMaps = { 0: true }; S.mapTeam = { 0: [1] }; addFolk(8, 0);
const _build542 = viewBuild();
if (_build542.includes("开局赠送 5 名") && _build542.includes("灵气×1") && _build542.includes("培元丹培养") && _build542.includes("修为 12/50")) log48("洞府显示五人开局、弟子修为与两种培养入口");
else { fail++; console.log("  [FAIL] 弟子成长/培养 UI 缺项"); }
showDispatchModal(0);
const _settlement542 = el("modal").innerHTML;
if (_settlement542.includes("凡人聚集地") && _settlement542.includes("本地人口 8/30") && _settlement542.includes("全境人口")) log48("秘境驻守弹窗显示本地聚落人口与全境总人口");
else { fail++; console.log("  [FAIL] 本地凡人聚落 UI 缺项"); }
S.missions = [{ id: 1, type: "clear", discipleId: 1, status: "done", success: true, growthGained: 12, levelsGained: 0, endAt: Date.now() }];
showMissionPanel();
if (el("modal").innerHTML.includes("历练 +12")) log48("弟子任务面板显示最近结算历练成长");
else { fail++; console.log("  [FAIL] 弟子任务成长结算 UI 缺项"); }

// v0.54.3：境界货架与自动刷新提示
const _market543 = viewWorld();
if (_market543.includes("境界货架") && _market543.includes("每2小时自动换货") && _market543.includes('data-action="buymarketshelf"')) log48("坊市展示境界随机货架、刷新周期与购买入口");
else { fail++; console.log("  [FAIL] 境界货架 UI 缺项"); }

console.log("\n===== UI 冒烟：" + (fail === 0 ? "全部通过" : fail + " 项失败") + " =====");
process.exit(fail === 0 ? 0 : 1);

