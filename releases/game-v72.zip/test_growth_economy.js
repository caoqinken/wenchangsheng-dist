// v0.54.8 成长效率投资与离线资源效率专项回归
const fs=require('fs'),path=require('path'),cp=require('child_process');
const out=cp.execFileSync(process.execPath,[path.join(__dirname,'audit_growth_economy.js')],{encoding:'utf8'});
const report=path.join(__dirname,'..','docs','v0.54.8_P1_成长效率投资与离线资源效率.md');
let pass=0,fail=0;function a(n,v){if(v){pass++;console.log('[PASS] '+n)}else{fail++;console.log('[FAIL] '+n)}}
a('覆盖99层修炼需求',out.includes('99层基础突破灵气需求'));
a('覆盖练功房多档等级',out.includes('| 0 |')&&out.includes('| 10 |'));
a('练功房累计成本公式明确',out.includes('50×2^level'));
a('练功房线性7%倍率明确',out.includes('1 + 7% × 等级'));
a('普通离线驻守25%口径明确',out.includes('实际是在线速率的 **25%**'));
a('引魔香离线驻守37.5%口径明确',out.includes('37.5%'));
a('不修改存档与玩法',out.includes('SAVE_VERSION` 保持17')&&out.includes('不修改经济倍率、成本、玩法或存档'));
a('报告已生成',fs.existsSync(report)&&fs.statSync(report).size>3000);
console.log(`结果：${pass} 通过，${fail} 失败`);if(fail)process.exit(1);
