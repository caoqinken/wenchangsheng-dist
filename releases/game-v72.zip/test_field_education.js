// v0.56.0 秘境教化/私有化专项回归。
const fs = require("fs"), path = require("path"), vm = require("vm");
const store = {};
global.localStorage = { getItem:k => (k in store ? store[k] : null), setItem:(k,v) => { store[k] = String(v); }, removeItem:k => { delete store[k]; } };
global.window = { addEventListener:() => {} };
const els = {};
const stubEl = () => ({ textContent:"", innerHTML:"", style:{}, classList:{ add(){}, remove(){}, toggle(){} }, dataset:{} });
global.document = { hidden:false, getElementById:id => (els[id] = els[id] || stubEl()), querySelectorAll:() => [], body:{ addEventListener:() => {} } };
global.confirm = () => true; global.location = { reload:() => {} };
function load(f) { vm.runInThisContext(fs.readFileSync(path.join(__dirname, f), "utf8"), { filename:f }); }
[
 "js/config.js","js/state.js","js/gongfa.js","js/avatar.js","js/pet.js","js/artifact.js","js/idle.js","js/combat.js","js/tower.js","js/build.js","js/dan.js","js/guide.js","js/time.js","js/faction.js","js/event.js","js/npc.js","js/economy.js","js/codex.js","js/field.js","js/dispatch.js","js/field_view.js","js/dao.js","js/tuna.js","js/daily.js","js/specialty.js","js/ancient.js","js/meridians.js","js/realm.js","js/recruit.js","js/staff.js","js/field_education.js","js/sect.js","js/element.js","js/life.js","js/ui.js","js/inventory.js"
].forEach(load);
let pass=0, fail=0;
function a(n,v){ if(v){pass++;console.log("[PASS] "+n);}else{fail++;console.log("[FAIL] "+n);} }
S=defaultState(); S.clearedMaps={0:true}; S.disciples=[]; S.mapTeam={0:[]};
for(let i=1;i<=8;i++) S.disciples.push({id:i,name:"弟子"+i,realm:0,layer:0,loyalty:80,aptitude:1,specialty:"none",bond:0,assignedTo:null});
for(let i=1;i<=8;i++) a("同一秘境可继续增加第"+i+"名驻守弟子",assignDispatch(0,i).ok);
a("驻守人数不再存在秘境硬上限",dispatchTeam(0).length===8 && CONFIG.DISPATCH.MAX_TEAM===undefined);
S.fieldEducation={0:{progress:0,private:false,totalGuardSec:0}}; S.mapTeam[0]=[1];
fieldEducationTickOne(0,3600,1);
const one=fieldEducationOf(0).progress;
a("一名驻守弟子推进教化",one>0);
S.fieldEducation[0]={progress:0,private:false,totalGuardSec:0};
fieldEducationTickOne(0,3600,0.25);
a("离线教化复用25%普通离线驻守效率",Math.abs(fieldEducationOf(0).progress-(CONFIG.FIELD_EDUCATION.BASE_RATE*0.25-CONFIG.FIELD_EDUCATION.PRESSURE_RATE)*3600)<1e-9);
S.mapTeam[0]=[1,2,3]; S.fieldEducation[0]={progress:0,private:false,totalGuardSec:0};
fieldEducationTickOne(0,3600,1);
const three=fieldEducationOf(0).progress;
a("多弟子教化叠加且第2/3人边际递减",Math.abs(one-(CONFIG.FIELD_EDUCATION.BASE_RATE-CONFIG.FIELD_EDUCATION.PRESSURE_RATE)*3600)<1e-8 && Math.abs(three-(CONFIG.FIELD_EDUCATION.BASE_RATE*2.15-CONFIG.FIELD_EDUCATION.PRESSURE_RATE)*3600)<1e-8);
S.fieldEducation[0]={progress:0.5,private:false,totalGuardSec:0}; S.mapTeam[0]=[];
fieldEducationTickOne(0,86400,1);
a("无人驻守时教化缓慢侵蚀而非清零",fieldEducationOf(0).progress<0.5 && fieldEducationOf(0).progress>0.48);
S.fieldEducation[0]={progress:0.99,private:false,totalGuardSec:0}; S.mapTeam[0]=[1];
fieldEducationTickOne(0,10000,1);
a("达到100%后自动私有化",fieldEducationOf(0).private && fieldEducationOf(0).progress===1);
const p=fieldEducationOf(0).progress; S.mapTeam[0]=[]; fieldEducationTickOne(0,86400,1);
a("私有化后不再被侵蚀",fieldEducationOf(0).progress===p);
S.fieldEducation[0]={progress:0.2,private:false,totalGuardSec:0};
fieldEducationAdd(0,CONFIG.FIELD_EDUCATION.PREACH_BONUS,"传道任务测试");
a("传道四方奖励直接增加5%教化",Math.abs(fieldEducationOf(0).progress-0.25)<1e-9);
S.fieldEducation[0]={progress:0.3,private:false,totalGuardSec:0};
S.missions=[{id:99,type:"preach",ch:0,discipleId:1,status:"run",endAt:Date.now()-1,successRate:1}];
const oldMissionRandom=Math.random; Math.random=()=>0; missionsTick(); Math.random=oldMissionRandom;
a("成功完成传道四方任务自动增加教化",Math.abs(fieldEducationOf(0).progress-0.35)<1e-9);
const migrated=migrateState({version:17,clearedMaps:{0:true},mapTeam:{0:[1]},disciples:[]});
a("旧存档迁移补齐教化字段",migrated.fieldEducation && typeof migrated.fieldEducation==="object");
const malformedPrivate=migrateState({version:17,fieldEducation:{0:{progress:0.4,private:true}},disciples:[]});
a("私有化旧数据统一修正为100%教化",malformedPrivate.fieldEducation[0].progress===1);
// 势力侵扰不得再把整处秘境夺走或清空弟子队伍。
S.fieldEducation[0]={progress:0.4,private:false,totalGuardSec:0}; S.mapTeam[0]=[1]; S.factions.moyuan.relation=-10;
const oldRandom=Math.random; Math.random=()=>0;
conflictDaily(); Math.random=oldRandom;
a("势力窥伺只侵蚀教化，不再夺取秘境/清空队伍",!S.lostFields[0] && S.mapTeam[0].length===1 && fieldEducationOf(0).progress<0.4);
showDispatchModal(0);
a("驻守面板展示教化进度和私有化规则",els.modal.innerHTML.includes("秘境教化") && els.modal.innerHTML.includes("传道四方"));
const mapHtml=viewFieldMaps();
a("秘境列表展示教化状态",mapHtml.includes("教化") && mapHtml.includes("驻守 1 人"));
console.log(`\n秘境教化专项：${pass} 通过，${fail} 失败`);
if(fail) process.exit(1);
