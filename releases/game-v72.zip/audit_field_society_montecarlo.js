// v0.57.0 凡人社会经济与婚育固定种子压力审计。
const WORLDS=10000,DAYS=365; let seed=0x57000001;
function rand(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;}
const totals={grossDispatchStone:0,playerStone:0,levyIncome:0,consumptionDemand:0,consumptionPaid:0,consumptionShortfall:0,births:0,closingTreasury:0,marriages:0};
let violations=0, maxTreasury=0, samples=[];
for(let w=0;w<WORLDS;w++){
  let pop=1+Math.floor(rand()*30), couples=0, marriageProgress=0,birthProgress=0,births=0,treasury=0;
  let levyIncome=0,paidTotal=0,shortfallTotal=0,grossTotal=0,playerTotal=0,marriages=0;
  for(let d=0;d<DAYS;d++){
    const gross=10+rand()*150, levy=gross*0.015, player=gross-levy;
    grossTotal+=gross;playerTotal+=player;levyIncome+=levy;treasury+=levy;
    const demand=pop*0.05, paid=Math.min(demand,treasury), shortfall=demand-paid;
    treasury-=paid;paidTotal+=paid;shortfallTotal+=shortfall;
    const livelihood=demand>0?paid/demand:1;
    const maxCouples=Math.floor(pop*0.30), eligible=Math.max(0,maxCouples-couples);
    if(eligible>0&&livelihood>0){marriageProgress+=eligible*livelihood/365;const wedding=Math.min(eligible,Math.floor(marriageProgress));couples+=wedding;marriages+=wedding;marriageProgress-=wedding;}
    else if(eligible<=0)marriageProgress=0;
    if(couples>0&&livelihood>0){birthProgress+=couples*livelihood/730;const due=Math.floor(birthProgress);if(due>0){const accepted=Math.min(due,30-pop);births+=accepted;pop+=accepted;birthProgress=accepted>=due?birthProgress-due:Math.min(0.999999,birthProgress-Math.floor(birthProgress));}}
    if(treasury< -1e-9||!Number.isFinite(treasury)||pop>30||couples>Math.floor(pop*0.30))violations++;
    maxTreasury=Math.max(maxTreasury,treasury);
  }
  if(Math.abs(levyIncome-paidTotal-treasury)>1e-6)violations++;
  totals.grossDispatchStone+=grossTotal;totals.playerStone+=playerTotal;totals.levyIncome+=levyIncome;totals.consumptionDemand+=paidTotal+shortfallTotal;totals.consumptionPaid+=paidTotal;totals.consumptionShortfall+=shortfallTotal;totals.births+=births;totals.closingTreasury+=treasury;totals.marriages+=marriages;
  if(w<8)samples.push({world:w+1,finalPopulation:pop,marriedCouples:couples,births,levyIncome,consumptionPaid:paidTotal,consumptionShortfall:shortfallTotal,closingTreasury:treasury});
}
const splitError=Math.abs(totals.grossDispatchStone-totals.playerStone-totals.levyIncome);
console.log(JSON.stringify({version:"0.57.0",seed:"0x57000001",worlds:WORLDS,daysPerWorld:DAYS,totalWorldDays:WORLDS*DAYS,violations,splitError,maxTreasury,totals,meanBirths:totals.births/WORLDS,meanAnnualConsumptionPaid:totals.consumptionPaid/WORLDS,samples},null,2));
if(violations||splitError>1e-5)process.exit(1);
