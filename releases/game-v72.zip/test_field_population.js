// v0.56.4 私有秘境修士留存与凡人转化专项回归。
const fs = require("fs"), path = require("path"), vm = require("vm");
const store = {};
global.localStorage = { getItem:k => (k in store ? store[k] : null), setItem:(k,v) => { store[k] = String(v); }, removeItem:k => { delete store[k]; } };
global.window = { addEventListener:() => {} };
const els = {};
const stubEl = () => ({ textContent:"", innerHTML:"", style:{}, classList:{ add(){}, remove(){}, toggle(){} }, dataset:{} });
global.document = { hidden:false, getElementById:id => (els[id] = els[id] || stubEl()), querySelectorAll:() => [], body:{ addEventListener:() => {} } };
global.confirm = () => true; global.location = { reload:() => {} };
function load(f) { vm.runInThisContext(fs.readFileSync(path.join(__dirname, f), "utf8"), { filename:f }); }
["js/config.js","js/state.js","js/gongfa.js","js/avatar.js","js/pet.js","js/artifact.js","js/idle.js","js/combat.js","js/tower.js","js/build.js","js/dan.js","js/guide.js","js/time.js","js/faction.js","js/event.js","js/npc.js","js/economy.js","js/codex.js","js/field.js","js/dispatch.js","js/field_view.js","js/dao.js","js/tuna.js","js/daily.js","js/specialty.js","js/ancient.js","js/meridians.js","js/realm.js","js/recruit.js","js/staff.js","js/field_education.js","js/sect.js","js/element.js","js/life.js","js/ui.js","js/inventory.js","js/field_commerce.js","js/field_population.js","js/field_society.js"].forEach(load);
let pass=0, fail=0; function a(n,v){ if(v){pass++;console.log("[PASS] "+n);}else{fail++;console.log("[FAIL] "+n);} }
S=defaultState(); S.clearedMaps[0]=true; S.fieldEducation[0]={progress:1,private:true,totalGuardSec:100}; S.stone=5000;
a("旧档迁移补齐修士人口账本",!!migrateState({version:17,folk:12}).fieldResidents);
const migratedResidents=migrateState({version:17,folk:0,fieldResidents:{0:{cultivators:9.8,progress:2,totalArrived:-3,lastDay:17}}}).fieldResidents[0];
a("修士人口迁移钳制非法数量、进度与累计值",migratedResidents.cultivators===9&&migratedResidents.progress===0.999999&&migratedResidents.totalArrived===0&&migratedResidents.lastDay==="");
let r=buildFieldCommerce(0,"cave");
a("私有秘境可建设修行洞府并正确扣费",r.ok&&S.stone===4100&&fieldResidentCapacity(0)===3);
a("未建设修行洞府时没有修士人口容量",fieldResidentCapacity(1)===0&&fieldResidentDailyRate(1)===0);
const firstRate=fieldResidentDailyRate(0);
S.fieldCommerce[0].buildings.auction=1;
a("商铺繁荣可提升修士流入速度",fieldResidentDailyRate(0)>firstRate);
// 推进日期，确认日结流入；重复执行同一天不能重复计入。
for(let i=0;i<20;i++){S.gameTime.day++; if(S.gameTime.day>30){S.gameTime.day=1;S.gameTime.month++;} fieldResidentsDailyTick();}
const arrived=fieldResidentsOf(0).cultivators;
a("修行洞府按日吸引本地修士流入",arrived>0&&arrived<=3&&fieldResidentsOf(0).totalArrived===arrived);
fieldResidentsDailyTick();
a("同一游戏日重复结算不会重复增加修士",fieldResidentsOf(0).cultivators===arrived);
for(let i=0;i<100;i++){S.gameTime.day++; if(S.gameTime.day>30){S.gameTime.day=1;S.gameTime.month++;} fieldResidentsDailyTick();}
a("修士人口不会超过洞府容量",fieldResidentsOf(0).cultivators===3&&fieldResidentsOf(0).cultivators<=fieldResidentCapacity(0));
const lockedBefore=fieldResidentsOf(1,false);
a("未私有化秘境不能自然吸引修士",!lockedBefore||lockedBefore.cultivators===0);
const html=fieldCommercePanelHtml(0);
a("经营面板展示修行洞府和本地修士人口",html.includes("修行洞府")&&html.includes("本地修士")&&html.includes("/ 3 人"));
// 凡人转化必须同时满足教化、安定、人口、容量与灵石条件，且账本守恒。
S.fieldResidents[0].cultivators = 0; S.fieldResidents[0].progress = 0;
S.fieldSettlements = {0:{population:20,foundedAt:"",name:"测试聚落"},_reserve:0}; S.folk=20; S.fieldStable[0]=60; S.stone=2000;
let cv=fieldResidentsConvert(0);
a("满足门槛后可用本地凡人与灵石转化修士",cv.ok&&S.fieldResidents[0].cultivators===1&&settlementPopulation(0)===10&&S.stone===1200&&S.folk===10);
const beforeFolk=S.folk,beforeStone=S.stone,beforeCult=S.fieldResidents[0].cultivators;
S.stone=0; cv=fieldResidentsConvert(0); S.stone=beforeStone;
a("容量满或资源不足时拒绝转化且不扣资源",!cv.ok&&S.folk===beforeFolk&&S.stone===beforeStone&&S.fieldResidents[0].cultivators===beforeCult);
S.fieldStable[0]=40; cv=fieldResidentsConvert(0);
a("安定度不足时拒绝凡人引修",!cv.ok&&S.folk===beforeFolk&&S.stone===beforeStone);
S.fieldStable[0]=60; S.fieldResidents[0].cultivators=3; cv=fieldResidentsConvert(0);
a("洞府容量已满时拒绝凡人引修",!cv.ok&&S.folk===beforeFolk&&S.stone===beforeStone);
S.fieldResidents[0].cultivators=0; S.fieldResidents[0].departureProgress=0; S.fieldStable[0]=0; S.fieldCommerce[0].buildings.cave=0;
for(let i=0;i<20;i++){S.gameTime.day++; if(S.gameTime.day>30){S.gameTime.day=1;S.gameTime.month++;} fieldResidentsDailyTick();}
a("没有修士居民时不会积累虚假的迁出压力",S.fieldResidents[0].departureProgress===0&&S.fieldResidents[0].totalDeparted===0);
S.fieldCommerce[0].buildings.cave=1; S.fieldResidents[0].cultivators=2; S.fieldResidents[0].departureProgress=0;
for(let i=0;i<13;i++){S.gameTime.day++; if(S.gameTime.day>30){S.gameTime.day=1;S.gameTime.month++;} fieldResidentsDailyTick();}
a("低安定度持续恶化会触发修士迁出",S.fieldResidents[0].totalDeparted>0&&S.fieldResidents[0].cultivators<2);

// v0.56.8：个人钱包由共享预算内的居民消费额度划拨，不新增货币发行。
S.fieldStable[0]=60; S.fieldCommerce[0].buildings.cave=1; S.fieldCommerce[0].buildings.auction=1; S.fieldCommerce[0].buildings.alchemy=0; S.fieldCommerce[0].buildings.forge=0;
S.fieldResidents[0].cultivators=2; S.fieldResidents[0].progress=0; S.fieldResidents[0].lastDay="old"; S.fieldResidents[0].lastRentDay="old"; S.fieldResidents[0].wallets=[]; S.fieldResidents[0].nextWalletId=1; S.fieldResidents[0].totalWalletIncome=0; S.fieldResidents[0].totalWalletSpent=0; S.fieldResidents[0].totalResidentPurchases=0; S.fieldResidents[0].totalRentPaid=0; S.fieldResidents[0].departedWalletBalance=0; S.fieldCommerce[0].budget=null;
S.gameTime.day++;
const rentStoneBefore=S.stone;
fieldResidentsDailyTick();
const rentBudget=S.fieldCommerce[0].budget;
a("每日居民消费额度从共享发行池划拨至个人钱包",rentBudget.issued===220&&rentBudget.residentAllocation===70&&rentBudget.spent===70&&rentBudget.remaining===150);
a("每名本地修士获得35灵石个人钱包收入",S.fieldResidents[0].wallets.length===2&&S.fieldResidents[0].wallets.every(w=>w.balance===33)&&S.fieldResidents[0].totalWalletIncome===70);
a("洞府租金由修士个人钱包支付并进入玩家账户",S.stone===rentStoneBefore+4&&S.fieldResidents[0].lastRentPaid===4&&S.fieldResidents[0].totalRentPaid>=4);
a("个人钱包收入与租金支出均有独立账本",S.fieldResidents[0].totalWalletSpent===4&&S.fieldResidents[0].wallets.reduce((n,w)=>n+w.balance,0)===66);
fieldResidentsDailyTick();
a("同一游戏日重复结算不会重复发放钱包收入或收租",S.stone===rentStoneBefore+4&&S.fieldResidents[0].totalWalletIncome===70&&rentBudget.spent===70);
S.gameTime.day++; S.fieldCommerce[0].budget=null; S.fieldResidents[0].lastRentDay="old"; S.fieldResidents[0].lastDay="old";
const nextDayIncome=S.fieldResidents[0].totalWalletIncome; fieldResidentsDailyTick();
a("跨日仅按当日居民人数再次划拨钱包额度",S.fieldResidents[0].totalWalletIncome===nextDayIncome+70&&S.fieldResidents[0].wallets.every(w=>w.balance===66));
const rentMigrated=migrateState({version:17,fieldResidents:{0:{cultivators:2,totalRentPaid:7,lastRentPaid:2,lastRentDay:"1-1-2"}}}).fieldResidents[0];
a("旧档迁移为既有修士建立零余额钱包而不补发历史货币",rentMigrated.wallets.length===2&&rentMigrated.wallets.every(w=>w.balance===0)&&rentMigrated.totalRentPaid===7);

// 居民购买玩家库存丹药：钱包扣款、库存扣除、玩家收款三方同时发生。
invSet("pill",5); S.market.pill=10;
const walletBefore=S.fieldResidents[0].wallets.reduce((n,w)=>n+w.balance,0), buyStoneBefore=S.stone, buyInvBefore=invCount("pill");
const residentBuy=fieldResidentsBuyFromPlayer(0,"pill",2);
a("居民可用个人钱包购买玩家储物袋中的丹药",residentBuy.ok&&residentBuy.n===2&&invCount("pill")===buyInvBefore-2&&S.stone===buyStoneBefore+residentBuy.total);
a("居民购买同步扣减个人钱包并记录消费账本",S.fieldResidents[0].wallets.reduce((n,w)=>n+w.balance,0)===walletBefore-residentBuy.total&&S.fieldResidents[0].totalResidentPurchases===2);
const repeatBuy=fieldResidentsBuyFromPlayer(0,"pill",1);
a("同一修士每日最多购买一枚丹药，防止钱包消费被重复刷取",!repeatBuy.ok&&invCount("pill")===buyInvBefore-2);
const failedBuyStone=S.stone, failedBuyWallet=S.fieldResidents[0].wallets.reduce((n,w)=>n+w.balance,0), failedBuyInv=invCount("pill");
const tooMuch=fieldResidentsBuyFromPlayer(0,"pill",99);
a("居民钱包不足或库存不足时交易整体拒绝",!tooMuch.ok&&S.stone===failedBuyStone&&S.fieldResidents[0].wallets.reduce((n,w)=>n+w.balance,0)===failedBuyWallet&&invCount("pill")===failedBuyInv);
const departedWalletBefore=S.fieldResidents[0].departedWalletBalance||0;
S.fieldResidents[0].cultivators=1; fieldResidentsSyncWallets(S.fieldResidents[0]);
a("修士迁出时个人余钱随本人离开，不转入玩家或其他钱包",S.fieldResidents[0].wallets.length===1&&S.fieldResidents[0].departedWalletBalance>=departedWalletBefore);
S.fieldResidents[0].cultivators=2; fieldResidentsSyncWallets(S.fieldResidents[0]);
S.fieldResidents[0].wallets.forEach(w => { w.purchasesDay = ""; });
const residentHtml=fieldCommercePanelHtml(0);
a("秘境经营面板展示居民钱包与丹药消费入口",residentHtml.includes("钱包余额")&&residentHtml.includes("居民购买"));
const convertedMigration=migrateState({version:17,folk:0,fieldResidents:{0:{cultivators:2,totalDeparted:1,converted:3,departureProgress:2}}}).fieldResidents[0];
a("旧档迁移补齐迁出与转化统计并钳制进度",convertedMigration.totalDeparted===1&&convertedMigration.converted===3&&convertedMigration.departureProgress===0.999999&&convertedMigration.wallets.length===2);

// v0.56.9：岗位由已建成设施提供，只有在岗修士领取工资。
S.fieldCommerce[0].buildings.cave=1; S.fieldCommerce[0].buildings.auction=0; S.fieldCommerce[0].buildings.alchemy=0; S.fieldCommerce[0].buildings.forge=0;
S.fieldResidents[0].cultivators=3; S.fieldResidents[0].wallets=[1,2,3].map(id=>({id,balance:0,lastIncomeDay:"",purchasesDay:"",purchasesCount:0,occupation:""})); S.fieldResidents[0].lastRentDay="old"; S.fieldResidents[0].lastDay="old"; S.fieldResidents[0].totalWalletIncome=0; S.fieldCommerce[0].budget=null; S.gameTime.day++;
fieldResidentsDailyTick();
const jobSummary=fieldResidentsSummary(0), jobBudget=S.fieldCommerce[0].budget;
a("岗位数量由已建成设施决定，单座修行洞府提供1个维护岗位",jobSummary.employed===1&&jobSummary.unemployed===2&&S.fieldResidents[0].wallets[0].occupation==="洞府维护");
a("只有在岗修士获得工资，待业修士不会凭空获得消费金",S.fieldResidents[0].wallets.filter(w=>w.balance>0).length===1&&S.fieldResidents[0].totalWalletIncome===35);
a("居民岗位工资按实际在岗人数划拨，不超过共享预算",jobBudget.residentAllocation===35&&jobBudget.spent===35&&jobBudget.remaining===jobBudget.issued-35);
S.fieldCommerce[0].buildings.auction=1;
const expandedJobs=fieldResidentJobPlan(0,S.fieldResidents[0]);
a("新增拍卖行后岗位容量增加且待业居民获得岗位",expandedJobs.employed===3&&expandedJobs.unemployed===0&&S.fieldResidents[0].wallets.some(w=>w.occupation==="坊市执事"));

console.log(`\n修士人口专项：${pass} 通过，${fail} 失败`); if(fail) process.exit(1);
