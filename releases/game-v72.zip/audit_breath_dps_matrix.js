const fs=require('fs'),path=require('path'),vm=require('vm');
const store={}; global.localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=String(v),removeItem:k=>delete store[k]};
global.window={addEventListener:()=>{},removeEventListener:()=>{}}; global.document={hidden:false}; global.confirm=()=>true; global.location={reload:()=>{}};
// 固定随机种子，确保敌人生成、会心与掉落模拟可复现。
let _seed=20261116; Math.random=()=>{_seed=(_seed*1664525+1013904223)>>>0;return _seed/4294967296;};
function load(f){vm.runInThisContext(fs.readFileSync(path.join(__dirname,f),'utf8'),{filename:f});}
[
'js/config.js','js/state.js','js/inventory.js','js/gongfa.js','js/avatar.js','js/pet.js','js/artifact.js','js/idle.js','js/combat.js','js/tower.js','js/build.js','js/dan.js','js/guide.js','js/time.js','js/faction.js','js/event.js','js/npc.js','js/economy.js','js/codex.js','js/field.js','js/dispatch.js','js/dao.js','js/tuna.js','js/daily.js','js/specialty.js','js/ancient.js','js/meridians.js','js/realm.js','js/recruit.js','js/staff.js','js/sect.js','js/element.js','js/life.js','js/field_view.js','js/field_ui.js','js/breath.js'
].forEach(load);
// stop delayed UI settlement in this deterministic harness
setTimeout=()=>0;
function sim(ch,realm,layer,runs){let rows=[];for(let n=0;n<runs;n++){
 S=defaultState(); S.realm=realm; S.layer=layer; S.bestStage=ch*6; S.stamina=30; S.playerName='sim';
 const f=fldCreate(ch); breathNormalizeEnemies(f); BREATH.field=f; BREATH.profile=gongfaV2Profile(); BREATH.active=true; BREATH.playerGas=0; BREATH.enemyGas=0; BREATH.enemyIndex=0; BREATH.slotCursor=0; BREATH.cooldowns={}; BREATH.tick=0; BREATH.resultShown=false;
 f.monsters.sort((a,b)=>({normal:0,elite:1,wild:2,boss:3}[a.kind]??0)-({normal:0,elite:1,wild:2,boss:3}[b.kind]??0));
 let ticks=0; while(BREATH.active && ticks<900){breathTick();ticks++;}
 rows.push({win:!!f.win,ticks,hp:Math.max(0,f.player.hp),hpPct:Math.max(0,f.player.hp/f.player.hpMax),monsters:f.monsters.length});
 }
 const wins=rows.filter(x=>x.win).length; const avg=rows.reduce((a,x)=>a+x.ticks,0)/rows.length; const hp=rows.filter(x=>x.win).reduce((a,x)=>a+x.hpPct,0)/Math.max(1,wins);
 return {chapter:ch,realm,wins,runs,avgTicks:+avg.toFixed(1),avgHpPct:+(hp*100).toFixed(1),rows};}

function dummyDps(ratio, slots, ticks=2400) {
 S=defaultState(); S.realm=7; S.yungongRatio=ratio; S.gongfaBooks={changsheng:{lv:3,learned:true},chiyang:{lv:6,learned:true},zixiao:{lv:6,learned:true}}; S.gongfaEquip={xin:'changsheng',shu:'chiyang',shen:null,dao:'zixiao'};
 const target={name:'木桩',hp:1e12,hpMax:1e12,def:0,atk:0,alive:true,kind:'normal'};
 Math.random=()=>0.99;
 BREATH.field={player:{atk:100,def:0,hp:1e9,hpMax:1e9,mana:200,manaMax:200,shield:0},monsters:[target],slots:slots.slice(),dmgDealt:0,killCount:0,bossKilled:false};
 BREATH.profile={crit:0,lifesteal:0,atk:0,yungong:0,speed:0,dodge:0,manaRegen:0}; BREATH.buffs={}; BREATH.enemySlow=null; BREATH.cooldowns={}; BREATH.playerGas=0; BREATH.enemyGas=0; BREATH.enemyIndex=0; BREATH.slotCursor=0; BREATH.tick=0; BREATH.active=true; BREATH.el=null;
 const counts={}; const original=breathUseSkill; breathUseSkill=function(key,manual){const r=original(key,manual);if(r.ok)counts[key]=(counts[key]||0)+1;return r;};
 for(let i=0;i<ticks;i++) breathTick(); BREATH.active=false; breathUseSkill=original;
 return {dps:BREATH.field.dmgDealt/ticks,counts,mana:BREATH.field.player.mana};
}
const builds=[
 ['empty',[]],['light',['lingxi_zhang']],['mid',['jian_qi']],['heavy',['tiangang_pierce']],['mixed-basic',['jian_qi','lingxi_zhang']],
 ['legacy-five',['jian_qi','lingxi_zhang','huo_hai','chiyang_burst','zixiao_thunder']],
 ['damage-only',['jian_qi','huo_hai','chiyang_burst','zixiao_thunder']],
 ['low-cost',['lingxi_zhang','jian_qi']],
];
for(const [name,slots] of builds){const r=dummyDps(0,slots);console.log(JSON.stringify({build:name,slots,dps:+r.dps.toFixed(3),manaLeft:+r.mana.toFixed(1),casts:r.counts}));}
const y=dummyDps(.6,[]);console.log(JSON.stringify({build:'yungong-60',dps:+y.dps.toFixed(3),manaLeft:+y.mana.toFixed(1),casts:y.counts}));
