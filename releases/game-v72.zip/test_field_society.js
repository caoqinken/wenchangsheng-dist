// v0.57.0 凡人家庭、婚育、生活消费与公库经济专项回归。
const fs = require("fs"), path = require("path"), vm = require("vm");
const store = {};
global.localStorage = { getItem:k => (k in store ? store[k] : null), setItem:(k,v) => { store[k] = String(v); }, removeItem:k => { delete store[k]; } };
global.window = { addEventListener:() => {} };
const els = {}; const stubEl = () => ({ textContent:"", innerHTML:"", style:{}, classList:{ add(){}, remove(){}, toggle(){} }, dataset:{} });
global.document = { hidden:false, getElementById:id => (els[id] = els[id] || stubEl()), querySelectorAll:() => [], body:{ addEventListener:() => {} } };
global.confirm = () => true; global.location = { reload:() => {} };
function load(f) { vm.runInThisContext(fs.readFileSync(path.join(__dirname, f), "utf8"), { filename:f }); }
["js/config.js","js/state.js","js/gongfa.js","js/avatar.js","js/pet.js","js/artifact.js","js/idle.js","js/combat.js","js/tower.js","js/build.js","js/dan.js","js/guide.js","js/time.js","js/faction.js","js/event.js","js/npc.js","js/economy.js","js/codex.js","js/field.js","js/dispatch.js","js/field_view.js","js/dao.js","js/tuna.js","js/daily.js","js/specialty.js","js/ancient.js","js/meridians.js","js/realm.js","js/recruit.js","js/staff.js","js/field_education.js","js/sect.js","js/element.js","js/life.js","js/ui.js","js/inventory.js","js/field_commerce.js","js/field_population.js","js/field_society.js"].forEach(load);
let pass=0, fail=0; function a(n,v){ if(v){pass++;console.log("[PASS] "+n);}else{fail++;console.log("[FAIL] "+n);} }
S=defaultState(); S.mapTeam={0:[1]}; S.clearedMaps[0]=true; S.fieldSettlements={0:{population:20,foundedAt:"",name:"测试聚落"},_reserve:0}; S.folk=20;
const old=migrateState({version:17,folk:0,fieldSociety:{0:{treasury:-10,marriedCouples:-2,births:4,children:2,consumptionShortfall:7}}}).fieldSociety[0];
a("旧档迁移创建凡人社会账本并钳制非法数值",old.treasury===0&&old.marriedCouples===0&&old.births===4&&old.children===2&&old.consumptionShortfall===7);
const tax=fieldSocietyCollectLevy(0,100);
a("聚落公库只取得本地驻守产出的1.5%留成",tax===1.5&&fieldSocietySummary(0).treasury===1.5&&S.stone===50);
const before=fieldSocietySummary(0).treasury;
fieldSocietyCollectLevy(1,100);
a("无本地驻守队伍的秘境不会凭空征收留成",fieldSocietySummary(1).treasury===0&&fieldSocietySummary(0).treasury===before);
// 一对夫妻逐日推进，约两年产生一名新生儿。
S.fieldSociety[0]={marriedCouples:1,marriageProgress:0,birthProgress:0,births:0,children:0,maturationProgress:0,treasury:2000,levyIncome:0,consumptionPaid:0,consumptionShortfall:0,lastConsumption:0,lastLevyDay:"",lastLifeDay:""};
const popBefore=settlementPopulation(0);
for(let i=0;i<730;i++){ S.gameTime.day++; if(S.gameTime.day>30){S.gameTime.day=1;S.gameTime.month++;if(S.gameTime.month>12){S.gameTime.month=1;S.gameTime.year++;}} fieldSocietyDailyTick(); }
const soc=fieldSocietySummary(0);
a("已婚家庭会随时间生育，出生人口进入本地凡人账本",soc.births>=1&&settlementPopulation(0)>popBefore&&S.folk===settlementPopulation(0));
const paid=soc.consumptionPaid, treasury=soc.treasury;
fieldSocietyDailyTick();
a("同一游戏日重复结算不会重复婚育或扣除生活消费",fieldSocietySummary(0).consumptionPaid===paid&&fieldSocietySummary(0).treasury===treasury);
// 聚落资金不足时只记录未满足需求，不透支玩家灵石。
S.gameTime.day++; if(S.gameTime.day>30){S.gameTime.day=1;S.gameTime.month++;}
S.fieldSociety[0].treasury=0; const stoneBefore=S.stone; fieldSocietyDailyTick();
a("生活消费资金不足时记录短缺，不透支玩家或制造负公库",S.stone===stoneBefore&&fieldSocietySummary(0).treasury===0&&fieldSocietySummary(0).consumptionShortfall>0);
// 只有成年人口估算形成的家庭容量允许婚配，且婚姻进度按日累积。
S.fieldSettlements[0].population=10; S.folk=10; S.fieldSociety[0]={marriedCouples:0,marriageProgress:0,birthProgress:0,births:0,children:0,maturationProgress:0,treasury:100,levyIncome:0,consumptionPaid:0,consumptionShortfall:0,lastConsumption:0,lastLevyDay:"",lastLifeDay:""};
for(let i=0;i<365;i++){ S.gameTime.day++; if(S.gameTime.day>30){S.gameTime.day=1;S.gameTime.month++;if(S.gameTime.month>12){S.gameTime.month=1;S.gameTime.year++;}} fieldSocietyDailyTick(); }
a("聚落成年人口规模决定婚姻容量，婚姻按日推进而非瞬时生成",fieldSocietySummary(0).marriedCouples>=1&&fieldSocietySummary(0).marriedCouples<=3);
const html=fieldSocietySummary(0);
a("凡人社会摘要提供家庭、出生、公库与生活消费字段",html.marriedCouples>=0&&html.births>=0&&html.children>=0&&Number.isFinite(html.dailyDemand)&&Number.isFinite(html.treasury));
console.log(`\n凡人社会专项：${pass} 通过，${fail} 失败`); if(fail) process.exit(1);
