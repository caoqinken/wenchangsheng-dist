// v0.54.7 成长经济路线图专项回归
const fs=require('fs'),path=require('path'),cp=require('child_process');
const out=cp.execFileSync(process.execPath,[path.join(__dirname,'audit_growth_roadmap.js')],{encoding:'utf8'});
const p=path.join(__dirname,'..','docs','v0.54.7_P1_成长经济路线图.md');
let pass=0,fail=0;function a(n,v){if(v){pass++;console.log('[PASS] '+n)}else{fail++;console.log('[FAIL] '+n)}}
a('覆盖炼气至金仙11境',out.includes('炼气')&&out.includes('金仙'));
a('按99层完整计算',out.includes('11境 × 9层 = 99层'));
a('突破公式来自配置',out.includes('100 × 1.29^k')&&out.includes('5^realm × 1.03^layer'));
a('明确层内突破与跨境渡劫差异',out.includes('层内突破：灵气达标后100%成功')&&out.includes('跨境：触发渡劫'));
a('明确建筑不是突破硬门槛',out.includes('没有要求先升级某座建筑'));
a('覆盖六阶法宝成本与坊级门槛',out.includes('仙器')&&out.includes('24,000灵石、96灵材'));
a('说明时间模型边界',out.includes('无任何额外加成')&&out.includes('不是实际通关承诺'));
a('报告已生成',fs.existsSync(p)&&fs.statSync(p).size>3000);
console.log(`结果：${pass} 通过，${fail} 失败`);if(fail)process.exit(1);
