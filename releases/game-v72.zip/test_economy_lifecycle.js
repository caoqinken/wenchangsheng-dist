// v0.54.5 生命周期经济模型公式回归
const fs=require('fs'),path=require('path'),vm=require('vm');
const store={};global.localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=String(v),removeItem:k=>delete store[k]};
global.window={addEventListener:()=>{}};global.document={hidden:false};global.confirm=()=>true;
function load(f){vm.runInThisContext(fs.readFileSync(path.join(__dirname,f),'utf8'),{filename:f});}
let pass=0,fail=0;function a(n,v){if(v){pass++;console.log('[PASS] '+n);}else{fail++;console.log('[FAIL] '+n);}}
load('js/config.js');load('js/state.js');load('js/inventory.js');load('js/npc.js');load('js/dispatch.js');load('js/build.js');load('js/realm.js');load('js/artifact.js');load('js/gongfa.js');
global.stableMult=()=>1;global.officeBonus=()=>0;global.dynastyFolkMult=()=>1;global.fieldTempleLv=()=>0;global.fieldMineLv=()=>0;global.fieldGardenLv=()=>0;global.blessed=()=>false;S=defaultState();
a('洞府建筑升级成本来自现行配置',CONFIG.buildingCost(0)===50&&CONFIG.buildingCost(5)===1600);
a('秘境建设成本来自现行成本函数',fieldBuildCost(0)===120&&fieldBuildCost(1)===192);
a('弟子招募成本按现行递增函数计算',CONFIG.recruitCost(0)===100&&CONFIG.recruitCost(1)===150);
a('法宝品阶成本覆盖六阶',forgeCost(1).material===3&&forgeCost(6).material===96&&forgeCost(6).stone===24000);
a('升阶与器纹成本引用实际函数',refineCost(6)===48&&engraveCost({tier:6}).mat===36&&engraveCost({tier:6}).stone===1560);
a('宗门阶段成本读取当前配置',CONFIG.SECT.BASE_STONE===5000&&CONFIG.SECT.UP_STONE===8000&&CONFIG.SECT.MAX_LV===5);
S.realm=0;S.disciples=[1,2,3].map(id=>({id,realm:0,loyalty:80,specialty:'farm',bond:90}));S.mapTeam={0:[1,2,3]};S.clearedMaps={0:true};
const low=dispatchRate(0);S.realm=10;S.disciples.forEach(d=>d.realm=10);const high=dispatchRate(0);
a('炼气至金仙的驻守产出随境界增长',high.stone>low.stone&&high.material>low.material&&high.folk>low.folk);
a('驻守产出字段完整且均为有限非负数',['stone','qi','herb','material','folk'].every(k=>Number.isFinite(high[k])&&high[k]>=0));
console.log(`结果：${pass} 通过，${fail} 失败`);if(fail)process.exit(1);
