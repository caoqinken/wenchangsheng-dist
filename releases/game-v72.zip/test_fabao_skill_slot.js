// v0.53.3：法宝独立第五格、普通槽排序与存档兼容专项
const fs = require('fs'), path = require('path'), vm = require('vm');
const context = {
  console, Math: Object.create(Math), Date, isFinite,
  S: {
    realm: 4, artifacts: [], loadout: { fabao0: 501 }, equipped: { attack:null, defense:null, support:null },
    fieldSlots: [], fabaoSkillSlot: null,
    gongfaBooks: { changsheng:{lv:3, learned:true} },
    gongfaEquip: { xin:'changsheng', shu:null, shen:null, dao:null },
    settings:{combatSpeed:1}, yungongRatio:0,
  },
  saveCount:0, save(){this.saveCount++;}, invTakeArtifact(){}, invPutArtifact(){}, invFreeSlots:()=>99,
  CONFIG:null, document:{}, window:{}, performance:{now:()=>1000}, setTimeout:()=>0,
  requestAnimationFrame:()=>1, cancelAnimationFrame:()=>{}, toast:()=>{}, esc:String, fmt:String,
};
vm.createContext(context);
for (const file of ['config.js','gongfa.js','artifact.js','field.js','breath.js']) {
  vm.runInContext(fs.readFileSync(path.join(__dirname,'js',file),'utf8'),context,{filename:file});
}
function run(s){ return vm.runInContext(s,context); }
let pass=0,fail=0;
function a(name,ok){ if(ok){pass++;console.log('[PASS] '+name)} else {fail++;console.log('[FAIL] '+name)} }

context.S.artifacts = [{id:501,name:'紫金葫芦',type:'fabao',tier:4,skill:'fb_zijin',atk:0,def:0,hp:0,cult:.2,affixes:[]}];
const normal = run('fldUnlockedSkills(S.realm).map(x=>x.key)');
const fabao = run('equippedFabaoSkills()');
a('普通术式候选池不再混入法宝技', normal.every(k=>!run(`fldSkill('${k}').fromFabao`)));
a('已装备法宝技能进入独立候选清单', fabao.length===1 && fabao[0].key==='fb_zijin');

context.S.fabaoSkillSlot='fb_zijin';
const selected = run('selectedFabaoSkill()');
a('选中的法宝技与当前已装备法宝绑定', !!selected && selected.key==='fb_zijin');
const slots = run('breathConfiguredSlots()');
a('独立法宝技追加在普通槽之后', slots[slots.length-1]==='fb_zijin' && slots.length===run('fldNormalizeSlots(S.fieldSlots,S.realm).length')+1);
a('法宝技不占普通槽位容量', run('fldNormalizeSlots(S.fieldSlots,S.realm).every(k=>!fldSkill(k).fromFabao)')); 

context.S.fieldSlots=['jian_qi','lingxi_zhang','jian_qi','fb_zijin','not_a_skill'];
const normalized=run('fldNormalizeSlots(S.fieldSlots,S.realm)');
a('旧档重复/非法/法宝技普通槽项目被安全清理', normalized.length===2 && normalized[0]==='jian_qi' && normalized[1]==='lingxi_zhang');
const moved=run('fldMoveSlot(0,1,S.realm)');
a('普通术式上下移保留其余顺序', moved.ok && moved.slots[0]==='lingxi_zhang' && moved.slots[1]==='jian_qi');
a('普通术式槽边界阻止越界换位', !run('fldMoveSlot(0,-1,S.realm).ok'));
a('换位操作持久化普通槽顺序', run('S.fieldSlots[0]')==='lingxi_zhang');

context.S.loadout.fabao0=null;
a('法宝卸下后已选法宝技立即失效', run('selectedFabaoSkill()')===null);
a('失效法宝技不会进入战斗技能循环', !run('breathConfiguredSlots().includes("fb_zijin")'));
context.S.loadout.fabao0=501;
context.S.fabaoSkillSlot='not_owned';
a('无效旧法宝技选择不会误带入战斗', run('selectedFabaoSkill()')===null);

console.log(`结果：${pass} 通过，${fail} 失败`);
if(fail) process.exit(1);
