// v0.56.1 洞府统一库房与共享库存接口专项回归。
const fs = require("fs"), path = require("path"), vm = require("vm");
const store = {};
global.localStorage = { getItem:k => (k in store ? store[k] : null), setItem:(k,v) => { store[k] = String(v); }, removeItem:k => { delete store[k]; } };
global.window = { addEventListener:() => {} };
const els = {};
const stubEl = () => ({ textContent:"", innerHTML:"", style:{}, classList:{ add(){}, remove(){}, toggle(){} }, dataset:{} });
global.document = { hidden:false, getElementById:id => (els[id] = els[id] || stubEl()), querySelectorAll:() => [], body:{ addEventListener:() => {} } };
global.confirm = () => true; global.location = { reload:() => {} };
function load(f) { vm.runInThisContext(fs.readFileSync(path.join(__dirname, f), "utf8"), { filename:f }); }
["js/config.js","js/state.js","js/gongfa.js","js/avatar.js","js/pet.js","js/artifact.js","js/idle.js","js/combat.js","js/tower.js","js/build.js","js/dan.js","js/guide.js","js/time.js","js/faction.js","js/event.js","js/npc.js","js/economy.js","js/codex.js","js/field.js","js/dispatch.js","js/field_view.js","js/dao.js","js/tuna.js","js/daily.js","js/specialty.js","js/ancient.js","js/meridians.js","js/realm.js","js/recruit.js","js/staff.js","js/field_education.js","js/sect.js","js/element.js","js/life.js","js/ui.js","js/inventory.js"].forEach(load);
let pass=0, fail=0;
function a(n,v){ if(v){pass++;console.log("[PASS] "+n);}else{fail++;console.log("[FAIL] "+n);} }
S=defaultState();
invSet("pill",12); invSet("material",30); invSet("herb",45);
const snap=fieldWarehouseSnapshot();
a("库房快照读取储物袋真实库存",snap.rows.some(x=>x.key==="pill"&&x.count===12)&&snap.rows.some(x=>x.key==="material"&&x.count===30));
a("库房快照标明唯一共享库存源",snap.source==="S.bag.slots + S.bag.stash");
S.bag.stash.herb=7;
const withStash=fieldWarehouseSnapshot();
a("袋口暂存计入库房总量并单独标识",withStash.rows.some(x=>x.key==="herb"&&x.count===52&&x.bagCount===45&&x.stashCount===7));
const before=invCount("pill");
const insufficient=fieldWarehouseTake("pill",before+1);
a("库存不足时拒绝整笔交易且不部分扣除",!insufficient.ok&&invCount("pill")===before);
const invalid=fieldWarehouseTake("pill",1.5);
a("交易数量仅接受正整数",!invalid.ok&&invCount("pill")===before);
const taken=fieldWarehouseTake("pill",5);
a("交易扣库成功并精确减少统一库存",taken.ok&&taken.removed===5&&invCount("pill")===7);
a("丹药等已有物品定义可直接进入库房清单",fieldWarehouseSnapshot().rows.some(x=>x.key==="pill"&&x.cat==="pill"));
const html=viewBuild();
a("统一库房嵌入现有洞府主页而非新增顶层页",html.includes("洞府统一库房")&&html.includes('data-action="bag"'));
a("库房卡提示丹药阁/炼器阁/拍卖行共享扣库",html.includes("不另建背包、不复制商品"));
console.log(`\n统一库房专项：${pass} 通过，${fail} 失败`);
if(fail) process.exit(1);
