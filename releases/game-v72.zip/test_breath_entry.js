// 气息战斗 v2 浏览器入口冒烟（最小 DOM mock）
const fs=require('fs'),path=require('path'),vm=require('vm');
const skill={key:'light',name:'轻式',mult:.6,mana:5,cd:1,color:'#aa8844'};
function node(){return {style:{},textContent:'',innerHTML:'',disabled:false,querySelector:()=>node(),querySelectorAll:()=>[],addEventListener:()=>{}};}
const canvas={width:900,height:430,getContext:()=>({})};
const overlay={id:'',className:'',innerHTML:'',parentNode:null,addEventListener:()=>{},querySelector:(s)=>s==='.bt-canvas'?canvas:node(),querySelectorAll:()=>[]};
const context={
 console,Math,Date,isFinite,
 S:{stamina:5,realm:0,playerName:'入口测试',yungongRatio:0,settings:{combatSpeed:1},fieldSlots:[]},
 CONFIG:{BATTLE2:{QI_MAX:200,QI_REGEN:100,YUNGONG_RATE:.15,SLOT_BY_REALM:[2,3,4,5,6,7,8,8,8,8,8]},FIELD:{SKILL_SLOTS:8}},
 FS:{field:null,el:null,raf:0,ended:false},
 document:{querySelectorAll:()=>[],createElement:()=>overlay,body:{appendChild:()=>{}}},
 window:{},performance:{now:()=>1000},requestAnimationFrame:()=>7,cancelAnimationFrame:()=>{},
 setTimeout:()=>0,confirm:()=>true,toast:()=>{},save:()=>{},dailyProgress:()=>{},sectTaskProgress:()=>{},
 fmt:n=>String(Math.floor(n)),esc:s=>String(s),
 fldChapterUnlocked:ch=>ch===0,fldDefaultSlots:()=>['light'],fldSkill:k=>k==='light'?skill:null,
 fldCreate:ch=>({chapter:ch,map:{name:'测试秘境',bossStage:5},player:{atk:100,def:50,hp:1000,hpMax:1000,mana:100,manaMax:100,shield:0},monsters:[{kind:'normal',name:'测试妖兽',hp:1000,hpMax:1000,atk:100,def:20,alive:true}],slots:['light'],events:[],dmgDealt:0,killCount:0,bossKilled:false,exploreMax:10,explore:0,gathered:0}),
};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname,'js/breath.js'),'utf8'),context);
let pass=0,fail=0; function a(n,v){if(v){pass++;console.log('[PASS] '+n)}else{fail++;console.log('[FAIL] '+n)}}
context.startFieldBattle(1); a('未解锁秘境拒绝进入且不扣体力',context.S.stamina===5 && context.FS.field===null);
context.startFieldBattle(0); const B=vm.runInContext('BREATH',context);
a('已解锁秘境进入后扣1体力',context.S.stamina===4);
a('气息战引擎接管原秘境入口',B.active===true && context.FS.field && context.FS.field.chapter===0);
a('生成新战斗界面并复用秘境关卡对象',overlay.className==='breath-screen' && context.FS.field.map.bossStage===5);
a('进入战斗时对旧怪物属性做回合制适配',context.FS.field.monsters[0].hpMax<1000 && context.FS.field.monsters[0].def<20);
context.breathClose(); a('关闭战斗后清理 RAF 与全局战斗引用',B.active===false && context.FS.field===null && context.FS.el===null);
console.log(`结果：${pass} 通过，${fail} 失败`); if(fail)process.exit(1);
