// v0.53.2：25部功法专属术式与战斗效果闭环专项回归
const fs = require('fs'), vm = require('vm'), path = require('path');
const context = {
  console, Math: Object.create(Math), Date, isFinite,
  S: { realm: 9, gongfaBooks: {}, gongfaEquip: { xin:null, shu:null, shen:null, dao:null }, yungongRatio:0, settings:{combatSpeed:1} },
  save:()=>{}, invCount:()=>0, invRemove:()=>{}, gainItem:()=>{}, fmt:n=>String(Math.floor(n)), esc:String,
  performance:{now:()=>1000}, setTimeout:(fn)=>{fn();return 0;},
  CONFIG:null, document:{}, window:{}, requestAnimationFrame:()=>1, cancelAnimationFrame:()=>{}, toast:()=>{},
};
vm.createContext(context);
for (const file of ['config.js','gongfa.js','field.js','breath.js']) {
  vm.runInContext(fs.readFileSync(path.join(__dirname,'js',file),'utf8'),context,{filename:file});
}
const CONFIG = vm.runInContext('CONFIG',context);
let pass=0,fail=0;
function a(name,ok){ if(ok){pass++;console.log('[PASS] '+name)} else {fail++;console.log('[FAIL] '+name)} }
const books=CONFIG.GONGFA_BOOKS;
const ownedSkills=CONFIG.FIELD_SKILLS.filter(x=>x.gongfaKey);
const assigned=books.flatMap(b=>b.skillKeys||[]);
a('25部功法全部配置专属术式',books.length===25&&books.every(b=>Array.isArray(b.skillKeys)&&b.skillKeys.length>0));
a('31个专属术式无重复且全部存在',assigned.length===31&&new Set(assigned).size===31&&assigned.every(k=>ownedSkills.some(s=>s.key===k)));
a('专属术式归属与功法配置双向一致',books.every(b=>b.skillKeys.every(k=>ownedSkills.some(s=>s.key===k&&s.gongfaKey===b.key))));
a('心法每部携带1个术式',books.filter(b=>b.category==='xin').every(b=>b.skillKeys.length>=0&&b.skillKeys.length<=1));
a('术法每部携带2至3个术式',books.filter(b=>b.category==='shu').every(b=>b.skillKeys.length>=2&&b.skillKeys.length<=3));
a('身法每部携带0至1个术式',books.filter(b=>b.category==='shen').every(b=>b.skillKeys.length<=1));
a('道法每部携带0至1个术式',books.filter(b=>b.category==='dao').every(b=>b.skillKeys.length<=1));
// 每部功法单独装备时，只解锁本功法的专属技能，不会越权解锁其他功法。
let ownershipOK=true;
for(const b of books){
  context.S.gongfaBooks[b.key]={lv:Math.min(1,b.layers),learned:true};
  context.S.gongfaEquip={xin:null,shu:null,shen:null,dao:null};
  context.S.gongfaEquip[b.category]=b.key;
  const unlocked=context.fldUnlockedSkills(9).filter(x=>x.gongfaKey);
  const keys=unlocked.map(x=>x.key).sort();
  if(JSON.stringify(keys)!==JSON.stringify(b.skillKeys.slice().sort())) ownershipOK=false;
}
a('专属术式必须对应功法已领悟且已装备',ownershipOK);
// 关窍/逐层战斗属性直接从每部功法 stats + nodes 汇入战斗 profile。
context.S.gongfaBooks.yuhua={lv:3,learned:true};
context.S.gongfaEquip={xin:null,shu:null,shen:null,dao:'yuhua'};
const profile=context.gongfaV2Profile();
a('功法逐层攻伐属性进入战斗 profile',profile.atk>0);
context.S.gongfaBooks.yuhua={lv:9,learned:true};
const profileNode=context.gongfaV2Profile();
a('第9层攻伐关窍效果进入战斗 profile',profileNode.atk>profile.atk);
// 战斗中逐项验证资源扣除、回复、护盾、增益、吸血与减伤。
const B=vm.runInContext('BREATH',context);
function setup(){B.field={player:{atk:100,def:10,hp:50,hpMax:100,mana:100,manaMax:200,shield:0},monsters:[{name:'测试妖兽',hp:2000,hpMax:2000,def:0,atk:50,alive:true,kind:'normal'}],slots:[],dmgDealt:0,killCount:0,bossKilled:false};B.profile={crit:0,lifesteal:0,atk:0,dodge:0};B.buffs={};B.enemySlow=null;B.cooldowns={};B.playerGas=200;B.enemyGas=0;B.el=null;context.Math.random=()=>0.99;}
setup(); const mana0=B.field.player.mana; context.breathUseSkill('ningshen_focus',true);
a('凝神守一实际消耗真元并回复真元',B.field.player.mana>mana0);
setup(); context.breathUseSkill('sanhua_guard',true);
a('三花护顶实际生成护盾',B.field.player.shield>0);
setup(); context.breathUseSkill('baihua_spring',true);
a('百花回春实际恢复气血',B.field.player.hp>50);
setup(); context.breathUseSkill('tianyan_oracle',true);
a('天衍观星实际生成限时会心增益',context.breathBuffValue('critPct')>0);
setup(); B.field.player.hp=20; context.breathDamage({atk:100,lifestealPct:0.2},B.field.monsters[0],1,'player','吸血测试');
a('化血类术式的吸血效果实际结算',B.field.player.hp>20);
setup(); context.breathUseSkill('wuse_guard',true); const before=B.field.player.hp; B.enemyGas=100; context.breathTick();
a('五色神光的减伤增益进入敌方伤害结算',B.field.player.hp>=before-50);
setup(); context.breathUseSkill('qingyun_frost',true); context.breathTick();
a('青云寒锋的迟滞效果实际降低敌方气息增长',B.enemyGas===45.5);
console.log(`结果：${pass} 通过，${fail} 失败`);
if(fail) process.exit(1);
