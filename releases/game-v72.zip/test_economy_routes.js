// v0.54.6 三类经营路线模拟回归
const fs=require('fs'),path=require('path'),cp=require('child_process');
const output=cp.execFileSync(process.execPath,[path.join(__dirname,'audit_economy_routes.js')],{encoding:'utf8'});
let pass=0,fail=0;function a(n,v){if(v){pass++;console.log('[PASS] '+n);}else{fail++;console.log('[FAIL] '+n);}}
a('三类路线均生成独立报告章节',['挂机型','常规经营型','深度经营型'].every(x=>output.includes('### '+x)));
a('报告明确标注情景假设与数据边界',output.includes('不是玩家行为统计')&&output.includes('没有真实遥测数据'));
a('各境界阶段均有累计资源表',output.includes('| 金仙 |')&&output.includes('| 炼气 |'));
a('未满足动作有单独追踪列',output.includes('未满足动作'));
a('未擅自将情景模型包装为真实玩家数据',output.includes('不应把次数直接当作真实玩家体验'));
const report=path.join(__dirname,'..','docs','v0.54.6_P1_三类经营路线情景模拟.md');a('报告文件可生成且非空',fs.existsSync(report)&&fs.statSync(report).size>1000);
console.log(`结果：${pass} 通过，${fail} 失败`);if(fail)process.exit(1);
