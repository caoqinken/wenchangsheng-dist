// v0.54.8：成长效率投资与在线/离线资源效率审计。只读复用现有 CONFIG 与实际产出函数。
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=__dirname,store={};
global.localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=String(v),removeItem:k=>delete store[k]};
global.window={addEventListener:()=>{}};global.document={hidden:false};global.confirm=()=>true;
function load(f){vm.runInThisContext(fs.readFileSync(path.join(root,f),'utf8'),{filename:f});}
['js/config.js','js/state.js','js/inventory.js','js/npc.js','js/dispatch.js','js/build.js'].forEach(load);
global.stableMult=()=>1;global.officeBonus=()=>0;global.dynastyFolkMult=()=>1;global.fieldTempleLv=()=>0;global.fieldMineLv=()=>0;global.fieldGardenLv=()=>0;global.blessed=()=>false;
const fmt=n=>Number(n).toLocaleString('en-US',{maximumFractionDigits:2});
const hours=3600, totalQi=Array.from({length:CONFIG.REALMS.length*CONFIG.LAYERS_PER_REALM},(_,k)=>CONFIG.breakCost(k)).reduce((a,b)=>a+b,0);
const levels=[0,1,3,5,6,10];
const practiceRows=levels.map(lv=>{
 let sec=0;for(let r=0;r<CONFIG.REALMS.length;r++)for(let l=0;l<CONFIG.LAYERS_PER_REALM;l++)sec+=CONFIG.breakCost(r*CONFIG.LAYERS_PER_REALM+l)/(CONFIG.baseRate(r,l)*(1+CONFIG.PRACTICE_RATE_BONUS*lv));
 const cost=50*(Math.pow(2,lv)-1);
 return {lv,cost,sec,days:sec/86400,offlineDays:sec/(hours*CONFIG.OFFLINE_RATE*8),incenseDays:sec/(hours*CONFIG.OFFLINE_RATE*13)};
});
// 采用可复现中性样本：3名筑基期、忠诚80、灵植专精、情谊90，驻守第1章；不叠建筑/势力/官职加成。
S=defaultState();S.realm=1;S.disciples=Array.from({length:3},(_,i)=>({id:i+1,realm:1,layer:0,loyalty:80,aptitude:2,specialty:'farm',bond:90,assignedTo:null}));S.mapTeam={0:[1,2,3]};S.clearedMaps={0:true};S.fieldVein={};S.fieldMine={};S.fieldGarden={};S.lostFields={};
const dr=dispatchRate(0);const dispatchRows=[
 {name:'在线驻守',factor:1,stone:dr.stone*hours,qi:dr.qi*hours,herb:dr.herb*hours,material:dr.material*hours},
 {name:'普通离线（8小时上限）',factor:CONFIG.OFFLINE_RATE*0.5,stone:dr.stone*hours*8*CONFIG.OFFLINE_RATE*0.5,qi:dr.qi*hours*8*CONFIG.OFFLINE_RATE*0.5,herb:dr.herb*hours*8*CONFIG.OFFLINE_RATE*0.5,material:dr.material*hours*8*CONFIG.OFFLINE_RATE*0.5},
 {name:'引魔香离线（13小时上限）',factor:CONFIG.OFFLINE_RATE*0.5*CONFIG.OFFLINE_INCENSE_DISPATCH_MULT,stone:dr.stone*hours*13*CONFIG.OFFLINE_RATE*0.5*CONFIG.OFFLINE_INCENSE_DISPATCH_MULT,qi:dr.qi*hours*13*CONFIG.OFFLINE_RATE*0.5*CONFIG.OFFLINE_INCENSE_DISPATCH_MULT,herb:dr.herb*hours*13*CONFIG.OFFLINE_RATE*0.5*CONFIG.OFFLINE_INCENSE_DISPATCH_MULT,material:dr.material*hours*13*CONFIG.OFFLINE_RATE*0.5*CONFIG.OFFLINE_INCENSE_DISPATCH_MULT}
];
const out=[];
out.push('# v0.54.8 P1：成长效率投资与在线/离线资源效率审计','','## 审计范围','','- 基线 v0.54.7；本轮只增加只读诊断与专项测试，不修改经济倍率、成本、玩法或存档。','- 修炼成本、基础速率、练功房加成、离线参数与驻守产出均读取当前源码配置/函数。','- 修炼时间模型仍不包含功法、药力、秘境、势力、经脉、古宝、法宝等额外乘区，也不包含渡劫失败；用于隔离练功房投资的边际影响。','',`- 99层基础突破灵气需求：${fmt(totalQi)}。`,`- 普通离线修炼等效效率：${fmt(CONFIG.OFFLINE_RATE*100)}%；每日上限 ${CONFIG.OFFLINE_CAP_SEC/hours} 小时，即约 ${CONFIG.OFFLINE_CAP_SEC/hours*CONFIG.OFFLINE_RATE} 等效在线小时。`,`- 引魔香离线修炼等效效率：${fmt(CONFIG.OFFLINE_RATE*100)}%；单次上限 ${CONFIG.OFFLINE_INCENSE_CAP_SEC/hours} 小时，即约 ${CONFIG.OFFLINE_INCENSE_CAP_SEC/hours*CONFIG.OFFLINE_RATE} 等效在线小时。`,'','## 练功房投资：时间收益与灵石门槛','','| 练功房等级 | 累计灵石成本 | 修炼速率倍率 | 全99层理论在线天数 | 普通离线天数* | 引魔香离线天数* |','|---:|---:|---:|---:|---:|---:|');
for(const x of practiceRows)out.push(`| ${x.lv} | ${fmt(x.cost)} | ×${(1+CONFIG.PRACTICE_RATE_BONUS*x.lv).toFixed(2)} | ${fmt(x.days)} | ${fmt(x.offlineDays)} | ${fmt(x.incenseDays)} |`);
out.push('','- *离线天数按每天都达到对应离线时长上限换算；普通离线每天4小时等效修炼，引魔香情景每天6.5小时等效修炼。不是实际玩家日历预测。','- 建筑成本按 `buildingCost(level)=50×2^level` 累计；升到 Lv.6 起还需对应章节特产，Lv.6 及以上的时间模型没有把特产获取耗时计入。','- 练功房加成是线性叠加：`1 + 7% × 等级`，不是复利。Lv.10 为 ×1.70，而不是 ×1.97 或 ×2.0。','- 练功房等级越高，理论修炼时间越短，但灵石成本指数增长；当前数据不能单独证明高等级一定“回本”，因为灵石没有统一的时间兑换价。','', '## 驻守资源：在线与离线折算口径','','- 代表性样本：3名筑基期弟子、忠诚80、资质2、灵植专精、情谊90，驻守第1章；无灵脉/矿场/药圃、安定度、官职、王朝或宗门加成。','- 这里直接调用 `dispatchRate(0)`，仅展示相同队伍在不同结算模式下的资源折算；不代表所有秘境和弟子组合。','','| 模式 | 相对在线驻守效率 | 灵石/结算 | 灵气/结算 | 灵草/结算 | 灵材/结算 |','|---|---:|---:|---:|---:|---:|');
for(const x of dispatchRows)out.push(`| ${x.name} | ${(x.factor*100).toFixed(1)}% | ${fmt(x.stone)} | ${fmt(x.qi)} | ${fmt(x.herb)} | ${fmt(x.material)} |`);
out.push('','### 一个需要明确告知玩家的口径','','- `computeOffline()` 中洞府修炼与建筑产出使用 `OFFLINE_RATE=0.5`；驻守资源则额外乘 `0.5`，因此普通离线驻守实际是在线速率的 **25%**。引魔香再乘 1.5，达到在线速率的 **37.5%**。','- 这是当前源码与现有回归测试共同锁定的行为，本轮不擅自改成50%/75%。但它与玩家可能从“离线按50%速率”得到的直觉不同，后续应在驻守说明/离线结算UI明确区分“修炼/建筑”和“驻守”两种折算。','- 资源点离线刷新是独立的固定周期补算，不包含在上表每小时连续产出折算中。','','## 成长路线决策建议','','1. **低操作频次**：先利用普通离线与引魔香上限；练功房先升低等级，避免前期为高等级升级掏空灵石。','2. **修炼优先**：优先比较练功房每一级增加的7%与当前其他修炼乘区；若已有高额功法/药力/法宝加成，练功房边际收益应按总乘区重新评估。','3. **资源经营**：驻守是持续资源来源，但离线驻守折算低于离线修炼；不要把两者当作同一效率。资源点刷新奖励需单独计入。','4. **后续校准**：要确定练功房最佳等级，需要明确灵石的机会成本（法宝、建筑、弟子招募的优先级）与玩家在线时长；没有遥测前不应给出唯一最优等级。','','## 结论与变更','','- 本轮识别出一个重要的信息呈现风险：离线修炼/建筑为50%效率，驻守连续资源为25%（引魔香37.5%）；现有代码与测试一致，因此只记录、不改玩法。','- 练功房Lv.0/1/3/5/6/10的累计成本和理论修炼时长已量化；Lv.6+特产门槛需纳入实际投资规划。','- `SAVE_VERSION` 保持17；无新增存档字段；无经济或战斗数值修改。','- P0未完成门禁继续暂缓，不计入本轮通过。','','## 复现','','```bash','node audit_growth_economy.js','node test_growth_economy.js','```','');
const report=path.join(root,'..','docs','v0.54.8_P1_成长效率投资与离线资源效率.md');fs.writeFileSync(report,out.join('\n'));console.log(out.join('\n'));
