// ============================================================
// 《问长生》UI 渲染层
// ============================================================

// 图鉴图标引用 (v0.23.1)
// 注意：三个函数均返回「图片路径字符串」（数据），由调用方包 <img> 渲染。
// v0.24.2 修复：此前调用方直接 ${icon} 插值，导致路径被当纯文本显示（画面出现裸路径文字）。
function codexEventIcon(key) {
  const map = {
    invasion: "assets/事迹_魔渊入侵.webp",
    beasttide: "assets/事迹_妖兽潮.webp",
    auction: "assets/事迹_散修拍卖会.webp",
    demonraid: "assets/事迹_魔道夺宝.webp",
    heartdemon: "assets/事迹_金丹心魔劫.webp",
  };
  return map[key] || "";
}

function codexBeastIcon(key) {
  const map = {
    wolf: "assets/妖兽_赤目狼王.webp",
    spider: "assets/妖兽_噬魂蛛后.webp",
    ape: "assets/妖兽_玄冰巨猿.webp",
    dragon: "assets/妖兽_幽冥蛟龙.webp",
    voidbeast: "assets/妖兽_虚空吞天兽.webp",
    tower_stone: "assets/妖兽_镇塔石灵.webp",
    tower_sword: "assets/妖兽_塔中剑魂.webp",
    tower_lord: "assets/妖兽_塔主无相.webp",
    starbeast: "assets/妖兽_星骸巨兽.webp",
    chaoslord: "assets/妖兽_混元守道人.webp",
  };
  return map[key] || "";
}

function codexRegionIcon(key) {
  const map = {
    region_ch0: "assets/秘境_青云山门.webp",
    region_ch1: "assets/秘境_幽谷魔渊.webp",
    region_ch2: "assets/秘境_昆仑之巅.webp",
    region_ch3: "assets/秘境_九幽冥海.webp",
    region_ch4: "assets/秘境_天外仙墟.webp",
    region_ch5: "assets/秘境_星陨古域.webp",
    region_ch6: "assets/秘境_混元道场.webp",
  };
  return map[key] || "";
}

function codexArtifactIcon(tier, type) {
  // 法宝图鉴图标：按类型返回对应装备图（品阶只影响颜色）
  const map = {
    attack: "assets/装备_本命.webp",
    defense: "assets/装备_护身.webp",
    support: "assets/装备_辅道.webp",
    relic: "assets/装备_古宝.webp",
    fabao: "assets/装备_法宝.webp",
  };
  return map[type] || "";
}

let currentTab = "home";
let battleLog = [];
// 增量渲染缓存（v0.9.0）：避免每秒整页 innerHTML 重建导致点击/滚动丢失
let _lastHtml = "";
let _homeSig = "";

// 修炼页「结构签名」：境界/层数/练功房/形貌/秘境章数/药力变化都需重建（v0.25.0）
function homeStructSig() {
  const fld = (typeof fieldClearCount === "function") ? fieldClearCount() : 0;
  return `${S.realm}_${S.layer}_${S.buildings.practice}_${S.avatar}_${fld}_${S.pillBuff || 0}`;
}
// 法宝库浏览状态（v0.10.0）：分页 / 筛选 / 排序（UI 态，不进存档）
let artifactPage = 0;
let artifactFilter = "all";
let artifactSort = "score";

function el(id) { return document.getElementById(id); }

function esc(s) { return String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

// 修炼速率显示（v0.26.0）：10 以下保留两位小数，避免 1.06 被显示成 1 让人误以为没加成
function rateText(n) { return n < 10 ? n.toFixed(2) : fmt(n); }

function toast(msg) {
  const t = el("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(t._t);
  t._t = setTimeout(() => t.classList.remove("show"), 1800);
}

function showModal(html) {
  // v0.48.0：所有弹窗统一右上关闭 + 点遮罩关闭，保证「归窗」有出路
  const wide = /class=["'][^"']*(?:inner-modal|ds-detail)/.test(html);
  el("modal").innerHTML = `<div class="modal-mask" data-close="1"><div class="modal-box${wide ? " modal-box-wide" : ""}">
    <button class="modal-x" data-action="closemodal" title="关闭">×</button>${html}</div></div>`;
  el("modal").style.display = "block";
}
function closeModal() {
  el("modal").style.display = "none";
  el("modal").innerHTML = "";
}

// ---------- 顶部资源条 ----------
let _topEls = null;
function renderTopbar() {
  if (!_topEls) _topEls = {
    qi: el("r-qi"), stone: el("r-stone"), mat: el("r-mat"),
    herb: el("r-herb"), pill: el("r-pill"), st: el("r-stamina"),
  };
  const setTxt = (node, val) => { if (node && node.textContent !== val) node.textContent = val; };
  setTxt(_topEls.qi, fmt(S.qi));
  setTxt(_topEls.stone, fmt(S.stone));
  setTxt(_topEls.mat, fmt(S.materials || 0));
  setTxt(_topEls.herb, fmt(S.herbs || 0));
  setTxt(_topEls.pill, fmt(S.pills || 0));
  setTxt(_topEls.st, Math.floor(S.stamina) + "/" + CONFIG.MAX_STAMINA);
}

// ---------- 视图切换 ----------
// 统一渲染入口：按 tab 产出 HTML（showView 与增量刷新共用，避免两处漂移）
function renderViewHtml(tab) {
  if (tab === "home") return viewHome();
  if (tab === "battle") return viewBattle();
  if (tab === "build") return viewBuild();
  if (tab === "world") return viewWorld();
  if (tab === "char") return viewChar();
  if (tab === "codex") return viewCodex();
  return "";
}

function showView(tab) {
  const switched = currentTab !== tab;
  currentTab = tab;
  document.querySelectorAll("#tabbar button").forEach(b => {
    b.classList.toggle("active", b.dataset.tab === tab);
  });
  const v = el("view");
  const html = renderViewHtml(tab);
  v.innerHTML = html;
  _lastHtml = html;
  _homeSig = tab === "home" ? homeStructSig() : "";
  renderTopbar();
  if (typeof updateTabBadges === "function") updateTabBadges();
  // 仅真正切换标签页时回到顶部；同页操作刷新保留原滚动位置
  if (switched && typeof window !== "undefined" && window.scrollTo) window.scrollTo(0, 0);
}

// ---------- 视图框架（v0.48.0 页头 / 分区 / 红点；v0.49.0 取消宫格，入口按场所唯一化） ----------
const TAB_DEFS = {
  home:   { name: "修炼", sub: "闭关吐纳 · 境界突破" },
  battle: { name: "历练", sub: "秘境探索 · 弟子驻守" },
  build:  { name: "洞府", sub: "经营建设 · 药园丹房" },
  world:  { name: "世界", sub: "坊市势力 · 天机机缘" },
  char:   { name: "人物", sub: "功法法宝 · 道侣灵兽" },
  codex:  { name: "道途", sub: "成就图鉴 · 生平事迹" },
};

function pageHeadHtml(tab) {
  const d = TAB_DEFS[tab] || { name: "", sub: "" };
  return `<div class="page-head"><span class="ph-name">${esc(d.name)}</span><span class="ph-sub">${esc(d.sub)}</span></div>`;
}

function secHeadHtml(title) {
  return `<div class="sec-head">${esc(title)}</div>`;
}

// 导航红点：每页是否有「可做之事」
function tabBadges() {
  const out = { home: false, battle: false, build: false, world: false, char: false, codex: false };
  try {
    if (typeof guideTick === "function") {
      const cur = guideCurrent();
      if (cur && guideStepDone(cur.def.key)) out[cur.def.tab] = true;
    }
    if (typeof claimableCount === "function" && claimableCount() > 0) out.world = true;
    if (typeof tunaLeftToday === "function" && tunaLeftToday() > 0) out.home = true;
    if (typeof danAnyReady === "function" && danAnyReady()) out.build = true;
    if (typeof S.qi === "number" && typeof CONFIG.breakCost === "function" && S.qi >= CONFIG.breakCost(kNow())) out.home = true;
    for (const b of CONFIG.BUILDINGS) {
      if ((S.realm || 0) < (b.unlockRealm || 0)) continue;
      if ((S.stone || 0) >= CONFIG.buildingCost(S.buildings[b.key] || 0)) { out.build = true; break; }
    }
    if ((S.stamina || 0) > 0) out.battle = true;
    if (CONFIG.GONGFA_BOOKS.some(b => !gongfaLearned(b.key) && gongfaUnlocked(b) && gongfaLearnReq(b.key).ok)) out.char = true;
    if ((S.artifacts || []).some(a => !slotOfArtifact(a.id))) out.char = true;
  } catch (e) { /* 红点失败不影响主流程 */ }
  return out;
}

function updateTabBadges() {
  const b = tabBadges();
  document.querySelectorAll("#tabbar .tab-dot").forEach(d => {
    d.classList.toggle("on", !!b[d.dataset.dot]);
  });
}

// v0.49.0：修炼页不再设功能宫格。
// 原「八宫格」（吐纳/日常/丹房/药园/化身/储物袋/炼器/宗门）与洞府页「建筑 + 生活 + 宗门 + 储物法器」、
// 世界页「日常」完全重叠，属同一功能两个入口。现按「场所即入口」归档：
//   · 修炼页 = 只放修炼行为（吐纳 / 突破 / 加成明细）
//   · 洞府页 = 丹房 / 药园 / 化身 / 炼器 / 宗门 / 储物袋（唯一入口）
//   · 世界页 = 日常与机缘（唯一入口）

// ---------- 内视：人物简图（v0.50.0） ----------
// 纯 SVG 线条绘制人体与三脉穴位，不依赖图片资源；已通＝金实心，下一穴＝朱砂描边
function meridianFigureSvg(interactive, flash) {
  const body = MERIDIAN_BODY_PATHS.map(d => `<path d="${d}" class="mi-body"/>`).join("");
  const data = meridianSvgData();
  const fx = flash && flash.key ? flash : null;
  const lines = data.map(m => {
    const pts = m.line.map(p => p.x + "," + p.y).join(" ");
    const hit = fx && fx.key === m.def.key ? " hit" : "";
    return `<polyline points="${pts}" class="mi-line ${m.def.key}${m.holes >= CONFIG.MERIDIAN.MAX_PER ? " full" : ""}${hit}"/>`;
  }).join("");
  const dots = data.map(m => m.pts.map((p, i) => {
    // v0.51.0：刚打通的穴位放一层扩散光环，让「打通」这一下有可见反馈
    const burst = (fx && fx.key === m.def.key && fx.idx === i) ? `<circle cx="${p.x}" cy="${p.y}" r="3" class="mi-burst"/>` : "";
    if (interactive && p.next) {
      return `<g class="mi-hot"><circle cx="${p.x}" cy="${p.y}" r="7.5" class="mi-hit" data-action="meridianopen" data-key="${m.def.key}"/>`
        + `<circle cx="${p.x}" cy="${p.y}" r="3" class="mi-dot-c next"/>`
        + `<text x="${p.x + 5}" y="${p.y + 2.5}" class="mi-label">${esc(p.name)}</text></g>`;
    }
    return burst + `<circle cx="${p.x}" cy="${p.y}" r="3" class="mi-dot-c ${p.on ? "on" : "off"}${burst ? " pop" : ""}"/>`;
  }).join("")).join("");
  return `<svg class="mi-svg" viewBox="0 0 120 200" preserveAspectRatio="xMidYMid meet" aria-label="内视经脉图">${body}${lines}${dots}</svg>`;
}

function innerCardHtml() {
  const tot = meridianTotal(), max = meridianMaxTotal();
  const dl = dantianLv();
  const sum = meridianSum();
  const pctv = v => "+" + Math.round(v * 100) + "%";
  const nx = (tot >= max) ? null : CONFIG.MERIDIANS.find(m => meridianHoles(m.key) < CONFIG.MERIDIAN.MAX_PER);
  const nxCost = nx ? meridianCost(nx.key) : null;
  // v0.51.0：下一穴真的付得起时给个「可开」提示，避免玩家不知道自己能变强了
  const canOpen = !!(nx && (S.realm || 0) >= nxCost.realm
    && (S.stone || 0) >= nxCost.stone && (S.materials || 0) >= nxCost.mat);
  const nextTxt = nx ? nx.name + "下一穴「" + meridianNextName(nx.key) + "」" : "三脉贯通 · 大周天已成";
  return `<div class="card inner-card">
    <div class="inner-figure" data-action="innerview">${meridianFigureSvg(false)}</div>
    <div class="inner-side">
      <div class="inner-title">内视${canOpen ? `<span class="inner-open-dot" aria-label="可开穴"></span>` : ""}</div>
      <div class="inner-row">经脉 <b>${tot}/${max}</b></div>
      <div class="inner-row">丹田 <b>${dl > 0 ? "九转 · 第 " + dl + " 转" : (dantianUnlocked() ? "未凝丹" : "未开（金丹期）")}</b></div>
      <div class="inner-row total">全属性 ${pctv(sum.atk)} ｜ 修炼 ${pctv(sum.cult)}${sum.trib > 0 ? " ｜ 渡劫 " + pctv(sum.trib) : ""}</div>
      <div class="inner-row muted">${esc(nextTxt)}${canOpen ? ` · <em class="inner-open-txt">可打通</em>` : ""}</div>
      <div class="inner-hint">点按人体 · 查看经脉 ›</div>
    </div>
  </div>`;
}

// 「本次开穴 / 本次升丹」的增量条：把 +2% 这种抽象数变成 12% → 14% 的前后对比
function innerDeltaHtml(delta) {
  if (!delta || !delta.before || !delta.after) return "";
  const pct = v => (v * 100).toFixed(1).replace(/\.0$/, "") + "%";
  const items = [
    ["属性", delta.before.atk, delta.after.atk],
    ["修炼", delta.before.cult, delta.after.cult],
    ["渡劫", delta.before.trib, delta.after.trib],
    ["真元", delta.before.mana, delta.after.mana],
  ].filter(x => Math.abs(x[2] - x[1]) > 1e-9);
  const rows = items.map(x => `<span class="idelta-item">${x[0]} <b>${pct(x[1])}</b> → <b class="up">${pct(x[2])}</b></span>`).join("");
  return `<div class="inner-delta">
    <div class="idelta-head">${esc(delta.label || "本次提升")}${delta.note ? `<span class="idelta-note">${esc(delta.note)}</span>` : ""}</div>
    <div class="idelta-body">${rows || `<span class="idelta-item muted">属性未变</span>`}</div>
  </div>`;
}

// 内视面板：经脉（三脉十八穴）+ 丹田（九转）
// opts: { flash: {key, idx}, delta: {before, after, label, note} } —— 开穴/升丹后传，用于播放反馈
function showInnerView(opts) {
  const opt = opts || {};
  const M = CONFIG.MERIDIAN, D = CONFIG.DANTIAN;
  const sum = meridianSum();
  const attrName = { atk: "攻击", def: "防御", hp: "气血" };
  const blocks = CONFIG.MERIDIANS.map(d => {
    const n = meridianHoles(d.key);
    const full = n >= M.MAX_PER;
    const c = meridianCost(d.key);
    const gain = M.PER_HOLE * n + (full ? M.ZHOUTIAN : 0);
    const cells = d.holes.map((h, i) =>
      `<span class="mr-hole ${i < n ? "on" : i === n ? "next" : ""}">${esc(h)}</span>`).join("");
    const gateOk = (S.realm || 0) >= c.realm;
    const canPay = (S.stone || 0) >= c.stone && (S.materials || 0) >= c.mat;
    return `<div class="mr-block">
      <div class="mr-head"><span>${esc(d.name)} · ${esc(d.alias)}</span><span>${n}/${M.MAX_PER} ｜ ${attrName[d.attr]} +${Math.round(gain * 100)}%${full ? " · 小周天" : ""}</span></div>
      <div class="mr-holes">${cells}</div>
      <div class="mr-next">${full ? "此脉已全通" : `下一穴「${esc(meridianNextName(d.key))}」：灵石 ${fmt(c.stone)} ｜ 灵材 ${c.mat} ｜ ${gateOk ? "境界已达" : "需" + CONFIG.REALMS[c.realm] + "期"}`}</div>
      ${full ? "" : `<button class="btn-sm" data-action="meridianopen" data-key="${d.key}" ${(gateOk && canPay) ? "" : "disabled"}>${gateOk ? "打通" : "境界不足"}</button>`}
    </div>`;
  }).join("");
  const dl = dantianLv();
  const dc = dantianCost();
  const danCan = dantianUnlocked() && dl < D.MAX && (S.stone || 0) >= dc.stone && (S.materials || 0) >= dc.mat;
  const danBlock = `<div class="mr-block">
    <div class="mr-head"><span>丹田 · 九转</span><span>${dl}/${D.MAX}</span></div>
    <div class="mr-next">${dl === 0 ? "尚未凝丹：金丹期可引气归元，凝为金丹" : `每阶：修炼 +${Math.round(D.CULT * 100)}% ｜ 真元 +${D.MANA} ｜ 渡劫 +${(D.TRIB * 100).toFixed(1)}%`}</div>
    ${dl >= D.MAX ? `<div class="mr-next">丹已九转，圆满</div>` : `<div class="mr-next">下一阶：灵石 ${fmt(dc.stone)} ｜ 灵材 ${dc.mat}</div>`}
    ${dl >= D.MAX ? "" : `<button class="btn-sm" data-action="dantianraise" ${danCan ? "" : "disabled"}>${!dantianUnlocked() ? "未到金丹期" : (dl === 0 ? "凝丹" : "升阶")}</button>`}
  </div>`;
  showModal(`<div class="result inner-modal">
    <div class="result-title">内视</div>
    <div class="inner-fig-big">${meridianFigureSvg(true, opt.flash)}</div>
    ${innerDeltaHtml(opt.delta)}
    <div class="result-line">经脉 <b>${meridianTotal()}/${meridianMaxTotal()}</b> ｜ 属性 +${Math.round(sum.atk * 100)}% ｜ 修炼 +${Math.round(sum.cult * 100)}% ｜ 渡劫 +${(sum.trib * 100).toFixed(1)}%</div>
    <div class="sec-title small">经脉 · 三脉十八穴</div>
    ${blocks}
    <div class="sec-title small">丹田</div>
    ${danBlock}
    <div class="tip">点穴与丹阶必成，只吃灵石与灵材；境界是硬门槛，灵石是唯一节流阀。图上金色为已通、朱砂描边为下一穴，点它即可打通。</div>
    <button class="btn-primary" data-action="closemodal">收功</button>
  </div>`);
}

// ---------- 炼器坊总面板（v0.50.0：炼制法宝 / 古宝升星 / 古宝注灵 三区合一） ----------
// 器物养成的唯一入口：升星与注灵不再散落在图鉴里
function showCraftPanel() {
  const A = CONFIG.ANCIENT;
  const cap = forgeMaxTier();
  const owned = CONFIG.ANCIENT_TREASURES.filter(a => ancientOwned(a.key));
  const starRows = owned.map(it => {
    const d = ancientDef(it.key);
    const star = ancientStar(it.key);
    const need = star * A.STAR_FRAG;
    const frag = ancientFragCount(d.set);
    const setName = (ancientSetDef(d.set) || { name: "" }).name;
    return `<div class="shop-row">
      <span class="shop-body"><b>${esc(it.name)}</b><span class="shop-desc">${esc(setName)} ｜ ${"★".repeat(star)}${"☆".repeat(A.MAX_STAR - star)} ｜ 碎片 ${frag}</span></span>
      <button class="btn-sm" data-action="ancstar" data-key="${it.key}" ${(star >= A.MAX_STAR || frag < need) ? "disabled" : ""}>${star >= A.MAX_STAR ? "满星" : "升星（" + need + "）"}</button>
    </div>`;
  }).join("") || `<div class="build-out muted">尚无可升星古宝：首探秘境可得古宝，击杀章 BOSS 得碎片</div>`;
  const infRows = owned.map(it => {
    const inf = ancientInfuse(it.key);
    return `<div class="shop-row">
      <span class="shop-body"><b>${esc(it.name)}</b><span class="shop-desc">注灵 Lv.${inf}/${A.INFUSE_MAX}</span></span>
      <button class="btn-sm" data-action="ancinfuse" data-key="${it.key}" ${(inf >= A.INFUSE_MAX || (S.materials || 0) < A.INFUSE_MAT || (S.stone || 0) < A.INFUSE_STONE) ? "disabled" : ""}>${inf >= A.INFUSE_MAX ? "已满" : "注灵"}</button>
    </div>`;
  }).join("") || `<div class="build-out muted">尚无可注灵古宝</div>`;
  showModal(`<div class="result">
    <div class="result-title">⛩ 炼器坊</div>
    <div class="result-line">灵材 ${fmt(S.materials || 0)} ｜ 灵石 ${fmt(S.stone)} ｜ 炼器坊 Lv.${S.buildings.forge}（可炼至 ${tierInfo(cap).name}）</div>
    <div class="sec-title small">炼制法宝</div>
    <div class="shop-row">
      <span class="shop-body"><b>开炉炼制</b><span class="shop-desc">消耗灵材与灵石；二品以上有概率携「器韵」成套装</span></span>
      <button class="btn-sm" data-action="openforge">炼制</button>
    </div>
    <div class="sec-title small">古宝升星（消耗套装碎片）</div>
    ${starRows}
    <div class="sec-title small">古宝注灵（${A.INFUSE_MAT} 灵材 + ${A.INFUSE_STONE} 灵石）</div>
    ${infRows}
    <div class="tip">器物养成统一在炼器坊：升星与注灵不散落在图鉴里；碎片合成仍在储物袋。</div>
    <button class="btn-primary" data-action="closemodal">离炉</button>
  </div>`);
}

// ---------- 洞府（主页） ----------
function viewHome() {
  const k = kNow();
  const cost = CONFIG.breakCost(k);
  const rate = cultivationRate();
  const cb = cultivationBreakdown();
  const pct = Math.min(100, (S.qi / cost) * 100);
  const maxed = isMaxRealm();
  const isTrib = S.layer === CONFIG.LAYERS_PER_REALM - 1;  // 第9层：下次突破为渡劫
  const tunaLeft = (typeof tunaLeftToday === "function") ? tunaLeftToday() : 0;
  // 加成摘要：只列偏离 1 的乘区，避免噪音
  const brief = [];
  if (cb.practiceLv > 0) brief.push(`练功房 ×${cb.practice.toFixed(2)}`);
  if (cb.gongfa > 1.001) brief.push(`功法 ×${cb.gongfa.toFixed(2)}`);
  if (cb.pillLayers > 0) brief.push(`药力 ×${cb.pill.toFixed(2)}`);
  if (cb.fieldChapters > 0) brief.push(`秘境 +${Math.round((cb.field - 1) * 100)}%`);
  return `
    <div class="view home">
      <div class="bg-cover" style="background-image:url('assets/洞府主背景.webp')"></div>
      <div class="content">
        ${pageHeadHtml("home")}
        <div class="realm-title">
          <div class="dao-name">${esc(S.playerName || "无名散修")}</div>
          <div class="realm-name">${realmName()}期</div>
          <div class="realm-layer">第${S.layer + 1}层${isTrib ? " · 雷劫将至" : ""}</div>
        </div>
        ${innerCardHtml()}
        <div class="qi-panel">
          <div class="qi-label">灵气 <span class="qi-rate" data-bind="rate">${rateText(rate)}/秒</span><span class="qi-more" data-action="cultdetail">加成明细 ›</span></div>
          <div class="qi-bar"><div class="qi-fill" data-bind="qi-fill" style="width:${pct}%"></div></div>
          <div class="qi-nums" data-bind="qi-nums">${fmt(S.qi)} / ${fmt(cost)}</div>
          <div class="cult-brief">在线修炼 ${fmt(rate)}/秒 ｜ 普通离线 ${fmt(offlineCultivationRate())}/秒（${Math.round(CONFIG.OFFLINE_RATE * 100)}%基础效率）</div>
          ${brief.length ? `<div class="cult-brief">${brief.join(" ｜ ")}</div>` : `<div class="cult-brief muted" data-action="tab" data-tab="build">尚无加成 · 去「洞府」建练功房（+7%/级）或探明秘境（+1%/章）›</div>`}
          ${(typeof nextStepHint === "function" && nextStepHint()) ? `<div class="next-hint" data-action="tab" data-tab="${nextStepHint().tab}">下一步：${esc(nextStepHint().text)} ›</div>` : ""}
        </div>
        ${typeof guideCardHtml === "function" ? guideCardHtml() : ""}
        <div class="actions">
          ${maxed
            ? ""
            : (tunaLeft > 0
              ? `<button class="btn-sm tuna-line" data-action="tuna">☯ 吐纳养气（今日剩 ${tunaLeft} 次）</button>`
              : `<button class="btn-sm tuna-line" data-action="tuna" disabled>☯ 今日吐纳已满</button>`)}
          ${maxed
            ? `<button class="btn-primary big" data-action="ascend">渡劫飞升</button>`
            : isTrib
              ? `<button class="btn-primary big trib" data-action="break" data-bind="break-btn" ${(S.qi >= cost && (S.soulHurtUntil || 0) <= Date.now()) ? "" : "disabled"}>⚡ 渡劫（成功率 ${(tribulationRate() * 100).toFixed(0)}%）</button>
                 ${(S.soulHurtUntil || 0) > Date.now() ? `<div class="tip trib-tip">元神受损：${Math.ceil(((S.soulHurtUntil || 0) - Date.now()) / 60000)} 分钟后可再渡劫</div>` : ""}
                 ${S.tribPillBuff > 0 ? `<div class="tip trib-tip">渡劫丹加成 ×${S.tribPillBuff}（+${CONFIG.TRIB_PILL_BONUS * 100}%/枚）已就绪</div>` : ""}
                 ${S.tribFails > 0 ? `<div class="tip trib-tip">此前连败 ${S.tribFails} 次${S.tribFails >= CONFIG.TRIB_PITY - 1 ? " · 心境圆融，下次必成" : ""}</div>` : ""}`
              : `<button class="btn-primary big" data-action="break" data-bind="break-btn" ${S.qi >= cost ? "" : "disabled"}>突破境界</button>`}
        </div>
        <div class="tip">离线也会自动修炼（上限 8 小时）；跨大境界需渡劫，失败损失灵气但不灭道心。</div>
      </div>
    </div>`;
}

// 修炼加成明细（v0.25.0）：乘区唯一来源 cultivationBreakdown()，此处只读不重算
function showCultDetail() {
  const b = cultivationBreakdown();
  const pct = v => (v >= 1 ? "+" + Math.round((v - 1) * 100) + "%" : Math.round((v - 1) * 100) + "%");
  const rows = [
    ["基础修炼（境界/层数）", fmt(b.base) + "/秒", ""],
    ["练功房 Lv." + b.practiceLv, pct(b.practice), "每级 +" + Math.round(CONFIG.PRACTICE_RATE_BONUS * 100) + "%" + (b.practiceDisc > 1 ? "，弟子 ×" + b.practiceDisc.toFixed(2) : "；派弟子入驻可再加速")],
    ["功法与道体", pct(b.gongfa), "十阶功法 + 形貌倾向"],
    ["药力 " + b.pillLayers + " 层", pct(b.pill), "每层 +" + Math.round(CONFIG.PILL_RATE_BONUS * 100) + "%"],
    ["势力庇护", pct(b.bless), "青云门关系达标 +10%"],
    ["辅道法宝", pct(b.art), "辅道件 / 词条"],
    ["道心剧本", pct(b.story), "章节「守心问道」"],
    ["秘境探明 " + b.fieldChapters + "/" + CONFIG.CHAPTERS.length + " 章", pct(b.field), "每章 +" + Math.round(CONFIG.FIELD_CLEAR_CULT_BONUS * 100) + "%"],
    ["经脉与丹田", pct(b.meridian), "三脉周天 " + meridianTotal() + "/" + meridianMaxTotal() + " ｜ 丹田 " + dantianLv() + "/" + CONFIG.DANTIAN.MAX],
  ].map(r => `
    <div class="shop-item">
      <span>${esc(r[0])}</span>
      <span><b>${esc(r[1])}</b>${r[2] ? ` <span class="muted">${esc(r[2])}</span>` : ""}</span>
    </div>`).join("");
  showModal(`
    <div class="result">
      <div class="result-title">修炼加成明细</div>
      <div class="result-line">在线修炼 <b>${fmt(b.total)}/秒</b> ｜ 普通离线 <b>${fmt(offlineCultivationRate())}/秒</b></div>
      <div class="result-line muted-line">普通离线按在线修炼速率的 ${Math.round(CONFIG.OFFLINE_RATE * 100)}% 结算，基础上限 ${Math.round(CONFIG.OFFLINE_CAP_SEC / 3600)} 小时；闭关功法加成已计入上方离线速率。</div>
      <div class="shop-list">${rows}</div>
      <div class="tip">练功房与秘境探明为常驻加成；药力随服丹累积；全部乘区仅此一处计算。</div>
      <button class="btn-primary" data-action="closemodal">明白了</button>
    </div>`);
}

// 洞府页动态更新（v0.9.0 增量渲染）：
// 每秒只改灵气/进度/按钮可用态这几个节点，不重建整页，
// 这样玩家连续点击「突破」时按钮不会被中途替换掉。
function updateHomeDynamic() {
  const v = el("view");
  if (!v || typeof v.querySelector !== "function") return;
  const cost = CONFIG.breakCost(kNow());
  const rate = cultivationRate();
  const pct = Math.min(100, (S.qi / cost) * 100);
  const q = sel => v.querySelector(sel);

  const rateEl = q("[data-bind=rate]");
  if (rateEl) {
    const s = rateText(rate) + "/秒";
    if (rateEl.textContent !== s) rateEl.textContent = s;
  }
  const numsEl = q("[data-bind=qi-nums]");
  if (numsEl) {
    const s = fmt(S.qi) + " / " + fmt(cost);
    if (numsEl.textContent !== s) numsEl.textContent = s;
  }
  const bar = q("[data-bind=qi-fill]");
  if (bar && bar.style) {
    const w = pct + "%";
    if (bar.style.width !== w) bar.style.width = w;
  }
  const btn = q("[data-bind=break-btn]");
  if (btn) {
    const shouldDisable = S.qi < cost;
    if (btn.disabled !== shouldDisable) btn.disabled = shouldDisable;
  }
}

// 章节背景（v0.14.0 配图）：按当前推进章节取图，章节缺失时回退第 1 章
function chapterBg(stage) {
  const ch = Math.min(CONFIG.chapterOf(stage), CONFIG.CHAPTERS.length - 1);
  const def = CONFIG.CHAPTERS[ch];
  return (def && def.bg) || "assets/秘境_青云山门.webp";
}

// ---------- 秘境地图列表（v0.17.0）----------
function discipleRealmName(d) {
  const idx = Math.min(d.realm || 0, CONFIG.REALMS.length - 1);
  return CONFIG.REALMS[idx] + "期";
}

// 章内关卡范围与进度（v0.26.0：分关「已通关可重刷」列表合并进秘境条目）
function chapterStageRange(ch) {
  const per = CONFIG.STAGES_PER_CHAPTER + 1;
  return { start: ch * per, end: ch * per + per - 1 };
}
function chapterProgress(ch) {
  const r = chapterStageRange(ch);
  const done = Math.max(0, Math.min(S.bestStage - r.start, r.end - r.start + 1));
  return { done, total: r.end - r.start + 1, bossStage: r.end };
}

// 章节五行与克制关系提示（v0.36.0）
function mapElementTag(ch) {
  if (typeof elementDef !== "function") return "";
  const el = CONFIG.CHAPTER_ELEMENTS[ch];
  if (!el) return "";
  const d = elementDef(el);
  const me = (typeof mainElement === "function") ? mainElement() : null;
  let rel = "";
  if (me) {
    if (elementBeats(me, el)) rel = " ｜ 我方克制（伤害 +" + Math.round(CONFIG.ELEMENT_COUNTER * 100) + "%）";
    else if (elementBeats(el, me)) rel = " ｜ 被克制（伤害 -" + Math.round(CONFIG.ELEMENT_COUNTERED * 100) + "%）";
    else rel = " ｜ 同源无克制";
  } else rel = " ｜ 未定流派";
  return "此域妖兽属 <b>" + esc(d.name) + "</b>" + esc(rel);
}

function viewFieldMaps() {
  const rows = [];
  const bestCh = CONFIG.chapterOf(Math.min(S.bestStage, CONFIG.CHAPTERS.length * (CONFIG.STAGES_PER_CHAPTER + 1) - 1));
  for (let ch = 0; ch < CONFIG.CHAPTERS.length; ch++) {
    const map = CONFIG.fieldMap(ch);
    const unlocked = fldChapterUnlocked(ch);
    const cleared = !!(S.clearedMaps && S.clearedMaps[ch]);
    const team = dispatchTeam(ch);
    const total = map.spawn + map.elite + (map.boss ? 1 : 0);
    const thumb = map.bg || "assets/秘境_青云山门.webp";
    const prog = chapterProgress(ch);
    const edu = typeof fieldEducationStatus === "function" ? fieldEducationStatus(ch) : { percent: 0, private: false };
    // v0.49.0：一章一个入口组。未通关 → 入秘境 + 速战（推进下一关）；
    // 已通关 → 只留驻守（速战对已探明章无意义，弟子驻守才是产出来源）
    const isCurrent = unlocked && !cleared && ch === bestCh;
    const nextStage = isCurrent ? S.bestStage : -1;
    rows.push(`
      <div class="map-row ${unlocked ? "" : "locked"}">
        <div class="map-thumb"><img src="${thumb}" alt=""></div>
        <div class="map-info">
          <span class="map-name">${esc(map.name)}${unlocked ? `<span class="map-prog">第 ${prog.done}/${prog.total} 关</span>` : ""}</span>
          <span class="map-meta">${cleared ? (S.lostFields && S.lostFields[ch] ? "旧版失守记录（可赎回）" : "已探明") : unlocked ? "可探索" : "未解锁"} ｜ 妖兽 ${total} ｜ 采集点 ${CONFIG.FIELD_MAP_NODES[ch]}</span>
          ${cleared ? `<span class="map-dispatch">${edu.private ? "◆ 已教化 · 私有秘境" : `教化 ${edu.percent.toFixed(1)}% · ${team.length ? "驻守持续推进" : "无人驻守时缓慢侵蚀"}`}</span>` : ""}
          <span class="map-element">${mapElementTag(ch)}</span>
          ${isCurrent ? `<span class="map-next">下一关 ${esc(stageName(nextStage))}${CONFIG.isBoss(nextStage) ? " · BOSS" : ""} ｜ 推荐战力 ${fmt(enemyPower(nextStage))} ｜ 怪攻 ${fmt(CONFIG.enemyAttack(nextStage))} ｜ 怪血 ${fmt(CONFIG.enemyHp(nextStage))}</span>` : ""}
          ${cleared ? `<span class="map-dispatch">驻守 ${team.length} 人${team.length ? " ｜ 领地 +1 ｜ " + dispatchText(ch) + (dispatchSettleReady(ch) ? " ｜ <em class=\"settle-dot\">可出结算单</em>" : "") : " ｜ 派弟子驻守可获资源与教化"}</span>` : ""}
        </div>
        <div class="map-btns">
          ${unlocked ? `<button class="btn-sm" data-action="entermap" data-ch="${ch}">入秘境</button>` : ""}
          ${cleared && S.lostFields && S.lostFields[ch]
            ? `<button class="btn-sm" data-action="ransom" data-ch="${ch}">赎回（${fmt(ransomCost(ch))}石）</button>`
            : ""}
          ${cleared && !(S.lostFields && S.lostFields[ch]) ? `<button class="btn-sm" data-action="dispatch" data-ch="${ch}">${team.length ? "驻守队伍" : "驻守"}</button>` : ""}
          ${isCurrent ? `<button class="btn-sm" data-action="battle" data-n="${nextStage}">速战（体力 -1）</button>` : ""}
        </div>
      </div>`);
  }
  return `<div class="card field-maps">
    <div class="build-head"><span>秘境</span><span>探索 · 采集 · 驻守</span></div>
    <div class="build-desc">每处秘境只有一个入口组：未探明时「入秘境」亲征或「速战」推进，探明后转为「驻守」派弟子持续产出。自由走位打怪，采集矿脉/灵脉/灵植/遗迹；探索度满 100 即通关。</div>
    ${rows.join("")}
  </div>`;
}

// ---------- 派遣弹窗 ----------
function showDispatchModal(ch) {
  const map = CONFIG.fieldMap(ch);
  const team = dispatchTeam(ch);
  const D = CONFIG.DISPATCH;
  const settlement = fieldSettlementOf(ch, true);
  const localFolk = settlement ? settlement.population : 0;
  const localFolkCap = fieldSettlementCap(ch);

  const teamRows = team.map(id => {
    const d = S.disciples.find(x => x.id === id);
    if (!d) return "";
    return `<div class="shop-row">
      <span class="shop-body"><b>${esc(d.name)}</b><span class="shop-desc">${discipleRealmName(d)} ｜ 忠诚 ${Math.round(d.loyalty)} ｜ 系数 ${dispatchRateOne(d).toFixed(3)}</span></span>
      <button class="btn-sm" data-action="unmap" data-ch="${ch}" data-id="${id}">撤回</button>
    </div>`;
  }).join("") || `<div class="build-out muted">尚未派遣弟子</div>`;

  const cands = S.disciples.filter(d => team.indexOf(d.id) < 0);
  const candRows = cands.map(d => `<div class="shop-row">
      <span class="shop-body"><b>${esc(d.name)}</b><span class="shop-desc">${discipleRealmName(d)} ｜ ${specialtyInfo(d.specialty).name} ｜ 忠诚 ${Math.round(d.loyalty)}</span></span>
      <button class="btn-sm" data-action="mapassign" data-ch="${ch}" data-id="${d.id}">驻守</button>
    </div>`).join("") || `<div class="build-out muted">无可派弟子（先去洞府招募）</div>`;

  const vein = fieldVeinLv(ch);
  const veinCost = fieldVeinCost(ch);
  const veinMax = CONFIG.FIELD_VEIN.MAX;
  const veinHtml = vein >= veinMax
    ? `<div class="build-out">灵脉已至 Lv.${veinMax}（圆满）</div>`
    : `<div class="shop-row">
        <span class="shop-body"><b>灵脉 Lv.${vein}</b><span class="shop-desc">每级驻守产出 +${Math.round(CONFIG.FIELD_VEIN.RATE_BONUS * 100)}%，并衍生凡人聚落（灵草 +${CONFIG.FIELD_VEIN.FOLK_RATE.toFixed(2)}/级/秒）</span></span>
        <button class="btn-sm" data-action="upgradevein" data-ch="${ch}">升级（${veinCost} 灵石 · ${laborNeed(vein + 1)} 灵脉师）</button>
      </div>`;

  // v0.51.0：收益明细（弟子贡献 + 倍率链）与驻守结算单
  const dtl = dispatchDetail(ch);
  const stl = dtl.settle;
  const stlLeft = Math.max(0, Math.ceil(CONFIG.DISPATCH.SETTLE_MIN_SEC - stl.sec));
  const offlineNormal = dispatchOfflineRate(ch, false);
  const offlineIncense = dispatchOfflineRate(ch, true);
  const stlHas = (stl.stone + stl.qi + stl.herb + stl.material + stl.folk) > 0;
  const detailHtml = `<div class="ds-detail">
      <div class="ds-rate">在线每秒：灵石 <b>${dtl.rate.stone.toFixed(2)}</b> ｜ 灵气 <b>${dtl.rate.qi.toFixed(2)}</b> ｜ 灵草 <b>${dtl.rate.herb.toFixed(3)}</b> ｜ 灵材 <b>${dtl.rate.material.toFixed(3)}</b>${dtl.rate.folk > 0 ? ` ｜ 凡人 <b>${dtl.rate.folk.toFixed(3)}</b>` : ""}</div>
      <div class="ds-rate">普通离线：灵石 <b>${offlineNormal.stone.toFixed(2)}</b>/秒 ｜ 灵气 <b>${offlineNormal.qi.toFixed(2)}</b>/秒 ｜ 灵草 <b>${offlineNormal.herb.toFixed(3)}</b>/秒 ｜ 灵材 <b>${offlineNormal.material.toFixed(3)}</b>/秒</div>
      <div class="ds-rate">引魔香离线：灵石 <b>${offlineIncense.stone.toFixed(2)}</b>/秒 ｜ 灵气 <b>${offlineIncense.qi.toFixed(2)}</b>/秒 ｜ 灵草 <b>${offlineIncense.herb.toFixed(3)}</b>/秒 ｜ 灵材 <b>${offlineIncense.material.toFixed(3)}</b>/秒</div>
      <div class="ds-settle-tip">驻守离线折算：普通为在线的 ${(offlineNormal.factor * 100).toFixed(1)}%，引魔香为 ${(offlineIncense.factor * 100).toFixed(1)}%；离线闭关功法加成另计。</div>
      <div class="ds-chain">${dtl.chain.map(c => `<span class="ds-chain-item">${esc(c.name)} ×${c.mul.toFixed(2)}<em>${esc(c.note)}</em></span>`).join("")}</div>
      ${dtl.team.length ? dtl.team.map(m => `<div class="ds-mem">
        <b>${esc(m.name)}</b>
        <span>${esc(m.realmName)} ｜ 忠诚 ${m.loyalty}${m.tags.length ? " ｜ " + m.tags.join("/") : ""} ｜ 系数 ${m.k.toFixed(3)} ｜ 占产出 ${Math.round(m.share * 100)}%</span>
      </div>`).join("") : `<div class="build-out muted">无弟子驻守 · 收益为 0，先派人进来</div>`}
    </div>`;
  const settleHtml = `<div class="ds-settle">
      <div class="ds-settle-row">已累计 <b>${dsDur(stl.sec)}</b>${stlHas ? ` ｜ 灵石 ${fmt(stl.stone)} ｜ 灵气 ${fmt(stl.qi)} ｜ 灵草 ${fmt(stl.herb)} ｜ 灵材 ${fmt(stl.material)}${stl.folk >= 1 ? " ｜ 凡人 +" + Math.floor(stl.folk) : ""}` : " ｜ 暂无产出"}</div>
      <div class="ds-settle-tip">产出每秒实时入账，结算单只汇总账目并记入世界大事，不会重复发放。</div>
      ${dtl.settleReady
        ? `<button class="btn-sm" data-action="dispatchsettle" data-ch="${ch}">出结算单</button>`
        : `<div class="ds-settle-wait">满 ${CONFIG.DISPATCH.SETTLE_MIN_SEC} 秒可出单${stlLeft > 0 ? `（还需 ${stlLeft} 秒）` : "（暂无产出）"}</div>`}
    </div>`;

  showModal(`
    <div class="result">
      <div class="result-title">驻守 · ${esc(map.name)}</div>
      <div class="result-line">产出：${esc(dispatchText(ch))}</div>
      <div class="sec-title small">秘境教化</div>
      ${(() => {
        const e = fieldEducationStatus(ch);
        return `<div class="ds-detail"><div class="ds-rate">${e.private ? "◆ 教化完成：此秘境已私有化，外部势力不再侵蚀。" : `教化进度 <b>${e.percent.toFixed(1)}%</b> ｜ 有效驻守 ${e.members} 人 ｜ ${e.ratePerHour >= 0 ? `预计每小时 +${e.ratePerHour.toFixed(2)}%` : `当前每小时侵蚀 ${Math.abs(e.ratePerHour).toFixed(2)}%`}`}</div>
          <div class="ds-rate">累计驻守 ${dsDur(e.totalGuardSec)}；第二名驻守弟子贡献为60%，第三名55%，后续边际递减。成功完成「传道四方」额外增加 ${(CONFIG.FIELD_EDUCATION.PREACH_BONUS * 100).toFixed(0)}% 教化。</div>
          ${!e.private ? `<div class="ds-rate">${e.remainingHours === null ? "当前教化无法自然推进，请恢复驻守并维持安定。" : `按当前在线驻守阵容，预计还需 ${e.remainingHours.toFixed(1)} 小时完成。离线按驻守效率折算。`}</div>` : ""}</div>`;
      })()}
      <div class="sec-title small">收益明细</div>
      ${detailHtml}
      <div class="sec-title small">驻守结算</div>
      ${settleHtml}
      <div class="result-line muted-line">资源点刷新：${team.length ? "剩余 " + dispatchNodeLeft(ch) + " 秒（每次产灵材/灵草并写入世界大事）" : "驻守后每 " + CONFIG.DISPATCH.NODE_INTERVAL + " 秒刷新一次采集点"}</div>
      <div class="result-line muted-line">弟子驻守此地 = 你的领地 +1 ｜ 灵植/丹道专精 +50%，情谊嫡传 +20%；每名弟子同一时间只能驻守一处秘境</div>
      <div class="result-line">安定度 <b>${fieldStableOf(ch)}</b>/100${fieldStableOf(ch) < CONFIG.STABLE.LOW ? "（低于 " + CONFIG.STABLE.LOW + "，产出减半！）" : ""} ｜ 神庙 Lv.${fieldTempleLv(ch)}</div>
      <div class="result-line">凡人聚集地：<b>${esc(settlement ? settlement.name : map.name + "聚落")}</b> ｜ 本地人口 ${Math.floor(localFolk)}/${localFolkCap} ｜ 全境人口 ${Math.floor(S.folk || 0)}/${folkCap()}</div>
      <div class="result-line muted-line">人口来源：本地弟子驻守繁衍；「传道四方」任务可为驻守聚落带来人口。建设与收徒优先消耗本地人口。</div>
      ${typeof fieldSocietySummary === "function" ? (() => { const society = fieldSocietySummary(ch); return `<div class="sec-title small">凡人家园</div><div class="result-line">家庭：约 ${society.marriedCouples} 对已婚夫妇 ｜ 儿童 ${society.children} 人 ｜ 累计出生 ${society.births} 人</div><div class="result-line">聚落公库：${society.treasury.toFixed(2)} 灵石 ｜ 今日生活消费：${society.lastConsumption.toFixed(2)} / ${society.dailyDemand.toFixed(2)} 灵石</div><div class="result-line muted-line">公库收入来自本地驻守灵石产出的1.5%留成（已从玩家本次收益扣除）；凡人每日按人均0.05灵石计基本生活消费。累计消费 ${society.consumptionPaid.toFixed(2)}，历史未满足需求 ${society.consumptionShortfall.toFixed(2)}。婚育为聚落级模拟估算。</div>`; })() : ""}
      <div class="sec-title small">秘境建设</div>
      <div class="shop-list">${veinHtml}${(function () {
        const mine = fieldMineLv(ch), garden = fieldGardenLv(ch);
        const cap = CONFIG.FIELD_VEIN.MAX;
        const mineCost = fieldBuildCost(mine), gardenCost = fieldBuildCost(garden);
        return `
          <div class="shop-row">
            <span class="shop-body"><b>矿场 Lv.${mine}</b><span class="shop-desc">每级驻守灵石产出 +${Math.round(CONFIG.FIELD_BUILD.MINE_RATE * 100)}%</span></span>
            ${mine >= cap ? `<span class="muted">已满级</span>` : `<button class="btn-sm" data-action="upgrademine" data-ch="${ch}">升级（${mineCost} 灵石 · ${laborNeed(mine + 1)} 矿工）</button>`}
          </div>
          <div class="shop-row">
            <span class="shop-body"><b>药圃 Lv.${garden}</b><span class="shop-desc">每级驻守灵草产出 +${Math.round(CONFIG.FIELD_BUILD.GARDEN_RATE * 100)}%</span></span>
            ${garden >= cap ? `<span class="muted">已满级</span>` : `<button class="btn-sm" data-action="upgradegarden" data-ch="${ch}">升级（${gardenCost} 灵石 · ${laborNeed(garden + 1)} 药农）</button>`}
          </div>`;
      })()}
        <div class="shop-row">
          <span class="shop-body"><b>神庙 Lv.${fieldTempleLv(ch)}</b><span class="shop-desc">每级：安定 +15、凡人繁衍 +${Math.round(CONFIG.STABLE.TEMPLE_CHANCE * 100)}%（安抚民心，抵御妖兽余孽与势力骚扰）</span></span>
          ${fieldTempleLv(ch) >= CONFIG.STABLE.TEMPLE_MAX
            ? `<span class="muted">已满级</span>`
            : `<button class="btn-sm" data-action="temple" data-ch="${ch}">建庙（${fmt(templeCost(ch).stone)} 灵石 · ${templeCost(ch).labor} 凡人）</button>`}
        </div>
        <div class="shop-row">
          <span class="shop-body"><b>安抚秘境</b><span class="shop-desc">祭祀犒赏，安定 +${CONFIG.STABLE.SOOTHE_ADD}（每次 ${CONFIG.STABLE.SOOTHE_STONE} 灵石）</span></span>
          <button class="btn-sm" data-action="soothe" data-ch="${ch}">安抚</button>
        </div>
        <div class="shop-row">
          <span class="shop-body"><b>弟子职务 · ${esc(staffSummary(ch))}</b><span class="shop-desc">${CONFIG.STAFF.OFFICES.map(o => o.name + "：" + o.desc).join("；")}</span></span>
        </div>
        <div class="build-row">
          ${CONFIG.STAFF.OFFICES.map(o => `<button class="btn-sm" data-action="appoint" data-ch="${ch}" data-office="${o.key}">任${o.name}</button>`).join("")}
        </div>
      </div>
      ${typeof fieldCommercePanelHtml === "function" ? fieldCommercePanelHtml(ch) : ""}
      <div class="sec-title small">已驻守（${team.length}人 · 不设秘境人数上限）</div>
      <div class="shop-list">${teamRows}</div>
      <div class="sec-title small">可选弟子</div>
      <div class="shop-list">${candRows}</div>
      <button class="btn-primary" data-action="closemodal">离开</button>
    </div>`);
}

// 驻守结算单（v0.51.0）：一次挂机的账目快照。资源已实时入账，这里只呈现与记账
function showSettleModal(ch, rs) {
  const map = CONFIG.fieldMap(ch);
  const rec = rs.rec || { sec: 0, stone: 0, qi: 0, herb: 0, material: 0, folk: 0 };
  const r = dispatchRate(ch);
  const team = dispatchTeam(ch).map(id => S.disciples.find(x => String(x.id) === String(id))).filter(Boolean);
  const rows = [
    { name: "灵石", got: rec.stone, rate: r.stone },
    { name: "灵气", got: rec.qi, rate: r.qi },
    { name: "灵草", got: rec.herb, rate: r.herb },
    { name: "灵材", got: rec.material, rate: r.material },
  ].filter(x => x.got > 0).map(x => `<div class="set-row"><span>${x.name}</span><b>+${fmt(x.got)}</b><em>${x.rate.toFixed(2)}/秒</em></div>`).join("");
  const folkRow = rec.folk >= 1 ? `<div class="set-row"><span>凡人</span><b>+${Math.floor(rec.folk)}</b><em>${r.folk.toFixed(2)}/秒</em></div>` : "";
  const avg = rec.sec > 0 ? (rec.stone / rec.sec) : 0;
  showModal(`<div class="result">
    <div class="result-title">驻守结算 · ${esc(map.name)}</div>
    <div class="result-line">驻守时长 <b>${dsDur(rec.sec)}</b> ｜ 驻守弟子 ${team.length} 名${team.length ? "（" + team.map(d => esc(d.name)).join("、") + "）" : ""}</div>
    <div class="sec-title small">账目</div>
    <div class="set-list">${rows}${folkRow}</div>
    <div class="result-line muted-line">均灵石 ${avg.toFixed(2)}/秒 ｜ 产出已随每秒结算入账，此单仅为账目汇总并已记入世界大事</div>
    <div class="result-line muted-line">下一张结算单：再累计满 ${CONFIG.DISPATCH.SETTLE_MIN_SEC} 秒即可</div>
    <button class="btn-sm" data-action="dispatch" data-ch="${ch}">回驻守</button>
    <button class="btn-primary" data-action="closemodal">收单</button>
  </div>`);
}

// ---------- 历练（战斗） ----------
function viewBattle() {
  const next = S.bestStage;   // 下一待挑战关卡
  const ch = CONFIG.chapterOf(next);
  const chName = CONFIG.CHAPTERS[Math.min(ch, CONFIG.CHAPTERS.length - 1)].name;
  const canChallenge = next < CONFIG.CHAPTERS.length * (CONFIG.STAGES_PER_CHAPTER + 1);
  // v0.49.0：速战入口只保留在对应秘境条目内（与「入秘境」同组），
  // 不再在页底重复一张「速战」卡（同一功能上下两个入口）。
  return `
    <div class="view battle">
      <div class="bg-cover" style="background-image:url('${chapterBg(next)}')"></div>
      <div class="content">
        ${pageHeadHtml("battle")}
        <div class="sec-title">${chName}</div>
        ${viewFieldMaps()}
        ${canChallenge ? "" : `<div class="card"><div class="stage-name">已通关全部秘境，静待新章开启</div></div>`}
        ${viewTowerSection()}
      </div>
    </div>`;
}

// ---------- 无尽试炼塔区块（v0.8.0，嵌在历练页） ----------
function viewTowerSection() {
  const next = towerNextFloor();
  const e = towerEnemy(next);
  const rw = towerReward(next);
  const my = playerPower();
  const ratio = e.power > 0 ? my / e.power : 99;
  const hint = ratio >= 1.25 ? "胜算颇大" : ratio >= 1.0 ? "旗鼓相当" : ratio >= 0.8 ? "凶险" : "力有不逮";
  return `
    <div class="sec-title small">无尽试炼塔</div>
    <div class="card tower-card">
      <div class="build-head">
        <span class="build-name">第 ${next} 层${towerIsBoss(next) ? " · 守关妖兽" : ""}</span>
        <span class="build-lv">最高 ${S.towerBest || 0} 层</span>
      </div>
      <div class="stage-meta">塔敌战力 ${fmt(e.power)} ｜ 我方战力 ${fmt(my)} ｜ <b>${hint}</b></div>
      <div class="build-desc">通关奖励：灵石 ${fmt(rw.stone)}${rw.mat ? "、灵材 " + rw.mat : ""}${rw.rep ? "、声望 " + rw.rep : ""}${rw.boss ? "（守关妖兽 ×2 灵石）" : ""}、塔币 ${towerCoinFor(next)}</div>
      <div class="build-row">
        <button class="btn-primary" data-action="tower">攀登（体力 -1）</button>
        <button class="btn-sm" data-action="towershop">塔阁（塔币 ${S.towerCoin || 0}）</button>
      </div>
      <div class="tip">塔无上限，唯战力可破；失败不损分毫，只耗体力。塔币仅由通关层数产出，只可在塔阁兑换。</div>
    </div>`;
}

// ---------- 塔阁弹窗（v0.9.0） ----------
function showTowerShopModal() {
  const rows = CONFIG.TOWER_SHOP.map(item => {
    const can = (S.towerCoin || 0) >= item.cost;
    return `<div class="shop-row">
      <span class="shop-body"><b>${esc(item.name)}</b><span class="shop-desc">${esc(item.desc)}</span></span>
      <button class="btn-sm" data-action="towerbuy" data-key="${item.key}" ${can ? "" : "disabled"}>${item.cost} 塔币</button>
    </div>`;
  }).join("");
  showModal(`
    <div class="result">
      <div class="result-title">🏯 塔阁</div>
      <div class="result-line">持有塔币 <b>${S.towerCoin || 0}</b> ｜ 最高 ${S.towerBest || 0} 层</div>
      <div class="shop-list">${rows}</div>
      <button class="btn-primary" data-action="closemodal">离开</button>
    </div>`);
}

// 道途改修弹窗（v0.29.0）
function showDaoPicker() {
  const rows = CONFIG.DAO_PATHS.map(d => `
    <div class="shop-item">
      <span><b>${esc(d.name)}</b><span class="muted"> ${esc(d.desc)}</span><br><span class="muted">${esc(daoSummary(d.key))}</span></span>
      ${S.dao === d.key
        ? `<span class="muted">当前</span>`
        : `<button class="btn-sm" data-action="setdaoapply" data-key="${d.key}">改修</button>`}
    </div>`).join("");
  showModal(`
    <div class="result">
      <div class="result-title">道途</div>
      <div class="result-line">改修立即生效（原型期免费），属性与修炼速率随之变化。</div>
      <div class="shop-list">${rows}</div>
      <button class="btn-primary" data-action="closemodal">返回</button>
    </div>`);
}

// ---------- 洞府（经营） ----------
function viewBuild() {
  const idle = idleDisciples();
  const cards = CONFIG.BUILDINGS.map(b => {
    const lv = S.buildings[b.key];
    const unlocked = S.realm >= b.unlockRealm;
    const cost = CONFIG.buildingCost(lv);
    const out = buildingOutput(b.key);
    const assigned = assignedCount(b.key);
    const artSrc = CONFIG.BUILDING_ART[b.key] || "";
    return `
      <div class="card build-card ${unlocked ? "" : "locked"}">
        ${artSrc ? `<div class="build-art"><img src="${artSrc}" alt=""></div>` : ""}
        <div class="build-body">
        <div class="build-head">
          <span class="build-name">${b.name}</span>
          <span class="build-lv">Lv.${lv}</span>
        </div>
        <div class="build-desc">${b.desc}</div>
        ${unlocked ? `
          <div class="build-out">产出：${b.key === "forge" ? "攻防 +" + lv * 10 : b.key === "practice" ? "修炼 ×" + ((1 + CONFIG.PRACTICE_RATE_BONUS * lv) * practiceDiscipleMult()).toFixed(2) + (assigned > 0 ? "（含弟子 ×" + practiceDiscipleMult().toFixed(2) + "）" : "") : b.key === "recruit" ? "弟子名额 " + discipleSlots() : fmt(out) + "/秒"}</div>
          ${b.key === "practice" ? (() => { const current = cultivationRate(); const next = current * (1 + CONFIG.PRACTICE_RATE_BONUS * (lv + 1)) / (1 + CONFIG.PRACTICE_RATE_BONUS * lv); return `<div class="build-desc">升至 Lv.${lv + 1}：修炼 ${fmt(current)}/秒 → ${fmt(next)}/秒（增加 ${fmt(next - current)}/秒）；投资 ${fmt(cost)} 灵石</div>`; })() : ""}
          ${b.key === "farm" || b.key === "alchemy" ? (() => { const f = herbFlowSnapshot(); const netText = f.net >= 0 ? `灵草净流入 +${f.net.toFixed(2)}/秒` : `灵草净流出 ${Math.abs(f.net).toFixed(2)}/秒`; const coverage = f.net < 0 ? ` ｜ 当前库存约可维持 ${f.coverageSec >= 3600 ? (f.coverageSec / 3600).toFixed(1) + " 小时" : Math.floor(f.coverageSec / 60) + " 分钟"}` : ""; return `<div class="build-desc">灵草：灵田 +${f.farmIn.toFixed(2)}/秒 ｜ 炼丹需求 ${f.consume.toFixed(2)}/秒 ｜ <b>${netText}</b>${coverage}</div>`; })() : ""}
          <div class="build-row">
            <button class="btn-sm" data-action="upgrade" data-key="${b.key}">升级(${fmt(cost)}灵石)</button>
            <span class="assign">弟子 ${assigned}</span>
            <button class="btn-sm" data-action="assign" data-key="${b.key}">+派</button>
            <button class="btn-sm" data-action="unassign" data-key="${b.key}">-撤</button>
            ${b.key === "forge" ? `<button class="btn-sm btn-forge" data-action="craft">⛩ 炼器坊</button>` : ""}
            ${b.key === "alchemy" ? `<button class="btn-sm" data-action="dan">${danBusy() ? (danReady() ? "🔥 丹已成·收取" : "🔥 炉中炼丹") : "🔥 开炉炼丹"}</button>` : ""}
          </div>` : `<div class="build-desc muted">需 ${CONFIG.REALMS[b.unlockRealm]}期解锁</div>`}
        </div>
      </div>`;
  }).join("");
  // 弟子列表（v0.4.1：个体 NPC，自主修炼，忠诚过低会离山；v0.8.0 可用声望提资质）
  const discipleList = S.disciples.map(d => {
    const apt = aptitudeInfo(d.aptitude);
    const bound = d.assignedTo ? (CONFIG.BUILDINGS.find(b => b.key === d.assignedTo) || { name: d.assignedTo }).name : "空闲";
    const aptCost = repAptitudeCost(d);
    const aptBtn = aptCost != null
      ? `<button class="btn-sm" data-action="upapt" data-id="${d.id}">提资质(${aptCost}声望)</button>`
      : "";
    const spec = specialtyInfo(d.specialty);
    const matched = specialtyMatched(d);
    const workMult = discipleGrowthWorkMult(d);
    const dailyGrowth = apt.growth * (Math.max(0, Math.min(100, Number(d.mood) || 0)) / 100) * workMult;
    const expNeed = Math.max(0, CONFIG.DISCIPLE_GROWTH_THRESHOLD - (Number(d.cultivation) || 0));
    const daysToLayer = dailyGrowth > 0 ? (expNeed / dailyGrowth).toFixed(1) : "—";
    const layersLeft = (CONFIG.REALMS.length - 1 - (d.realm || 0)) * CONFIG.LAYERS_PER_REALM + (CONFIG.LAYERS_PER_REALM - 1 - (d.layer || 0));
    const totalExpLeft = Math.max(0, layersLeft * CONFIG.DISCIPLE_GROWTH_THRESHOLD - (Number(d.cultivation) || 0));
    const qiTimes = Math.min(Math.floor((Number(S.qi) || 0) / CONFIG.DISCIPLE_GROWTH.QI_COST), Math.ceil(totalExpLeft / CONFIG.DISCIPLE_GROWTH.QI_EXP));
    const pillTimes = Math.min(invCount("pill"), Math.ceil(totalExpLeft / CONFIG.DISCIPLE_GROWTH.PILL_EXP));
    return `
      <div class="disciple-row">
        <span class="dp-name">${esc(d.name)}${d.origin === "开山赠礼" ? '<i class="gf-tier">开山赠礼</i>' : ""}</span>
        <span class="dp-apt" style="color:${apt.color}">${apt.name}</span>
        <span class="dp-spec" style="color:${spec.color}">${spec.name}${matched ? "✦" : ""}</span>
        <span class="dp-realm">${CONFIG.REALMS[d.realm]}${d.layer + 1}层</span>
        <span class="dp-loyal">忠${Math.round(d.loyalty)}</span>
        <span class="dp-bond">${bondTitle(d)}</span>
        <span class="dp-state">${bound}</span>
        <span class="dp-growth">修为 ${Math.floor(d.cultivation || 0)}/${CONFIG.DISCIPLE_GROWTH_THRESHOLD}</span>
        <span class="dp-growth">心境 ${Math.round(d.mood || 0)} · 日增约 ${dailyGrowth.toFixed(2)} · 距下一层约 ${daysToLayer} 日</span>
        ${aptBtn}
        <button class="btn-sm" data-action="traindisciple" data-id="${d.id}" data-method="qi">灵气×1（${fmt(CONFIG.DISCIPLE_GROWTH.QI_COST)}）</button>
        <button class="btn-sm" data-action="traindisciple" data-id="${d.id}" data-method="qi" data-count="max" ${qiTimes <= 0 ? "disabled" : ""}>灵气最大培养（${qiTimes}次）</button>
        <button class="btn-sm" data-action="traindisciple" data-id="${d.id}" data-method="pill">培元丹×1（+${CONFIG.DISCIPLE_GROWTH.PILL_EXP}）</button>
        <button class="btn-sm" data-action="traindisciple" data-id="${d.id}" data-method="pill" data-count="max" ${pillTimes <= 0 ? "disabled" : ""}>培元丹最大培养（${pillTimes}枚）</button>
      </div>`;
  }).join("");
  return `
    <div class="view build">
      <div class="bg-cover" style="background-image:url('assets/宗门山门.webp')"></div>
      <div class="content">
        ${pageHeadHtml("build")}
        ${secHeadHtml("营建")}
        <div class="card disciple-card">
          <div>弟子 ${S.disciples.length}/${discipleSlots()} ｜ 空闲 ${idle} ｜ 凡人 ${Math.floor(S.folk || 0)}/${folkCap()}</div>
          <div class="build-desc">开局赠送 5 名凡俗弟子，可分别安排秘境驻守、洞府职守与弟子任务；弟子会随资质和工作历练成长，也可消耗灵气/培元丹培养。凡人按各秘境聚落分别统计。名额 = ${CONFIG.SLOTS.BASE} + 招募堂 + 境界 + 建筑总级÷${CONFIG.SLOTS.BUILD_DIV} + 宗门×${CONFIG.SLOTS.PER_SECT} + 立朝 ${CONFIG.SLOTS.DYNASTY}。派驻灵脉/矿场/药圃需灵脉师·矿工·药农。</div>
          <div class="build-row">
            <button class="btn-sm" data-action="recruit">开山收徒（秘境选拔）</button>
            <button class="btn-sm" data-action="missions">弟子任务</button>
          </div>
        </div>
        ${S.disciples.length ? `<div class="card"><div class="build-head"><span class="build-name">门下弟子</span><span class="build-lv">专精✦匹配委派 +${CONFIG.SPECIALTY_MATCH_BONUS * 100}% ｜ 嫡传 +${CONFIG.BOND_ELITE_BONUS * 100}%</span></div>
          <div class="build-desc">专精决定该弟子最适合的建筑；闲修、洞府职守、秘境驻守和限时任务提供不同历练速度。师徒情谊随相处增长，达 ${CONFIG.BOND_LOYALTY_GUARD} 后忠诚不再自然下降，达 ${CONFIG.BOND_ELITE_THRESHOLD} 成为嫡传。直接培养不设每日次数或修为上限，灵气/培元丹充足即可持续培养。</div>${discipleList}</div>` : ""}
        ${secHeadHtml("洞府建筑")}
        ${cards}
        ${secHeadHtml("生活 · 药园化身仙友")}
        <div class="card">
          <div class="build-head"><span>生活</span><span>种药 · 分身 · 交游</span></div>
          <div class="build-desc">药园提供灵草与稀有作物，化身可代炼/代采，仙友传功结缘。丹房入口在「炼丹房」建筑卡上，此处不重复设一个。</div>
          <div class="build-row">
            <button class="btn-sm" data-action="garden">药园</button>
            <button class="btn-sm" data-action="avatar">化身</button>
            <button class="btn-sm" data-action="friends">仙友</button>
          </div>
        </div>
        ${secHeadHtml("宗门")}
        ${viewSectCard()}
        ${secHeadHtml("法宝")}
        ${viewArtifactSection()}
        ${secHeadHtml("储物法器")}
        <div class="card">
          <div class="build-head"><span>储物法器</span><span>${esc(invDef().name)} ｜ ${invUsedSlots()}/${invSlots()} 格</span></div>
          <div class="build-desc">${esc(invDef().desc)} ｜ 单格堆叠上限 ${invDef().stack}</div>
          <div class="build-out">${invNextDef() ? "下一级 " + esc(invNextDef().name) + "： " + invNextDef().slots + " 格 · 单格 " + invNextDef().stack + " ｜ " + fmt(invNextDef().price) + " 灵石 ｜ 需 " + CONFIG.REALMS[invNextDef().realm] + "期" : "已是最高品级：乾坤袋"}</div>
          <button class="btn-sm" data-action="bag">打开储物袋</button>
        </div>
        ${secHeadHtml("统一库房")}
        ${typeof fieldWarehouseCardHtml === "function" ? fieldWarehouseCardHtml() : ""}
      </div>
    </div>`;
}

// 职务任命（v0.33.0）：列出该秘境驻守弟子
function showAppointModal(ch, officeKey) {
  const team = dispatchTeam(ch);
  const def = officeDef(officeKey);
  if (!def) { toast("无此职务"); return; }
  const rows = team.map(id => {
    const d = S.disciples.find(x => String(x.id) === String(id));
    if (!d) return "";
    return `<div class="shop-item">
      <span><b>${esc(d.name)}</b><span class="muted"> 资质 ${d.aptitude} ｜ 忠诚 ${Math.round(d.loyalty)}</span></span>
      <button class="btn-sm" data-action="appointpick" data-ch="${ch}" data-office="${officeKey}" data-id="${d.id}">任命</button>
    </div>`;
  }).join("") || `<div class="build-out muted">此秘境暂无驻守弟子</div>`;
  showModal(`<div class="result">
    <div class="result-title">任${def.name}</div>
    <div class="result-line">${esc(def.desc)}（效果按弟子资质放大 0.6~1.4 倍）</div>
    <div class="shop-list">${rows}</div>
    <button class="btn-primary" data-action="dispatch" data-ch="${ch}">返回驻守</button>
  </div>`);
}

// 弟子任务面板（v0.33.0）
function showMissionPanel() {
  const running = (S.missions || []).filter(m => m.status === "run");
  const recent = (S.missions || []).filter(m => m.status === "done");
  const rows = CONFIG.MISSION.TYPES.map(t => `
    <div class="shop-item">
      <span><b>${esc(t.name)}</b><span class="muted"> ${Math.round(t.sec / 60)} 分钟 ｜ ${esc(t.desc)} ｜ 历练 +${t.growth || 0} ｜ 失败率 ${Math.round(t.risk * 100)}%（基础）</span></span>
      <button class="btn-sm" data-action="missionpick" data-type="${t.key}">派弟子</button>
    </div>`).join("");
  const runningRows = running.map(m => {
    const d = S.disciples.find(x => String(x.id) === String(m.discipleId));
    const def = missionDef(m.type);
    const left = Math.max(0, Math.ceil((m.endAt - Date.now()) / 1000));
    return `<div class="shop-item"><span>${esc(def ? def.name : m.type)} · ${d ? esc(d.name) : "?"}</span><span class="muted">剩余 ${left} 秒</span></div>`;
  }).join("") || `<div class="build-out muted">无进行中的任务</div>`;
  const recentRows = recent.map(m => {
    const d = S.disciples.find(x => String(x.id) === String(m.discipleId));
    const def = missionDef(m.type);
    return `<div class="shop-item"><span>${esc(d ? d.name : "弟子")} · ${esc(def ? def.name : m.type)}</span><span class="muted">${m.success ? "成功" : "失利"} · 历练 +${m.growthGained || 0}${m.levelsGained ? ` · 升层 ${m.levelsGained}` : ""}</span></div>`;
  }).join("");
  showModal(`<div class="result">
    <div class="result-title">弟子任务</div>
    <div class="result-line">体力 ${Math.floor(S.stamina)} ｜ 空闲弟子 ${S.disciples.filter(d => !discipleBusy(d.id)).length}</div>
    <div class="result-line muted-line">任务基础失败率因任务类型而异；弟子资质与境界会提高成功率，实际成功率以派遣时锁定值为准。</div>
    <div class="sec-title small">可执行</div>
    <div class="shop-list">${rows}</div>
    <div class="sec-title small">进行中</div>
    <div class="shop-list">${runningRows}</div>
    ${recentRows ? `<div class="sec-title small">最近结算</div><div class="shop-list">${recentRows}</div>` : ""}
    <button class="btn-primary" data-action="closemodal">关闭</button>
  </div>`);
}

function showMissionPick(type) {
  const def = missionDef(type);
  const cands = S.disciples.filter(d => !discipleBusy(d.id));
  const rows = cands.map(d => `
    <div class="shop-item">
      <span><b>${esc(d.name)}</b><span class="muted"> 资质 ${d.aptitude} ｜ 成功率 ${Math.round(missionRate(d, type) * 100)}%</span></span>
      <button class="btn-sm" data-action="missionstart" data-type="${type}" data-id="${d.id}">派出</button>
    </div>`).join("") || `<div class="build-out muted">没有空闲弟子</div>`;
  showModal(`<div class="result">
    <div class="result-title">${esc(def.name)}</div>
    <div class="result-line">${esc(def.desc)} ｜ 消耗体力 ${def.stamina} ｜ 失败：忠诚 -${CONFIG.MISSION.FAIL_LOYALTY} ｜ 成功率按弟子资质/境界计算</div>
    <div class="shop-list">${rows}</div>
    <button class="btn-sm" data-action="missions">返回</button>
  </div>`);
}

// 王朝官职（v0.33.0）
function showDynastyOfficeModal() {
  if (!S.dynasty || !S.dynasty.name) { toast("尚未立朝"); return; }
  const rows = CONFIG.DYNASTY_OFFICES.map(o => {
    const id = S.dynastyOffice ? S.dynastyOffice[o.key] : null;
    const d = id ? S.disciples.find(x => String(x.id) === String(id)) : null;
    return `<div class="shop-item">
      <span><b>${esc(o.name)}</b><span class="muted"> ${esc(o.desc)}</span><br><span class="muted">现任：${d ? esc(d.name) : "空缺"}</span></span>
      <button class="btn-sm" data-action="dynappointpick" data-office="${o.key}">任命</button>
    </div>`;
  }).join("");
  showModal(`<div class="result">
    <div class="result-title">王朝官职</div>
    <div class="result-line">${esc(dynastySummary())} ｜ 每日赋税约 ${Math.floor((S.folk || 0) * CONFIG.TAX_RATE * 100)} 灵石</div>
    <div class="shop-list">${rows}</div>
    <button class="btn-primary" data-action="closemodal">关闭</button>
  </div>`);
}

function showDynAppointPick(officeKey) {
  const def = dynastyOfficeDef(officeKey);
  const rows = S.disciples.map(d => `
    <div class="shop-item">
      <span><b>${esc(d.name)}</b><span class="muted"> 资质 ${d.aptitude} ｜ ${d.assignedTo ? "已有职守" : "空闲"}</span></span>
      <button class="btn-sm" data-action="dynappoint" data-office="${officeKey}" data-id="${d.id}">任命</button>
    </div>`).join("");
  showModal(`<div class="result">
    <div class="result-title">任${def.name}</div>
    <div class="result-line">${esc(def.desc)}</div>
    <div class="shop-list">${rows}</div>
    <button class="btn-sm" data-action="dynoffice">返回</button>
  </div>`);
}

// 招徒：秘境凡人聚集地选拔（v0.32.0）
function showRecruitModal() {
  const maps = Object.keys(S.mapTeam || {}).filter(ch => (S.mapTeam[ch] || []).length && S.clearedMaps && S.clearedMaps[ch]);
  if (!maps.length) {
    showModal(`<div class="result">
      <div class="result-title">开山收徒</div>
      <div class="result-line">收徒需前往已驻守的秘境凡人聚集地选拔。</div>
      <div class="tip">先派弟子驻守已探明秘境 → 凡人繁衍 → 再回来开山收徒。</div>
      <button class="btn-primary" data-action="closemodal">知道了</button>
    </div>`);
    return;
  }
  const rows = maps.map(ch => {
    const nm = CONFIG.fieldMap(parseInt(ch, 10)).name;
    return `<div class="shop-item">
      <span>${esc(nm)} <span class="muted">凡人聚集地 · 人口 ${Math.floor(settlementPopulation(ch))}/${fieldSettlementCap(ch)} · 驻守 ${dispatchTeam(ch).length} 人</span></span>
      <button class="btn-sm" data-action="recruitmap" data-ch="${ch}">选拔</button>
    </div>`;
  }).join("");
  showModal(`<div class="result">
    <div class="result-title">开山收徒</div>
    <div class="result-line">选择秘境凡人聚集地，测灵根、择优录用（每人耗灵石与本地 1 凡人）</div>
    <div class="player-slots">弟子名额 ${S.disciples.length}/${discipleSlots()} ｜ 凡人 ${Math.floor(S.folk || 0)}/${folkCap()}</div>
    <div class="shop-list">${rows}</div>
    <button class="btn-primary" data-action="closemodal">返回</button>
  </div>`);
}

function showRecruitCandidates(ch) {
  ch = parseInt(ch, 10);
  // 已有当日候选池时只重绘，不重新抽签；否则录用一人后列表会被整批刷新，
  // 甚至因刚扣掉最后一名凡人而无法重新打开候选页。
  const oldPool = S.recruitPool;
  const hasPool = oldPool && Number(oldPool.ch) === ch
    && oldPool.day === gameDayKey() && Array.isArray(oldPool.list);
  const r = hasPool ? { ok: true, pool: oldPool } : recruitCandidates(ch);
  if (!r.ok) { toast(r.msg); return; }
  const pool = S.recruitPool;
  const rows = pool.list.map((c, i) => `
    <div class="shop-item cand-row">
      <span><b>${esc(c.name)}</b><span class="muted"> ${esc(c.root)} · 资质 ${c.aptitude}</span></span>
      <button class="btn-sm" data-action="hirecand" data-i="${i}">录用（${fmt(c.cost)}石+1凡人）</button>
    </div>`).join("") || `<div class="build-out muted">候选已全部录用</div>`;
  showModal(`<div class="result">
    <div class="result-title">测灵石 · ${esc(CONFIG.fieldMap(pool.ch).name)}</div>
    <div class="result-line">本地聚落人口 ${Math.floor(settlementPopulation(pool.ch))}/${fieldSettlementCap(pool.ch)}；灵根越佳资质越高（天品需立朝方现）；择优录用，余者可刷新</div>
    <div class="shop-list">${rows}</div>
    <div class="build-row">
      <button class="btn-sm" data-action="refreshcand">刷新候选（${CONFIG.RECRUIT.REFRESH_STONE}石）</button>
      <button class="btn-sm" data-action="recruit">换一处秘境</button>
    </div>
    <button class="btn-primary" data-action="closemodal">返回</button>
  </div>`);
}

// 宗门卡（v0.31.0）：驻守 3 处秘境可立宗
function viewSectCard() {
  const has = S.sect && S.sect.lv;
  const terr = (typeof playerTerritory === "function") ? playerTerritory() : 0;
  const C = CONFIG.SECT;
  if (!has) {
    return `<div class="card">
      <div class="build-head"><span>宗门</span><span>未立宗</span></div>
      <div class="build-desc">派弟子驻守 ${C.NEED_TERRITORY} 处已探明秘境（当前 ${terr}），再以灵石 ${fmt(C.BASE_STONE)} 与特产 ${C.BASE_SPC} 立宗。立宗后全属性与修炼永久提升，可继续升宗。</div>
      <button class="btn-sm" data-action="foundsect" ${sectReady() ? "" : "disabled"}>立宗</button>
    </div>`;
  }
  const cost = sectUpgradeCost();
  return `<div class="card">
    <div class="build-head"><span>宗门</span><span>${esc(S.sect.name)} Lv.${S.sect.lv} ｜ 贡献 ${S.contribution || 0}</span></div>
    <div class="build-out">${esc(sectSummary())}</div>
    <button class="btn-sm" data-action="sect">宗门事务（任务/藏经阁/试炼/外交）</button>
    <div class="build-desc">下一级：灵石 ${fmt(cost.stone)} + 特产 ${cost.spc}（${esc(specialtyName(Math.max(0, highestClearedChapter())))}）</div>
    <button class="btn-sm" data-action="upgradesect" ${S.sect.lv >= C.MAX_LV ? "disabled" : ""}>${S.sect.lv >= C.MAX_LV ? "已至顶级" : "升宗"}</button>
    <div class="build-desc" style="margin-top:8px">凡间王朝：${esc(dynastySummary())}</div>
    ${S.dynasty && S.dynasty.name
      ? `<div class="build-out muted">王朝已成 · 凡人繁衍 ×${CONFIG.DYNASTY.FOLK_MULT}</div>`
      : `<button class="btn-sm" data-action="founddynasty" ${dynastyReady() ? "" : "disabled"}>立朝（宗门 Lv.${CONFIG.DYNASTY.NEED_SECT} + 凡人 ${CONFIG.DYNASTY.NEED_FOLK} + ${fmt(CONFIG.DYNASTY.STONE)} 灵石）</button>`}
    ${S.dynasty && S.dynasty.name ? `<button class="btn-sm" data-action="dynoffice">王朝官职</button>` : ""}
  </div>`;
}

// ---------- 法宝区块（v0.6.0） ----------
// 法宝加成的文字摘要
function artBonusText() {
  const b = artifactBonus();
  const parts = [];
  if (b.atk) parts.push(`攻+${(b.atk * 100).toFixed(1)}%`);
  if (b.def) parts.push(`防+${(b.def * 100).toFixed(1)}%`);
  if (b.cult) parts.push(`修炼+${(b.cult * 100).toFixed(1)}%`);
  if (b.hp) parts.push(`血+${(b.hp * 100).toFixed(1)}%`);
  return parts.length ? parts.join(" ") : "无";
}

// 词条彩色标签（v0.6.2）
function affixHtml(a) {
  if (!a || !Array.isArray(a.affixes) || !a.affixes.length) return "";
  return a.affixes
    .map(af => `<span class="affix-tag" style="color:${af.color};border-color:${af.color}">${af.name} ${(af.value * 100).toFixed(1)}%</span>`)
    .join("");
}

// 法宝库筛选 + 排序（v0.10.0）
function artifactFilteredList() {
  let arr = S.artifacts.slice();
  if (artifactFilter !== "all") arr = arr.filter(a => a.type === artifactFilter);
  if (artifactSort === "tier") {
    arr.sort((x, y) => (y.tier - x.tier) || (artifactScore(y) - artifactScore(x)));
  } else if (artifactSort === "newest") {
    arr.sort((x, y) => y.id - x.id);
  } else {
    arr.sort((x, y) => artifactScore(y) - artifactScore(x));
  }
  return arr;
}

// ---------- 12 格装备栏（v0.18.0） ----------
function loadoutSlotHtml(slot) {
  if (!slotUnlocked(slot)) {
    return `<div class="slot-row locked">
      <span class="slot-label">${artifactIcon(slot.accepts[0])}${slot.name}</span>
      <span class="slot-attr muted">需 ${CONFIG.REALMS[slot.unlockRealm] || "更高"} 期</span>
    </div>`;
  }
  const a = slotArtifact(slot.key);
  if (!a) {
    return `<div class="slot-row empty">
      <span class="slot-label">${artifactIcon(slot.accepts[0])}${slot.name}</span>
      <span class="slot-attr muted">未装备</span>
    </div>`;
  }
  const ti = tierInfo(a.tier);
  const sk = (a.skill && typeof fldSkill === "function") ? fldSkill(a.skill) : null;
  const engTxt = (a.engrave || []).map(e =>
    `<span class="affix-tag" style="color:${e.color};border-color:${e.color}">${e.name} ${(e.value * 100).toFixed(1)}%</span>`
  ).join("");
  return `<div class="slot-row">
    <span class="slot-label">${artifactIcon(slot.accepts[0])}${slot.name}</span>
    <span class="art-name" style="color:${ti.color}">${esc(a.name)}</span>
    <span class="art-tier" style="color:${ti.color}">${ti.name}</span>
    <span class="slot-attr">${artifactAttrText(a)}</span>
    <button class="btn-sm" data-action="unequip" data-slot="${slot.key}">卸下</button>
  </div>
  <div class="slot-affix">
    ${sk ? `<span class="affix-tag" style="color:${sk.color};border-color:${sk.color}">神通·${sk.name}</span>` : ""}
    ${affixHtml(a)}
    ${engTxt}
  </div>`;
}

function viewLoadoutHtml() {
  const all = CONFIG.LOADOUT_SLOTS;
  const groups = [
    { name: "本体", from: 0, to: 3 },
    { name: "古宝", from: 3, to: 6 },
    { name: "法宝", from: 6, to: 12 },
  ];
  let html = "";
  for (const g of groups) {
    const part = all.slice(g.from, g.to);
    const openCnt = part.filter(sl => slotUnlocked(sl)).length;
    html += `<div class="loadout-group">
      <div class="loadout-title">${g.name}<span class="muted"> ${openCnt}/${part.length}</span></div>
      ${part.map(loadoutSlotHtml).join("")}
    </div>`;
  }
  const res = resonanceBonus();
  if (res.bonus > 0) {
    html += `<div class="tip">共鸣生效：${tierInfo(res.tier).name} ×${res.count}，全属性 +${(res.bonus * 100).toFixed(0)}%</div>`;
  }
  return html;
}

function viewArtifactSection() {
  const slots = viewLoadoutHtml();

  // 法宝库分页（v0.10.0）：只渲染当前页，件数再多 DOM 也固定
  const filtered = artifactFilteredList();
  const pageSize = CONFIG.ARTIFACT_PAGE_SIZE;
  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));
  if (artifactPage > pageCount - 1) artifactPage = pageCount - 1;
  if (artifactPage < 0) artifactPage = 0;
  const pageItems = filtered.slice(artifactPage * pageSize, (artifactPage + 1) * pageSize);
  const list = pageItems.length ? pageItems.map(a => {
    const ti = tierInfo(a.tier);
    const isEq = S.equipped && S.equipped[a.type] === a.id;
    const canRefine = refineCandidates(a).length > 0 && a.tier < maxTier();
    return `<div class="art-row ${isEq ? "equipped" : ""}">
      <div class="art-head">
        <span class="art-name" style="color:${ti.color}">${esc(a.name)}</span>
        <span class="art-tier" style="color:${ti.color}">${ti.name}</span>
        <span class="art-type">${typeInfo(a.type).slot}</span>
        <span class="art-roll">品质 ${Math.round(a.roll * 100)}%</span>
        ${a.setKey ? `<span class="art-set-tag">套·${esc((artifactSetDef(a.setKey) || {}).name || "")}</span>` : ""}
        ${isEq ? '<span class="art-eq-tag">已装备</span>' : ""}
      </div>
      <div class="art-line">${artifactAttrText(a)}</div>
      ${affixHtml(a) ? `<div class="art-affix">${affixHtml(a)}</div>` : ""}
      <div class="build-row">
        <button class="btn-sm" data-action="${isEq ? "unequip" : "equip"}" data-id="${a.id}" data-type="${a.type}">${isEq ? "卸下" : "装备"}</button>
        <button class="btn-sm" data-action="openrefine" data-id="${a.id}" ${canRefine ? "" : "disabled"}>炼化</button>
        <button class="btn-sm" data-action="reroll" data-id="${a.id}" ${canReroll(a) ? "" : "disabled"}>洗练</button>
        <button class="btn-sm" data-action="engrave" data-id="${a.id}" ${(a.engrave || []).length >= engraveMax(a) ? "disabled" : ""}>淬灵</button>
        <button class="btn-sm" data-action="warmart" data-id="${a.id}" ${artWarmLv(a.id) >= CONFIG.WARM.MAX ? "disabled" : ""}>温养 Lv.${artWarmLv(a.id)}</button>
        <button class="btn-sm" data-action="dismantle" data-id="${a.id}">分解</button>
      </div>
    </div>`;
  }).join("") : (S.artifacts.length === 0
    ? (S.realm >= 2
      ? '<div class="tip">尚无法宝。点炼器坊的「⚒ 炼制法宝」，消耗灵材与灵石即可炼制。</div>'
      : '<div class="tip">炼器坊需金丹期解锁，届时可炼制法宝。</div>')
    : '<div class="tip">当前筛选条件下没有法宝。</div>');

  // 筛选 / 排序工具栏
  const sortName = { score: "评分", tier: "品阶", newest: "最新" }[artifactSort] || "评分";
  const filterBtns = [["all", "全部"]].concat(CONFIG.ARTIFACT_TYPES.map(t => [t.key, t.slot]))
    .map(([key, label]) =>
      `<button class="btn-sm ${artifactFilter === key ? "on" : ""}" data-action="artfilter" data-filter="${key}">${label}</button>`)
    .join("");
  const toolbar = `
    <div class="art-toolbar">
      ${filterBtns}
      <button class="btn-sm" data-action="artsort">排序：${sortName}</button>
    </div>`;
  const pager = filtered.length > pageSize ? `
    <div class="art-pager">
      <button class="btn-sm" data-action="artpage" data-page="${artifactPage - 1}" ${artifactPage <= 0 ? "disabled" : ""}>上一页</button>
      <span class="art-pager-info">${artifactPage + 1} / ${pageCount}（共 ${filtered.length} 件）</span>
      <button class="btn-sm" data-action="artpage" data-page="${artifactPage + 1}" ${artifactPage >= pageCount - 1 ? "disabled" : ""}>下一页</button>
    </div>` : "";

  const capTier = forgeMaxTier();
  const setCnt = artifactSetCounts();
  const setActive = activeArtifactSets();
  const setAttrName = { atk: "攻", def: "防", hp: "血", cult: "修炼" };
  const setRows = (CONFIG.ARTIFACT_SETS || []).map(st => {
    const c = setCnt[st.key] || 0;
    const on = c >= 2;
    const b = c >= 3 ? st.bonus3 : st.bonus2;
    const bt = Object.keys(b || {}).map(k => setAttrName[k] + " +" + (b[k] * 100).toFixed(0) + "%").join(" ");
    return `<div class="set-row ${on ? "on" : ""}">
      <span class="set-name">${esc(st.name)}</span>
      <span class="set-cnt">${c}/3</span>
      <span class="set-bonus">${on ? bt : "未激活"}</span>
    </div>
    <div class="set-desc">${esc(st.desc)}</div>`;
  }).join("");
  const setCard = `<div class="card artifact-card">
    <div class="build-head"><span class="build-name">法宝套装</span><span class="build-lv">${setActive.length} 套生效</span></div>
    <div class="build-desc">炼制二品及以上法宝有概率携「器韵」成套装；装备 2 件起触发，3 件全额。</div>
    <div class="set-list">${setRows}</div>
  </div>`;
  return `
    <div class="sec-title small">法宝</div>
    <div class="card artifact-card">
      <div class="build-head">
        <span class="build-name">装备</span>
        <span class="build-lv">灵材 ${fmt(S.materials || 0)} ｜ 炼器坊 Lv.${S.buildings.forge}（可炼至${tierInfo(capTier).name}）</span>
      </div>
      ${slots}
    </div>
    ${setCard}
    <div class="card artifact-card">
      <div class="build-head"><span class="build-name">法宝库</span><span class="build-lv">共 ${S.artifacts.length} 件</span></div>
      ${toolbar}
      ${list}
      ${pager}
    </div>`;
}

// ---------- 技能盘（v0.16.0，秘境战场用）----------
function artSlotList() {
  const rawSlots = Array.isArray(S.fieldSlots) ? S.fieldSlots : [];
  const cleaned = fldCleanSlots(rawSlots, S.realm);
  // 持久化只保存玩家明确排布的技能；默认补位仅用于展示/战斗，不污染旧档字段。
  if (rawSlots.length && (cleaned.length !== rawSlots.length || cleaned.some((k, i) => k !== rawSlots[i]))) S.fieldSlots = cleaned.slice();
  return fldNormalizeSlots(cleaned, S.realm);
}

function viewFabaoSkillSlot() {
  const chosen = typeof selectedFabaoSkill === "function" ? selectedFabaoSkill() : null;
  const title = chosen ? esc(chosen.skill.name) : "尚未选择";
  const desc = chosen ? `${esc(chosen.artifactName)} · ${esc(chosen.slotName)} · ${esc(chosen.skill.desc || "法宝主动术式")}` : "从当前已装备法宝中选择一项主动术式；不占用境界开放的普通术式槽。";
  return `<div class="slot-row fabao-skill-slot"><span class="slot-idx">Ⅴ</span><span class="slot-lock">法宝技</span><span class="slot-name">${title}</span><span class="slot-meta">${desc}</span><button class="btn-xs" data-action="fabaoSkillPick">${chosen ? "更换" : "选择"}</button></div>`;
}

function showFabaoSkillPick() {
  const list = typeof equippedFabaoSkills === "function" ? equippedFabaoSkills() : [];
  const chosen = S.fabaoSkillSlot;
  const rows = list.map(x => `<div class="shop-row"><span class="shop-body"><b>${esc(x.skill.name)}</b><span class="shop-desc">${esc(x.artifactName)} · ${esc(x.slotName)} · ${esc(x.skill.desc || "法宝主动术式")}</span></span><button class="btn-sm" data-action="fabaoSkillSet" data-key="${x.key}" ${chosen === x.key ? "disabled" : ""}>${chosen === x.key ? "已选中" : "选用"}</button></div>`).join("");
  showModal(`<div class="result"><div class="result-title">选择独立法宝技槽</div><div class="shop-list">${rows || '<div class="empty-hint">尚无已装备且带主动术式的法宝。</div>'}</div><button class="btn-primary" data-action="fabaoSkillSet" data-key="">清空法宝技槽</button><button class="btn-primary" data-action="closemodal">关闭</button></div>`);
}

function viewArtSlotCard() {
  const capList = (CONFIG.BATTLE2 && CONFIG.BATTLE2.SLOT_BY_REALM) || [];
  const n = capList.length ? (capList[Math.min(capList.length - 1, Math.max(0, S.realm || 0))] || 2) : CONFIG.FIELD.SKILL_SLOTS;
  const slots = artSlotList();
  const rows = slots.map((k, i) => {
    const a = fldSkill(k);
    const shapeTxt = { line: "直线", cone: "扇形", nova: "环身", self: "自身" }[a.shape] || "";
    const lockDef = (CONFIG.SKILL_LOCKS || []).find(x => x.key === a.lock) || { name: "群体", color: "#B08A3E" };
    return `<div class="slot-row">
      <span class="slot-idx">${i + 1}</span>
      <span class="slot-lock" style="background:${lockDef.color}">${esc(lockDef.name)}</span>
      <span class="slot-name">${esc(a.name)}</span>
      <span class="slot-meta">${shapeTxt}·元${a.mana}·冷${a.cd}息</span>
      <button class="btn-xs" data-action="artup" data-i="${i}" ${i === 0 ? "disabled" : ""}>↑</button>
      <button class="btn-xs" data-action="artdown" data-i="${i}" ${i === slots.length - 1 ? "disabled" : ""}>↓</button>
      <button class="btn-xs" data-action="artpick" data-i="${i}">换</button>
      <button class="btn-xs" data-action="insightskill" data-key="${a.key}" ${skillInsightLv(a.key) >= CONFIG.INSIGHT.MAX ? "disabled" : ""}>悟${skillInsightLv(a.key)}</button>
    </div>`;
  }).join("");
  return `<div class="card">
    <div class="build-head"><span>技能盘</span><span>${slots.length}/${n} ｜ 入秘境生效</span></div>
    <div class="build-desc">秘境中按住技能拖拽可实时预览弹道，松开即出：「强锁」自动锁定最近敌人必中，「单体」直线弹道命中首个，「群体」范围伤害，「辅助」自身生效。</div>
    ${rows}
    ${viewFabaoSkillSlot()}
    <div class="build-desc">法宝技使用独立第五格，不占用上方 ${n} 个境界术式槽；战斗中接在普通术式循环之后，拥有独立冷却。</div>
  </div>`;
}

function showArtPick(index) {
  const unlocked = fldUnlockedSkills(S.realm);
  const slots = artSlotList();
  const rows = unlocked.map(a => {
    const usedAt = slots.indexOf(a.key);
    const used = usedAt >= 0 && usedAt !== index;
    return `<div class="shop-row">
      <span class="shop-body"><b>${esc(a.name)}</b><span class="shop-desc">${a.gongfaKey && typeof gongfaBook === "function" ? `《${esc(gongfaBook(a.gongfaKey)?.name || "功法")}》专属术式 · ` : a.fromFabao ? "法宝自带术式 · " : ""}${esc(a.desc || "")}</span></span>
      <button class="btn-sm" data-action="artset" data-i="${index}" data-key="${a.key}" ${used ? "disabled" : ""}>${used ? "已上阵" : "选"}</button>
    </div>`;
  }).join("");
  showModal(`
    <div class="result">
      <div class="result-title">选择神通 · 第 ${index + 1} 槽</div>
      <div class="shop-list">${rows}</div>
      <button class="btn-primary" data-action="closemodal">取消</button>
    </div>`);
}

// ---------- 角色形象选择（v0.22.0） ----------
function showAvatarPicker() {
  const cards = CONFIG.AVATARS.map(a => {
    const on = S.avatar === a.key;
    return `<button class="avatar-opt ${on ? "on" : ""}" data-action="setavatar" data-key="${a.key}">
      <img src="${a.img}" alt="">
      <span class="avatar-opt-name">${a.name}</span>
      <span class="avatar-opt-tint">仅外观</span>
    </button>`;
  }).join("");
  showModal(`
    <div class="modal-title">选择形象</div>
    <div class="avatar-grid">${cards}</div>
    <div class="tip">形象仅改变外观，不提供数值加成。</div>
    <button class="btn-primary" data-action="closemodal">完成</button>
  `);
}

// ---------- 灵兽卡片（v0.21.0；v0.24.0 星级/亲密度/技能） ----------
function viewPetCard() {
  const list = (S.pets || []);
  const activeId = S.petActive;
  if (!list.length) {
    return `<div class="card">
      <div class="build-head"><span>灵兽</span><span>0/${CONFIG.PET_MAX}</span></div>
      <div class="build-desc">尚无灵兽。在秘境中偶遇野生灵兽，将其击败即有机会收服。</div>
    </div>`;
  }
  const rows = list.map(pt => {
    const def = petDef(pt.key);
    if (!def) return "";
    const isOn = activeId === pt.id;
    const need = CONFIG.PET_EXP_PER_LV * pt.lv;
    const cost = CONFIG.PET_TRAIN_STONE * pt.lv;
    const maxed = pt.lv >= CONFIG.PET_MAX_LV;
    const pc = petCombat(pt);
    const star = pt.star || 1;
    const starMaxed = star >= CONFIG.PET_STAR_MAX;
    const starCost = CONFIG.PET_STAR_STONE * star;
    // 同名可作素材的个体数（不含自身）
    const fodderCount = list.filter(x => x.id !== pt.id && x.key === pt.key).length;
    const bond = pt.bond || 0;
    const bondMaxed = bond >= CONFIG.PET_BOND_MAX;
    const skillTags = (pt.skills || []).map(k => {
      const sd = CONFIG.petSkillDef(k);
      return sd ? `<i class="pet-skill" title="${esc(sd.desc)}">${sd.name}</i>` : "";
    }).join("");
    return `<div class="pet-row ${isOn ? "on" : ""}">
      <div class="pet-line">
        <span class="pet-name" style="color:${def.color}">${petIcon(pt.key)}${def.name}
          <i class="pet-tier">${def.tier}阶</i>
          <i class="pet-star">${"★".repeat(star)}${"☆".repeat(CONFIG.PET_STAR_MAX - star)}</i>
          ${isOn ? '<i class="pet-on">出战</i>' : ""}
        </span>
        <span class="pet-lv">Lv.${pt.lv}${maxed ? "（满）" : ""}</span>
      </div>
      <div class="pet-expbar"><i style="width:${maxed ? 100 : Math.min(100, (pt.exp / need) * 100)}%"></i></div>
      <div class="pet-stat">攻击 ${fmt(pc ? pc.atk : 0)} ｜ 出手 ${def.cd.toFixed(2)}s ｜ ${def.desc}</div>
      ${skillTags ? `<div class="pet-skillrow">技能：${skillTags}</div>` : `<div class="pet-skillrow muted">未领悟技能（稀有度越高越易领悟）</div>`}
      <div class="pet-bondrow">亲密度 ${Math.round(bond)}/${CONFIG.PET_BOND_MAX}${bondMaxed ? "（满 · 攻击加成全额生效）" : ""}</div>
      <div class="pet-expbar bond"><i style="width:${Math.min(100, (bond / CONFIG.PET_BOND_MAX) * 100)}%"></i></div>
      <div class="pet-btns">
        <button class="btn-sm" data-action="petset" data-id="${pt.id}" data-on="${isOn ? "0" : "1"}">${isOn ? "休息" : "出战"}</button>
        <button class="btn-sm" data-action="pettrain" data-id="${pt.id}" ${maxed ? "disabled" : ""}>培养(${fmt(cost)}灵石)</button>
        <button class="btn-sm" data-action="petfeed" data-id="${pt.id}" ${bondMaxed || S.herbs < 1 ? "disabled" : ""}>喂食(灵草×1)</button>
        <button class="btn-sm" data-action="petfuse" data-id="${pt.id}" ${starMaxed || fodderCount < 1 ? "disabled" : ""}>融合升星(${fmt(starCost)}灵石${starMaxed ? "·已满星" : fodderCount < 1 ? "·无同名" : ""})</button>
        <button class="btn-sm" data-action="petinner" data-id="${pt.id}">内丹：${petInnerOf(pt.id) ? (CONFIG.PET_INNER.find(x => x.key === petInnerOf(pt.id)) || {}).name : "无"}</button>
        <button class="btn-sm" data-action="petrelease" data-id="${pt.id}">放生</button>
      </div>
    </div>`;
  }).join("");
  return `<div class="card">
    <div class="build-head"><span>灵兽</span><span>${list.length}/${CONFIG.PET_MAX}</span></div>
    <div class="pet-list">${rows}</div>
    <div class="tip">同名灵兽可融合升星（每星攻击 +8%）；喂食灵草提升亲密度（满亲密攻击最高 +10%）。</div>
  </div>`;
}

// 融合升星：选素材弹窗（v0.24.0）
function petFuseModal(targetId) {
  const target = (S.pets || []).find(p => p.id === targetId);
  if (!target) return;
  const tdef = petDef(target.key);
  const list = (S.pets || []).filter(p => p.id !== targetId && p.key === target.key);
  const rows = list.map(p => `
    <div class="pet-row">
      <div class="pet-line">
        <span class="pet-name">${petIcon(p.key)}${tdef.name} <i class="pet-tier">${(p.star || 1)}星 Lv.${p.lv}</i></span>
        <button class="btn-sm" data-action="petfusedo" data-target="${targetId}" data-fodder="${p.id}">作为素材</button>
      </div>
    </div>`).join("");
  showModal(`
    <div class="modal-title">融合升星 · ${tdef.name}</div>
    <div class="tip">消耗 1 只同名灵兽 + ${fmt(CONFIG.PET_STAR_STONE * (target.star || 1))} 灵石，升到 ${(target.star || 1) + 1} 星（攻击 +8%/星）。素材灵兽将被吞噬。</div>
    ${rows || '<div class="tip">没有同名灵兽可作素材。多去秘境收服吧。</div>'}
    <button class="btn-primary" data-action="closemodal">取消</button>
  `);
}

// ---------- 功法卡片（v0.19.0） ----------
function viewGongfaCard() {
  const gb = gongfaBonus();
  const sum = [];
  for (const k of GONGFA_ATTR_KEYS) {
    if (gb[k]) sum.push(`${attrIcon(k)}${GONGFA_ATTR_NAME[k]}+${(gb[k] * 100).toFixed(1)}%`);
  }
  const fullCnt = gongfaFullCount();

  // 展示按设计稿收敛为六阶；内部旧十阶 tier 不动，避免破坏掉落/悟道成本与旧存档。
  const grades = [];
  for (const b of CONFIG.GONGFA_BOOKS) {
    const grade = gongfaGrade(b);
    if (!grades[grade]) grades[grade] = [];
    grades[grade].push(b);
  }

  let body = "";
  for (let t = 1; t <= 6; t++) {
    const list = grades[t] || [];
    if (!list.length) continue;
    const anyUnlocked = list.some(b => gongfaUnlocked(b));
    const rows = list.map(b => {
      const learned = gongfaLearned(b.key);
      const unlocked = gongfaUnlocked(b) || learned;
      const lv = gongfaLv(b.key);
      const maxed = lv >= b.layers;
      const mainAttr = Object.keys(b.stats)[0];
      const gfCat = gongfaCategory(b.key);
      const gfEq = gongfaEquipState()[gfCat] === b.key;
      if (!unlocked) {
        return `<div class="gf-row locked">
          <div class="gf-line"><span class="gf-name">${b.name}</span>
          <span class="gf-pips">${gongfaUnlockReason(b)}</span></div>
        </div>`;
      }
      if (!learned) {
        const req = gongfaLearnReq(b.key);
        return `<div class="gf-row unlearned">
          <div class="gf-line">
            <span class="gf-name">${attrIcon(mainAttr)}${b.name}<i class="gf-tier">${gongfaGradeName(gongfaGrade(b))}</i><i class="gf-layer">${b.layers}层</i></span>
            <span class="gf-pips">未领悟</span>
          </div>
          <div class="gf-desc">${b.desc}</div>
          <div class="gf-preview">圆满效果：${gongfaBonusText(b, b.layers)}</div>
          <div class="gf-book">秘籍：<b>${bookHeldCount(b.key)}/${b.cost}</b> 本 ${req.ok ? "" : '<span class="muted">（秘境 BOSS 可得 / 花灵石寻访）</span>'}</div>
          <button class="btn-sm gf-up" data-action="gflearn" data-key="${b.key}" ${req.ok ? "" : "disabled"}>领悟（需《${b.name}》×${b.cost}）</button>
        </div>`;
      }
      const cost = gongfaCost(b, lv + 1);
      return `<div class="gf-row ${maxed ? "maxed" : ""}">
        <div class="gf-line">
          <span class="gf-name">${attrIcon(mainAttr)}${b.name}<i class="gf-tier">${gongfaGradeName(gongfaGrade(b))}</i>${maxed ? '<i class="gf-full">圆满</i>' : ""}</span>
          <span class="gf-pips">${gongfaPips(lv, b.layers)} <b>${lv}/${b.layers}</b></span>
        </div>
        <div class="gf-bonus">${gongfaBonusText(b, lv)}</div>
        <div class="gf-desc">${b.desc}</div>
        <div class="gf-equipline">战斗归类：${GONGFA_V2_CATEGORIES[gfCat].name} · ${GONGFA_V2_CATEGORIES[gfCat].desc} ${gfEq ? '<b class="gf-equipped">已装备</b>' : `<button class="btn-sm" data-action="gfequip" data-key="${b.key}">装备至${GONGFA_V2_CATEGORIES[gfCat].name}位</button>`}</div>
        ${maxed
          ? `<div class="gf-fulltip">已圆满 · 收益翻倍</div>`
          : `<button class="btn-sm gf-up" data-action="gongfaup" data-key="${b.key}">参悟第 ${lv + 1} 层（悟道 ${fmt(cost.wudao)}）</button>`}
      </div>`;
    }).join("");
    body += `<div class="gf-tier-block ${anyUnlocked ? "" : "locked"}">
      <div class="gf-tier-head">${gongfaGradeName(t)}功法 <span class="muted">${list.length} 部</span></div>
      ${rows}
    </div>`;
  }

  return `<div class="card">
    <div class="build-head">
      <span>功法</span>
      <span>悟道 ${fmt(S.wudao || 0)}（+${fmt(cultivationRate() * CONFIG.GONGFA_WUDAO_RATE)}/秒）／ 残卷 ${Math.floor(S.talisman || 0)} 卷 ／ 圆满 ${fullCnt}/${CONFIG.GONGFA_BOOKS.length}</span>
    </div>
    <div class="build-row">
      <button class="btn-sm" data-action="gfrefine" ${(S.talisman || 0) >= CONFIG.PILLS.REFINE_TALISMAN ? "" : "disabled"}>参悟残卷（${CONFIG.PILLS.REFINE_TALISMAN} 卷 → 1 秘籍）</button>
      <button class="btn-sm" data-action="gfsearch">寻访秘籍（${fmt(Math.floor(CONFIG.TALISMAN_PRICE * 6 * (1 + (S.realm || 0) * 0.5)))} 石）</button>
    </div>
    <div class="gf-equip-summary">${Object.keys(GONGFA_V2_CATEGORIES).map(k => `${GONGFA_V2_CATEGORIES[k].name}：${gongfaEquipState()[k] ? esc(gongfaBook(gongfaEquipState()[k]).name) : "未装备"}`).join(" ｜ ")}</div>
    <div class="gf-sum">${sum.length ? sum.join(" ") : "尚未参悟"}</div>
    <div class="build-desc">秘籍来源：秘境 BOSS 掉落对应阶数秘籍 ／ 残卷参悟（3 卷换 1 本）／ 灵石寻访。残卷来自坊市、宗门藏经阁与事件。</div>
    <div class="build-out">${esc(elementSummary())}</div>
    <div class="gf-list">${body}</div>
  </div>`;
}

// ---------- 人物 ----------
function viewChar() {
  const p = playerCombat();
  return `
    <div class="view char">
      <div class="bg-cover" style="background-image:url('assets/修士立绘.webp')"></div>
      <div class="content">
        ${pageHeadHtml("char")}
        ${secHeadHtml("道体")}
        <div class="card char-card">
          <div class="char-head">
            <img class="char-avatar" src="${currentAvatar().img}" alt="">
            <div class="char-id">
              <div class="char-name">${esc(S.playerName || "无名散修")}</div>
              <div class="char-avatar-name">${realmName()}期 · 第${S.layer + 1}层 ｜ ${currentAvatar().name}</div>
              <button class="btn-sm char-change" data-action="pickavatar">更换形象</button>
              <button class="btn-sm char-change" data-action="switchchar">道号</button>
            </div>
          </div>
          <div class="attr-row">${attrIcon("atk")}攻击 <b>${fmt(p.attack)}</b></div>
          <div class="attr-row">${attrIcon("def")}防御 <b>${fmt(p.defense)}</b></div>
          <div class="attr-row">${attrIcon("hp")}血量 <b>${fmt(p.hp)}</b></div>
          <div class="attr-row">战力 <b>${fmt(playerPower())}</b></div>
          <div class="attr-row">渡劫成功率 <b>${(tribulationRate() * 100).toFixed(0)}%</b></div>
          <div class="attr-row">法宝加成 <b class="art-bonus">${artBonusText()}</b></div>
          ${affixSummaryText() ? `<div class="attr-row">法宝词条 <b class="art-bonus">${affixSummaryText()}</b></div>` : ""}
        </div>
        ${secHeadHtml("道途与功法")}
        <div class="card">
          <div class="build-head"><span>道途</span><span>${esc(daoDef(S.dao).name)}</span></div>
          <div class="build-desc">${esc(daoDef(S.dao).desc)} ｜ ${esc(daoSummary(S.dao))}</div>
          <button class="btn-sm" data-action="setdao">改修道途</button>
        </div>
        ${secHeadHtml("收藏与灵兽")}
        <div class="card">
          <div class="build-head"><span>古宝</span><span>${Object.keys(S.ancient || {}).length}/${CONFIG.ANCIENT_TREASURES.length} ｜ 图鉴收录</span></div>
          <div class="build-desc">古宝属收集图鉴：首探秘境得古宝，击杀章 BOSS 得碎片。套装详情与升星/注灵在「道途 → 古宝图鉴」，碎片合成在「储物袋」。</div>
          <div class="build-out">${(typeof ancientBonusTxt === "function" ? ancientBonusTxt(ancientBonus()) : "") || "尚无古宝"}</div>
          <button class="btn-sm" data-action="tab" data-tab="codex">去古宝图鉴</button>
        </div>
        ${viewGongfaCard()}
        ${viewPetCard()}
        ${viewArtSlotCard()}
        <div class="card">
          <div class="build-head"><span>道心</span><span>战 ${storyBonus().war} ／ 道 ${storyBonus().dao}（共 ${CONFIG.CHAPTERS.length} 章）</span></div>
          <div class="build-desc">章节剧情可在首次通关各章 BOSS 时二选一：执剑入世 +${CONFIG.STORY_WAR_ATK * 100}% 攻击／守心问道 +${CONFIG.STORY_DAO_CULT * 100}% 修炼，永久生效且不可更改。</div>
          ${storyEnding() ? `<div class="build-out">道心：<b>${storyEnding().title}</b></div>` : `<div class="build-out muted">五章选满后结算道心</div>`}
        </div>
        <div class="card">
          <div class="build-head"><span>丹药</span><span>×${S.pills} ｜ 药力 ${S.pillBuff || 0}/${pillBuffCapLayers()}（修炼 +${(Math.min((S.pillBuff || 0) * CONFIG.PILL_RATE_BONUS, CONFIG.PILL_BONUS_CAP) * 100).toFixed(0)}%）</span></div>
          <div class="build-desc">服用可炼化药力：每层修炼 +${CONFIG.PILL_RATE_BONUS * 100}%，上限 +${CONFIG.PILL_BONUS_CAP * 100}%。药力上限 = 炼丹房等级 × 10 层，升级炼丹房可扩容。</div>
          <button class="btn-sm" data-action="usepill">炼化药力</button>
        </div>
        <div class="card">
          <div class="build-head"><span>渡劫丹</span><span>×${S.tribPills}${S.tribPillBuff > 0 ? " ｜ 已服 ×" + S.tribPillBuff : ""}</span></div>
          <div class="build-desc">服用后下次渡劫成功率 +15%/枚（可叠加，渡劫后消耗）。坊市有售。</div>
          <button class="btn-sm" data-action="usetribpill">服用</button>
        </div>
        ${secHeadHtml("设置与存档")}
        <div class="card">
          <div class="build-head"><span>游戏偏好</span><span>当前道号独立保存</span></div>
          <div class="build-desc">调整战斗节奏、界面动效与文字大小；存档支持导出备份和导入恢复。</div>
          <div class="build-row">
            <button class="btn-sm" data-action="settings">游戏设置</button>
            <button class="btn-sm" data-action="exportsave">导出存档</button>
            <button class="btn-sm" data-action="importsave">导入存档</button>
          </div>
        </div>
        <div class="card danger">
          <div class="build-head"><span>危险操作</span><span>不可撤销</span></div>
          <button class="btn-sm" data-action="reset">重置当前道号</button>
        </div>
      </div>
    </div>`;
}

// ---------- 道途录（v0.6.5） ----------
function viewCodex() {
  // —— 成就（按 key 前缀分组，避免再维护一份分类表）——
  const groups = {};
  for (const def of CONFIG.ACHIEVEMENTS) {
    const g = achievementGroup(def);
    (groups[g] = groups[g] || []).push(def);
  }
  const achHtml = Object.keys(groups).map(g => {
    const list = groups[g];
    const doneN = list.filter(d => S.achievements && S.achievements[d.key] != null).length;
    const rows = list.map(def => {
      const done = S.achievements && S.achievements[def.key] != null;
      return `<div class="ach-row ${done ? "done" : ""}">
        <span class="ach-mark">${done ? "✓" : "○"}</span>
        <span class="ach-body"><b>${esc(def.name)}</b><span class="ach-desc">${esc(def.desc)}</span></span>
        <span class="ach-reward">${achievementRewardText(def.reward)}</span>
      </div>`;
    }).join("");
    return `<div class="card">
      <div class="build-head"><span class="build-name">${g}</span><span class="build-lv">${doneN}/${list.length}</span></div>
      ${rows}
    </div>`;
  }).join("");

  // —— 法宝图鉴：品阶 × 类型 网格 ——
  const artRows = CONFIG.ARTIFACT_TIERS.map(t => {
    const cells = CONFIG.ARTIFACT_TYPES.map(ty => {
      const seen = codexArtifactSeen(t.tier, ty.key);
      const icon = codexArtifactIcon(t.tier, ty.key);
      return `<div class="codex-cell ${seen ? "seen" : ""}" style="${seen ? "color:" + t.color : ""}">
        ${icon ? `<img src="${icon}" alt="">` : ""}
        <div class="codex-cell-t">${t.name}</div>
        <div class="codex-cell-s">${seen ? ty.slot : "？"}</div>
      </div>`;
    }).join("");
    return `<div class="codex-row">${cells}</div>`;
  }).join("");

  // —— 事迹图鉴 ——
  // v0.24.2：未解锁不显示插图（防剧透）；路径需包 <img> 渲染，不能直接插值
  const evRows = CONFIG.CODEX_EVENTS.map(e => {
    const seen = codexEventSeen(e.key);
    const icon = seen ? codexEventIcon(e.key) : "";
    return `<div class="codex-ev ${seen ? "seen" : ""}">
      ${icon ? `<img src="${icon}" alt="">` : ""}<span style="${seen && icon ? 'margin-left:4px' : ''}">${seen ? esc(e.name) : '？？？'}</span>
    </div>`;
  }).join("");

  // —— 妖兽图鉴（v0.8.0）——
  const beastRows = CONFIG.CODEX_BEASTS.map(b => {
    const seen = codexBeastSeen(b.key);
    const icon = seen ? codexBeastIcon(b.key) : "";
    return `<div class="codex-ev ${seen ? "seen" : ""}">
      ${icon ? `<img src="${icon}" alt="">` : ""}<span style="${seen && icon ? 'margin-left:4px' : ''}">${seen ? esc(b.name) : '？？？'}</span>
    </div>`;
  }).join("");

  // —— 秘境图鉴（v0.8.0）——
  const regionRows = CONFIG.CODEX_REGIONS.map(r => {
    const seen = codexRegionSeen(r.key);
    const icon = seen ? codexRegionIcon(r.key) : "";
    return `<div class="codex-ev ${seen ? "seen" : ""}">
      ${icon ? `<img src="${icon}" alt="">` : ""}<span style="${seen && icon ? 'margin-left:4px' : ''}">${seen ? esc(r.name) : '？？？'}</span>
    </div>`;
  }).join("");

  return `
    <div class="view codex">
      <div class="bg-cover" style="background-image:url('assets/道途书卷.webp')"></div>
      <div class="content">
        <div class="sec-title">道途录</div>
        <div class="card">
          <div class="attr-row">成就 <b>${achievementCount()} / ${achievementTotal()}</b></div>
          <div class="attr-row">古宝图鉴 <b>${Object.keys(S.ancient || {}).length} / ${CONFIG.ANCIENT_TREASURES.length}</b></div>
          <div class="attr-row">法宝图鉴 <b>${codexArtifactCount()} / ${codexArtifactTotal()}</b></div>
          <div class="attr-row">事迹图鉴 <b>${codexEventCount()} / ${codexEventTotal()}</b></div>
          <div class="attr-row">妖兽图鉴 <b>${codexBeastCount()} / ${codexBeastTotal()}</b></div>
          <div class="attr-row">秘境图鉴 <b>${codexRegionCount()} / ${codexRegionTotal()}</b></div>
          <div class="tip">成就达成即自动发放奖励，无需领取；图鉴一经收录永不丢失。</div>
        </div>
        <div class="sec-title small">古宝图鉴（点击套装看详情）</div>
        <div class="card">${typeof ancientSetCodexHtml === "function" ? ancientSetCodexHtml() : ""}</div>
        <div class="sec-title small">法宝图鉴（品阶 × 类型）</div>
        <div class="card">${artRows}</div>
        <div class="sec-title small">妖兽图鉴（章节守关 + 塔中妖兽）</div>
        <div class="card codex-ev-grid">${beastRows}</div>
        <div class="sec-title small">秘境图鉴</div>
        <div class="card codex-ev-grid">${regionRows}</div>
        <div class="sec-title small">事迹图鉴</div>
        <div class="card codex-ev-grid">${evRows}</div>
        <div class="sec-title small">成就</div>
        ${achHtml}
      </div>
    </div>`;
}

// ---------- 事件卡（数据驱动，v0.6.1 多链通用） ----------
function renderEventCard(ev) {
  const m = eventMeta(ev);
  const btns = (m.choices || []).map(c =>
    `<button class="${c.primary ? "btn-primary" : "btn-sm"}" data-action="event" data-choice="${c.key}"${c.disabled ? " disabled" : ""}>${c.label}</button>`
  ).join("");
  return `
    <div class="card event-card">
      <div class="build-name">${m.title}</div>
      <div class="build-desc">${m.desc}</div>
      <div class="build-row">${btns}</div>
    </div>`;
}

// ---------- 世界（动态世界） ----------
// ---------- 势力领地地图（v0.10.0） ----------
// 用 flex 宽度直观表达「领地占比」：领地越多，地图上占的面积越大。
// 不引入图片资源，纯 CSS 绘制，移动端自适应。
function viewFactionMap() {
  const territory = k => (S.factions[k] && S.factions[k].territory) || 0;
  const total = Math.max(1, CONFIG.FACTIONS.reduce((sum, f) => sum + territory(f.key), 0));
  const regions = CONFIG.FACTIONS.map(f => {
    const st = S.factions[f.key] || { power: 0, resource: 0, territory: 0, relation: 0 };
    const blessed = st.relation >= CONFIG.BLESSING_THRESHOLD;
    const share = Math.round((st.territory / total) * 100);
    return `<div class="map-region ${blessed ? "blessed" : ""}"
        style="flex:${Math.max(1, st.territory)};--fc:${f.color}">
      <div class="map-name" style="color:${f.color}">${f.name}</div>
      <div class="map-camp">${f.camp}</div>
      <div class="map-stat">领地 ${st.territory}（${share}%）</div>
      <div class="map-stat">实力 ${fmt(st.power)}</div>
      <div class="map-rel">关系 ${st.relation > 0 ? "+" : ""}${st.relation}${blessed ? " · 庇护" : ""}</div>
    </div>`;
  }).join("");
  return `
    <div class="sec-title small">天下形势</div>
    <div class="card map-card">
      <div class="faction-map">${regions}</div>
      <div class="map-legend">
        <span>区块宽度 = 领地占比</span>
        <span class="map-mine">⌂ 洞府（你）· 领地 ${playerTerritory()} 块</span>
      </div>
    </div>`;
}

function viewWorld() {
  const factions = CONFIG.FACTIONS.map(f => {
    const s = S.factions[f.key];
    const rel = s.relation;
    const hasBlessing = rel >= CONFIG.BLESSING_THRESHOLD;
    return `
      <div class="card faction-card">
        ${f.img ? `<div class="faction-art"><img src="${f.img}" alt=""></div>` : ""}
        <div class="faction-body">
          <div class="build-head">
            <span class="build-name" style="color:${f.color}">${f.name}</span>
            <span class="build-lv">${f.camp}</span>
          </div>
          <div class="attr-row">实力 <b>${fmt(s.power)}</b></div>
          <div class="attr-row">资源 <b>${fmt(s.resource)}</b></div>
          <div class="attr-row">领地 <b>${s.territory}</b></div>
          <div class="attr-row">关系 <b>${rel > 0 ? "+" : ""}${rel}</b></div>
          ${hasBlessing ? '<div class="build-out blessing">庇护生效（修炼+10% 渡劫+' + CONFIG.TRIB_BLESS_BONUS * 100 + '%）</div>' : ''}
        </div>
      </div>`;
  }).join("");
  const ev = S.activeEvent;
  const evHtml = ev ? renderEventCard(ev) : "";
  const marketHtml = `
    <div class="card market-card">
      <div class="build-head"><span class="build-name">坊市</span><span class="build-lv">行情每日波动 · 境界货架 ${esc(marketShelfCountdownText(marketShelfRemaining()))}</span></div>
      <div class="market-row">
        <span>灵草 <b>${fmt(S.market.herb)}</b> 灵石（持有 ${fmt(S.herbs)}）</span>
        <button class="btn-sm" data-action="buyherb">买10</button>
        <button class="btn-sm" data-action="sellherb">卖10</button>
      </div>
      <div class="market-row">
        <span>丹药 <b>${fmt(S.market.pill)}</b> 灵石（持有 ${fmt(S.pills)}）</span>
        <button class="btn-sm" data-action="buypill">买1</button>
        <button class="btn-sm" data-action="sellpill">卖1</button>
      </div>
      <div class="market-row">
        <span>渡劫丹 <b>${fmt(S.market.tribPill)}</b> 灵石（持有 ${S.tribPills}）</span>
        <button class="btn-sm" data-action="buytribpill">买1</button>
      </div>
      <div class="market-row">
        <span>灵材 <b>${fmt(S.market.material)}</b> 灵石（持有 ${fmt(S.materials || 0)}）</span>
        <button class="btn-sm" data-action="buymaterial">买10</button>
        <button class="btn-sm" data-action="sellmaterial">卖10</button>
      </div>
      <div class="market-row">
        <span>功法残卷 <b>${CONFIG.TALISMAN_PRICE}</b> 灵石（持有 ${Math.floor(S.talisman || 0)}）</span>
        <button class="btn-sm" data-action="buytalisman">买1</button>
      </div>
      <div class="market-row">
        <span>行情刷新 剩余 <b>${ensureMarketRefresh().left}</b>/${CONFIG.MARKET_REFRESH.DAILY} 次（${CONFIG.MARKET_REFRESH.COST} 灵石/次）</span>
        <button class="btn-sm" data-action="refreshmarket" ${ensureMarketRefresh().left <= 0 ? "disabled" : ""}>刷新行情</button>
      </div>
      <div class="market-row"><span><b>境界货架</b> · ${CONFIG.REALMS[Math.max(0, Math.min(CONFIG.REALMS.length - 1, S.realm || 0))]}期修士可购</span><span class="muted">每2小时自动换货</span></div>
      ${ensureMarketShelf().items.map((it, i) => `
        <div class="market-row deal-row"><span>${esc(it.name)} ×${it.stock} <b>${fmt(it.price)}</b> 灵石/件</span>${it.stock > 0 ? `<button class="btn-sm" data-action="buymarketshelf" data-i="${i}">买1</button>` : `<span class="muted">已售罄</span>`}</div>`).join("")}
      ${ensureDeals().items.map((it, i) => `
        <div class="market-row deal-row">
          <span>特价 ${esc(it.name)} <b>${dealPrice(it)}</b> 灵石 <span class="muted">（${Math.round(it.mult * 10)} 折）</span></span>
          ${it.bought ? `<span class="muted">已售罄</span>` : `<button class="btn-sm" data-action="buydeal" data-i="${i}">买</button>`}
        </div>`).join("")}
      ${(function () {
        const cleared = Object.keys(S.clearedMaps || {}).filter(k => S.clearedMaps[k]).map(Number);
        if (!cleared.length) return `<div class="market-row muted"><span>探明秘境后可买卖该章特产</span></div>`;
        const ch = Math.max.apply(null, cleared);
        return `<div class="market-row">
          <span>${CONFIG.FIELD_SPECIALTIES[ch]}（第${ch + 1}章特产） <b>${specialtyPrice(ch)}</b> 灵石（持有 ${specialtyCount(ch)}）</span>
          <button class="btn-sm" data-action="buyspecialty" data-ch="${ch}">买1</button>
          <button class="btn-sm" data-action="sellspecialty" data-ch="${ch}">卖1</button>
        </div>`;
      })()}
      <div class="tip">坊市只卖常规货；秘境通关、驻守采集、试炼塔是稀有材料的主要来源。</div>
    </div>`;
  const log = S.eventLog.slice(0, 10).map(l => `<div class="log-line"><span class="log-day">${esc(l.day)}</span>${esc(l.text)}</div>`).join("");
  return `
    <div class="view world">
      <div class="bg-cover" style="background-image:url('assets/天下山川.webp')"></div>
      <div class="content">
        ${pageHeadHtml("world")}
        <div class="sec-title">${dateStr()}</div>
        <div class="world-banner">
          <img src="assets/世界_山河长卷.webp" alt="">
          <div class="world-banner-text">
            <div class="world-banner-title">天下</div>
            <div class="world-banner-sub">正道 · 魔道 · 散修 ｜ 你的领地 ${playerTerritory()} 块</div>
          </div>
        </div>
        <div class="card">
          <div class="attr-row">声望 <b>${S.reputation}</b><span class="muted">（渡劫加成 +${(Math.min(Math.floor(S.reputation / 100) * CONFIG.TRIB_REP_BONUS, CONFIG.TRIB_REP_CAP) * 100).toFixed(0)}%，上限 +${CONFIG.TRIB_REP_CAP * 100}%）</span></div>
          <div class="build-desc">声望出口：兑换渡劫丹（${CONFIG.REP_TO_TRIBPILL} 声望/枚），或去「洞府」为弟子提升资质。</div>
          <div class="build-row">
            <button class="btn-sm" data-action="reptribpill">兑换渡劫丹(${CONFIG.REP_TO_TRIBPILL}声望)</button>
            <button class="btn-sm" data-action="tab" data-tab="build">去洞府提弟子资质</button>
          </div>
        </div>
        ${viewFactionMap()}
        <div class="card">
          <div class="build-head"><span>魔渊据点</span><span>已攻占 ${S.conquered || 0} 处</span></div>
          <div class="build-desc">攻打魔渊据点可掠夺灵石、提升声望，但会激怒魔道（关系 −${CONFIG.RAID.REL_HIT}），增加秘境被夺风险。</div>
          <button class="btn-sm" data-action="raid" ${S.stamina >= CONFIG.RAID.STAMINA ? "" : "disabled"}>攻打（体力 -${CONFIG.RAID.STAMINA}）</button>
        </div>
        ${secHeadHtml("日常与机缘")}
        <div class="card">
          <div class="build-head"><span>日常 · 机缘</span><span>${(function () {
            const n = (typeof claimableCount === "function") ? claimableCount() : 0;
            return n > 0 ? "可领 " + n + " 项" : "今日已清";
          })()} ｜ 机缘 ${S.fate || 0}</span></div>
          <div class="build-desc">每日／周常任务与天机阁机缘兑换集中于此，完成即在本地领取；这是它的唯一入口。</div>
          <button class="btn-sm" data-action="daily">${(function () {
            const n = (typeof claimableCount === "function") ? claimableCount() : 0;
            return n > 0 ? "领取日常奖励（" + n + "）" : "查看日常任务";
          })()}</button>
        </div>
        ${secHeadHtml("坊市与天机")}
        ${marketHtml}
        ${secHeadHtml("势力与据点")}
        ${factions}
        ${secHeadHtml("世界事件")}
        ${evHtml}
        <div class="sec-title small">天下大事</div>
        ${log || '<div class="tip">世界刚刚苏醒，尚无大事发生。</div>'}
        <div class="tip">与势力关系达 ${CONFIG.BLESSING_THRESHOLD} 可获得其庇护加成。</div>
      </div>
    </div>`;
}

// ---------- 词条洗练弹窗（v0.6.3，v0.6.4 支持锁定） ----------
function showRerollModal(id) {
  const a = S.artifacts.find(x => x.id === id);
  if (!a) return;
  if (!canReroll(a)) { toast(`${tierInfo(CONFIG.REROLL_MIN_TIER).name}及以上才有词条`); return; }
  const ti = tierInfo(a.tier);
  const baseCost = rerollCost(a.tier, false);
  const lockCost = rerollCost(a.tier, true);
  const cnt = CONFIG.AFFIX_COUNT[a.tier - 1] || 0;
  const lockBtns = canLockReroll(a)
    ? (a.affixes || []).map((af, i) =>
        `<button class="btn-sm" data-action="rerollconfirm" data-id="${a.id}" data-lock="${i}">🔒 锁「${af.name} ${(af.value * 100).toFixed(1)}%」</button>`
      ).join("")
    : "";
  showModal(`
    <div class="forge-box">
      <div class="result-title">🎲 词条洗练</div>
      <div class="result-line"><b style="color:${ti.color}">${esc(a.name)}</b>（${ti.name}）</div>
      <div class="result-line">当前词条：${affixHtml(a) || '<span class="muted">无</span>'}</div>
      <div class="result-line">全部重掷：灵材 ${baseCost.material}（持有 ${fmt(S.materials || 0)}）｜ 灵石 ${fmt(baseCost.stone)}（持有 ${fmt(S.stone)}）</div>
      ${lockBtns ? `<div class="result-line muted">锁定一条再洗（消耗翻倍 ${CONFIG.REROLL_LOCK_MULT}×，保住已有好词条）：灵材 ${lockCost.material} ｜ 灵石 ${fmt(lockCost.stone)}</div>` : ""}
      <div class="build-row">
        <button class="btn-primary" data-action="rerollconfirm" data-id="${a.id}">全部重掷（${cnt} 条）</button>
      </div>
      ${lockBtns ? `<div class="build-row">${lockBtns}</div>` : ""}
      <div class="build-row">
        <button class="btn-sm" data-action="closemodal">取消</button>
      </div>
    </div>`);
}

// 词条综合评分（与 artifactScore 的权重口径一致，便于玩家判断洗练是否值得）
function affixScoreValue(affixes) {
  if (!Array.isArray(affixes) || !affixes.length) return 0;
  let s = 0;
  for (const af of affixes) s += af.value * (af.key === "thorns" ? 120 : 100);
  return s * 100;
}

// 洗练结果对比（旧 → 新）
function renderRerollResult(r) {
  const a = r.artifact, ti = tierInfo(a.tier);
  const oldHtml = (r.oldAffixes && r.oldAffixes.length)
    ? r.oldAffixes.map(af => `<span class="affix-tag" style="color:${af.color};border-color:${af.color}">${af.name} ${(af.value * 100).toFixed(1)}%</span>`).join("")
    : '<span class="muted">无</span>';
  const oldScore = affixScoreValue(r.oldAffixes);
  const newScore = affixScoreValue(a.affixes);
  const cmp = newScore > oldScore ? "↑" : (newScore < oldScore ? "↓" : "＝");
  const cmpColor = newScore > oldScore ? "#5C7A6E" : (newScore < oldScore ? "#A93F2E" : "#8C8C8C");
  showModal(`
    <div class="forge-box">
      <div class="result-title">🎲 洗练完成</div>
      <div class="result-line"><b style="color:${ti.color}">${esc(a.name)}</b>（${ti.name}）</div>
      <div class="result-line">原词条：${oldHtml}</div>
      <div class="result-line">新词条：${affixHtml(a) || '<span class="muted">无</span>'}</div>
      <div class="result-line">词条评分：${oldScore.toFixed(1)} → <b style="color:${cmpColor}">${newScore.toFixed(1)} ${cmp}</b></div>
      ${r.locked ? `<div class="result-line">🔒 已锁定「${r.locked}」，其余词条已重掷</div>` : ""}
      <div class="result-line muted">消耗：灵材 ${r.cost.material} ｜ 灵石 ${fmt(r.cost.stone)}</div>
      <div class="build-row">
        <button class="btn-primary" data-action="reroll" data-id="${a.id}">再洗一次</button>
        <button class="btn-sm" data-action="closemodal">完成</button>
      </div>
    </div>`);
}

// ---------- 游戏设置（v0.52.0） ----------
function settingsState() {
  if (!S.settings || typeof S.settings !== "object") S.settings = { combatSpeed: 1, reducedMotion: false, textScale: "normal" };
  return S.settings;
}
function applySettings() {
  const st = settingsState();
  const root = document.documentElement;
  if (!root || !root.classList) return;
  root.classList.toggle("reduce-motion", !!st.reducedMotion);
  root.classList.toggle("large-text", st.textScale === "large");
}
function showSettingsModal() {
  const st = settingsState();
  showModal(`
    <div class="forge-box settings-box">
      <div class="result-title">⚙ 游戏设置</div>
      <div class="setting-row"><div><b>战斗速度</b><small>影响实时战斗的逻辑推进速度</small></div>
        <select data-setting="combatSpeed"><option value="1" ${st.combatSpeed === 1 ? "selected" : ""}>标准 ×1</option><option value="1.5" ${st.combatSpeed === 1.5 ? "selected" : ""}>加速 ×1.5</option><option value="2" ${st.combatSpeed === 2 ? "selected" : ""}>快速 ×2</option></select></div>
      <div class="setting-row"><div><b>减少动效</b><small>降低界面过渡与装饰动画</small></div><input type="checkbox" data-setting="reducedMotion" ${st.reducedMotion ? "checked" : ""}></div>
      <div class="setting-row"><div><b>文字大小</b><small>适合小屏阅读</small></div><select data-setting="textScale"><option value="normal" ${st.textScale === "normal" ? "selected" : ""}>标准</option><option value="large" ${st.textScale === "large" ? "selected" : ""}>较大</option></select></div>
      <div class="setting-row"><div><b>检查更新</b><small>当前构建 <span id="app-build">—</span></small></div><button class="btn-sm" data-action="checkupdate">检查</button></div>
      <div class="result-line muted">设置自动保存到当前道号，不影响其他角色存档。</div>
      <div class="build-row"><button class="btn-primary" data-action="closemodal">完成</button></div>
    </div>`);
  applySettings();
  refreshAppBuild();
}
function updateSetting(key, value) {
  const st = settingsState();
  if (key === "combatSpeed") { const n = Number(value); st.combatSpeed = [1, 1.5, 2].includes(n) ? n : 1; }
  else if (key === "reducedMotion") st.reducedMotion = !!value;
  else if (key === "textScale") st.textScale = value === "large" ? "large" : "normal";
  applySettings();
  save();
}

// ---------- 应用内更新（Android 壳提供 NativeBridge） ----------
function appBridge() {
  return (typeof window !== "undefined" && window.NativeBridge) ? window.NativeBridge : null;
}
function refreshAppBuild() {
  const el = document.getElementById("app-build");
  if (!el) return;
  const b = appBridge();
  el.textContent = (b && b.version) ? b.version() : "网页版";
}
function doCheckUpdate() {
  const b = appBridge();
  if (b && b.checkUpdate) { b.checkUpdate(); return; }
  toast("网页版不支持应用内更新");
}

// ---------- 存档导出 / 导入弹窗（v0.6.2） ----------
function showExportSaveModal() {
  const text = exportSaveText();
  showModal(`
    <div class="forge-box">
      <div class="result-title">💾 导出存档</div>
      <div class="result-line">方式一：点「复制存档码」，到新设备的「导入存档」粘贴。<br>方式二：点「下载文件」，保存 .json 备用。</div>
      <textarea id="export-text" class="save-area" readonly>${esc(text)}</textarea>
      <div class="build-row">
        <button class="btn-primary" data-action="copysave">复制存档码</button>
        <button class="btn-sm" data-action="dosavefile">下载文件</button>
        <button class="btn-sm" data-action="closemodal">关闭</button>
      </div>
      <div class="result-line muted">存档大小 ${(text.length / 1024).toFixed(1)} KB</div>
    </div>`);
}

function showImportSaveModal() {
  showModal(`
    <div class="forge-box">
      <div class="result-title">📥 导入存档</div>
      <div class="result-line">把存档码粘贴到下面，点「确认导入」。<b style="color:#A93F2E">当前进度会被覆盖，不可撤销。</b></div>
      <textarea id="import-text" class="save-area" placeholder="在此粘贴存档 JSON…"></textarea>
      <div class="build-row">
        <button class="btn-primary" data-action="doimport">确认导入</button>
        <button class="btn-sm" data-action="closemodal">取消</button>
      </div>
    </div>`);
}

// ---------- 炼制法宝弹窗（v0.6.0） ----------
function showForgeModal() {
  const capTier = forgeMaxTier();
  const lv = S.buildings.forge || 0;
  const rows = CONFIG.ARTIFACT_TIERS.map(t => {
    const locked = t.tier > capTier;
    const cost = forgeCost(t.tier);
    const rate = forgeRate(t.tier);
    const needLv = (t.tier - 1) * CONFIG.ARTIFACT_TIER_LV_STEP;
    return `<div class="forge-row ${locked ? "locked" : ""}">
      <span class="forge-tier" style="color:${t.color}">${t.name}</span>
      <span class="forge-meta">主+${Math.round(t.main * 100)}% 血+${(t.sub * 100).toFixed(1)}%</span>
      <span class="forge-meta">灵材${cost.material}·灵石${fmt(cost.stone)}</span>
      <span class="forge-meta">成功${Math.round(rate * 100)}%</span>
      ${locked
        ? `<span class="muted">需Lv.${needLv}</span>`
        : `<button class="btn-sm" data-action="forgeconfirm" data-tier="${t.tier}">炼制</button>`}
    </div>`;
  }).join("");
  showModal(`
    <div class="forge-box">
      <div class="result-title">⚒ 炼制法宝</div>
      <div class="result-line">消耗灵材与灵石，成功获得一件随机类型法宝；失败损失灵材、返还 50% 灵石</div>
      <div class="forge-list">${rows}</div>
      <div class="result-line">当前：灵材 ${fmt(S.materials || 0)} ｜ 灵石 ${fmt(S.stone)} ｜ 炼器坊 Lv.${lv}</div>
      <button class="btn-primary" data-action="closemodal">关闭</button>
    </div>`);
}

// ---------- 炼化升阶弹窗（v0.6.0） ----------
function showRefineModal(id) {
  const a = S.artifacts.find(x => x.id === id);
  if (!a) return;
  const ti = tierInfo(a.tier);
  const cands = refineCandidates(a);
  if (!cands.length) { toast("需要 1 件同类型同品阶的祭品法宝"); return; }
  const matCost = refineCost(a.tier);
  const nextTi = tierInfo(Math.min(a.tier + 1, maxTier()));
  const rows = cands.map(c => `
    <div class="forge-row">
      <span style="color:${tierInfo(c.tier).color}">${esc(c.name)}</span>
      <span class="forge-meta">${artifactAttrText(c)}</span>
      <button class="btn-sm" data-action="refineconfirm" data-id="${a.id}" data-sac="${c.id}">选为祭品</button>
    </div>`).join("");
  showModal(`
    <div class="forge-box">
      <div class="result-title">🔥 炼化升阶</div>
      <div class="result-line">
        主法宝：<b style="color:${ti.color}">${esc(a.name)}·${ti.name}</b> → <b style="color:${nextTi.color}">${nextTi.name}</b>
      </div>
      <div class="result-line">消耗：祭品法宝 ×1 ＋ 灵材 ${matCost}（持有 ${fmt(S.materials || 0)}）｜ 成功率 ${Math.round(refineRate() * 100)}%</div>
      <div class="result-line">成功：主法宝升一阶并重铸属性；失败：祭品消散，主法宝保留</div>
      <div class="forge-list">${rows}</div>
      <button class="btn-primary" data-action="closemodal">取消</button>
    </div>`);
}

// ---------- 战斗结果弹窗（速战 / 亲征共用，v0.15.0 抽出）----------
function showStageReward(n, st, modeLabel) {
  // 章节叙事（v0.11.0）：首次通关该章 BOSS，先给剧情再给战果
  if (st.story) {
    const pick = (st.story.choices || []).map((c, i) =>
      `<button class="${i === 0 ? "btn-primary" : "btn-sm"} story-choice"
        data-action="storychoice" data-ch="${st.story.ch}" data-pick="${c.key}">
        <b>${esc(c.label)}</b><span class="story-choice-desc">${esc(c.desc || "")}</span>
      </button>`).join("");
    showModal(`
      <div class="result story">
        <div class="result-title">${esc(st.story.title)}</div>
        <div class="story-text">${esc(st.story.text)}</div>
        <div class="story-choices">${pick}</div>
        <div class="result-line muted-line">灵石 +${fmt(st.stones)}${st.dropText ? "、" + st.dropText : ""} ｜ 此选择永久生效</div>
      </div>`);
    showView(currentTab);
    return;
  }
  showModal(`
    <div class="result win">
      <div class="result-title">✔ 大胜</div>
      <div class="result-line">击败 ${stageName(n)}${modeLabel ? "（" + modeLabel + "）" : ""}</div>
      <div class="result-line">获得 灵石 ${fmt(st.stones)}${st.dropText ? "、" + st.dropText : ""}</div>
      <button class="btn-primary" data-action="closemodal">继续</button>
    </div>`);
  showView(currentTab);
}

// ---------- 战斗执行（速战：按公式一键结算）----------
function doBattle(n) {
  const r = startBattle(n);
  if (!r.ok) { toast(r.msg); return; }
  if (r.win) { showStageReward(n, r, "速战"); return; }
  showModal(`
    <div class="result lose">
      <div class="result-title">✘ 落败</div>
      <div class="result-line">鏖战 ${r.rounds} 回合不敌</div>
      <div class="result-line">提示：提升境界或锻造法宝可增强战力</div>
      <button class="btn-primary" data-action="closemodal">继续</button>
    </div>`);
  showView(currentTab);
}

// ---------- 事件委托 ----------
function bindEvents() {
  document.body.addEventListener("change", e => {
    const el = e.target && e.target.closest ? e.target.closest("[data-setting]") : null;
    if (!el) return;
    updateSetting(el.dataset.setting, el.type === "checkbox" ? el.checked : el.value);
  });
  document.body.addEventListener("click", e => {
    if (e.target.dataset && e.target.dataset.close) { closeModal(); return; }
    const btn = e.target.closest("[data-action]");
    if (!btn) return;
    const a = btn.dataset.action;
    switch (a) {
      case "break": {
        const r = doBreak();
        if (r.ok && r.trib) {
          if (r.success) {
            showModal(`
              <div class="result win">
                <div class="result-title">⚡ 渡劫成功</div>
                <div class="result-line">雷劫淬体，晋升 ${realmName()}期！声望 +${CONFIG.TRIB_SUCCESS_REP}</div>
                ${r.pity
                  ? `<div class="result-line">心境圆融 · 保底必成</div>`
                  : `<div class="result-line">本次渡劫成功率 ${(r.rate * 100).toFixed(0)}%</div>`}
                <button class="btn-primary" data-action="closemodal">继续</button>
              </div>`);
          } else {
            showModal(`
              <div class="result lose">
                <div class="result-title">✘ 渡劫失败</div>
                <div class="result-line">天雷落体，损失剩余灵气 ${CONFIG.TRIB_FAIL_QI_LOSS * 100}%</div>
                <div class="result-line">已连败 ${r.fails} 次${r.fails >= CONFIG.TRIB_PITY - 1 ? " · 下次心境圆融必成" : " · 再败 " + (CONFIG.TRIB_PITY - r.fails - 1) + " 次后必成"}</div>
                <div class="result-line">提示：服用渡劫丹、结好青云门、积攒声望均可提升成功率</div>
                <button class="btn-primary" data-action="closemodal">重整旗鼓</button>
              </div>`);
          }
        } else if (r.ok) {
          toast(`突破成功！${realmName()}期 ${S.layer + 1}层`);
        } else toast(r.msg);
        showView(currentTab); break;
      }
      case "ascend": {
        const r = doAscend();
        if (r.ok) showModal(`<div class="result win"><div class="result-title">🎉 渡劫飞升</div><div class="result-line">道成飞升，问鼎长生！</div><button class="btn-primary" data-action="closemodal">继续修仙</button></div>`);
        showView(currentTab); break;
      }
      case "artup": {
        fldMoveSlot(parseInt(btn.dataset.i), -1, S.realm);
        showView(currentTab); break;
      }
      case "artdown": {
        fldMoveSlot(parseInt(btn.dataset.i), 1, S.realm);
        showView(currentTab); break;
      }
      case "artpick": showArtPick(parseInt(btn.dataset.i)); break;
      case "fabaoSkillPick": showFabaoSkillPick(); break;
      case "fabaoSkillSet": {
        const key = btn.dataset.key || null;
        const allowed = !key || (typeof equippedFabaoSkills === "function" && equippedFabaoSkills().some(x => x.key === key));
        if (!allowed) { toast("该法宝技已不属于当前装备中的法宝"); break; }
        S.fabaoSkillSlot = key;
        save(); closeModal(); showView(currentTab); break;
      }
      case "artset": {
        const i = parseInt(btn.dataset.i);
        const key = btn.dataset.key;
        const slots = artSlotList();
        const allowed = fldUnlockedSkills(S.realm).some(x => x.key === key);
        const duplicate = slots.some((x, idx) => x === key && idx !== i);
        if (!Number.isInteger(i) || i < 0 || i >= slots.length || !allowed || duplicate) {
          toast("该术式当前不可装备，或已占用其他槽位");
          break;
        }
        slots[i] = key;
        S.fieldSlots = slots;
        save();
        closeModal();
        showView(currentTab); break;
      }
      case "battle": doBattle(parseInt(btn.dataset.n)); break;
      case "battlehard": startFieldBattle(CONFIG.chapterOf(parseInt(btn.dataset.n))); break;
      case "entermap": startFieldBattle(parseInt(btn.dataset.ch)); break;
      case "dispatch": showDispatchModal(parseInt(btn.dataset.ch)); break;
      case "dispatchsettle": {
        const chs = parseInt(btn.dataset.ch);
        const rs = dispatchSettle(chs);
        if (!rs.ok) { toast(rs.msg); break; }
        toast(`结算单已出 · ${rs.name}`);
        showSettleModal(chs, rs);
        break;
      }
      case "upgradevein": {
        const chv = parseInt(btn.dataset.ch);
        const rv = upgradeFieldVein(chv);
        if (!rv.ok) { toast(rv.msg); break; }
        toast(`灵脉升至 Lv.${rv.lv} · 驻守产出提升`);
        showDispatchModal(chv);
        break;
      }
      case "fieldcommercebuild": {
        const ch = parseInt(btn.dataset.ch, 10), facility = btn.dataset.facility;
        const r = buildFieldCommerce(ch, facility);
        toast(r.ok ? `${FIELD_COMMERCE.FACILITIES[facility].name}建成，开始营业` : r.msg);
        showDispatchModal(ch); break;
      }
      case "fieldcommercesell": {
        const ch = parseInt(btn.dataset.ch, 10), facility = btn.dataset.facility;
        const r = fieldCommerceSell(ch, facility, btn.dataset.key, parseInt(btn.dataset.n, 10));
        toast(r.ok ? `售出${r.name} ×${r.n} · 灵石 +${r.total}` : r.msg);
        showDispatchModal(ch); break;
      }
      case "fieldresidentconvert": {
        const ch = parseInt(btn.dataset.ch, 10);
        const r = fieldResidentsConvert(ch);
        toast(r.ok ? `本地凡人完成引导，修士人口 +1（凡人 -${r.folkCost}，灵石 -${r.stoneCost}）` : r.msg);
        showDispatchModal(ch); break;
      }
      case "fieldresidentbuy": {
        const ch = parseInt(btn.dataset.ch, 10);
        const r = fieldResidentsBuyFromPlayer(ch, btn.dataset.key, parseInt(btn.dataset.n, 10));
        toast(r.ok ? `居民购买${invItemDef(r.key).name} ×${r.n} · 灵石 +${r.total}` : r.msg);
        showDispatchModal(ch); break;
      }
      case "mapassign": {
        const r = assignDispatch(parseInt(btn.dataset.ch), parseInt(btn.dataset.id));
        if (!r.ok) toast(r.msg);
        showDispatchModal(parseInt(btn.dataset.ch));
        break;
      }
      case "unmap": {
        const r = removeDispatch(parseInt(btn.dataset.ch), parseInt(btn.dataset.id));
        if (!r.ok) toast(r.msg);
        showDispatchModal(parseInt(btn.dataset.ch));
        break;
      }
      case "tower": {
        const r = challengeTower();
        if (!r.ok) { toast(r.msg); break; }
        if (r.win) {
          showModal(`
            <div class="result win">
              <div class="result-title">🗼 试炼塔 第 ${r.floor} 层 · 破关</div>
              <div class="result-line">灵石 +${fmt(r.reward.stone)}${r.reward.mat ? " ｜ 灵材 +" + r.reward.mat : ""}${r.reward.rep ? " ｜ 声望 +" + r.reward.rep : ""} ｜ 塔币 +${r.coin}</div>
              ${r.beast ? `<div class="result-line">🐾 妖兽图鉴收录「${esc(r.beast.name)}」</div>` : ""}
              <div class="result-line">下一层：第 ${r.floor + 1} 层</div>
              <button class="btn-primary" data-action="closemodal">继续攀登</button>
            </div>`);
        } else {
          showModal(`
            <div class="result lose">
              <div class="result-title">✘ 试炼塔 第 ${r.floor} 层 · 力竭</div>
              <div class="result-line">塔敌战力 ${fmt(r.enemyPower)} ｜ 我方战力 ${fmt(r.myPower)}</div>
              <div class="result-line">提升境界、装备法宝、服用丹药后再来，失败无任何损失。</div>
              <button class="btn-primary" data-action="closemodal">退下调息</button>
            </div>`);
        }
        showView(currentTab); break;
      }
      case "storychoice": {
        const ch = parseInt(btn.dataset.ch, 10);
        const pick = btn.dataset.pick;
        const res = chooseStory(ch, pick);
        if (!res.ok) { toast(res.msg); break; }
        showView(currentTab);
        if (res.ending) {
          showModal(`
            <div class="result story">
              <div class="result-title">☯ ${esc(res.ending.title)}</div>
              <div class="story-text">${esc(res.ending.desc)}</div>
              <div class="result-line">战之抉择 ${res.war} 次 ｜ 道之抉择 ${res.dao} 次</div>
              <button class="btn-primary" data-action="closemodal">继续前行</button>
            </div>`);
        } else {
          showModal(`
            <div class="result win">
              <div class="result-title">道心已定</div>
              <div class="result-line">${esc(res.label)}：${esc(res.desc)}</div>
              <div class="result-line muted-line">战 ${res.war} ／ 道 ${res.dao}（共五章，选满后结算道心）</div>
              <button class="btn-primary" data-action="closemodal">继续</button>
            </div>`);
        }
        break;
      }
      case "towershop": showTowerShopModal(); break;
      case "artpage": {
        const pg = parseInt(btn.dataset.page, 10);
        const total = Math.max(1, Math.ceil(artifactFilteredList().length / CONFIG.ARTIFACT_PAGE_SIZE));
        artifactPage = Math.max(0, Math.min(total - 1, isNaN(pg) ? 0 : pg));
        showView(currentTab); break;
      }
      case "artfilter": {
        artifactFilter = btn.dataset.filter || "all";
        artifactPage = 0;
        showView(currentTab); break;
      }
      case "artsort": {
        const order = ["score", "tier", "newest"];
        artifactSort = order[(order.indexOf(artifactSort) + 1) % order.length];
        artifactPage = 0;
        showView(currentTab); break;
      }
      case "towerbuy": {
        const r = exchangeTower(btn.dataset.key);
        if (!r.ok) { toast(r.msg); break; }
        showView(currentTab);
        if (r.artifact) {
          const a = r.artifact, ti = tierInfo(a.tier);
          showModal(`
            <div class="result win">
              <div class="result-title">🏯 塔阁所得</div>
              <div class="result-line"><b style="color:${ti.color}">${esc(a.name)}</b>（${ti.name}）</div>
              <div class="result-line">${artifactAttrText(a)}</div>
              ${affixHtml(a) ? `<div class="result-line">${affixHtml(a)}</div>` : ""}
              <button class="btn-primary" data-action="closemodal">收下</button>
            </div>`);
        } else {
          showTowerShopModal();
          toast(`换取「${r.item.name}」`);
        }
        break;
      }
      case "upgrade": {
        const key = btn.dataset.key;
        const before = cultivationRate();
        const r = upgradeBuilding(key);
        if (!r.ok) { toast(r.msg); break; }
        if (key === "practice") {
          const after = cultivationRate();
          const name = (CONFIG.BUILDINGS.find(b => b.key === "practice") || {}).name || "练功房";
          toast(`${name}升至 Lv.${r.lv} · 修炼 ${rateText(before)}/秒 → ${rateText(after)}/秒`);
        } else {
          toast("升级成功");
        }
        showView(currentTab); break;
      }
      case "recruit": showRecruitModal(); break;
      case "assign": {
        const r = assignDisciple(btn.dataset.key);
        toast(r.ok ? "已委派" : r.msg);
        showView(currentTab); break;
      }
      case "unassign": {
        const r = unassignDisciple(btn.dataset.key);
        toast(r.ok ? "已撤回" : r.msg);
        showView(currentTab); break;
      }
      case "usepill": {
        const r = usePill();
        toast(r.ok ? `炼化药力 ${r.buff}/${r.cap}（修炼 +${(Math.min(r.buff * CONFIG.PILL_RATE_BONUS, CONFIG.PILL_BONUS_CAP) * 100).toFixed(0)}%）` : r.msg);
        showView(currentTab); break;
      }
      case "usetribpill": {
        const r = useTribPill();
        toast(r.ok ? `服下渡劫丹，下次渡劫成功率 +${CONFIG.TRIB_PILL_BONUS * 100}%（已叠 ${r.buff} 枚）` : r.msg);
        showView(currentTab); break;
      }
      case "pickavatar": showAvatarPicker(); break;
      case "switchchar": showSwitchCharModal(); break;
      case "newchar": doNewChar(); break;
      case "switchto": doSwitchChar(btn.dataset.name); break;
      case "cultdetail": showCultDetail(); break;
      case "bag": showInventory(); break;
      case "invitem": showItemDetail(btn.dataset.key); break;
      case "invfilter": showInventory(btn.dataset.cat); break;
      case "invback": showInventory(); break;
      case "invuse": {
        const k = _invDetailKey;
        const r = useItem(k);
        toast(useItemText(k, r));
        showInventory(); break;
      }
      case "invequip": {
        const r = equipArtifact(parseInt(btn.dataset.aid, 10));
        toast(r.ok ? `已装备 ${r.artifact ? r.artifact.name : "法宝"}` : r.msg);
        showInventory(); break;
      }
      case "invsalvage": {
        const aid = parseInt(btn.dataset.aid, 10);
        const a = (S.artifacts || []).find(x => x.id === aid);
        showModal(`<div class="result">
          <div class="result-title">分解法宝</div>
          <div class="result-line">分解 <b>${esc(a ? a.name : "法宝")}</b> 回收灵材？此操作不可撤销。</div>
          <div class="build-row">
            <button class="btn-sm danger" data-action="invsalvagedo" data-aid="${aid}">确认分解</button>
            <button class="btn-sm" data-action="invitem" data-key="art:${aid}">取消</button>
          </div></div>`);
        break;
      }
      case "invsalvagedo": {
        const r = dismantleArtifact(parseInt(btn.dataset.aid, 10));
        toast(r.ok ? `已分解 ${r.name}，回收灵材 ×${r.gain}` : r.msg);
        showInventory(); break;
      }
      case "invsell": {
        const k = _invDetailKey;
        const n = btn.dataset.n === "all" ? 1e9 : (parseInt(btn.dataset.n, 10) || 1);
        const r = invSell(k, n);
        toast(r.ok ? `出售 ${r.name} ×${fmt(r.count)}，得 ${fmt(r.gain)} 灵石` : r.msg);
        showInventory(); break;
      }
      case "invdrop": {
        const k = _invDetailKey;
        const def = invItemDef(k);
        const n = parseInt(btn.dataset.n, 10) || 1;
        showModal(`<div class="result">
          <div class="result-title">丢弃确认</div>
          <div class="result-line">丢弃 <b>${esc(def ? def.name : "物品")} ×${n}</b>？弃于荒野概不退还。</div>
          <div class="build-row">
            <button class="btn-sm danger" data-action="invdropdo" data-n="${n}">确认丢弃</button>
            <button class="btn-sm" data-action="invitem" data-key="${esc(k)}">取消</button>
          </div></div>`);
        break;
      }
      case "invdropdo": {
        const r = invDrop(_invDetailKey, parseInt(btn.dataset.n, 10) || 1);
        toast(r.ok ? `已丢弃 ${r.name} ×${fmt(r.count)}` : r.msg);
        showInventory(); break;
      }
      case "gfrefine": {
        const r = refineTalisman();
        toast(r.ok ? `参悟残卷，得《${r.book.name}》秘籍` : r.msg);
        showView("char"); break;
      }
      case "gfsearch": {
        const r = searchGongfaBook();
        toast(r.ok ? `寻得《${r.book.name}》秘籍（耗 ${fmt(r.price)} 灵石）` : r.msg);
        showView("char"); break;
      }
      case "invupgrade": {
        const r = invUpgrade();
        toast(r.ok ? `已换上 ${r.def.name}（${r.def.slots} 格 · 单格 ${r.def.stack}）` : r.msg);
        showInventory(); break;
      }
      case "invcompact": { invCompact(); toast("已整理：同类堆叠压紧"); showInventory(); break; }
      case "invrecall": {
        const r = invRecallStash();
        toast(r.got.length ? `入库：${r.got.join("、")}${r.left ? "（格子仍不足，剩余留在袋口）" : ""}` : "格子仍不足，先更换更高品级法器");
        showInventory(); break;
      }
      case "invbuy": {
        const r = buySeed(btn.dataset.crop, parseInt(btn.dataset.n, 10) || 1);
        toast(r.ok ? `购得 ${r.name} ×${r.count}，耗 ${fmt(r.cost)} 灵石` : r.msg);
        showGardenPanel(); break;
      }
      case "ancient": showAncientPanel(); break;
      case "sect": showSectPanel(); break;
      case "garden": showGardenPanel(); break;
      case "dan": showDanPanel(); break;
      case "danpick": showDanPick(btn.dataset.key); break;
      case "danstart": {
        const r = danStart(btn.dataset.key, parseInt(btn.dataset.mult, 10) || 1);
        toast(r.ok ? `开炉：${r.recipe.name}（${danMultDef(r.mult).name} · 火候 ${r.dur} 秒 · 成功率 ${Math.round(r.rate * 100)}%）` : r.msg);
        showDanPanel(); break;
      }
      case "danstartgo": {
        const r = danStart(btn.dataset.key, parseInt(btn.dataset.mult, 10) || 1);
        toast(r.ok ? `开炉：${r.recipe.name}（${danMultDef(r.mult).name} · 成功率 ${Math.round(r.rate * 100)}%）` : r.msg);
        showDanPanel(); break;
      }
      case "danclaim": {
        const r = danClaim(parseInt(btn.dataset.slot, 10));
        if (!r.ok) { toast(r.msg); showDanPanel(); break; }
        if (r.success) toast(r.crit ? `丹成上品！${r.name} ×${r.n}` : `收得 ${r.name} ×${r.n}`);
        else toast(`炸炉失丹（${r.name}）：返还灵草 ${r.backHerb}、灵材 ${r.backMat}`);
        showDanPanel(); break;
      }
      case "danabort": {
        const r = danAbort(parseInt(btn.dataset.slot, 10));
        toast(r.ok ? `已撤炉，返还灵草 ${r.backHerb}、灵材 ${r.backMat}` : r.msg);
        showDanPanel(); break;
      }
      case "avatar": showAvatarPanel(); break;
      case "friends": showFriendPanel(); break;
      case "gardenplant": {
        const i = parseInt(btn.dataset.i, 10);
        const rows = CONFIG.GARDEN.CROPS.map(c => {
          const normal = Math.floor(invCount(seedKeyOf(c.key)));
          const rare = Math.floor(invCount(seedKeyOf(c.key, true)));
          const locked = c.realm && (S.realm || 0) < c.realm;
          return `<div class="shop-item"><span>${esc(c.name)} <span class="muted">${Math.round(c.sec / 60)} 分 ｜ 普通 ${normal} · 异种 ${rare}</span></span>
            <span class="build-row">${locked ? `<span class="muted">需 ${CONFIG.REALMS[c.realm]}</span>` : ""}
            <button class="btn-sm" data-action="gardenplantdo" data-i="${i}" data-crop="${c.key}" ${normal > 0 && !locked ? "" : "disabled"}>普通种植</button>
            <button class="btn-sm" data-action="gardenplantdo" data-i="${i}" data-crop="${c.key}" data-rare="1" ${rare > 0 && !locked ? "" : "disabled"}>异种种植</button></span></div>`;
        }).join("");
        showModal(`<div class="result"><div class="result-title">选择种子</div><div class="shop-list">${rows}</div>
          <button class="btn-sm" data-action="garden">返回</button></div>`);
        break;
      }
      case "gardenplantdo": {
        const r = gardenPlant(parseInt(btn.dataset.i, 10), btn.dataset.crop, btn.dataset.rare === "1");
        toast(r.ok ? `已种下${r.rare ? "异种" : ""}${r.crop.name}` : r.msg);
        showGardenPanel(); break;
      }
      case "gardenplot": showGardenPlot(parseInt(btn.dataset.i, 10)); break;
      case "gardenfert": {
        const r = gardenFert(parseInt(btn.dataset.i, 10));
        toast(r.ok ? "已施肥，地力充盈" : r.msg);
        showGardenPanel(); break;
      }
      case "gardenwater": {
        const r = gardenWater(parseInt(btn.dataset.i, 10));
        toast(r.ok ? "已浇水 · 生长加速" : r.msg);
        showGardenPanel(); break;
      }
      case "gardenharvest": {
        const r = gardenHarvest(parseInt(btn.dataset.i, 10));
        if (!r.ok) { toast(r.msg); break; }
        const txt = Object.keys(r.out).filter(k => k !== "rareSeed").map(k => ({ herb: "灵草", pill: "丹药", material: "灵材" }[k] + " +" + r.out[k])).join("、");
        toast(r.mutated ? `灵植变异！${txt}，异种灵种 +1` : `收获：${txt}${r.withered ? "（枯萎减半）" : ""}`);
        showGardenPanel(); break;
      }
      case "gardenexpand": {
        const r = gardenExpand();
        toast(r.ok ? `药园扩至 ${r.size}×${r.size}` : r.msg);
        showGardenPanel(); break;
      }
      case "avatarmake": {
        const r = avatarUnlock();
        toast(r.ok ? "化身已开辟" : r.msg);
        showAvatarPanel(); break;
      }
      case "avatarduty": {
        const r = avatarSetDuty(btn.dataset.duty);
        toast(r.ok ? `化身改派：${r.duty}` : r.msg);
        showAvatarPanel(); break;
      }
      case "avatarup": {
        const r = avatarUpgrade();
        toast(r.ok ? `化身升至 Lv.${r.lv}` : r.msg);
        showAvatarPanel(); break;
      }
      case "avatarmap": {
        const r = avatarSetMap(parseInt(btn.dataset.ch, 10));
        toast(r.ok ? "化身已派驻" : r.msg);
        showAvatarPanel(); break;
      }
      case "avatarclaim": {
        const r = avatarClaim();
        toast(r.ok ? (r.gain.duty === "dan" ? `化身代炼：培元丹 +${fmt(Math.floor(r.gain.pill))}${r.gain.rare ? " ／ 稀有丹 +" + r.gain.rare : ""}`
          : r.gain.duty === "garden" ? `化身代采：灵草 +${fmt(r.gain.herb)} ｜ 丹药 +${fmt(r.gain.pill)} ｜ 灵材 +${fmt(r.gain.material)}`
          : `化身收获：灵石 +${fmt(r.gain.stone)} ｜ 灵气 +${fmt(r.gain.qi)}`) : r.msg);
        showAvatarPanel(); break;
      }
      case "friendevent": {
        const r = friendEventDo(btn.dataset.id);
        if (!r.ok) { toast(r.msg); showFriendPanel(); break; }
        toast(`${r.title}：${r.text}` + (r.gains.length ? "（" + r.gains.join("、") + "）" : ""));
        showFriendPanel(); break;
      }
      case "friendhelp": {
        const r = friendHelp(btn.dataset.id);
        toast(r.ok ? `${r.name}应约相助：修炼 +${Math.round(r.bonus * 100)}%，持续 ${r.hours} 小时` : r.msg);
        showFriendPanel(); break;
      }
      case "lovergift": {
        const r = loverGift();
        toast(r.ok ? r.text : r.msg);
        showFriendPanel(); break;
      }
      case "friendtrain": {
        const r = friendTrain(btn.dataset.id);
        toast(r.ok ? `传功完成 · 好感 ${r.rel}` : r.msg);
        showFriendPanel(); break;
      }
      case "friendgift": {
        const r = friendGift(btn.dataset.id);
        toast(r.ok ? `赠礼完成 · 好感 ${r.rel}` : r.msg);
        showFriendPanel(); break;
      }
      case "friendlover": {
        const r = friendBeLover(btn.dataset.id);
        toast(r.ok ? `与「${r.name}」结为道侣 · 修炼 +5%` : r.msg);
        showFriendPanel(); break;
      }
      case "frienddual": {
        const r = friendDualCultivate(btn.dataset.id);
        toast(r.ok ? `双修 · 灵气 +${fmt(r.gain)}` : r.msg);
        showFriendPanel(); break;
      }
      case "petinner": {
        const id = btn.dataset.id;
        const rows = CONFIG.PET_INNER.map(k => `
          <div class="shop-item"><span><b>${esc(k.name)}</b><span class="muted"> ${esc(k.desc)}</span></span>
            <button class="btn-sm" data-action="petinnerset" data-id="${id}" data-inner="${k.key}">镶嵌</button></div>`).join("");
        showModal(`<div class="result">
          <div class="result-title">灵兽内丹</div>
          <div class="result-line">每只灵兽 1 颗内丹，仅在出战时生效</div>
          <div class="shop-list">${rows}</div>
          <button class="btn-sm" data-action="petinnerclear" data-id="${id}">取出内丹</button>
          <button class="btn-primary" data-action="closemodal">关闭</button>
        </div>`);
        break;
      }
      case "petinnerset": {
        const r = setPetInner(btn.dataset.id, btn.dataset.inner);
        toast(r.ok ? "内丹已镶嵌" : r.msg);
        showView(currentTab); break;
      }
      case "petinnerclear": {
        const r = clearPetInner(btn.dataset.id);
        toast(r.ok ? "内丹已取出" : r.msg);
        closeModal(); showView(currentTab); break;
      }
      case "raid": {
        const r = raidMoyuan();
        if (!r.ok) { toast(r.msg); break; }
        toast(r.win ? `攻破据点 · 灵石 +${fmt(r.gain)} · 声望 +${r.rep}` : "攻打失利 · 声望受损");
        showView(currentTab); break;
      }
      case "sectdonate": {
        const r = sectDonate();
        toast(r.ok ? `供奉完成 · 贡献 +${r.contrib}` : r.msg);
        showSectPanel(); break;
      }
      case "sectclaim": {
        const r = claimSectTask(btn.dataset.key);
        toast(r.ok ? `「${r.name}」完成 · 贡献 +${r.contrib}` : r.msg);
        showSectPanel(); break;
      }
      case "sectbuy": {
        const r = buySectItem(btn.dataset.key);
        toast(r.ok ? `兑换「${r.item.name}」` : r.msg);
        showSectPanel(); break;
      }
      case "secttrial": {
        const r = sectTrialRun();
        if (!r.ok) { toast(r.msg); break; }
        toast(`护法试炼：过 ${r.wave} 波 ｜ 贡献 +${r.contrib} ｜ 灵石 +${fmt(r.stone)}`);
        showSectPanel(); break;
      }
      case "sectdiplo": {
        const r = sectDiplomacy(btn.dataset.faction);
        toast(r.ok ? `关系提升至 ${r.rel}` : r.msg);
        showSectPanel(); break;
      }
      case "appoint": showAppointModal(parseInt(btn.dataset.ch, 10), btn.dataset.office); break;
      case "appointpick": {
        const r = appointStaff(parseInt(btn.dataset.ch, 10), btn.dataset.office, btn.dataset.id);
        toast(r.ok ? `${r.disciple.name} 任${r.office.name}` : r.msg);
        showDispatchModal(parseInt(btn.dataset.ch, 10)); break;
      }
      case "missions": showMissionPanel(); break;
      case "missionpick": showMissionPick(btn.dataset.type); break;
      case "missionstart": {
        const r = missionStart(btn.dataset.type, null, btn.dataset.id);
        toast(r.ok ? `${r.def.name} 已派出` : r.msg);
        showMissionPanel(); break;
      }
      case "dynoffice": showDynastyOfficeModal(); break;
      case "dynappointpick": showDynAppointPick(btn.dataset.office); break;
      case "dynappoint": {
        const r = dynastyAppoint(btn.dataset.office, btn.dataset.id);
        toast(r.ok ? `${r.disciple.name} 任${r.office.name}` : r.msg);
        showDynastyOfficeModal(); break;
      }
      case "ransom": {
        const r = ransomField(parseInt(btn.dataset.ch, 10));
        toast(r.ok ? `秘境已赎回（灵石 -${fmt(r.cost)}）` : r.msg);
        showView(currentTab); break;
      }
      case "recruitmap": showRecruitCandidates(btn.dataset.ch); break;
      case "hirecand": {
        const r = hireCandidate(parseInt(btn.dataset.i, 10));
        if (!r.ok) { toast(r.msg); break; }
        toast(`收得弟子「${r.disciple.name}」（${r.disciple.root}）`);
        showRecruitCandidates(S.recruitPool.ch); break;
      }
      case "refreshcand": {
        const r = refreshCandidates();
        toast(r.ok ? "候选已刷新" : r.msg);
        if (r.ok) showRecruitCandidates(S.recruitPool.ch); break;
      }
      case "temple": {
        const ch = parseInt(btn.dataset.ch, 10);
        const r = upgradeTemple(ch);
        toast(r.ok ? `神庙升至 Lv.${r.lv} · 安定 +15` : r.msg);
        showDispatchModal(ch); break;
      }
      case "soothe": {
        const ch = parseInt(btn.dataset.ch, 10);
        const r = sootheField(ch);
        toast(r.ok ? `安抚完成 · 安定度 ${r.stable}` : r.msg);
        showDispatchModal(ch); break;
      }
      case "founddynasty": {
        const nm = (typeof prompt === "function") ? (prompt("王朝名号（最多 8 字）", "大衍王朝") || "大衍王朝") : "大衍王朝";
        const r = foundDynasty(nm);
        toast(r.ok ? `凡间王朝「${r.dynasty.name}」立成 · 凡人大兴` : r.msg);
        showView(currentTab); break;
      }
      case "upgrademine": {
        const r = upgradeFieldMine(parseInt(btn.dataset.ch, 10));
        toast(r.ok ? `矿场升至 Lv.${r.lv}` : r.msg);
        showDispatchModal(parseInt(btn.dataset.ch, 10)); break;
      }
      case "upgradegarden": {
        const r = upgradeFieldGarden(parseInt(btn.dataset.ch, 10));
        toast(r.ok ? `药圃升至 Lv.${r.lv}` : r.msg);
        showDispatchModal(parseInt(btn.dataset.ch, 10)); break;
      }
      case "warmart": {
        const r = warmArtifact(parseInt(btn.dataset.id, 10));
        toast(r.ok ? `温养成功 · Lv.${r.lv}（评分 +${r.lv * 2}%）` : r.msg);
        showView(currentTab); break;
      }
      case "insightskill": {
        const r = insightSkill(btn.dataset.key);
        toast(r.ok ? `参悟成功 · Lv.${r.lv}（倍率 +${r.lv * 3}%）` : r.msg);
        showView(currentTab); break;
      }
      case "foundsect": {
        const nm = (typeof prompt === "function") ? (prompt("宗门名号（最多 6 字）", "长生宗") || "长生宗") : "长生宗";
        const r = foundSect(nm);
        toast(r.ok ? `宗门「${r.sect.name}」立成 · 全属性与修炼提升` : r.msg);
        showView(currentTab); break;
      }
      case "upgradesect": {
        const r = upgradeSect();
        toast(r.ok ? `宗门升至 Lv.${r.lv}` : r.msg);
        showView(currentTab); break;
      }
      case "ancset": showAncientSetDetail(btn.dataset.set); break;
      case "craft": showCraftPanel(); break;
      case "innerview": showInnerView(); break;
      case "meridianopen": {
        const r = openMeridianHole(btn.dataset.key);
        if (!r.ok) { toast(r.msg); break; }
        const mdef = meridianDef(btn.dataset.key);
        toast(r.allFull ? `三脉贯通 · 大周天！打通「${r.name}」`
          : r.zhoutian ? `${mdef.name}小周天 · 打通「${r.name}」`
          : `打通「${r.name}」`);
        if (currentTab === "home") showView("home");
        // v0.51.0：带上刚打通的穴位与前后属性，面板里播放扩散光环 + 增量对比
        showInnerView({
          flash: { key: btn.dataset.key, idx: r.hole - 1 },
          delta: {
            before: r.before, after: r.after,
            label: `${mdef.name}「${r.name}」打通`,
            note: r.allFull ? "大周天已成" : (r.zhoutian ? "此脉小周天" : `第 ${r.hole} 穴`),
          },
        });
        break;
      }
      case "dantianraise": {
        const r = raiseDantian();
        toast(r.ok ? (r.first ? `凝丹成功 · 丹田初成 Lv.${r.lv}` : `丹田升至 Lv.${r.lv} 转`) : r.msg);
        if (currentTab === "home") showView("home");
        if (r.ok) {
          showInnerView({
            delta: {
              before: r.before, after: r.after,
              label: r.first ? "凝丹 · 丹田初成" : `丹田第 ${r.lv} 转`,
              note: r.lv >= CONFIG.DANTIAN.MAX ? "九转圆满" : "",
            },
          });
        } else showInnerView();
        break;
      }
      case "ancstar": {
        const r = starUpAncient(btn.dataset.key);
        toast(r.ok ? `升星成功 · 当前 ${r.star} 星` : r.msg);
        showCraftPanel();
        break;
      }
      case "ancinfuse": {
        const r = infuseAncient(btn.dataset.key);
        toast(r.ok ? `注灵成功 · Lv.${r.infuse}` : r.msg);
        showCraftPanel();
        break;
      }
      case "ancforge": {
        const set = btn.dataset.set;
        const r = forgeAncient(set);
        toast(r.ok ? `合成古宝「${r.item.name}」` : r.msg);
        // 从储物袋发起 → 留在碎片详情；从图鉴发起 → 回该套详情
        if (typeof _invDetailKey === "string" && _invDetailKey.indexOf("frag:") === 0 && typeof showItemDetail === "function") {
          showItemDetail(_invDetailKey);
        } else {
          showAncientSetDetail(set);
        }
        break;
      }
      case "buydeal": {
        const r = buyDeal(parseInt(btn.dataset.i, 10));
        toast(r.ok ? `购得特价 ${r.item.name}（灵石 -${r.price}）` : r.msg);
        showView(currentTab); break;
      }
      case "tuna": showTunaModal(); break;
      case "daily": showDailyPanel(); break;
      case "claimtask": {
        const rc = claimTask(btn.dataset.kind, btn.dataset.key);
        toast(rc.ok ? `「${rc.name}」完成 · 机缘 +${rc.fate}` : rc.msg);
        showDailyPanel(); break;
      }
      case "fatefuqi": {
        const rf = fateFuQi();
        toast(rf.ok ? `服下修为福袋 · 灵气 +${fmt(rf.gain)}` : rf.msg);
        showDailyPanel(); break;
      }
      case "fatetalisman": {
        const rt2 = fateTalisman();
        toast(rt2.ok ? "兑换功法要诀 ×1" : rt2.msg);
        showDailyPanel(); break;
      }
      case "fateincense": {
        const ri = fateIncense();
        toast(ri.ok ? "兑换引魔香 ×1" : ri.msg);
        showDailyPanel(); break;
      }
      case "setdao": showDaoPicker(); break;
      case "setdaoapply": {
        const rs = setDao(btn.dataset.key);
        if (!rs.ok) { toast(rs.msg); break; }
        closeModal();
        toast(`道途改为「${rs.path.name}」`);
        showView(currentTab); break;
      }
      case "refreshmarket": {
        const rm = refreshMarket();
        toast(rm.ok ? `行情已刷新（剩余 ${rm.left} 次）` : rm.msg);
        showView(currentTab); break;
      }
      case "buymarketshelf": {
        const rbm = buyMarketShelf(parseInt(btn.dataset.i, 10));
        toast(rbm.ok ? `购得 ${rbm.item.name} ×1` : rbm.msg);
        showView(currentTab); break;
      }
      case "buyspecialty": {
        const rb = buySpecialty(parseInt(btn.dataset.ch), 1);
        toast(rb.ok ? `购得 ${CONFIG.FIELD_SPECIALTIES[parseInt(btn.dataset.ch)]} ×1` : rb.msg);
        showView(currentTab); break;
      }
      case "sellspecialty": {
        const rs2 = sellSpecialty(parseInt(btn.dataset.ch), 1);
        toast(rs2.ok ? `售出特产 · 灵石 +${fmt(rs2.gain)}` : rs2.msg);
        showView(currentTab); break;
      }
      case "buytalisman": {
        const rt = buyTalisman();
        toast(rt.ok ? `购得功法要诀 ×1（灵石 -${rt.cost}）` : rt.msg);
        showView(currentTab); break;
      }
      case "setavatar": {
        const r = setAvatar(btn.dataset.key);
        if (!r.ok) { toast(r.msg); break; }
        closeModal();
        showView(currentTab);
        toast(`形象已更换为「${r.avatar.name}」`);
        break;
      }
      case "petset": {
        const r = setActivePet(btn.dataset.on === "1" ? parseInt(btn.dataset.id) : null);
        toast(r.ok ? (r.pet ? `「${petDef(r.pet.key).name}」出战` : "灵兽已休息") : r.msg);
        showView(currentTab); break;
      }
      case "pettrain": {
        const r = trainPet(parseInt(btn.dataset.id));
        toast(r.ok ? (r.levelUp ? `灵兽升至 Lv.${r.pet.lv}` : `培养完成（${r.pet.exp}/${CONFIG.PET_EXP_PER_LV * r.pet.lv}）`) : r.msg);
        showView(currentTab); break;
      }
      case "petrelease": {
        const id = parseInt(btn.dataset.id);
        const pt = (S.pets || []).find(x => x.id === id);
        if (!pt) break;
        if (!confirm(`放生「${petDef(pt.key).name}」（Lv.${pt.lv}）？不可恢复。`)) break;
        const r = releasePet(id);
        toast(r.ok ? "已放生" : r.msg);
        showView(currentTab); break;
      }
      case "petfeed": {   // v0.24.0：喂食灵草提升亲密度
        const r = feedBond(parseInt(btn.dataset.id));
        toast(r.ok ? `亲密度提升至 ${Math.round(r.bond)}` : r.msg);
        showView(currentTab); break;
      }
      case "petfuse": {   // v0.24.0：打开选素材弹窗
        petFuseModal(parseInt(btn.dataset.id)); break;
      }
      case "petfusedo": {
        const r = fuseStar(parseInt(btn.dataset.target), parseInt(btn.dataset.fodder));
        closeModal();
        toast(r.ok ? `融合成功！${petDef(r.pet.key).name} 升至 ${r.star} 星` : r.msg);
        showView(currentTab); break;
      }
      case "gflearn": {
        const r = learnGongfa(btn.dataset.key);
        toast(r.ok ? `领悟「${r.book.name}」` : r.msg);
        showView(currentTab); break;
      }
      case "gfequip": {
        const r = equipGongfaV2(btn.dataset.key);
        toast(r.ok ? `${r.book.name} 已装备至${GONGFA_V2_CATEGORIES[r.category].name}位` : r.msg);
        showView(currentTab); break;
      }
      case "gongfaup": {
        const r = upgradeGongfa(btn.dataset.key);
        if (!r.ok) { toast(r.msg); break; }
        toast(r.full
          ? `「${r.book.name}」圆满！收益翻倍 · 悟道 -${fmt(r.cost.wudao)}`
          : r.node
            ? `「${r.book.name}」第 ${r.lv} 层 · 悟道 -${fmt(r.cost.wudao)} · 关窍开启：${r.node.desc}`
            : `「${r.book.name}」精进至第 ${r.lv} 层 · 悟道 -${fmt(r.cost.wudao)}`);
        showView(currentTab); break;
      }
      case "event": {
        const r = resolveEvent(btn.dataset.choice);
        if (!r.ok) { toast(r.msg); break; }
        if (r.next) {
          if (r.summary) toast(r.summary);
          showView(currentTab);
        } else if (r.summary) {
          showModal(`
            <div class="result ${r.tone || "win"}">
              <div class="result-title">${r.title || "事件结算"}</div>
              <div class="result-line">${r.summary}</div>
              <button class="btn-primary" data-action="closemodal">继续</button>
            </div>`);
          showView(currentTab);
        } else {
          toast("事件已处理");
          showView(currentTab);
        }
        break;
      }
      case "buyherb": {
        const r = buyHerb();
        toast(r.ok ? `购入灵草×${r.n}，-灵石${fmt(r.cost)}` : r.msg);
        showView(currentTab); break;
      }
      case "sellherb": {
        const r = sellHerb();
        toast(r.ok ? `售出灵草×${r.n}，+灵石${fmt(r.gain)}` : r.msg);
        showView(currentTab); break;
      }
      case "buypill": {
        const r = buyPill();
        toast(r.ok ? `购入丹药×1，-灵石${fmt(r.cost)}` : r.msg);
        showView(currentTab); break;
      }
      case "sellpill": {
        const r = sellPill();
        toast(r.ok ? `售出丹药×1，+灵石${fmt(r.gain)}` : r.msg);
        showView(currentTab); break;
      }
      case "buytribpill": {
        const r = buyTribPill();
        toast(r.ok ? `购入渡劫丹×1，-灵石${fmt(r.cost)}` : r.msg);
        showView(currentTab); break;
      }
      case "reptribpill": {
        const r = exchangeRepForTribPill();
        toast(r.ok ? `以 ${r.cost} 声望换得渡劫丹×1（现有 ${r.tribPills}）` : r.msg);
        showView(currentTab); break;
      }
      case "upapt": {
        const r = upgradeDiscipleAptitude(parseInt(btn.dataset.id));
        toast(r.ok ? `「${r.name}」资质 ${r.before} → ${r.after}（-${r.cost} 声望）` : r.msg);
        showView(currentTab); break;
      }
      case "traindisciple": {
        const r = trainDisciple(btn.dataset.id, btn.dataset.method, btn.dataset.count || 1);
        if (!r.ok) toast(r.msg);
        else toast(`培养「${S.disciples.find(d => String(d.id) === String(btn.dataset.id)).name}」：${r.count > 1 ? `消耗${r.count}${r.method === "qi" ? "次灵气灌注" : "枚培元丹"}，` : ""}修为 +${r.gain}${r.levels ? `，突破 ${r.levels} 层` : ""}（${r.after}）`);
        showView(currentTab); break;
      }
      case "openforge": showForgeModal(); break;
      case "forgeconfirm": {
        const r = forgeArtifact(parseInt(btn.dataset.tier));
        if (!r.ok) { toast(r.msg); break; }
        if (r.success) {
          const a = r.artifact, ti = tierInfo(a.tier);
          showModal(`
            <div class="result win">
              <div class="result-title">✨ 炼成法宝</div>
              <div class="result-line"><b style="color:${ti.color}">${esc(a.name)}</b>（${ti.name} · ${typeInfo(a.type).slot}）</div>
              <div class="result-line">${artifactAttrText(a)}</div>
              <div class="result-line">品质 ${Math.round(a.roll * 100)}%（浮动 ${Math.round(CONFIG.ARTIFACT_ROLL_MIN * 100)}%~${Math.round(CONFIG.ARTIFACT_ROLL_MAX * 100)}%）</div>
              <button class="btn-primary" data-action="closemodal">收入法宝库</button>
            </div>`);
        } else {
          showModal(`
            <div class="result lose">
              <div class="result-title">✘ 炼制失败</div>
              <div class="result-line">器胚崩裂，灵材损耗</div>
              <div class="result-line">返还灵石 ${fmt(r.back)}（本次成功率 ${Math.round(r.rate * 100)}%）</div>
              <button class="btn-primary" data-action="closemodal">再试一次</button>
            </div>`);
        }
        showView(currentTab); break;
      }
      case "equip": {
        const r = equipArtifact(parseInt(btn.dataset.id));
        toast(r.ok ? (r.replaced ? "已装备，替换下「" + r.replaced.name + "」" : "已装备「" + r.artifact.name + "」") : r.msg);
        showView(currentTab); break;
      }
      case "unequip": {
        const r = unequipSlot(btn.dataset.slot);
        toast(r.ok ? "已卸下「" + r.artifact.name + "」" : r.msg);
        showView(currentTab); break;
      }
      case "engrave": {
        const r = engraveArtifact(parseInt(btn.dataset.id));
        toast(r.ok ? `淬灵成功：「${r.line.name}」+${(r.line.value * 100).toFixed(1)}%` : r.msg);
        showView(currentTab); break;
      }
      case "openrefine": showRefineModal(parseInt(btn.dataset.id)); break;
      case "reroll": showRerollModal(parseInt(btn.dataset.id)); break;
      case "rerollconfirm": {
        const lockRaw = btn.dataset.lock;
        const lockIdx = (lockRaw == null || lockRaw === "") ? undefined : parseInt(lockRaw);
        const r = rerollAffixes(parseInt(btn.dataset.id), lockIdx);
        if (!r.ok) { toast(r.msg); break; }
        showView(currentTab);
        renderRerollResult(r);
        break;
      }
      case "refineconfirm": {
        const r = refineArtifact(parseInt(btn.dataset.id), parseInt(btn.dataset.sac));
        if (!r.ok) { toast(r.msg); break; }
        if (r.success) {
          const a = r.artifact, ti = tierInfo(a.tier);
          showModal(`
            <div class="result win">
              <div class="result-title">🔥 炼化成功</div>
              <div class="result-line"><b style="color:${ti.color}">${esc(a.name)}</b> 晋升 <b>${ti.name}</b></div>
              <div class="result-line">重铸属性：${artifactAttrText(a)}（品质 ${Math.round(a.roll * 100)}%）</div>
              <div class="result-line">祭品「${esc(r.sacName)}」已消散</div>
              <button class="btn-primary" data-action="closemodal">继续</button>
            </div>`);
        } else {
          showModal(`
            <div class="result lose">
              <div class="result-title">✘ 炼化失败</div>
              <div class="result-line">祭品「${esc(r.sacName)}」化为灰烬</div>
              <div class="result-line">主法宝保留原品阶（本次成功率 ${Math.round(r.rate * 100)}%）</div>
              <button class="btn-primary" data-action="closemodal">继续</button>
            </div>`);
        }
        showView(currentTab); break;
      }
      case "dismantle": {
        const a = S.artifacts.find(x => x.id === parseInt(btn.dataset.id));
        if (!a) break;
        if (!confirm(`分解「${a.name}」（${tierInfo(a.tier).name}）？将返还少量灵材，不可撤销。`)) break;
        const r = dismantleArtifact(a.id);
        toast(r.ok ? "分解「" + a.name + "」，灵材 +" + r.got : r.msg);
        showView(currentTab); break;
      }
      case "buymaterial": {
        const r = buyMaterial();
        toast(r.ok ? `购入灵材×${r.n}，-灵石${fmt(r.cost)}` : r.msg);
        showView(currentTab); break;
      }
      case "sellmaterial": {
        const r = sellMaterial();
        toast(r.ok ? `售出灵材×${r.n}，+灵石${fmt(r.gain)}` : r.msg);
        showView(currentTab); break;
      }
      case "settings": showSettingsModal(); break;
      case "checkupdate": doCheckUpdate(); break;
      case "exportsave": showExportSaveModal(); break;
      case "importsave": showImportSaveModal(); break;
      case "copysave": {
        const ta = document.getElementById("export-text");
        if (!ta) break;
        ta.focus();
        ta.select();
        ta.setSelectionRange(0, ta.value.length);
        let ok = false;
        try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
        if (ok) { toast("已复制存档码"); break; }
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(ta.value)
            .then(() => toast("已复制存档码"), () => toast("复制失败，请长按文本框手动全选复制"));
        } else {
          toast("复制失败，请长按文本框手动全选复制");
        }
        break;
      }
      case "dosavefile": {
        const r = downloadSaveFile();
        toast(r.ok ? `已下载「${r.name}」` : r.msg);
        break;
      }
      case "doimport": {
        const ta = document.getElementById("import-text");
        if (!ta) break;
        const r = importSaveText(ta.value);
        if (!r.ok) { toast(r.msg); break; }
        showView(currentTab);
        showModal(`
          <div class="result win">
            <div class="result-title">✅ 存档导入成功</div>
            <div class="result-line">${r.summary}</div>
            <button class="btn-primary" data-action="closemodal">继续</button>
          </div>`);
        break;
      }
      case "reset": resetSave(); break;
      case "closemodal": closeModal(); break;
      case "tab": showView(btn.dataset.tab); break;
    }
  });
  document.querySelectorAll("#tabbar button").forEach(b => {
    b.addEventListener("click", () => showView(b.dataset.tab));
  });
}
